"""SQLite persistence for the maintenance recommendation system."""

from maint_rec.db.repository import Repository, get_repository

__all__ = ["Repository", "get_repository"]
