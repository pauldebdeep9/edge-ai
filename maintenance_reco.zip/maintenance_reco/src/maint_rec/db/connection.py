"""Low-level SQLite connection and transaction helpers."""

import sqlite3
from collections.abc import Iterator
from contextlib import contextmanager
from importlib import resources
from pathlib import Path


def connect(db_path: Path) -> sqlite3.Connection:
    """Open a configured SQLite connection."""
    conn = sqlite3.connect(db_path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    return conn


@contextmanager
def transaction(conn: sqlite3.Connection) -> Iterator[None]:
    """Commit successful work and roll back failed work."""
    try:
        yield
    except Exception:
        conn.rollback()
        raise
    else:
        conn.commit()


def init_schema(conn: sqlite3.Connection) -> None:
    """Create all database tables and indexes from the packaged schema."""
    schema = resources.files("maint_rec.db").joinpath("schema.sql").read_text(encoding="utf-8")
    conn.executescript(schema)
