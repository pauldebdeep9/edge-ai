"""Typed repository containing all SQL used by the application."""

import sqlite3
from datetime import UTC, date, datetime, time, timedelta
from pathlib import Path
from types import TracebackType
from typing import Literal, Self, TypeVar, overload

from pydantic import BaseModel

from maint_rec.config import Settings, ensure_dirs, get_settings
from maint_rec.config_loader import MachineDef
from maint_rec.db.connection import connect, init_schema, transaction
from maint_rec.recommend.schemas import (
    FailureEvent,
    OperatorComment,
    Recommendation,
    SensorDaily,
)

ModelT = TypeVar("ModelT", bound=BaseModel)
Temporal = date | datetime

_COUNT_QUERIES = {
    "machines": "SELECT COUNT(*) FROM machines",
    "sensor_daily": "SELECT COUNT(*) FROM sensor_daily",
    "failure_events": "SELECT COUNT(*) FROM failure_events",
    "operator_comments": "SELECT COUNT(*) FROM operator_comments",
    "recommendations_log": "SELECT COUNT(*) FROM recommendations_log",
}


@overload
def _iso(value: Temporal) -> str: ...


@overload
def _iso(value: str, *, as_type: type[date]) -> date: ...


@overload
def _iso(value: str, *, as_type: type[datetime]) -> datetime: ...


def _iso(
    value: Temporal | str, *, as_type: type[date] | type[datetime] | None = None
) -> Temporal | str:
    """Convert temporal values to and from their ISO-8601 database form."""
    if isinstance(value, str):
        if as_type is datetime:
            return datetime.fromisoformat(value)
        if as_type is date:
            return date.fromisoformat(value)
        raise TypeError("as_type is required when parsing an ISO value")
    return value.isoformat()


def _model_from_row(
    model_type: type[ModelT],
    row: sqlite3.Row,
    temporal_fields: dict[str, type[date] | type[datetime]],
) -> ModelT:
    values = dict(row)
    for field, field_type in temporal_fields.items():
        values[field] = _iso(values[field], as_type=field_type)
    return model_type.model_validate(values)


class Repository:
    """Own a SQLite connection and expose typed persistence operations."""

    def __init__(self, db_path: Path) -> None:
        self.db_path = db_path
        self._conn = connect(db_path)

    def __enter__(self) -> Self:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        self.close()

    def close(self) -> None:
        self._conn.close()

    def init(self) -> None:
        init_schema(self._conn)

    def reset(self) -> None:
        self._conn.executescript(
            """
            DROP TABLE IF EXISTS recommendations_log;
            DROP TABLE IF EXISTS operator_comments;
            DROP TABLE IF EXISTS failure_events;
            DROP TABLE IF EXISTS sensor_daily;
            DROP TABLE IF EXISTS machines;
            """
        )
        init_schema(self._conn)

    def counts(self) -> dict[str, int]:
        return {
            table: int(self._conn.execute(query).fetchone()[0])
            for table, query in _COUNT_QUERIES.items()
        }

    def upsert_machines(self, machines: list[MachineDef]) -> int:
        values = [
            (
                machine.machine_id,
                machine.name,
                machine.type,
                machine.location,
                _iso(machine.install_date),
            )
            for machine in machines
        ]
        with transaction(self._conn):
            self._conn.executemany(
                """
                INSERT INTO machines (machine_id, name, type, location, install_date)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(machine_id) DO UPDATE SET
                    name = excluded.name,
                    type = excluded.type,
                    location = excluded.location,
                    install_date = excluded.install_date
                """,
                values,
            )
        return len(values)

    def get_machines(self) -> list[MachineDef]:
        rows = self._conn.execute(
            "SELECT machine_id, name, type, location, install_date FROM machines "
            "ORDER BY machine_id"
        ).fetchall()
        return [_model_from_row(MachineDef, row, {"install_date": date}) for row in rows]

    def get_machine(self, machine_id: str) -> MachineDef:
        row = self._conn.execute(
            "SELECT machine_id, name, type, location, install_date FROM machines "
            "WHERE machine_id = ?",
            (machine_id,),
        ).fetchone()
        if row is None:
            raise KeyError(f"unknown machine id {machine_id!r}")
        return _model_from_row(MachineDef, row, {"install_date": date})

    def insert_sensor_rows(self, rows: list[SensorDaily]) -> int:
        values = [
            (
                row.machine_id,
                _iso(row.date),
                row.temp_avg,
                row.temp_max,
                row.vibration_rms,
                row.current_avg,
                row.runtime_hours,
            )
            for row in rows
        ]
        with transaction(self._conn):
            self._conn.executemany(
                """
                INSERT OR REPLACE INTO sensor_daily (
                    machine_id, date, temp_avg, temp_max, vibration_rms,
                    current_avg, runtime_hours
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                values,
            )
        return len(values)

    def get_latest_date(self, machine_id: str | None = None) -> date | None:
        if machine_id is None:
            row = self._conn.execute("SELECT MAX(date) AS latest FROM sensor_daily").fetchone()
        else:
            row = self._conn.execute(
                "SELECT MAX(date) AS latest FROM sensor_daily WHERE machine_id = ?",
                (machine_id,),
            ).fetchone()
        return None if row["latest"] is None else _iso(row["latest"], as_type=date)

    def get_sensor_range(self, machine_id: str, start: date, end: date) -> list[SensorDaily]:
        rows = self._conn.execute(
            """
            SELECT machine_id, date, temp_avg, temp_max, vibration_rms,
                   current_avg, runtime_hours
            FROM sensor_daily
            WHERE machine_id = ? AND date BETWEEN ? AND ?
            ORDER BY date ASC
            """,
            (machine_id, _iso(start), _iso(end)),
        ).fetchall()
        return [_model_from_row(SensorDaily, row, {"date": date}) for row in rows]

    def get_sensor_window(
        self, machine_id: str, days: int, end: date | None = None
    ) -> list[SensorDaily]:
        if days < 1:
            raise ValueError("days must be at least 1")
        window_end = end or self.get_latest_date(machine_id)
        if window_end is None:
            return []
        window_start = window_end - timedelta(days=days - 1)
        return self.get_sensor_range(machine_id, window_start, window_end)

    def insert_failure_events(self, events: list[FailureEvent]) -> int:
        values = [
            (
                event.event_id,
                event.machine_id,
                event.machine_type,
                _iso(event.date),
                event.failure_mode,
                event.symptoms,
                event.root_cause,
                event.action_taken,
                event.parts_replaced,
                event.downtime_hours,
            )
            for event in events
        ]
        with transaction(self._conn):
            self._conn.executemany(
                """
                INSERT INTO failure_events (
                    event_id, machine_id, machine_type, date, failure_mode,
                    symptoms, root_cause, action_taken, parts_replaced, downtime_hours
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                values,
            )
        return len(values)

    def get_failure(self, event_id: str) -> FailureEvent:
        row = self._conn.execute(
            """
            SELECT event_id, machine_id, machine_type, date, failure_mode,
                   symptoms, root_cause, action_taken, parts_replaced, downtime_hours
            FROM failure_events WHERE event_id = ?
            """,
            (event_id,),
        ).fetchone()
        if row is None:
            raise KeyError(f"unknown failure event id {event_id!r}")
        return _model_from_row(FailureEvent, row, {"date": date})

    def list_failures(
        self, machine_id: str | None = None, machine_type: str | None = None
    ) -> list[FailureEvent]:
        rows = self._conn.execute(
            """
            SELECT event_id, machine_id, machine_type, date, failure_mode,
                   symptoms, root_cause, action_taken, parts_replaced, downtime_hours
            FROM failure_events
            WHERE (? IS NULL OR machine_id = ?)
              AND (? IS NULL OR machine_type = ?)
            ORDER BY date ASC, event_id ASC
            """,
            (machine_id, machine_id, machine_type, machine_type),
        ).fetchall()
        return [_model_from_row(FailureEvent, row, {"date": date}) for row in rows]

    def insert_comments(self, comments: list[OperatorComment]) -> int:
        values = [
            (
                comment.comment_id,
                comment.machine_id,
                _iso(comment.timestamp),
                comment.shift,
                comment.operator,
                comment.comment_text,
            )
            for comment in comments
        ]
        with transaction(self._conn):
            self._conn.executemany(
                """
                INSERT INTO operator_comments (
                    comment_id, machine_id, timestamp, shift, operator, comment_text
                ) VALUES (?, ?, ?, ?, ?, ?)
                """,
                values,
            )
        return len(values)

    def next_comment_id(self) -> str:
        row = self._conn.execute(
            """
            SELECT COALESCE(MAX(CAST(SUBSTR(comment_id, 5) AS INTEGER)), 0) + 1 AS next_id
            FROM operator_comments
            WHERE comment_id GLOB 'CMT-[0-9]*'
            """
        ).fetchone()
        return f"CMT-{int(row['next_id']):03d}"

    def add_comment(
        self,
        machine_id: str,
        text: str,
        shift: Literal["A", "B", "C"],
        operator: str,
        timestamp: datetime | None = None,
    ) -> OperatorComment:
        effective_timestamp = timestamp
        if effective_timestamp is None:
            latest_date = self.get_latest_date(machine_id)
            if latest_date is None:
                raise ValueError(
                    f"cannot choose a synthetic timestamp without sensor data for {machine_id!r}"
                )
            effective_timestamp = datetime.combine(latest_date, time(hour=12, tzinfo=UTC))
        comment = OperatorComment(
            comment_id=self.next_comment_id(),
            machine_id=machine_id,
            timestamp=effective_timestamp,
            shift=shift,
            operator=operator,
            comment_text=text,
        )
        self.insert_comments([comment])
        return comment

    def get_comment(self, comment_id: str) -> OperatorComment:
        row = self._conn.execute(
            """
            SELECT comment_id, machine_id, timestamp, shift, operator, comment_text
            FROM operator_comments WHERE comment_id = ?
            """,
            (comment_id,),
        ).fetchone()
        if row is None:
            raise KeyError(f"unknown comment id {comment_id!r}")
        return _model_from_row(OperatorComment, row, {"timestamp": datetime})

    def get_recent_comments(
        self, machine_id: str, days: int, end: datetime | None = None
    ) -> list[OperatorComment]:
        if days < 1:
            raise ValueError("days must be at least 1")
        window_end = end
        if window_end is None:
            row = self._conn.execute(
                "SELECT MAX(timestamp) AS latest FROM operator_comments WHERE machine_id = ?",
                (machine_id,),
            ).fetchone()
            if row["latest"] is None:
                return []
            window_end = _iso(row["latest"], as_type=datetime)
        window_start = window_end - timedelta(days=days - 1)
        rows = self._conn.execute(
            """
            SELECT comment_id, machine_id, timestamp, shift, operator, comment_text
            FROM operator_comments
            WHERE machine_id = ? AND timestamp BETWEEN ? AND ?
            ORDER BY timestamp DESC, comment_id DESC
            """,
            (machine_id, _iso(window_start), _iso(window_end)),
        ).fetchall()
        return [_model_from_row(OperatorComment, row, {"timestamp": datetime}) for row in rows]

    def list_comments(self, machine_id: str | None = None) -> list[OperatorComment]:
        rows = self._conn.execute(
            """
            SELECT comment_id, machine_id, timestamp, shift, operator, comment_text
            FROM operator_comments
            WHERE (? IS NULL OR machine_id = ?)
            ORDER BY timestamp ASC, comment_id ASC
            """,
            (machine_id, machine_id),
        ).fetchall()
        return [_model_from_row(OperatorComment, row, {"timestamp": datetime}) for row in rows]

    def log_recommendation(self, rec: Recommendation) -> int:
        with transaction(self._conn):
            cursor = self._conn.execute(
                """
                INSERT INTO recommendations_log (
                    machine_id, created_at, risk_level, likely_failure_mode,
                    source, model, latency_ms, payload_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    rec.machine_id,
                    _iso(rec.generated_at),
                    rec.risk_level.value,
                    rec.likely_failure_mode,
                    rec.source.value,
                    rec.model,
                    rec.latency_ms,
                    rec.model_dump_json(),
                ),
            )
        return int(cursor.lastrowid)

    def list_recommendations(
        self, machine_id: str | None = None, limit: int = 20
    ) -> list[Recommendation]:
        if limit < 1:
            raise ValueError("limit must be at least 1")
        rows = self._conn.execute(
            """
            SELECT payload_json
            FROM recommendations_log
            WHERE (? IS NULL OR machine_id = ?)
            ORDER BY created_at DESC, id DESC
            LIMIT ?
            """,
            (machine_id, machine_id, limit),
        ).fetchall()
        return [Recommendation.model_validate_json(row["payload_json"]) for row in rows]


def get_repository(settings: Settings | None = None) -> Repository:
    """Create a repository for the configured database path."""
    active_settings = settings or get_settings()
    ensure_dirs(active_settings)
    return Repository(active_settings.db_path)
