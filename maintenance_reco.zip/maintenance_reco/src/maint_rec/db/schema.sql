PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS machines (
    machine_id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    type TEXT NOT NULL,
    location TEXT NOT NULL,
    install_date TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sensor_daily (
    machine_id TEXT NOT NULL,
    date TEXT NOT NULL,
    temp_avg REAL NOT NULL,
    temp_max REAL NOT NULL,
    vibration_rms REAL NOT NULL,
    current_avg REAL NOT NULL,
    runtime_hours REAL NOT NULL,
    PRIMARY KEY (machine_id, date),
    FOREIGN KEY (machine_id) REFERENCES machines(machine_id)
);

CREATE TABLE IF NOT EXISTS failure_events (
    event_id TEXT PRIMARY KEY,
    machine_id TEXT NOT NULL,
    machine_type TEXT NOT NULL,
    date TEXT NOT NULL,
    failure_mode TEXT NOT NULL,
    symptoms TEXT NOT NULL,
    root_cause TEXT NOT NULL,
    action_taken TEXT NOT NULL,
    parts_replaced TEXT,
    downtime_hours REAL NOT NULL,
    FOREIGN KEY (machine_id) REFERENCES machines(machine_id)
);

CREATE TABLE IF NOT EXISTS operator_comments (
    comment_id TEXT PRIMARY KEY,
    machine_id TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    shift TEXT NOT NULL,
    operator TEXT NOT NULL,
    comment_text TEXT NOT NULL,
    FOREIGN KEY (machine_id) REFERENCES machines(machine_id)
);

CREATE TABLE IF NOT EXISTS recommendations_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    machine_id TEXT NOT NULL,
    created_at TEXT NOT NULL,
    risk_level TEXT NOT NULL,
    likely_failure_mode TEXT NOT NULL,
    source TEXT NOT NULL,
    model TEXT,
    latency_ms INTEGER,
    payload_json TEXT NOT NULL,
    FOREIGN KEY (machine_id) REFERENCES machines(machine_id)
);

CREATE INDEX IF NOT EXISTS idx_sensor_daily_machine_date
    ON sensor_daily(machine_id, date);
CREATE INDEX IF NOT EXISTS idx_failure_events_machine
    ON failure_events(machine_id);
CREATE INDEX IF NOT EXISTS idx_failure_events_mode
    ON failure_events(failure_mode);
CREATE INDEX IF NOT EXISTS idx_operator_comments_machine_timestamp
    ON operator_comments(machine_id, timestamp);
CREATE INDEX IF NOT EXISTS idx_recommendations_machine_created
    ON recommendations_log(machine_id, created_at);
