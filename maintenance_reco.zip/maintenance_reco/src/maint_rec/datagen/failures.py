"""Plan historical failures and convert them to domain records."""

import logging
import math
from collections import Counter
from dataclasses import dataclass
from datetime import date, timedelta

import numpy as np

from maint_rec.config_loader import AppConfig, FailureModeDef, MachineDef
from maint_rec.datagen.params import GenParams
from maint_rec.recommend.schemas import FailureEvent

LOGGER = logging.getLogger(__name__)

_PARTS_REPLACED: dict[str, str | None] = {
    "bearing_wear": "Drive-end bearing set",
    "spindle_misalignment": "Spindle alignment shims",
    "hydraulic_leak": "Hydraulic seal and hose kit",
    "overheating": None,
    "belt_slippage": "Drive belt",
    "lubrication_failure": "Lubrication filter",
}

_TYPE_KEYWORDS: dict[str, set[str]] = {
    "conveyor": {"conveyor_drive"},
    "spindle": {"cnc_mill"},
    "tool": {"cnc_mill"},
    "ram": {"hydraulic_press"},
    "press": {"hydraulic_press"},
}


@dataclass(frozen=True, slots=True)
class PlannedFailure:
    machine_id: str
    machine_type: str
    failure_mode: str
    failure_date: date
    lead_days: int
    drift_start: date


def _phrase_matches_machine(phrase: str, machine_type: str) -> bool:
    lowered = phrase.lower()
    return all(
        keyword not in lowered or machine_type in allowed
        for keyword, allowed in _TYPE_KEYWORDS.items()
    )


def _round_half_hour(value: float) -> float:
    return round(value * 2.0) / 2.0


def _effect_signals(mode: FailureModeDef) -> set[str]:
    return {effect.signal for effect in mode.signal_effects}


def _ranges_overlap(start_a: date, end_a: date, start_b: date, end_b: date) -> bool:
    return start_a <= end_b and start_b <= end_a


def plan_failures(
    cfg: AppConfig, params: GenParams, rng: np.random.Generator
) -> list[PlannedFailure]:
    """Place non-overlapping historical degradation windows."""
    timeline = params.timeline()
    earliest_drift = timeline[params.min_history_days]
    quiet_tail_start = timeline[-params.quiet_tail_days]
    latest_failure = quiet_tail_start - timedelta(days=1)
    live_clean_start = params.end_date - timedelta(
        days=cfg.thresholds.window_days + cfg.thresholds.baseline_days - 1
    )
    live_clean_end = params.end_date
    mode_by_id = {mode.id: mode for mode in cfg.failure_modes}
    machines_by_id = {machine.machine_id: machine for machine in cfg.machines}
    machines_by_type: dict[str, list[MachineDef]] = {}
    for machine in cfg.machines:
        machines_by_type.setdefault(machine.type, []).append(machine)

    planned: list[PlannedFailure] = []
    counts: Counter[str] = Counter()
    live_signals = (
        _effect_signals(mode_by_id[params.live_failure_mode]) if params.live_enabled else set()
    )

    def has_clean_reference(
        mode: FailureModeDef,
        machine: MachineDef,
        drift_start: date,
        failure_date: date,
    ) -> bool:
        signals = _effect_signals(mode)
        candidate = PlannedFailure(
            machine_id=machine.machine_id,
            machine_type=machine.type,
            failure_mode=mode.id,
            failure_date=failure_date,
            lead_days=(failure_date - drift_start).days,
            drift_start=drift_start,
        )
        for existing in planned:
            if existing.machine_id != machine.machine_id:
                continue
            existing_signals = _effect_signals(mode_by_id[existing.failure_mode])
            if not signals & existing_signals:
                continue
            earlier, later = sorted((candidate, existing), key=lambda item: item.drift_start)
            reference_start = later.drift_start - timedelta(days=params.reference_days)
            reference_end = later.drift_start - timedelta(days=1)
            if _ranges_overlap(
                earlier.drift_start,
                earlier.failure_date,
                reference_start,
                reference_end,
            ):
                return False

        return not (
            params.live_enabled
            and machine.machine_id == params.live_machine_id
            and bool(signals & live_signals)
            and _ranges_overlap(
                drift_start,
                failure_date,
                live_clean_start,
                live_clean_end,
            )
        )

    def place(mode: FailureModeDef, machine: MachineDef) -> bool:
        machine_windows = [item for item in planned if item.machine_id == machine.machine_id]
        for _ in range(1_000):
            configured_min = int(mode.lead_time_days.min)
            configured_max = int(mode.lead_time_days.max)
            # lead_bias=0.5 samples the upper half of the configured duration range.
            lead_min = math.ceil(
                configured_min + params.lead_bias * (configured_max - configured_min)
            )
            lead_days = int(rng.integers(lead_min, configured_max + 1))
            earliest_failure = earliest_drift + timedelta(days=lead_days)
            if earliest_failure > latest_failure:
                return False
            span = (latest_failure - earliest_failure).days
            failure_date = earliest_failure + timedelta(days=int(rng.integers(0, span + 1)))
            drift_start = failure_date - timedelta(days=lead_days)
            occupied_end = failure_date + timedelta(days=params.cooldown_days)
            overlaps = any(
                drift_start <= existing.failure_date + timedelta(days=params.cooldown_days)
                and occupied_end >= existing.drift_start
                for existing in machine_windows
            )
            if overlaps:
                continue
            if not has_clean_reference(mode, machine, drift_start, failure_date):
                continue
            planned.append(
                PlannedFailure(
                    machine_id=machine.machine_id,
                    machine_type=machine.type,
                    failure_mode=mode.id,
                    failure_date=failure_date,
                    lead_days=lead_days,
                    drift_start=drift_start,
                )
            )
            counts[machine.machine_id] += 1
            return True
        return False

    bearing = mode_by_id["bearing_wear"]
    for machine_id in ("CNC-01", "CNC-02"):
        machine = machines_by_id[machine_id]
        if machine.type not in bearing.applicable_types or not place(bearing, machine):
            raise ValueError(f"could not place required bearing_wear history on {machine_id}")

    mode_counts: Counter[str] = Counter(item.failure_mode for item in planned)
    for mode in cfg.failure_modes:
        while mode_counts[mode.id] < params.min_events_per_mode:
            applicable = [
                machine
                for type_id in mode.applicable_types
                for machine in machines_by_type.get(type_id, [])
            ]
            applicable.sort(key=lambda machine: (counts[machine.machine_id], machine.machine_id))
            placed = False
            for machine in applicable:
                if place(mode, machine):
                    mode_counts[mode.id] += 1
                    placed = True
                    break
            if not placed:
                raise ValueError(f"could not guarantee coverage for failure mode {mode.id!r}")

    cursor = 0
    attempts = 0
    max_attempts = max(2_000, params.n_failures * 500)
    while len(planned) < params.n_failures and attempts < max_attempts:
        machine = cfg.machines[cursor % len(cfg.machines)]
        cursor += 1
        attempts += 1
        minimum_count = min(counts[item.machine_id] for item in cfg.machines)
        if counts[machine.machine_id] > minimum_count:
            continue
        modes = cfg.modes_for_type(machine.type)
        mode = modes[int(rng.integers(0, len(modes)))]
        place(mode, machine)

    if len(planned) < params.n_failures:
        LOGGER.warning(
            "Placed %s of %s requested failures because the timeline is constrained",
            len(planned),
            params.n_failures,
        )
    return sorted(planned, key=lambda item: (item.failure_date, item.machine_id))


def to_failure_events(
    planned: list[PlannedFailure], cfg: AppConfig, rng: np.random.Generator
) -> list[FailureEvent]:
    """Create deterministic database records for planned failures."""
    events: list[FailureEvent] = []
    ordered = sorted(planned, key=lambda item: (item.failure_date, item.machine_id))
    for index, item in enumerate(ordered, start=1):
        mode = cfg.get_failure_mode(item.failure_mode)
        phrases = [
            phrase
            for phrase in mode.symptom_phrases
            if _phrase_matches_machine(phrase, item.machine_type)
        ]
        if len(phrases) < 2:
            raise ValueError(f"failure mode {mode.id!r} lacks two applicable symptom phrases")
        selected = rng.choice(len(phrases), size=2, replace=False)
        downtime = _round_half_hour(
            float(rng.uniform(mode.downtime_hours.min, mode.downtime_hours.max))
        )
        actions = "; ".join(template.action for template in mode.standard_actions) + "."
        events.append(
            FailureEvent(
                event_id=f"EVT-{index:03d}",
                machine_id=item.machine_id,
                machine_type=item.machine_type,
                date=item.failure_date,
                failure_mode=item.failure_mode,
                symptoms="; ".join(phrases[int(position)] for position in selected),
                root_cause=mode.root_cause,
                action_taken=actions,
                parts_replaced=_PARTS_REPLACED[item.failure_mode],
                downtime_hours=downtime,
            )
        )
    return events
