"""Generate daily sensor history with accelerating pre-failure drift."""

from collections import defaultdict
from datetime import timedelta

import numpy as np

from maint_rec.config_loader import AppConfig
from maint_rec.datagen.failures import PlannedFailure
from maint_rec.datagen.params import GenParams
from maint_rec.recommend.schemas import FailureEvent, SensorDaily

_ROUND_DIGITS = {
    "temp_avg": 1,
    "temp_max": 1,
    "vibration_rms": 3,
    "current_avg": 2,
    "runtime_hours": 1,
}


def _round_sensor_values(values: dict[str, float]) -> dict[str, float]:
    return {signal: round(value, _ROUND_DIGITS[signal]) for signal, value in values.items()}


def generate_sensors(
    cfg: AppConfig,
    params: GenParams,
    planned: list[PlannedFailure],
    events: list[FailureEvent],
    rng: np.random.Generator,
) -> list[SensorDaily]:
    """Generate healthy readings, historical drift, downtime, and repairs."""
    planned_by_machine: dict[str, list[PlannedFailure]] = defaultdict(list)
    for item in planned:
        planned_by_machine[item.machine_id].append(item)
    downtime = {(event.machine_id, event.date): event.downtime_hours for event in events}

    rows: list[SensorDaily] = []
    for machine in cfg.machines:
        baselines = cfg.machine_types[machine.type].baseline
        offsets = {
            signal: float(rng.uniform(-params.machine_offset_pct, params.machine_offset_pct))
            / 100.0
            for signal in cfg.signals
        }
        values_by_day = {
            day: {
                signal: float(
                    np.clip(
                        baseline.mean * (1.0 + offsets[signal])
                        + rng.normal(0.0, params.noise_scale * baseline.std),
                        baseline.min,
                        baseline.max,
                    )
                )
                for signal, baseline in baselines.items()
            }
            for day in params.timeline()
        }
        for values in values_by_day.values():
            values["temp_max"] = max(values["temp_max"], values["temp_avg"] + 2.0)

        machine_failures = sorted(
            planned_by_machine[machine.machine_id], key=lambda item: item.failure_date
        )
        for item in machine_failures:
            mode = cfg.get_failure_mode(item.failure_mode)
            day = item.drift_start
            while day <= item.failure_date:
                values = values_by_day[day]
                elapsed = (day - item.drift_start).days
                progress = (elapsed / item.lead_days) ** params.drift_exponent
                for effect in mode.signal_effects:
                    direction = 1.0 if effect.direction == "up" else -1.0
                    values[effect.signal] *= (
                        1.0 + direction * effect.magnitude_pct / 100.0 * progress
                    )
                values["temp_max"] = max(values["temp_max"], values["temp_avg"] + 2.0)
                day += timedelta(days=1)

        for day in params.timeline():
            values = values_by_day[day]
            values["runtime_hours"] = max(
                0.0, values["runtime_hours"] - downtime.get((machine.machine_id, day), 0.0)
            )
            values["temp_max"] = max(values["temp_max"], values["temp_avg"] + 2.0)
            rounded = _round_sensor_values(values)
            rows.append(SensorDaily(machine_id=machine.machine_id, date=day, **rounded))
    return rows
