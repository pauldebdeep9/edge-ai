"""Generate realistic shift comments aligned with synthetic machine history."""

from collections import Counter
from dataclasses import dataclass
from datetime import UTC, date, datetime, time, timedelta
from typing import Literal

import numpy as np

from maint_rec.config_loader import AppConfig
from maint_rec.datagen.failures import PlannedFailure, _phrase_matches_machine
from maint_rec.datagen.params import GenParams
from maint_rec.datagen.scenario import LiveScenario
from maint_rec.recommend.schemas import FailureEvent, OperatorComment

CommentCategory = Literal["routine", "warning", "repair", "red_herring"]
Shift = Literal["A", "B", "C"]
COMMENT_CATEGORIES: tuple[CommentCategory, ...] = (
    "routine",
    "warning",
    "repair",
    "red_herring",
)

OPERATORS_BY_SHIFT: dict[Shift, tuple[str, str]] = {
    "A": ("Maya Chen", "Luis Ortega"),
    "B": ("Nina Patel", "Owen Brooks"),
    "C": ("Priya Nair", "Ethan Cole"),
}

GENERIC_ROUTINE = (
    "Normal operation this shift",
    "No issues this shift",
    "Completed the standard walk-around",
    "Area clean and machine running normally",
    "Checked guards and indicators, all normal",
)

ROUTINE_BY_TYPE: dict[str, tuple[str, ...]] = {
    "cnc_mill": (
        "Changed end mill on station 2",
        "Cleaned chips from the table",
        "Topped up coolant after the morning run",
        "Checked tool offsets before the next batch",
        "Wiped down the spindle enclosure",
        "Cleared chips from the auger",
        "Loaded the next production program",
        "Checked coolant concentration",
        "Emptied the chip bin",
        "Inspected tool holders during changeover",
    ),
    "hydraulic_press": (
        "Cleaned the die area after changeover",
        "Checked the light curtain before startup",
        "Wiped down the press bed",
        "Verified the pressure gauge at startup",
        "Changed tooling for the next job",
        "Cleared scrap from around the press",
        "Checked the foot controls",
        "Lubricated the die guide posts",
        "Ran the standard first-piece check",
        "Inspected hoses during the walk-around",
    ),
    "air_compressor": (
        "Drained condensate from the receiver",
        "Checked receiver pressure",
        "Cleaned the intake screen",
        "Verified the automatic drain cycle",
        "Logged the compressor hour reading",
        "Checked the dryer indicator",
        "Cleared dust around the cooling grille",
        "Inspected the air lines for loose fittings",
        "Checked the oil sight glass",
        "Rotated duty to the standby unit",
    ),
    "conveyor_drive": (
        "Cleared debris beside the conveyor",
        "Checked the emergency pull cords",
        "Cleaned the photo-eye lenses",
        "Verified tracking during startup",
        "Removed loose packaging from the guard",
        "Checked the transfer point for buildup",
        "Adjusted the side guide for the next run",
        "Inspected the drive guard",
        "Tested the stop station",
        "Cleaned under the return section",
    ),
}

WARNING_WRAPPERS = (
    "{phrase}",
    "{phrase}, keeping an eye on it",
    "noticed {phrase_lower} during the shift",
    "{phrase} again, reported to maintenance",
    "possible issue: {phrase_lower}",
    "heard {phrase_lower} under load",
    "{phrase}, seems more noticeable today",
    "logged {phrase_lower} for follow-up",
)

RED_HERRINGS = (
    "Slight noise at startup, went away after warm-up",
    "Brief vibration after restart, settled within a minute",
    "Warm casing after cleanup, normal by the next round",
    "Short squeak came from a loose cart beside the machine",
    "Faint smell near the line, traced to nearby cleaning",
    "One rough cycle after the material change, then normal",
    "Momentary current flicker when the line restarted",
    "Guard rattled briefly after washdown, tightened it",
)

_SHIFT_MINUTES: dict[Shift, tuple[int, int]] = {
    "A": (6 * 60, 14 * 60),
    "B": (14 * 60, 22 * 60),
    "C": (22 * 60, 30 * 60),
}


@dataclass(frozen=True, slots=True)
class CommentLinks:
    warning_comment_ids: dict[str, list[str]]
    live_warning_comment_ids: list[str]
    category_by_comment_id: dict[str, CommentCategory]

    def counts_by_category(self) -> dict[str, int]:
        counts = Counter(self.category_by_comment_id.values())
        return {category: counts[category] for category in COMMENT_CATEGORIES}


@dataclass(frozen=True, slots=True)
class _CommentDraft:
    machine_id: str
    timestamp: datetime
    shift: Shift
    operator: str
    text: str
    category: CommentCategory
    event_id: str | None = None
    live_warning: bool = False


def _random_timestamp(day: date, rng: np.random.Generator) -> tuple[datetime, Shift, str]:
    shifts: tuple[Shift, ...] = ("A", "B", "C")
    shift = shifts[int(rng.integers(0, len(shifts)))]
    start, end = _SHIFT_MINUTES[shift]
    minute = int(rng.integers(start, end))
    timestamp = datetime.combine(day, time.min, tzinfo=UTC) + timedelta(minutes=minute)
    operators = OPERATORS_BY_SHIFT[shift]
    operator = operators[int(rng.integers(0, len(operators)))]
    return timestamp, shift, operator


def _draft_on_allowed_days(
    machine_id: str,
    text: str,
    category: CommentCategory,
    allowed_days: list[date],
    rng: np.random.Generator,
    *,
    valid_calendar_days: list[date] | None = None,
    event_id: str | None = None,
    live_warning: bool = False,
) -> _CommentDraft:
    allowed = set(valid_calendar_days or allowed_days)
    for _ in range(100):
        day = allowed_days[int(rng.integers(0, len(allowed_days)))]
        timestamp, shift, operator = _random_timestamp(day, rng)
        if timestamp.date() in allowed:
            return _CommentDraft(
                machine_id=machine_id,
                timestamp=timestamp,
                shift=shift,
                operator=operator,
                text=text,
                category=category,
                event_id=event_id,
                live_warning=live_warning,
            )
    raise RuntimeError("could not place comment timestamp on an allowed calendar date")


def _routine_comments(
    cfg: AppConfig, params: GenParams, rng: np.random.Generator
) -> list[_CommentDraft]:
    drafts: list[_CommentDraft] = []
    timeline = params.timeline()
    final_week = timeline[-7:]
    live_days = [day for day in timeline if date(2026, 9, 14) <= day <= params.end_date]
    for machine in cfg.machines:
        templates = ROUTINE_BY_TYPE[machine.type] + GENERIC_ROUTINE
        final_day = final_week[int(rng.integers(0, len(final_week)))]
        required: list[tuple[date, list[date]]] = [(final_day, final_week)]
        random_pool = timeline
        if machine.machine_id == params.live_machine_id and params.live_enabled:
            extra = live_days[int(rng.integers(0, len(live_days)))]
            while extra == final_day:
                extra = live_days[int(rng.integers(0, len(live_days)))]
            required.append((extra, live_days))
            random_pool = [day for day in timeline if day < live_days[0] - timedelta(days=1)]
        random_days = [
            random_pool[int(rng.integers(0, len(random_pool)))] for _ in range(48 - len(required))
        ]
        for day, valid_days in required + [(day, random_pool) for day in random_days]:
            text = templates[int(rng.integers(0, len(templates)))]
            drafts.append(
                _draft_on_allowed_days(
                    machine.machine_id,
                    text,
                    "routine",
                    [day],
                    rng,
                    valid_calendar_days=valid_days,
                )
            )
    return drafts


def _historical_warning_comments(
    cfg: AppConfig,
    planned: list[PlannedFailure],
    events: list[FailureEvent],
    rng: np.random.Generator,
) -> list[_CommentDraft]:
    drafts: list[_CommentDraft] = []
    for item, event in zip(planned, events, strict=True):
        mode = cfg.get_failure_mode(item.failure_mode)
        phrases = [
            phrase
            for phrase in mode.symptom_phrases
            if _phrase_matches_machine(phrase, item.machine_type)
        ]
        second_half = item.drift_start + timedelta(days=(item.lead_days + 1) // 2)
        days = [
            second_half + timedelta(days=offset)
            for offset in range((item.failure_date - second_half).days + 1)
        ]
        count = min(int(rng.integers(2, 6)), len(days))
        weights = np.arange(1, len(days) + 1, dtype=float) ** 2
        positions = sorted(
            int(position)
            for position in rng.choice(
                len(days), size=count, replace=False, p=weights / weights.sum()
            )
        )
        for position in positions:
            phrase = phrases[int(rng.integers(0, len(phrases)))]
            wrapper = WARNING_WRAPPERS[int(rng.integers(0, len(WARNING_WRAPPERS)))]
            text = wrapper.format(phrase=phrase, phrase_lower=phrase.lower())
            drafts.append(
                _draft_on_allowed_days(
                    item.machine_id,
                    text,
                    "warning",
                    [days[position]],
                    rng,
                    valid_calendar_days=days,
                    event_id=event.event_id,
                )
            )
    return drafts


def _repair_comments(
    cfg: AppConfig,
    events: list[FailureEvent],
    rng: np.random.Generator,
) -> list[_CommentDraft]:
    drafts: list[_CommentDraft] = []
    for event in events:
        mode = cfg.get_failure_mode(event.failure_mode)
        templates = [
            f"Back in service after {mode.name.lower()} repair",
            f"Maintenance completed the {mode.name.lower()} repair",
        ]
        if event.parts_replaced is not None:
            templates.append(f"Maintenance replaced {event.parts_replaced.lower()}")
        text = templates[int(rng.integers(0, len(templates)))]
        days = [event.date, event.date + timedelta(days=1)]
        drafts.append(_draft_on_allowed_days(event.machine_id, text, "repair", days, rng))
    return drafts


def _red_herring_comments(
    cfg: AppConfig,
    params: GenParams,
    planned: list[PlannedFailure],
    live_scenario: LiveScenario | None,
    rng: np.random.Generator,
) -> list[_CommentDraft]:
    all_phrases = [phrase.lower() for mode in cfg.failure_modes for phrase in mode.symptom_phrases]
    templates = [
        text for text in RED_HERRINGS if not any(phrase in text.lower() for phrase in all_phrases)
    ]
    drafts: list[_CommentDraft] = []
    final_14_start = params.end_date - timedelta(days=13)
    for machine in cfg.machines:
        excluded = {
            item.drift_start + timedelta(days=offset)
            for item in planned
            if item.machine_id == machine.machine_id
            for offset in range((item.failure_date - item.drift_start).days + 1)
        }
        if live_scenario is not None and machine.machine_id == live_scenario.machine_id:
            excluded.update(
                live_scenario.drift_start + timedelta(days=offset)
                for offset in range((live_scenario.end_date - live_scenario.drift_start).days + 1)
            )
        allowed_days = [
            day
            for day in params.timeline()
            if day not in excluded
            and (machine.machine_id == params.live_machine_id or day < final_14_start)
        ]
        selected = rng.choice(len(allowed_days), size=4, replace=False)
        for position in selected:
            text = templates[int(rng.integers(0, len(templates)))]
            drafts.append(
                _draft_on_allowed_days(
                    machine.machine_id,
                    text,
                    "red_herring",
                    [allowed_days[int(position)]],
                    rng,
                    valid_calendar_days=allowed_days,
                )
            )
    return drafts


def _live_warning_comments(
    cfg: AppConfig,
    params: GenParams,
    live_scenario: LiveScenario | None,
    rng: np.random.Generator,
) -> list[_CommentDraft]:
    if live_scenario is None:
        return []
    machine = cfg.get_machine(live_scenario.machine_id)
    mode = cfg.get_failure_mode(live_scenario.failure_mode)
    phrases = [
        phrase for phrase in mode.symptom_phrases if _phrase_matches_machine(phrase, machine.type)
    ]
    start = max(date(2026, 9, 14), live_scenario.drift_start)
    candidate_days = [
        start + timedelta(days=offset)
        for offset in range((live_scenario.end_date - start).days + 1)
    ]
    count = int(rng.integers(3, 5))
    last_day = live_scenario.end_date - timedelta(days=int(rng.integers(0, 3)))
    earlier_days = [day for day in candidate_days if day < last_day]
    selected = sorted(
        [
            earlier_days[int(position)]
            for position in rng.choice(len(earlier_days), size=count - 1, replace=False)
        ]
        + [last_day]
    )
    wrappers = (
        "slight {phrase_lower}, monitoring",
        "{phrase}, more noticeable today",
        "condition worsening: {phrase_lower}, reported to maintenance",
        "urgent check requested: {phrase_lower}",
    )
    drafts: list[_CommentDraft] = []
    for index, day in enumerate(selected):
        phrase = phrases[int(rng.integers(0, len(phrases)))]
        wrapper = wrappers[min(index, len(wrappers) - 1)]
        drafts.append(
            _draft_on_allowed_days(
                live_scenario.machine_id,
                wrapper.format(phrase=phrase, phrase_lower=phrase.lower()),
                "warning",
                [day],
                rng,
                valid_calendar_days=candidate_days,
                live_warning=True,
            )
        )
    return drafts


def generate_comments(
    cfg: AppConfig,
    params: GenParams,
    planned_failures: list[PlannedFailure],
    events: list[FailureEvent],
    live_scenario: LiveScenario | None,
    rng: np.random.Generator,
) -> tuple[list[OperatorComment], CommentLinks]:
    """Generate, chronologically identify, and link all operator comments."""
    drafts = _routine_comments(cfg, params, rng)
    drafts.extend(_historical_warning_comments(cfg, planned_failures, events, rng))
    drafts.extend(_repair_comments(cfg, events, rng))
    drafts.extend(_red_herring_comments(cfg, params, planned_failures, live_scenario, rng))
    drafts.extend(_live_warning_comments(cfg, params, live_scenario, rng))
    drafts.sort(key=lambda item: (item.timestamp, item.machine_id, item.category, item.text))

    comments: list[OperatorComment] = []
    warning_ids = {event.event_id: [] for event in events}
    live_warning_ids: list[str] = []
    category_by_id: dict[str, CommentCategory] = {}
    for index, draft in enumerate(drafts, start=1):
        comment_id = f"CMT-{index:03d}"
        comments.append(
            OperatorComment(
                comment_id=comment_id,
                machine_id=draft.machine_id,
                timestamp=draft.timestamp,
                shift=draft.shift,
                operator=draft.operator,
                comment_text=draft.text,
            )
        )
        category_by_id[comment_id] = draft.category
        if draft.event_id is not None:
            warning_ids[draft.event_id].append(comment_id)
        if draft.live_warning:
            live_warning_ids.append(comment_id)

    return comments, CommentLinks(warning_ids, live_warning_ids, category_by_id)
