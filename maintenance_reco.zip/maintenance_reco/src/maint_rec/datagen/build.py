"""Orchestrate pure generators and persist the resulting dataset."""

import json
from collections import Counter
from dataclasses import asdict, dataclass
from datetime import timedelta
from pathlib import Path

from maint_rec.config import get_settings
from maint_rec.config_loader import AppConfig, get_app_config
from maint_rec.datagen.comments import (
    COMMENT_CATEGORIES,
    CommentLinks,
    generate_comments,
)
from maint_rec.datagen.failures import PlannedFailure, plan_failures, to_failure_events
from maint_rec.datagen.params import GenParams, spawn_rngs
from maint_rec.datagen.scenario import LiveScenario, apply_live_scenario
from maint_rec.datagen.sensors import generate_sensors
from maint_rec.db import Repository
from maint_rec.recommend.schemas import FailureEvent, OperatorComment, SensorDaily


@dataclass(frozen=True, slots=True)
class BuildSummary:
    table_counts: dict[str, int]
    events_per_mode: dict[str, int]
    events_per_machine: dict[str, int]
    live_scenario: LiveScenario | None
    ground_truth_path: Path
    planned_failures: list[PlannedFailure]
    failure_events: list[FailureEvent]
    live_sensor_tail: list[SensorDaily]
    comments: list[OperatorComment]
    comment_links: CommentLinks
    comment_counts: dict[str, int]
    comments_per_machine: dict[str, int]


def _params_payload(params: GenParams) -> dict[str, object]:
    return {
        "seed": params.seed,
        "end_date": params.end_date.isoformat(),
        "days": params.days,
        "n_failures": params.n_failures,
        "min_events_per_mode": params.min_events_per_mode,
        "noise_scale": params.noise_scale,
        "machine_offset_pct": params.machine_offset_pct,
        "min_history_days": params.min_history_days,
        "reference_days": params.reference_days,
        "quiet_tail_days": params.quiet_tail_days,
        "cooldown_days": params.cooldown_days,
        "lead_bias": params.lead_bias,
        "drift_exponent": params.drift_exponent,
        "live_machine_id": params.live_machine_id,
        "live_failure_mode": params.live_failure_mode,
        "live_drift_days": params.live_drift_days,
        "live_pct_at_end": params.live_pct_at_end,
        "live_enabled": params.live_enabled,
        "comments_enabled": params.comments_enabled,
    }


def _write_ground_truth(
    path: Path,
    params: GenParams,
    planned: list[PlannedFailure],
    events: list[FailureEvent],
    live_scenario: LiveScenario | None,
    comment_links: CommentLinks,
    comment_counts: dict[str, int],
) -> None:
    payload = {
        "params": _params_payload(params),
        "planned_failures": [
            {
                "event_id": event.event_id,
                "machine_id": item.machine_id,
                "failure_mode": item.failure_mode,
                "drift_start": item.drift_start.isoformat(),
                "failure_date": item.failure_date.isoformat(),
                "lead_days": item.lead_days,
                "warning_comment_ids": comment_links.warning_comment_ids[event.event_id],
            }
            for item, event in zip(planned, events, strict=True)
        ],
        "live_scenario": None
        if live_scenario is None
        else {
            **asdict(live_scenario),
            "drift_start": live_scenario.drift_start.isoformat(),
            "end_date": live_scenario.end_date.isoformat(),
        },
        "live_warning_comment_ids": comment_links.live_warning_comment_ids,
        "comment_counts": comment_counts,
        "comment_ids_by_category": {
            category: [
                comment_id
                for comment_id, linked_category in comment_links.category_by_comment_id.items()
                if linked_category == category
            ]
            for category in COMMENT_CATEGORIES
        },
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def build_dataset(
    params: GenParams, repo: Repository, cfg: AppConfig | None = None
) -> BuildSummary:
    """Generate, persist, and document a complete deterministic dataset."""
    active_config = cfg or get_app_config()
    rngs = spawn_rngs(params.seed)
    planned = plan_failures(active_config, params, rngs["failures"])
    events = to_failure_events(planned, active_config, rngs["failures"])
    sensors = generate_sensors(active_config, params, planned, events, rngs["sensors"])
    live_scenario: LiveScenario | None = None
    if params.live_enabled:
        sensors, live_scenario = apply_live_scenario(
            sensors, active_config, params, rngs["scenario"]
        )

    comments: list[OperatorComment] = []
    comment_links = CommentLinks(
        warning_comment_ids={event.event_id: [] for event in events},
        live_warning_comment_ids=[],
        category_by_comment_id={},
    )
    if params.comments_enabled:
        comments, comment_links = generate_comments(
            active_config,
            params,
            planned,
            events,
            live_scenario,
            rngs["comments"],
        )
    comment_counts = comment_links.counts_by_category()

    repo.reset()
    repo.upsert_machines(active_config.machines)
    repo.insert_sensor_rows(sensors)
    repo.insert_failure_events(events)
    repo.insert_comments(comments)

    ground_truth_path = params.ground_truth_path or get_settings().data_dir / "ground_truth.json"
    _write_ground_truth(
        ground_truth_path,
        params,
        planned,
        events,
        live_scenario,
        comment_links,
        comment_counts,
    )
    counts = repo.counts()
    events_per_mode = dict(sorted(Counter(event.failure_mode for event in events).items()))
    events_per_machine = dict(sorted(Counter(event.machine_id for event in events).items()))
    comments_per_machine = dict(sorted(Counter(comment.machine_id for comment in comments).items()))
    live_tail = [
        row
        for row in sensors
        if row.machine_id == params.live_machine_id
        and row.date >= params.end_date - timedelta(days=13)
    ]
    return BuildSummary(
        table_counts=counts,
        events_per_mode=events_per_mode,
        events_per_machine=events_per_machine,
        live_scenario=live_scenario,
        ground_truth_path=ground_truth_path,
        planned_failures=planned,
        failure_events=events,
        live_sensor_tail=live_tail,
        comments=comments,
        comment_links=comment_links,
        comment_counts=comment_counts,
        comments_per_machine=comments_per_machine,
    )
