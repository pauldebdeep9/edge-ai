"""Parameters and independent random streams for synthetic data generation."""

from dataclasses import dataclass
from datetime import date, timedelta
from pathlib import Path

import numpy as np

RngMap = dict[str, np.random.Generator]


@dataclass(frozen=True, slots=True)
class GenParams:
    seed: int = 42
    end_date: date = date(2026, 9, 20)
    days: int = 240
    n_failures: int = 20
    min_events_per_mode: int = 2
    noise_scale: float = 0.2
    machine_offset_pct: float = 3.0
    min_history_days: int = 45
    reference_days: int = 30
    quiet_tail_days: int = 30
    cooldown_days: int = 5
    lead_bias: float = 0.5  # 0 uses the full lead range; 0.5 uses its upper half.
    drift_exponent: float = 1.5
    live_machine_id: str = "CNC-02"
    live_failure_mode: str = "bearing_wear"
    live_drift_days: int = 12
    live_pct_at_end: float = 70.0
    live_enabled: bool = True
    comments_enabled: bool = True
    ground_truth_path: Path | None = None

    def __post_init__(self) -> None:
        if self.days < 1:
            raise ValueError("days must be at least 1")
        if self.n_failures < 0 or self.min_events_per_mode < 0:
            raise ValueError("failure counts cannot be negative")
        if self.reference_days < 1:
            raise ValueError("reference_days must be at least 1")
        if self.min_history_days < self.reference_days or self.quiet_tail_days < 1:
            raise ValueError("history and quiet-tail bounds are invalid")
        if self.min_history_days + self.quiet_tail_days >= self.days:
            raise ValueError("timeline is too short for the history and quiet-tail bounds")
        if self.cooldown_days < 0 or self.live_drift_days < 1:
            raise ValueError("cooldown_days must be non-negative and live_drift_days positive")
        if not 0.0 <= self.lead_bias < 1.0:
            raise ValueError("lead_bias must be at least 0 and less than 1")
        if self.noise_scale < 0 or self.machine_offset_pct < 0:
            raise ValueError("noise and machine offset values cannot be negative")
        if self.drift_exponent <= 0 or self.live_pct_at_end < 0:
            raise ValueError("drift exponent must be positive and live drift cannot be negative")

    def timeline(self) -> list[date]:
        """Return the inclusive fixed generation timeline."""
        start = self.end_date - timedelta(days=self.days - 1)
        return [start + timedelta(days=offset) for offset in range(self.days)]


def spawn_rngs(seed: int) -> RngMap:
    """Spawn stable component streams, including the reserved comments stream."""
    names = ("failures", "sensors", "scenario", "comments")
    children = np.random.SeedSequence(seed).spawn(len(names))
    generators = (np.random.default_rng(child) for child in children)
    return dict(zip(names, generators, strict=True))
