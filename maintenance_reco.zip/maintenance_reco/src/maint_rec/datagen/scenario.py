"""Apply the unfinished live degradation scenario to generated readings."""

from dataclasses import dataclass
from datetime import date, timedelta
from statistics import mean

import numpy as np

from maint_rec.config_loader import AppConfig
from maint_rec.datagen.params import GenParams
from maint_rec.datagen.sensors import _round_sensor_values
from maint_rec.recommend.schemas import SensorDaily


@dataclass(frozen=True, slots=True)
class LiveScenario:
    machine_id: str
    failure_mode: str
    drift_start: date
    end_date: date
    live_reference_mean: float
    pct_at_end: float


def apply_live_scenario(
    rows: list[SensorDaily],
    cfg: AppConfig,
    params: GenParams,
    rng: np.random.Generator,
) -> tuple[list[SensorDaily], LiveScenario]:
    """Return rows with an accelerating, not-yet-failed live fault."""
    del rng  # The dedicated stream is reserved even though this scenario is deterministic.
    try:
        machine = cfg.get_machine(params.live_machine_id)
        mode = cfg.get_failure_mode(params.live_failure_mode)
    except KeyError as error:
        raise ValueError(str(error)) from error
    if machine.type not in mode.applicable_types:
        raise ValueError(
            f"failure mode {mode.id!r} does not apply to machine type {machine.type!r}"
        )

    drift_start = params.end_date - timedelta(days=params.live_drift_days)
    primary = max(mode.signal_effects, key=lambda effect: effect.magnitude_pct)
    magnitude_scale = params.live_pct_at_end / primary.magnitude_pct
    thresholds = cfg.thresholds
    reference_start = params.end_date - timedelta(
        days=thresholds.window_days + thresholds.baseline_days - 1
    )
    reference_end = params.end_date - timedelta(days=thresholds.window_days)
    live_reference_mean = mean(
        getattr(row, primary.signal)
        for row in rows
        if row.machine_id == params.live_machine_id and reference_start <= row.date <= reference_end
    )
    updated: list[SensorDaily] = []
    for row in rows:
        if (
            row.machine_id != params.live_machine_id
            or row.date < drift_start
            or row.date > params.end_date
        ):
            updated.append(row)
            continue
        elapsed = (row.date - drift_start).days
        progress = (elapsed / params.live_drift_days) ** params.drift_exponent
        values = {
            "temp_avg": row.temp_avg,
            "temp_max": row.temp_max,
            "vibration_rms": row.vibration_rms,
            "current_avg": row.current_avg,
            "runtime_hours": row.runtime_hours,
        }
        for effect in mode.signal_effects:
            direction = 1.0 if effect.direction == "up" else -1.0
            magnitude = effect.magnitude_pct * magnitude_scale
            values[effect.signal] *= 1.0 + direction * magnitude / 100.0 * progress
        if row.date == params.end_date:
            # Earlier drift days retain ordinary noisy readings. The terminal primary
            # value is exact by design so the configured live change is unambiguous.
            values[primary.signal] = live_reference_mean * (1.0 + params.live_pct_at_end / 100.0)
        values["temp_max"] = max(values["temp_max"], values["temp_avg"] + 2.0)
        updated.append(row.model_copy(update=_round_sensor_values(values)))

    end_row = next(
        row
        for row in updated
        if row.machine_id == params.live_machine_id and row.date == params.end_date
    )
    achieved_pct_at_end = (getattr(end_row, primary.signal) / live_reference_mean - 1.0) * 100.0
    scenario = LiveScenario(
        machine_id=params.live_machine_id,
        failure_mode=params.live_failure_mode,
        drift_start=drift_start,
        end_date=params.end_date,
        live_reference_mean=live_reference_mean,
        pct_at_end=achieved_pct_at_end,
    )
    return updated, scenario
