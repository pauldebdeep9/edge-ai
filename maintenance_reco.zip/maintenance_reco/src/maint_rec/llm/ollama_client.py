"""Asynchronous structured-output client for the local Ollama service."""

import logging
import time
from copy import deepcopy
from types import TracebackType
from typing import Any, Self

import httpx
from pydantic import BaseModel, ValidationError

from maint_rec.config import Settings
from maint_rec.llm.base import (
    ChatMeta,
    LLMError,
    LLMInvalidOutputError,
    LLMUnavailableError,
    ModelT,
)
from maint_rec.recommend.schemas import RecommendationDraft, draft_json_schema

LOGGER = logging.getLogger(__name__)


def _inline_schema_refs(schema: dict[str, Any]) -> dict[str, Any]:
    document = deepcopy(schema)
    definitions = document.pop("$defs", {})

    def inline(node: Any) -> Any:
        if isinstance(node, dict):
            reference = node.get("$ref")
            if isinstance(reference, str) and reference.startswith("#/$defs/"):
                name = reference.removeprefix("#/$defs/")
                resolved = deepcopy(definitions[name])
                resolved.update({key: value for key, value in node.items() if key != "$ref"})
                return inline(resolved)
            return {key: inline(value) for key, value in node.items()}
        if isinstance(node, list):
            return [inline(item) for item in node]
        return node

    return inline(document)


def _schema_for(model: type[BaseModel]) -> dict[str, Any]:
    if model is RecommendationDraft:
        return draft_json_schema()
    return _inline_schema_refs(model.model_json_schema())


def _compact_errors(error: ValidationError) -> list[str]:
    messages: list[str] = []
    for item in error.errors(include_url=False):
        location = ".".join(str(part) for part in item["loc"]) or "response"
        messages.append(f"{location}: {item['msg']}")
    return messages


def _unavailable(base_url: str, detail: str) -> LLMUnavailableError:
    return LLMUnavailableError(
        f"Ollama not reachable at {base_url} — is `ollama serve` running? {detail}"
    )


def _raise_for_status(response: httpx.Response, base_url: str, model: str) -> None:
    if response.is_success:
        return
    detail = response.text.strip()
    if response.status_code == 404:
        raise LLMUnavailableError(
            f"Ollama model {model!r} was not found at {base_url}. {detail}".strip()
        )
    if response.status_code >= 500:
        raise _unavailable(base_url, f"HTTP {response.status_code}: {detail}")
    raise LLMError(f"Ollama request failed with HTTP {response.status_code}: {detail}")


class OllamaClient:
    """Call Ollama's chat endpoint and validate its structured output."""

    def __init__(
        self,
        base_url: str,
        model: str,
        timeout_s: float,
        temperature: float,
        num_ctx: int,
        seed: int,
        keep_alive: str,
        max_retries: int,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        if max_retries < 0:
            raise ValueError("max_retries cannot be negative")
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.temperature = temperature
        self.num_ctx = num_ctx
        self.seed = seed
        self.keep_alive = keep_alive
        self.max_retries = max_retries
        self._owns_client = http_client is None
        self._client = http_client or httpx.AsyncClient(timeout=timeout_s)

    @classmethod
    def from_settings(cls, settings: Settings) -> Self:
        return cls(
            base_url=settings.ollama_base_url,
            model=settings.llm_model,
            timeout_s=settings.llm_timeout_s,
            temperature=settings.llm_temperature,
            num_ctx=settings.llm_num_ctx,
            seed=settings.llm_seed,
            keep_alive=settings.llm_keep_alive,
            max_retries=settings.llm_max_retries,
        )

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        await self.aclose()

    async def aclose(self) -> None:
        if self._owns_client:
            await self._client.aclose()

    async def is_alive(self) -> bool:
        try:
            response = await self._client.get(f"{self.base_url}/api/version")
            return response.is_success
        except httpx.HTTPError:
            return False

    async def version(self) -> str | None:
        try:
            response = await self._client.get(f"{self.base_url}/api/version")
            _raise_for_status(response, self.base_url, self.model)
            value = response.json().get("version")
            return value if isinstance(value, str) else None
        except (httpx.ConnectError, httpx.TimeoutException) as error:
            raise _unavailable(self.base_url, str(error)) from error

    async def list_models(self) -> list[str]:
        try:
            response = await self._client.get(f"{self.base_url}/api/tags")
            _raise_for_status(response, self.base_url, self.model)
        except (httpx.ConnectError, httpx.TimeoutException) as error:
            raise _unavailable(self.base_url, str(error)) from error
        models = response.json().get("models", [])
        return sorted(
            name
            for item in models
            if isinstance(item, dict)
            and isinstance(name := item.get("name") or item.get("model"), str)
        )

    async def missing_models(self, required: list[str]) -> list[str]:
        installed = await self.list_models()

        def canonical(name: str) -> str:
            return name.removesuffix(":latest")

        installed_names = {canonical(name) for name in installed}
        return [name for name in required if canonical(name) not in installed_names]

    async def chat_json(
        self, messages: list[dict[str, str]], schema: type[ModelT]
    ) -> tuple[ModelT, ChatMeta]:
        started = time.perf_counter()
        working_messages = [dict(message) for message in messages]
        schema_document = _schema_for(schema)
        LOGGER.debug("Ollama messages: %s", working_messages)
        raw_output = ""
        validation_errors: list[str] = []
        prompt_tokens: int | None = None
        completion_tokens: int | None = None

        for attempt in range(1, self.max_retries + 2):
            payload = {
                "model": self.model,
                "messages": working_messages,
                "stream": False,
                "format": schema_document,
                "options": {
                    "temperature": self.temperature,
                    "num_ctx": self.num_ctx,
                    "seed": self.seed,
                },
                "keep_alive": self.keep_alive,
            }
            try:
                response = await self._client.post(f"{self.base_url}/api/chat", json=payload)
                _raise_for_status(response, self.base_url, self.model)
            except (httpx.ConnectError, httpx.TimeoutException) as error:
                raise _unavailable(self.base_url, str(error)) from error

            body = response.json()
            content = body.get("message", {}).get("content")
            if not isinstance(content, str):
                raise LLMError("Ollama chat response did not contain message.content")
            raw_output = content
            prompt_tokens = body.get("prompt_eval_count")
            completion_tokens = body.get("eval_count")
            try:
                result = schema.model_validate_json(raw_output)
            except ValidationError as error:
                validation_errors = _compact_errors(error)
                if attempt > self.max_retries:
                    raise LLMInvalidOutputError(
                        f"Ollama returned invalid {schema.__name__} output after {attempt} attempts",
                        raw_output=raw_output,
                        validation_errors=validation_errors,
                    ) from error
                compact = "; ".join(validation_errors)
                working_messages.extend(
                    [
                        {"role": "assistant", "content": raw_output},
                        {
                            "role": "user",
                            "content": (
                                f"Your previous response was invalid: {compact}. "
                                "Return only a JSON object that matches the schema."
                            ),
                        },
                    ]
                )
                continue

            latency_ms = round((time.perf_counter() - started) * 1000)
            meta = ChatMeta(
                model=self.model,
                latency_ms=latency_ms,
                attempts=attempt,
                prompt_tokens=prompt_tokens if isinstance(prompt_tokens, int) else None,
                completion_tokens=(
                    completion_tokens if isinstance(completion_tokens, int) else None
                ),
            )
            LOGGER.info(
                "Ollama chat model=%s attempts=%s latency_ms=%s prompt_tokens=%s "
                "completion_tokens=%s",
                meta.model,
                meta.attempts,
                meta.latency_ms,
                meta.prompt_tokens,
                meta.completion_tokens,
            )
            return result, meta

        raise AssertionError("unreachable")
