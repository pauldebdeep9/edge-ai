"""Synchronous Ollama embeddings adapter for indexing and Chroma integration."""

from types import TracebackType
from typing import Any, Self

import httpx

from maint_rec.config import Settings
from maint_rec.llm.base import LLMError
from maint_rec.llm.ollama_client import _raise_for_status, _unavailable


class OllamaEmbedder:
    """Create embeddings with Ollama's batch-capable ``/api/embed`` endpoint."""

    def __init__(
        self,
        base_url: str,
        model: str,
        timeout_s: float,
        batch_size: int,
        http_client: httpx.Client | None = None,
        document_prefix: str = "search_document: ",
        query_prefix: str = "search_query: ",
    ) -> None:
        if batch_size < 1:
            raise ValueError("batch_size must be at least 1")
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.batch_size = batch_size
        # nomic-embed-text uses task prefixes to distinguish indexed text from queries.
        self.document_prefix = document_prefix
        self.query_prefix = query_prefix
        self.dimension: int | None = None
        self._owns_client = http_client is None
        self._client = http_client or httpx.Client(timeout=timeout_s)

    @classmethod
    def from_settings(cls, settings: Settings) -> Self:
        return cls(
            base_url=settings.ollama_base_url,
            model=settings.embed_model,
            timeout_s=settings.llm_timeout_s,
            batch_size=settings.embed_batch_size,
        )

    def __enter__(self) -> Self:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        self.close()

    def close(self) -> None:
        if self._owns_client:
            self._client.close()

    def embed_documents(self, texts: list[str]) -> list[list[float]]:
        return self._embed([f"{self.document_prefix}{text}" for text in texts])

    def embed_query(self, text: str) -> list[float]:
        vectors = self._embed([f"{self.query_prefix}{text}"])
        return vectors[0]

    def _embed(self, texts: list[str]) -> list[list[float]]:
        vectors: list[list[float]] = []
        for start in range(0, len(texts), self.batch_size):
            batch = texts[start : start + self.batch_size]
            try:
                response = self._client.post(
                    f"{self.base_url}/api/embed",
                    json={"model": self.model, "input": batch},
                )
                _raise_for_status(response, self.base_url, self.model)
            except (httpx.ConnectError, httpx.TimeoutException) as error:
                raise _unavailable(self.base_url, str(error)) from error
            payload: Any = response.json().get("embeddings")
            if not isinstance(payload, list) or len(payload) != len(batch):
                raise LLMError("Ollama returned an unexpected number of embeddings")
            for raw_vector in payload:
                if not isinstance(raw_vector, list) or not raw_vector:
                    raise LLMError("Ollama returned an empty or invalid embedding")
                vector = [float(value) for value in raw_vector]
                if self.dimension is None:
                    self.dimension = len(vector)
                elif len(vector) != self.dimension:
                    raise LLMError(
                        f"inconsistent embedding dimension: expected {self.dimension}, "
                        f"received {len(vector)}"
                    )
                vectors.append(vector)
        return vectors
