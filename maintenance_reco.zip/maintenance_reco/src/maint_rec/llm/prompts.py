"""Versioned recommendation prompts assembled from typed domain records."""

from maint_rec.config_loader import FailureModeDef, MachineDef
from maint_rec.recommend.schemas import Comment, Incident, RiskResult, Urgency

PROMPT_VERSION = "v1"

SYSTEM_PROMPT = """You are an assistant to a maintenance reliability engineer.

Follow these rules:
- Use ONLY the information in the provided context. Never invent measurements, parts, dates, or IDs.
- likely_failure_mode MUST be one of the listed candidate failure mode ids.
- evidence.similar_incidents and evidence.operator_comments may ONLY contain IDs that appear in the context. Cite only evidence actually used: 0–3 incidents and 0–5 comments.
- Every recommended action's urgency must be one of the listed allowed urgency values.
- Write reasoning in 2–4 sentences. Mention the key signal change with its number, how it matches or does not match the candidate signatures, and supporting incident or comment IDs.
- Signals not listed under risk triggers are within the normal range. Use normal signals to discriminate between modes; for example, rising vibration with normal temperature points away from lubrication failure.
- If evidence is weak or contradictory, use confidence "Low".
- Output only the JSON object.
"""

_SCORED_SIGNALS = ("vibration_rms", "temp_avg", "temp_max", "current_avg")


def _format_similarity(value: float | None) -> str:
    return "n/a" if value is None else f"{value:.2f}"


def _truncate(text: str, limit: int = 200) -> str:
    return text if len(text) <= limit else f"{text[: limit - 3]}..."


def render_context(
    machine: MachineDef,
    machine_type_name: str,
    risk: RiskResult,
    candidate_modes: list[FailureModeDef],
    incidents: list[Incident],
    comments: list[Comment],
) -> str:
    """Render the deterministic user-facing context for one recommendation."""
    applicable_modes = [mode for mode in candidate_modes if machine.type in mode.applicable_types]
    ordered_incidents = sorted(
        incidents,
        key=lambda incident: (
            incident.similarity is None,
            -(incident.similarity or 0.0),
            incident.event_id,
        ),
    )
    ordered_comments = sorted(
        comments,
        key=lambda comment: (comment.timestamp, comment.comment_id),
        reverse=True,
    )
    triggered_signals = {trigger.signal for trigger in risk.triggers}
    normal_signals = [signal for signal in _SCORED_SIGNALS if signal not in triggered_signals]

    lines = [
        "MACHINE",
        f"id: {machine.machine_id}",
        f"name: {machine.name}",
        f"type: {machine.type} ({machine_type_name})",
        f"location: {machine.location}",
        "",
        "RISK ASSESSMENT",
        f"overall level: {risk.level.value}",
    ]
    if risk.triggers:
        lines.extend(
            f"- {trigger.signal} | {trigger.metric}: {trigger.value} vs threshold "
            f"{trigger.threshold} | {trigger.level.value}"
            for trigger in risk.triggers
        )
    else:
        lines.append("- none")
    lines.append(f"within normal range: {', '.join(normal_signals) if normal_signals else 'none'}")

    lines.extend(["", "CANDIDATE FAILURE MODES"])
    if applicable_modes:
        for mode in applicable_modes:
            signature = ", ".join(
                f"{effect.signal} {effect.direction} {effect.magnitude_pct:g}%"
                for effect in mode.signal_effects
            )
            lines.extend(
                [
                    f"- {mode.id} | {mode.name}",
                    f"  signature: {signature}",
                    "  standard actions:",
                    *(
                        f"    - {template.action} [{template.urgency.value}]"
                        for template in mode.standard_actions
                    ),
                ]
            )
    else:
        lines.append("none")

    lines.extend(["", "SIMILAR PAST INCIDENTS"])
    if ordered_incidents:
        for incident in ordered_incidents:
            lines.extend(
                [
                    f"- ID: {incident.event_id}",
                    f"  date: {incident.date.isoformat()}",
                    f"  machine: {incident.machine_id}",
                    f"  mode: {incident.failure_mode}",
                    f"  symptoms: {incident.symptoms}",
                    f"  root cause: {incident.root_cause}",
                    f"  action taken: {incident.action_taken}",
                    f"  downtime hours: {incident.downtime_hours:g}",
                    f"  similarity: {_format_similarity(incident.similarity)}",
                ]
            )
    else:
        lines.append("none")

    lines.extend(["", "RECENT OPERATOR COMMENTS"])
    if ordered_comments:
        lines.extend(
            f"- {comment.comment_id} | {comment.timestamp.date().isoformat()} | "
            f"shift {comment.shift} | {_truncate(comment.comment_text)}"
            for comment in ordered_comments
        )
    else:
        lines.append("none")

    candidate_ids = [mode.id for mode in applicable_modes]
    incident_ids = [incident.event_id for incident in ordered_incidents]
    comment_ids = [comment.comment_id for comment in ordered_comments]
    lines.extend(
        [
            "",
            "ALLOWED VALUES",
            f"candidate mode ids: {', '.join(candidate_ids) if candidate_ids else 'none'}",
            f"incident ids: {', '.join(incident_ids) if incident_ids else 'none'}",
            f"comment ids: {', '.join(comment_ids) if comment_ids else 'none'}",
            f"urgency values: {', '.join(urgency.value for urgency in Urgency)}",
            "",
            "TASK",
            "Produce the maintenance recommendation JSON using only the context above.",
        ]
    )
    return "\n".join(lines)


def build_recommendation_messages(
    machine: MachineDef,
    machine_type_name: str,
    risk: RiskResult,
    candidate_modes: list[FailureModeDef],
    incidents: list[Incident],
    comments: list[Comment],
) -> list[dict[str, str]]:
    """Build the system and user messages for structured recommendation generation."""
    return [
        {"role": "system", "content": SYSTEM_PROMPT},
        {
            "role": "user",
            "content": render_context(
                machine,
                machine_type_name,
                risk,
                candidate_modes,
                incidents,
                comments,
            ),
        },
    ]
