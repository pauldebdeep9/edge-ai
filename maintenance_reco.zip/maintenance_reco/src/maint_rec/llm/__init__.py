"""Provider-neutral LLM interfaces and local Ollama implementations."""

from maint_rec.llm.base import (
    ChatMeta,
    Embedder,
    LLMClient,
    LLMError,
    LLMInvalidOutputError,
    LLMUnavailableError,
)
from maint_rec.llm.embeddings import OllamaEmbedder
from maint_rec.llm.ollama_client import OllamaClient
from maint_rec.llm.prompts import build_recommendation_messages

__all__ = [
    "ChatMeta",
    "Embedder",
    "LLMClient",
    "LLMError",
    "LLMInvalidOutputError",
    "LLMUnavailableError",
    "OllamaClient",
    "OllamaEmbedder",
    "build_recommendation_messages",
]
