"""Provider-neutral interfaces and errors for language and embedding models."""

from dataclasses import dataclass
from typing import Protocol, TypeVar

from pydantic import BaseModel

ModelT = TypeVar("ModelT", bound=BaseModel)


@dataclass(frozen=True, slots=True)
class ChatMeta:
    model: str
    latency_ms: int
    attempts: int
    prompt_tokens: int | None
    completion_tokens: int | None


class LLMError(RuntimeError):
    """Base error for local model operations."""


class LLMUnavailableError(LLMError):
    """Raised when Ollama or a requested model cannot serve a request."""


class LLMInvalidOutputError(LLMError):
    """Raised when model output remains invalid after all retries."""

    def __init__(
        self,
        message: str,
        *,
        raw_output: str,
        validation_errors: list[str],
    ) -> None:
        super().__init__(message)
        self.raw_output = raw_output
        self.validation_errors = validation_errors


class LLMClient(Protocol):
    model: str

    async def chat_json(
        self, messages: list[dict[str, str]], schema: type[ModelT]
    ) -> tuple[ModelT, ChatMeta]: ...

    async def is_alive(self) -> bool: ...


class Embedder(Protocol):
    dimension: int | None

    def embed_documents(self, texts: list[str]) -> list[list[float]]: ...

    def embed_query(self, text: str) -> list[float]: ...
