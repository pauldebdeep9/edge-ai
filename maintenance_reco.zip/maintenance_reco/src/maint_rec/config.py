"""Application settings and filesystem setup helpers."""

from functools import lru_cache
from pathlib import Path

from pydantic import model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

_PROJECT_ROOT = Path(__file__).resolve().parents[2]


class Settings(BaseSettings):
    """Configuration loaded from defaults, ``.env``, and environment variables."""

    model_config = SettingsConfigDict(
        env_prefix="MAINT_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    ollama_base_url: str = "http://localhost:11434"
    llm_model: str = "llama3.1:8b"
    embed_model: str = "nomic-embed-text"
    llm_timeout_s: float = 120.0
    llm_temperature: float = 0.1
    llm_num_ctx: int = 8192
    llm_seed: int = 42
    llm_keep_alive: str = "30m"
    llm_max_retries: int = 1
    embed_batch_size: int = 32
    project_root: Path = _PROJECT_ROOT
    data_dir: Path = Path("data")
    config_dir: Path = Path("config")
    db_path: Path = Path("data/maintenance.db")
    chroma_dir: Path = Path("data/chroma")
    top_k_incidents: int = 3
    top_k_comments: int = 5
    comment_window_days: int = 14
    sensor_window_days: int = 14
    random_seed: int = 42

    @model_validator(mode="after")
    def resolve_paths(self) -> "Settings":
        """Resolve configured relative paths from the project root."""
        fields_set = self.model_fields_set
        root = self.project_root
        if not root.is_absolute():
            root = (_PROJECT_ROOT / root).resolve()
        else:
            root = root.resolve()
        self.project_root = root

        self.data_dir = self._resolve(self.data_dir, root)
        self.config_dir = self._resolve(self.config_dir, root)
        self.db_path = (
            self._resolve(self.db_path, root)
            if "db_path" in fields_set
            else self.data_dir / "maintenance.db"
        )
        self.chroma_dir = (
            self._resolve(self.chroma_dir, root)
            if "chroma_dir" in fields_set
            else self.data_dir / "chroma"
        )
        return self

    @staticmethod
    def _resolve(path: Path, root: Path) -> Path:
        return path.resolve() if path.is_absolute() else (root / path).resolve()


@lru_cache
def get_settings() -> Settings:
    """Return the cached application settings."""
    return Settings()


def ensure_dirs(settings: Settings | None = None) -> None:
    """Create runtime data directories when explicitly requested."""
    active_settings = settings or get_settings()
    active_settings.data_dir.mkdir(parents=True, exist_ok=True)
    active_settings.chroma_dir.mkdir(parents=True, exist_ok=True)
