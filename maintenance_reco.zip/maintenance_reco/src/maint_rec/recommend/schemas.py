"""Shared domain contract for every maintenance recommendation work package.

Field changes here must be reflected in the database, generation, LLM, risk,
retrieval, pipeline, and API implementations added by later WBS packages.
"""

import re
from copy import deepcopy
from datetime import UTC, date, datetime
from enum import Enum
from typing import Annotated, Any, Literal, Self

from pydantic import BaseModel, ConfigDict, Field, StringConstraints, field_validator

NonEmptyStr = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1)]
FailureModeId = Annotated[str, StringConstraints(pattern=r"^[a-z][a-z0-9_]*$")]


class ContractModel(BaseModel):
    """Strict base for records exchanged between system components."""

    model_config = ConfigDict(extra="forbid")


class RiskLevel(str, Enum):
    LOW = "Low"
    MEDIUM = "Medium"
    HIGH = "High"


class Confidence(str, Enum):
    LOW = "Low"
    MEDIUM = "Medium"
    HIGH = "High"


class Urgency(str, Enum):
    IMMEDIATE = "Immediate"
    NEXT_SHIFT = "Next shift"
    WITHIN_48_HOURS = "Within 48 hours"
    WITHIN_1_WEEK = "Within 1 week"
    NEXT_PLANNED_MAINTENANCE = "Next planned maintenance"


class RecommendationSource(str, Enum):
    LLM = "llm"
    FALLBACK = "fallback"


class SensorDaily(ContractModel):
    machine_id: str
    date: date
    temp_avg: float
    temp_max: float
    vibration_rms: float
    current_avg: float
    runtime_hours: float


class FailureEvent(ContractModel):
    event_id: str
    machine_id: str
    machine_type: str
    date: date
    failure_mode: str
    symptoms: str
    root_cause: str
    action_taken: str
    parts_replaced: str | None
    downtime_hours: float


class OperatorComment(ContractModel):
    comment_id: str
    machine_id: str
    timestamp: datetime
    shift: Literal["A", "B", "C"]
    operator: str
    comment_text: str


class Incident(FailureEvent):
    similarity: float | None = None


class Comment(OperatorComment):
    similarity: float | None = None


class RiskTrigger(ContractModel):
    signal: str
    metric: Literal["pct_change_vs_baseline", "slope_pct_per_day"]
    value: float
    threshold: float
    level: RiskLevel


class RiskResult(ContractModel):
    machine_id: str
    level: RiskLevel
    triggers: list[RiskTrigger]
    window_days: int
    computed_at: datetime


class Action(ContractModel):
    action: NonEmptyStr
    urgency: Urgency


class Evidence(ContractModel):
    similar_incidents: list[str]
    operator_comments: list[str]


class RecommendationDraft(ContractModel):
    likely_failure_mode: FailureModeId
    confidence: Confidence
    reasoning: NonEmptyStr
    recommended_actions: list[Action] = Field(min_length=1, max_length=4)
    evidence: Evidence
    estimated_downtime_if_ignored_hours: float = Field(ge=0)

    @field_validator("reasoning")
    @classmethod
    def validate_reasoning_sentence_count(cls, value: str) -> str:
        sentences = [part for part in re.split(r"[.!?]+", value) if part.strip()]
        if not 1 <= len(sentences) <= 5:
            raise ValueError("reasoning must contain between 1 and 5 sentences")
        return value


class Recommendation(RecommendationDraft):
    machine_id: str
    risk_level: RiskLevel
    risk_triggers: list[RiskTrigger]
    source: RecommendationSource
    model: str | None
    generated_at: datetime
    latency_ms: int | None

    @classmethod
    def from_draft(
        cls,
        draft: RecommendationDraft,
        risk: RiskResult,
        source: RecommendationSource,
        model: str | None,
        latency_ms: int | None,
    ) -> Self:
        """Combine model-generated content with deterministic pipeline metadata."""
        return cls(
            **draft.model_dump(),
            machine_id=risk.machine_id,
            risk_level=risk.level,
            risk_triggers=risk.triggers,
            source=source,
            model=model,
            generated_at=datetime.now(UTC),
            latency_ms=latency_ms,
        )


def draft_json_schema() -> dict[str, Any]:
    """Return an Ollama-ready JSON schema with local definitions inlined."""
    schema = RecommendationDraft.model_json_schema()
    definitions = schema.pop("$defs", {})

    def inline(node: Any) -> Any:
        if isinstance(node, dict):
            reference = node.get("$ref")
            if isinstance(reference, str) and reference.startswith("#/$defs/"):
                name = reference.removeprefix("#/$defs/")
                resolved = deepcopy(definitions[name])
                resolved.update({key: value for key, value in node.items() if key != "$ref"})
                return inline(resolved)
            return {key: inline(value) for key, value in node.items()}
        if isinstance(node, list):
            return [inline(item) for item in node]
        return node

    return inline(schema)
