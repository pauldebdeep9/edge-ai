"""Build deterministic plain-language semantic search queries."""

from collections import defaultdict

from maint_rec.recommend.schemas import OperatorComment, RiskTrigger
from maint_rec.risk import RiskAssessment

_SIGNAL_NAMES = {
    "vibration_rms": "vibration",
    "temp_avg": "average temperature",
    "temp_max": "peak temperature",
    "current_avg": "motor current",
}


def _metric_phrase(trigger: RiskTrigger) -> str:
    value = abs(trigger.value)
    if trigger.metric == "pct_change_vs_baseline":
        direction = "increasing" if trigger.value >= 0 else "decreasing"
        return f"{direction} {value:.0f}% vs baseline"
    direction = "rising" if trigger.value >= 0 else "falling"
    return f"{direction} {value:.1f}% per day"


def build_query(
    machine_type_name: str,
    assessment: RiskAssessment | None,
    recent_comments: list[OperatorComment],
    max_comments: int = 3,
) -> str:
    """Render triggered signals and newest operator notes as search text."""
    if max_comments < 0:
        raise ValueError("max_comments cannot be negative")

    triggers_by_signal: dict[str, list[RiskTrigger]] = defaultdict(list)
    if assessment is not None:
        for trigger in assessment.risk.triggers:
            triggers_by_signal[trigger.signal].append(trigger)

    if triggers_by_signal:
        signal_phrases = []
        for signal in sorted(triggers_by_signal):
            triggers = sorted(
                triggers_by_signal[signal],
                key=lambda item: (
                    item.metric != "pct_change_vs_baseline",
                    item.metric,
                ),
            )
            details = ", ".join(_metric_phrase(trigger) for trigger in triggers)
            signal_phrases.append(f"{_SIGNAL_NAMES.get(signal, signal)} {details}")
        signal_text = f"Abnormal signals: {'; '.join(signal_phrases)}."
    else:
        signal_text = "No abnormal signals."

    ordered_comments = sorted(
        recent_comments,
        key=lambda comment: (comment.timestamp, comment.comment_id),
        reverse=True,
    )[:max_comments]
    comment_text = (
        "Operator reports: " + "; ".join(comment.comment_text for comment in ordered_comments) + "."
        if ordered_comments
        else "No operator reports."
    )
    return f"{machine_type_name}. {signal_text} {comment_text}"
