"""Build persistent Chroma collections from repository source records."""

import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import chromadb
from chromadb.api.models.Collection import Collection

from maint_rec.config_loader import AppConfig, get_app_config
from maint_rec.db import Repository
from maint_rec.llm import Embedder
from maint_rec.recommend.schemas import FailureEvent, OperatorComment

FAILURE_COLLECTION = "failure_events"
COMMENT_COLLECTION = "operator_comments"
MANIFEST_NAME = "manifest.json"
_COSINE_CONFIGURATION: dict[str, Any] = {"hnsw": {"space": "cosine"}}


class Indexer:
    """Embed repository records explicitly and upsert them into cosine indexes."""

    def __init__(
        self,
        chroma_dir: Path,
        embedder: Embedder,
        embed_model_name: str,
        cfg: AppConfig | None = None,
    ) -> None:
        self.chroma_dir = chroma_dir
        self.embedder = embedder
        self.embed_model_name = embed_model_name
        self.cfg = cfg or get_app_config()
        self.chroma_dir.mkdir(parents=True, exist_ok=True)
        self._client = chromadb.PersistentClient(path=self.chroma_dir)
        self._failure_collection: Collection
        self._comment_collection: Collection
        self._open_collections()

    @property
    def manifest_path(self) -> Path:
        return self.chroma_dir / MANIFEST_NAME

    def _open_collections(self) -> None:
        self._failure_collection = self._client.get_or_create_collection(
            FAILURE_COLLECTION,
            configuration=_COSINE_CONFIGURATION,
            embedding_function=None,
        )
        self._comment_collection = self._client.get_or_create_collection(
            COMMENT_COLLECTION,
            configuration=_COSINE_CONFIGURATION,
            embedding_function=None,
        )

    def _reset(self) -> None:
        existing = {collection.name for collection in self._client.list_collections()}
        for name in (FAILURE_COLLECTION, COMMENT_COLLECTION):
            if name in existing:
                self._client.delete_collection(name)
        self._open_collections()

    def build(self, repo: Repository, reset: bool = True) -> dict[str, int]:
        """Build both collections from database records and write the manifest."""
        if reset:
            self._reset()
        self.index_failures(repo.list_failures())
        self.index_comments(repo.list_comments())
        counts = self.counts()
        self._write_manifest(counts)
        return counts

    def index_failures(self, events: list[FailureEvent]) -> None:
        if not events:
            return
        documents = [self._failure_document(event) for event in events]
        embeddings = self.embedder.embed_documents(documents)
        self._failure_collection.upsert(
            ids=[event.event_id for event in events],
            documents=documents,
            embeddings=embeddings,
            metadatas=[
                {
                    "event_id": event.event_id,
                    "machine_id": event.machine_id,
                    "machine_type": event.machine_type,
                    "failure_mode": event.failure_mode,
                    "date": event.date.isoformat(),
                    "date_ord": event.date.toordinal(),
                    "downtime_hours": event.downtime_hours,
                }
                for event in events
            ],
        )

    def index_comments(self, comments: list[OperatorComment]) -> None:
        if not comments:
            return
        documents = [comment.comment_text for comment in comments]
        embeddings = self.embedder.embed_documents(documents)
        self._comment_collection.upsert(
            ids=[comment.comment_id for comment in comments],
            documents=documents,
            embeddings=embeddings,
            metadatas=[
                self._comment_metadata(comment, self.cfg.get_machine(comment.machine_id).type)
                for comment in comments
            ],
        )

    def add_comment(self, comment: OperatorComment, machine_type: str) -> None:
        """Upsert one newly persisted operator comment and refresh the manifest."""
        self._comment_collection.upsert(
            ids=[comment.comment_id],
            documents=[comment.comment_text],
            embeddings=self.embedder.embed_documents([comment.comment_text]),
            metadatas=[self._comment_metadata(comment, machine_type)],
        )
        self._write_manifest(self.counts())

    def counts(self) -> dict[str, int]:
        return {
            FAILURE_COLLECTION: self._failure_collection.count(),
            COMMENT_COLLECTION: self._comment_collection.count(),
        }

    def _failure_document(self, event: FailureEvent) -> str:
        mode_name = self.cfg.get_failure_mode(event.failure_mode).name
        return (
            f"{mode_name}. Symptoms: {event.symptoms}. Root cause: {event.root_cause}. "
            f"Action taken: {event.action_taken}."
        )

    @staticmethod
    def _comment_metadata(comment: OperatorComment, machine_type: str) -> dict[str, Any]:
        timestamp = comment.timestamp
        if timestamp.tzinfo is None:
            timestamp = timestamp.replace(tzinfo=UTC)
        return {
            "comment_id": comment.comment_id,
            "machine_id": comment.machine_id,
            "machine_type": machine_type,
            "shift": comment.shift,
            "operator": comment.operator,
            "timestamp": comment.timestamp.isoformat(),
            "ts_epoch": int(timestamp.timestamp()),
        }

    def _write_manifest(self, counts: dict[str, int]) -> None:
        previous_dimension: int | None = None
        if self.manifest_path.exists():
            try:
                previous_dimension = json.loads(self.manifest_path.read_text(encoding="utf-8")).get(
                    "dimension"
                )
            except (json.JSONDecodeError, OSError):
                previous_dimension = None
        payload = {
            "embed_model_name": self.embed_model_name,
            "dimension": self.embedder.dimension or previous_dimension,
            "counts": counts,
            "built_at": datetime.now(UTC).isoformat(),
        }
        self.manifest_path.write_text(
            json.dumps(payload, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
