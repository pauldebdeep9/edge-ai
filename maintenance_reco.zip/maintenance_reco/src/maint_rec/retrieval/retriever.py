"""Synchronous, leakage-safe retrieval over persistent Chroma indexes."""

import json
from datetime import UTC, date, datetime, timedelta
from pathlib import Path
from typing import Any

import chromadb
from chromadb.errors import NotFoundError

from maint_rec.db import Repository
from maint_rec.llm import Embedder
from maint_rec.recommend.schemas import Comment, Incident
from maint_rec.retrieval.indexer import (
    COMMENT_COLLECTION,
    FAILURE_COLLECTION,
    MANIFEST_NAME,
)


class IndexMismatchError(RuntimeError):
    """Raised when a compatible persistent retrieval index is unavailable."""


class Retriever:
    """Query explicit embeddings and rebuild typed results from the repository."""

    def __init__(
        self,
        chroma_dir: Path,
        embedder: Embedder,
        embed_model_name: str,
        repo: Repository,
    ) -> None:
        self.chroma_dir = chroma_dir
        self.embedder = embedder
        self.embed_model_name = embed_model_name
        self.repo = repo
        self._manifest = self._load_manifest()
        built_model = self._manifest.get("embed_model_name")
        if built_model != embed_model_name:
            raise IndexMismatchError(
                f"index built with {built_model}, current model {embed_model_name} — run make index"
            )
        self._dimension = self._manifest.get("dimension")
        try:
            client = chromadb.PersistentClient(path=chroma_dir)
            self._failure_collection = client.get_collection(
                FAILURE_COLLECTION, embedding_function=None
            )
            self._comment_collection = client.get_collection(
                COMMENT_COLLECTION, embedding_function=None
            )
        except NotFoundError as error:
            raise IndexMismatchError("retrieval index is incomplete — run make index") from error
        self._client = client

    def _load_manifest(self) -> dict[str, Any]:
        path = self.chroma_dir / MANIFEST_NAME
        if not path.is_file():
            raise IndexMismatchError("retrieval index is missing — run make index")
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError) as error:
            raise IndexMismatchError(
                "retrieval index manifest is invalid — run make index"
            ) from error
        if not isinstance(payload, dict):
            raise IndexMismatchError("retrieval index manifest is invalid — run make index")
        return payload

    def similar_incidents(
        self,
        query: str,
        machine_type: str,
        k: int,
        before: date | None = None,
    ) -> list[Incident]:
        if k < 1:
            raise ValueError("k must be at least 1")
        effective_before = before
        if effective_before is None:
            latest = self.repo.get_latest_date()
            if latest is None:
                return []
            effective_before = latest + timedelta(days=1)
        return self._query_incidents(query, machine_type, k, effective_before)

    def _query_incidents(
        self, query: str, machine_type: str, k: int, before: date
    ) -> list[Incident]:
        if self._failure_collection.count() == 0:
            return []
        vector = self.embedder.embed_query(query)
        self._validate_dimension(vector)
        result = self._failure_collection.query(
            query_embeddings=[vector],
            n_results=min(k, self._failure_collection.count()),
            where={
                "$and": [
                    {"machine_type": {"$eq": machine_type}},
                    {"date_ord": {"$lt": before.toordinal()}},
                ]
            },
            include=["distances"],
        )
        return sorted(
            (
                Incident.model_validate(
                    self.repo.get_failure(record_id).model_dump()
                    | {"similarity": 1.0 - float(distance)}
                )
                for record_id, distance in self._first_query_rows(result)
            ),
            key=lambda item: item.similarity if item.similarity is not None else float("-inf"),
            reverse=True,
        )

    def relevant_comments(
        self,
        query: str,
        machine_id: str,
        k: int,
        days: int,
        end: datetime | None = None,
    ) -> list[Comment]:
        if k < 1:
            raise ValueError("k must be at least 1")
        if days < 1:
            raise ValueError("days must be at least 1")
        effective_end = end
        if effective_end is None:
            comments = self.repo.list_comments(machine_id)
            if not comments:
                return []
            effective_end = comments[-1].timestamp
        if effective_end.tzinfo is None:
            effective_end = effective_end.replace(tzinfo=UTC)
        start = effective_end - timedelta(days=days)
        return self._query_comments(query, machine_id, k, start, effective_end)

    def _query_comments(
        self,
        query: str,
        machine_id: str,
        k: int,
        start: datetime,
        end: datetime,
    ) -> list[Comment]:
        if self._comment_collection.count() == 0:
            return []
        vector = self.embedder.embed_query(query)
        self._validate_dimension(vector)
        result = self._comment_collection.query(
            query_embeddings=[vector],
            n_results=min(k, self._comment_collection.count()),
            where={
                "$and": [
                    {"machine_id": {"$eq": machine_id}},
                    {"ts_epoch": {"$gte": int(start.timestamp())}},
                    {"ts_epoch": {"$lte": int(end.timestamp())}},
                ]
            },
            include=["distances"],
        )
        return sorted(
            (
                Comment.model_validate(
                    self.repo.get_comment(record_id).model_dump()
                    | {"similarity": 1.0 - float(distance)}
                )
                for record_id, distance in self._first_query_rows(result)
            ),
            key=lambda item: item.similarity if item.similarity is not None else float("-inf"),
            reverse=True,
        )

    @staticmethod
    def _first_query_rows(result: dict[str, Any]) -> list[tuple[str, float]]:
        id_batches = result.get("ids") or [[]]
        distance_batches = result.get("distances") or [[]]
        return [
            (str(record_id), float(distance))
            for record_id, distance in zip(id_batches[0], distance_batches[0], strict=True)
        ]

    def _validate_dimension(self, vector: list[float]) -> None:
        if isinstance(self._dimension, int) and len(vector) != self._dimension:
            raise IndexMismatchError(
                f"index dimension is {self._dimension}, current embedding dimension is "
                f"{len(vector)} — run make index"
            )
