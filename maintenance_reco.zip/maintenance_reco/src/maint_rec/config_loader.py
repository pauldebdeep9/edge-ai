"""Load and validate the human-editable demo configuration."""

from datetime import date
from functools import lru_cache
from pathlib import Path
from typing import Any, Literal

import yaml
from pydantic import BaseModel, ConfigDict, Field, model_validator

from maint_rec.config import get_settings
from maint_rec.recommend.schemas import Urgency


class ConfigModel(BaseModel):
    """Strict base model for configuration records."""

    model_config = ConfigDict(extra="forbid")


class SignalDef(ConfigModel):
    unit: str
    description: str


class Baseline(ConfigModel):
    mean: float
    std: float
    min: float
    max: float


class MachineTypeDef(ConfigModel):
    name: str
    baseline: dict[str, Baseline]


class MachineDef(ConfigModel):
    machine_id: str
    name: str
    type: str
    location: str
    install_date: date


class SignalEffect(ConfigModel):
    signal: str
    direction: Literal["up", "down"]
    magnitude_pct: float = Field(gt=0)


class ActionTemplate(ConfigModel):
    action: str = Field(min_length=1)
    urgency: Urgency


class RangeDef(ConfigModel):
    min: float
    max: float


class FailureModeDef(ConfigModel):
    id: str
    name: str
    description: str
    applicable_types: list[str] = Field(min_length=1)
    signal_effects: list[SignalEffect] = Field(min_length=1)
    lead_time_days: RangeDef
    symptom_phrases: list[str] = Field(min_length=4, max_length=6)
    root_cause: str
    standard_actions: list[ActionTemplate] = Field(min_length=2, max_length=4)
    downtime_hours: RangeDef


class LevelRule(ConfigModel):
    pct_change_vs_baseline: float = Field(ge=0)
    slope_pct_per_day: float = Field(ge=0)


class SignalRule(ConfigModel):
    medium: LevelRule
    high: LevelRule


class AggregationRule(ConfigModel):
    escalate_to_high_if_medium_count_at_least: int = Field(ge=1)


class MaintenanceResetConfig(ConfigModel):
    min_baseline_days: int = Field(default=7, ge=1)
    min_window_days: int = Field(default=7, ge=1)


class ThresholdsConfig(ConfigModel):
    window_days: int = Field(gt=0)
    baseline_days: int = Field(gt=0)
    signals: dict[str, SignalRule]
    aggregation: AggregationRule
    maintenance_reset: MaintenanceResetConfig = Field(default_factory=MaintenanceResetConfig)
    direction_aware: bool = True


class AppConfig(ConfigModel):
    signals: dict[str, SignalDef]
    machine_types: dict[str, MachineTypeDef]
    machines: list[MachineDef]
    failure_modes: list[FailureModeDef]
    thresholds: ThresholdsConfig

    @model_validator(mode="after")
    def validate_references_and_ranges(self) -> "AppConfig":
        signal_ids = set(self.signals)
        type_ids = set(self.machine_types)

        machine_ids = [machine.machine_id for machine in self.machines]
        self._require_unique(machine_ids, "machine_id")
        mode_ids = [mode.id for mode in self.failure_modes]
        self._require_unique(mode_ids, "failure mode id")

        for machine in self.machines:
            if machine.type not in type_ids:
                raise ValueError(
                    f"machine {machine.machine_id} references unknown machine type {machine.type!r}"
                )

        for type_id, machine_type in self.machine_types.items():
            baseline_signals = set(machine_type.baseline)
            missing = signal_ids - baseline_signals
            if missing:
                raise ValueError(
                    f"machine type {type_id!r} is missing baseline signal(s): "
                    f"{', '.join(sorted(missing))}"
                )
            unknown = baseline_signals - signal_ids
            if unknown:
                raise ValueError(
                    f"machine type {type_id!r} has unknown baseline signal(s): "
                    f"{', '.join(sorted(unknown))}"
                )
            for signal, baseline in machine_type.baseline.items():
                if not baseline.min < baseline.mean < baseline.max:
                    raise ValueError(
                        f"baseline for {type_id}.{signal} must satisfy min < mean < max"
                    )
                if baseline.std <= 0:
                    raise ValueError(f"baseline std for {type_id}.{signal} must be greater than 0")

        for mode in self.failure_modes:
            unknown_types = set(mode.applicable_types) - type_ids
            if unknown_types:
                raise ValueError(
                    f"failure mode {mode.id!r} references unknown machine type(s): "
                    f"{', '.join(sorted(unknown_types))}"
                )
            for effect in mode.signal_effects:
                if effect.signal not in signal_ids:
                    raise ValueError(
                        f"failure mode {mode.id!r} references unknown signal {effect.signal!r}"
                    )
            if mode.lead_time_days.min > mode.lead_time_days.max:
                raise ValueError(
                    f"failure mode {mode.id!r} has lead_time_days min greater than max"
                )
            if mode.downtime_hours.min > mode.downtime_hours.max:
                raise ValueError(
                    f"failure mode {mode.id!r} has downtime_hours min greater than max"
                )

        for signal, rule in self.thresholds.signals.items():
            if signal not in signal_ids:
                raise ValueError(f"thresholds reference unknown signal {signal!r}")
            if rule.high.pct_change_vs_baseline <= rule.medium.pct_change_vs_baseline:
                raise ValueError(
                    f"high pct_change_vs_baseline threshold must exceed medium for {signal!r}"
                )
            if rule.high.slope_pct_per_day <= rule.medium.slope_pct_per_day:
                raise ValueError(
                    f"high slope_pct_per_day threshold must exceed medium for {signal!r}"
                )
        return self

    @staticmethod
    def _require_unique(values: list[str], label: str) -> None:
        duplicates = sorted({value for value in values if values.count(value) > 1})
        if duplicates:
            raise ValueError(f"duplicate {label}(s): {', '.join(duplicates)}")

    def get_machine(self, machine_id: str) -> MachineDef:
        for machine in self.machines:
            if machine.machine_id == machine_id:
                return machine
        raise KeyError(f"unknown machine id {machine_id!r}")

    def get_failure_mode(self, mode_id: str) -> FailureModeDef:
        for mode in self.failure_modes:
            if mode.id == mode_id:
                return mode
        raise KeyError(f"unknown failure mode id {mode_id!r}")

    def modes_for_type(self, type_id: str) -> list[FailureModeDef]:
        if type_id not in self.machine_types:
            raise KeyError(f"unknown machine type id {type_id!r}")
        return [mode for mode in self.failure_modes if type_id in mode.applicable_types]


def _read_yaml(path: Path) -> dict[str, Any]:
    with path.open(encoding="utf-8") as stream:
        document = yaml.safe_load(stream)
    if not isinstance(document, dict):
        raise TypeError(f"configuration file must contain a mapping: {path}")
    return document


def load_app_config(config_dir: Path | None = None) -> AppConfig:
    """Load the three YAML files and validate their combined references."""
    directory = config_dir or get_settings().config_dir
    machine_data = _read_yaml(directory / "machines.yaml")
    failure_data = _read_yaml(directory / "failure_modes.yaml")
    threshold_data = _read_yaml(directory / "thresholds.yaml")
    return AppConfig.model_validate(
        {
            **machine_data,
            "failure_modes": failure_data.get("failure_modes"),
            "thresholds": threshold_data,
        }
    )


@lru_cache(maxsize=1)
def get_app_config() -> AppConfig:
    """Return the cached application configuration."""
    return load_app_config()
