"""Deterministic risk classification over non-overlapping sensor windows."""

import logging
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, date, datetime, timedelta
from typing import Literal

from maint_rec.config_loader import AppConfig, LevelRule, SignalRule
from maint_rec.db import Repository
from maint_rec.recommend.schemas import RiskLevel, RiskResult, RiskTrigger
from maint_rec.risk.features import SignalFeatures, compute_features

LOGGER = logging.getLogger(__name__)

_LEVEL_RANK = {RiskLevel.LOW: 0, RiskLevel.MEDIUM: 1, RiskLevel.HIGH: 2}


class InsufficientDataError(ValueError):
    """Raised when a machine lacks a complete baseline plus scoring window."""


@dataclass(frozen=True, slots=True)
class RiskAssessment:
    risk: RiskResult
    features: dict[str, SignalFeatures]
    status: Literal["ok", "recently_serviced", "config_baseline"]
    last_repair_date: date | None
    window_start: date
    window_end: date
    baseline_start: date
    baseline_end: date


class RiskScorer:
    """Score sensor change and slope against the configured strict thresholds.

    The analysis window contains ``window_days`` rows ending on ``as_of``.
    Its reference is the immediately preceding ``baseline_days`` rows, with
    no overlap. Change compares the last three window days with the baseline
    mean. OLS slope uses actual day offsets across the effective window and is
    normalized to percent of the baseline mean per day. A repair within the
    nominal span discards readings through its date; short post-repair windows
    are suppressed and short references use configured healthy means. Signed
    metrics use strict ``>`` thresholds and only trigger in directions present
    in applicable configured failure modes.
    """

    def __init__(
        self,
        repo: Repository,
        cfg: AppConfig,
        clock: Callable[[], datetime] | None = None,
    ) -> None:
        self.repo = repo
        self.cfg = cfg
        self.clock = clock or (lambda: datetime.now(UTC))
        self._directions_by_type = {
            type_id: {
                (effect.signal, effect.direction)
                for mode in cfg.modes_for_type(type_id)
                for effect in mode.signal_effects
            }
            for type_id in cfg.machine_types
        }

    def assess(self, machine_id: str, as_of: date | None = None) -> RiskAssessment:
        thresholds = self.cfg.thresholds
        window_end = as_of or self.repo.get_latest_date(machine_id)
        if window_end is None:
            raise InsufficientDataError(f"no sensor data available for machine {machine_id!r}")

        nominal_window_start = window_end - timedelta(days=thresholds.window_days - 1)
        nominal_baseline_end = nominal_window_start - timedelta(days=1)
        nominal_baseline_start = nominal_baseline_end - timedelta(days=thresholds.baseline_days - 1)
        window_rows = self.repo.get_sensor_range(machine_id, nominal_window_start, window_end)
        baseline_rows = self.repo.get_sensor_range(
            machine_id, nominal_baseline_start, nominal_baseline_end
        )
        if (
            len(window_rows) < thresholds.window_days
            or len(baseline_rows) < thresholds.baseline_days
        ):
            available = len(window_rows) + len(baseline_rows)
            required = thresholds.window_days + thresholds.baseline_days
            raise InsufficientDataError(
                f"machine {machine_id!r} needs {required} daily rows ending {window_end}; "
                f"found {available} ({len(baseline_rows)} baseline, "
                f"{len(window_rows)} window)"
            )

        failures = [
            event
            for event in self.repo.list_failures(machine_id=machine_id)
            if event.date <= window_end
        ]
        last_repair_date = max((event.date for event in failures), default=None)
        repair_in_span = (
            last_repair_date is not None
            and nominal_baseline_start <= last_repair_date <= window_end
        )
        effective_window_start = nominal_window_start
        effective_baseline_start = nominal_baseline_start
        effective_baseline_end = nominal_baseline_end
        if repair_in_span:
            repair_cutoff = last_repair_date + timedelta(days=1)
            window_rows = [row for row in window_rows if row.date > last_repair_date]
            baseline_rows = [row for row in baseline_rows if row.date > last_repair_date]
            effective_window_start = max(nominal_window_start, repair_cutoff)
            effective_baseline_start = max(nominal_baseline_start, repair_cutoff)

        machine = self.cfg.get_machine(machine_id)
        configured_means = {
            signal: self.cfg.machine_types[machine.type].baseline[signal].mean
            for signal in thresholds.signals
        }
        reset = thresholds.maintenance_reset
        if repair_in_span and len(window_rows) < reset.min_window_days:
            features = (
                compute_features(
                    window_rows,
                    [],
                    list(thresholds.signals),
                    recent_days=min(3, len(window_rows)),
                    baseline_means=configured_means,
                )
                if window_rows
                else {}
            )
            return RiskAssessment(
                risk=RiskResult(
                    machine_id=machine_id,
                    level=RiskLevel.LOW,
                    triggers=[],
                    window_days=thresholds.window_days,
                    computed_at=self.clock(),
                ),
                features=features,
                status="recently_serviced",
                last_repair_date=last_repair_date,
                window_start=effective_window_start,
                window_end=window_end,
                baseline_start=effective_baseline_start,
                baseline_end=effective_baseline_end,
            )

        use_config_baseline = repair_in_span and len(baseline_rows) < reset.min_baseline_days
        features = compute_features(
            window_rows,
            baseline_rows,
            list(thresholds.signals),
            baseline_means=configured_means if use_config_baseline else None,
        )
        allowed_directions = (
            self._directions_by_type[machine.type] if thresholds.direction_aware else None
        )
        level, triggers = self.classify(features, allowed_directions)
        return RiskAssessment(
            risk=RiskResult(
                machine_id=machine_id,
                level=level,
                triggers=triggers,
                window_days=thresholds.window_days,
                computed_at=self.clock(),
            ),
            features=features,
            status="config_baseline" if use_config_baseline else "ok",
            last_repair_date=last_repair_date,
            window_start=effective_window_start,
            window_end=window_end,
            baseline_start=effective_baseline_start,
            baseline_end=effective_baseline_end,
        )

    def score(self, machine_id: str, as_of: date | None = None) -> RiskResult:
        return self.assess(machine_id, as_of).risk

    def assess_fleet(self, as_of: date | None = None) -> list[RiskAssessment]:
        assessments: list[RiskAssessment] = []
        for machine in self.repo.get_machines():
            try:
                assessments.append(self.assess(machine.machine_id, as_of))
            except InsufficientDataError as error:
                LOGGER.warning("Skipping risk assessment: %s", error)
        return assessments

    def classify(
        self,
        features: dict[str, SignalFeatures],
        allowed_directions: set[tuple[str, str]] | None = None,
    ) -> tuple[RiskLevel, list[RiskTrigger]]:
        """Classify precomputed features without accessing the database."""
        signal_levels: list[RiskLevel] = []
        triggers: list[RiskTrigger] = []
        for signal, rule in self.cfg.thresholds.signals.items():
            if signal not in features:
                raise KeyError(f"missing features for configured signal {signal!r}")
            feature = features[signal]
            metric_values = {
                "pct_change_vs_baseline": feature.pct_change_vs_baseline,
                "slope_pct_per_day": feature.slope_pct_per_day,
            }
            metric_levels: list[RiskLevel] = []
            for metric, value in metric_values.items():
                direction = "up" if value > 0 else "down" if value < 0 else None
                if allowed_directions is not None and (
                    direction is None or (signal, direction) not in allowed_directions
                ):
                    continue
                level, threshold = self._classify_metric(value, rule, metric)
                if level is RiskLevel.LOW:
                    continue
                metric_levels.append(level)
                triggers.append(
                    RiskTrigger(
                        signal=signal,
                        metric=metric,
                        value=value,
                        threshold=threshold,
                        level=level,
                    )
                )
            signal_levels.append(
                max(metric_levels, key=_LEVEL_RANK.__getitem__) if metric_levels else RiskLevel.LOW
            )

        overall = max(signal_levels, key=_LEVEL_RANK.__getitem__, default=RiskLevel.LOW)
        medium_signals = sum(level is RiskLevel.MEDIUM for level in signal_levels)
        if (
            overall is not RiskLevel.HIGH
            and medium_signals
            >= self.cfg.thresholds.aggregation.escalate_to_high_if_medium_count_at_least
        ):
            overall = RiskLevel.HIGH
        triggers.sort(key=lambda item: (-_LEVEL_RANK[item.level], -abs(item.value), item.signal))
        return overall, triggers

    @staticmethod
    def _classify_metric(
        value: float,
        rule: SignalRule,
        metric: str,
    ) -> tuple[RiskLevel, float]:
        high: LevelRule = rule.high
        medium: LevelRule = rule.medium
        high_threshold = float(getattr(high, metric))
        medium_threshold = float(getattr(medium, metric))
        if abs(value) > high_threshold:
            return RiskLevel.HIGH, high_threshold
        if abs(value) > medium_threshold:
            return RiskLevel.MEDIUM, medium_threshold
        return RiskLevel.LOW, medium_threshold
