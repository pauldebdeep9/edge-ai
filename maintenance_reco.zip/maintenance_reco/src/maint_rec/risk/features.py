"""Pure feature calculations for deterministic risk scoring."""

from dataclasses import dataclass

import numpy as np

from maint_rec.recommend.schemas import SensorDaily


@dataclass(frozen=True, slots=True)
class SignalFeatures:
    """Summary metrics for one signal over separate baseline and risk windows."""

    signal: str
    baseline_mean: float
    recent_mean: float
    latest_value: float
    pct_change_vs_baseline: float
    slope_pct_per_day: float


def compute_features(
    window_rows: list[SensorDaily],
    baseline_rows: list[SensorDaily],
    signals: list[str],
    recent_days: int = 3,
    baseline_means: dict[str, float] | None = None,
) -> dict[str, SignalFeatures]:
    """Compute signed change and trend metrics for each configured signal.

    ``baseline_mean`` uses only the supplied reference rows. ``recent_mean``
    uses exactly the last ``recent_days`` window rows. The trend is the
    ordinary least-squares slope over actual day offsets from the first window
    row, normalized by the baseline mean and expressed as percent per day.
    Configured ``baseline_means`` may replace a short or empty measured
    reference after maintenance. The caller owns window selection; this
    function deliberately makes no overlap assumptions.
    """
    if not window_rows:
        raise ValueError("window_rows cannot be empty")
    if not baseline_rows and baseline_means is None:
        raise ValueError("baseline_rows cannot be empty")
    if recent_days < 1 or recent_days > len(window_rows):
        raise ValueError("recent_days must be between 1 and the window length")

    first_date = window_rows[0].date
    x = np.asarray([(row.date - first_date).days for row in window_rows], dtype=float)
    centered_x = x - float(x.mean())
    denominator = float(np.dot(centered_x, centered_x))
    features: dict[str, SignalFeatures] = {}

    for signal in signals:
        window_values = np.asarray(
            [float(getattr(row, signal)) for row in window_rows], dtype=float
        )
        if baseline_means is not None:
            try:
                baseline_mean = float(baseline_means[signal])
            except KeyError as error:
                raise ValueError(f"configured baseline mean missing for {signal!r}") from error
        else:
            baseline_values = np.asarray(
                [float(getattr(row, signal)) for row in baseline_rows], dtype=float
            )
            baseline_mean = float(baseline_values.mean())
        if baseline_mean == 0.0:
            raise ValueError(f"baseline mean for {signal!r} cannot be zero")
        recent_mean = float(window_values[-recent_days:].mean())
        slope = (
            0.0
            if denominator == 0.0
            else float(np.dot(centered_x, window_values - window_values.mean()) / denominator)
        )
        features[signal] = SignalFeatures(
            signal=signal,
            baseline_mean=baseline_mean,
            recent_mean=recent_mean,
            latest_value=float(window_values[-1]),
            pct_change_vs_baseline=(recent_mean - baseline_mean) / baseline_mean * 100.0,
            slope_pct_per_day=slope / baseline_mean * 100.0,
        )
    return features
