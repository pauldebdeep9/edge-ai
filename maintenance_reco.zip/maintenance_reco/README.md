# Maintenance Recommendation System

A Python demo that will combine synthetic sensor readings, failure history, and operator
comments to produce maintenance recommendations with a locally hosted Ollama model.
FastAPI will serve the system and Streamlit will provide its user interface. WBS-00
through WBS-03 now provide the environment scaffold, validated configuration contracts,
and a typed SQLite repository with deterministic synthetic maintenance history.

## Prerequisites

- Conda via Miniconda or Miniforge
- Ollama installed at the operating-system level, not inside Conda
- Git

## Setup

```bash
conda env create -f environment.yml
conda activate Sai2609
pip install -e ".[ui,dev]"
cp .env.example .env
python -c "import maint_rec; from maint_rec.config import get_settings; print(maint_rec.__version__, get_settings().db_path)"
```

`Sai2609` is a reusable environment shared across projects. Project-specific dependencies
are declared in `pyproject.toml` and installed separately with editable `pip` installation.

## Configuration

The human-readable files in `config/` are the demo's operational knobs. `machines.yaml`
defines signals, healthy baselines, and the fleet; `failure_modes.yaml` defines symptoms,
signal drift, and standard actions; and `thresholds.yaml` defines deterministic risk levels.
They are loaded together and cross-validated by `maint_rec.config_loader`.

## Database

SQLite stores `machines`, `sensor_daily`, `failure_events`, `operator_comments`, and
`recommendations_log`. All SQL is isolated in `maint_rec.db`; initialize or reset and seed
the database with `make init-db` or `python scripts/init_db.py --reset`.

## Synthetic data

Run `make data` to generate a fixed 240-day timeline. Historical faults accelerate with a
power-law drift toward each failure, followed by an immediate repair. Each drift has a clean
30-day, same-signal reference window, and the final 30 days are kept free of historical
faults. That quiet tail contains an unfinished CNC-02 bearing-wear scenario for the live demo.
Operator comments combine routine shift notes, fault warnings, repair notes, and harmless
red herrings; the live CNC-02 warnings become more urgent near the end date.
`data/ground_truth.json` records every drift window, warning-comment links, live-warning IDs,
category counts, and the live scenario for repeatable evaluation.

## Local LLM

Ollama runs at the operating-system level with `llama3.1:8b` for structured maintenance
recommendations and `nomic-embed-text` for retrieval embeddings. Run `make models` to pull
both configured models and `make check-llm` for the end-to-end embedding and chat smoke test.
The versioned prompt presents the machine, risk triggers and normal signals, applicable
failure-mode signatures, similar incidents, recent comments, allowed IDs and urgency values,
then requests a schema-validated JSON recommendation.

## Risk scoring

Run `make risk` for the latest fleet assessment or `make risk-replay` to evaluate planted
failures. Each assessment uses a 14-day window and the preceding non-overlapping 30-day
baseline. Signal change compares the last three window days with the baseline mean; trend is
an ordinary least-squares slope expressed as baseline percent per day. Signed metrics use
strict thresholds: Medium is an early warning and High means act now. Two Medium signals
escalate the overall level to High.

Maintenance resets the usable history. Post-repair windows shorter than seven days are
`recently_serviced` and remain Low; short post-repair baselines use configured healthy means
with status `config_baseline`; all other assessments are `ok`. Direction-aware alarms only
trigger when a change matches a configured failure-mode direction for that machine type.
Replay reports detection and signal matching, per-mode warning-day ranges, final-tail alarms,
and the false-alarm rate over healthy scoring windows.

## Retrieval

Chroma stores cosine indexes in two collections: `failure_events` and `operator_comments`.
Failure documents combine the configured failure-mode name, symptoms, root cause, and action;
comment documents contain the shift note exactly as written. Embeddings are always supplied
explicitly by the configured Ollama model—Chroma's built-in embedding function is disabled.

Retrieval enforces no future leakage: incidents must predate the requested date, and comments
must fall within the requested historical time window. `data/chroma/manifest.json` records the
embedding model, vector dimension, collection counts, and build time; querying with a different
model fails with instructions to rebuild. Run `make index` after every `make data`, or use
`make setup-data` for both. Run `make eval-retrieval` for the ground-truth evaluation.

## Planned repository layout

```text
maintenance-recsys/
├── config/                         # WBS-01
├── data/
├── scripts/
├── docs/
├── notebooks/
├── src/maint_rec/
│   ├── config.py                   # WBS-00
│   ├── config_loader.py            # WBS-01
│   ├── datagen/                    # WBS-03
│   ├── db/                         # WBS-02
│   ├── llm/                        # WBS-04
│   ├── risk/                       # WBS-05
│   ├── retrieval/                  # WBS-06
│   ├── recommend/                  # WBS-01, extended in WBS-07
│   └── api/                        # added in WBS-08
├── ui/                             # added in WBS-09
├── docker/                         # added in WBS-10
├── tests/unit/
└── tests/integration/
```

## WBS progress

- [x] WBS-00 — Environment and project scaffold
- [x] WBS-01 — Configuration and recommendation contracts
- [x] WBS-02 — Database layer
- [x] WBS-03 — Synthetic sensors, failures, live scenario, and operator comments
- [x] WBS-04 — Local LLM integration
- [x] WBS-05 — Risk analysis
- [x] WBS-06 — Retrieval
- [ ] WBS-07 — Recommendation pipeline
- [ ] WBS-08 — FastAPI service
- [ ] WBS-09 — Streamlit UI
- [ ] WBS-10 — Containerization and delivery
