"""Show current fleet risk or replay detection against planted failures."""

import argparse
import json
from collections import Counter, defaultdict
from collections.abc import Callable, Sequence
from datetime import date, timedelta
from pathlib import Path
from statistics import median

from maint_rec.config import get_settings
from maint_rec.config_loader import AppConfig, get_app_config
from maint_rec.db import Repository, get_repository
from maint_rec.recommend.schemas import RiskLevel
from maint_rec.risk import RiskAssessment, RiskScorer


def _date(value: str) -> date:
    try:
        return date.fromisoformat(value)
    except ValueError as error:
        raise argparse.ArgumentTypeError(f"invalid ISO date: {value}") from error


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--as-of", type=_date, help="assessment date in YYYY-MM-DD form")
    parser.add_argument("--replay", action="store_true", help="replay planted failures")
    return parser


def _table(headers: list[str], rows: list[list[str]]) -> str:
    widths = [
        max(len(header), *(len(row[index]) for row in rows)) for index, header in enumerate(headers)
    ]
    line = "  ".join(header.ljust(widths[index]) for index, header in enumerate(headers))
    divider = "  ".join("-" * width for width in widths)
    body = [
        "  ".join(value.ljust(widths[index]) for index, value in enumerate(row)) for row in rows
    ]
    return "\n".join([line, divider, *body])


def _feature_cell(assessment: RiskAssessment, signal: str) -> str:
    if signal not in assessment.features:
        return "n/a"
    feature = assessment.features[signal]
    triggered = {(trigger.signal, trigger.metric) for trigger in assessment.risk.triggers}
    change_mark = "*" if (signal, "pct_change_vs_baseline") in triggered else ""
    slope_mark = "*" if (signal, "slope_pct_per_day") in triggered else ""
    return (
        f"{feature.pct_change_vs_baseline:+.1f}{change_mark}/"
        f"{feature.slope_pct_per_day:+.2f}{slope_mark}"
    )


def _show_fleet(repo: Repository, cfg: AppConfig, as_of: date | None) -> None:
    scorer = RiskScorer(repo, cfg)
    assessments = scorer.assess_fleet(as_of)
    signals = list(cfg.thresholds.signals)
    effective_date = as_of or repo.get_latest_date()
    print(f"Fleet risk as of {effective_date} (* = triggered metric)")
    print(
        _table(
            [
                "machine",
                "level",
                "status",
                *(f"{signal} change/slope" for signal in signals),
            ],
            [
                [
                    assessment.risk.machine_id,
                    assessment.risk.level.value,
                    assessment.status,
                    *(_feature_cell(assessment, signal) for signal in signals),
                ]
                for assessment in assessments
            ],
        )
    )
    print("\nNon-Low triggers:")
    non_low = [item for item in assessments if item.risk.level is not RiskLevel.LOW]
    if not non_low:
        print("  none")
    for assessment in non_low:
        print(f"  {assessment.risk.machine_id} ({assessment.risk.level.value})")
        for trigger in assessment.risk.triggers:
            print(
                f"    {trigger.level.value}: {trigger.signal} {trigger.metric} "
                f"{trigger.value:+.3f} (threshold {trigger.threshold:.3f})"
            )


def _historical_intervals(
    payload: dict[str, object], cfg: AppConfig
) -> dict[str, list[tuple[date, date]]]:
    intervals = {machine.machine_id: [] for machine in cfg.machines}
    planned = payload["planned_failures"]
    assert isinstance(planned, list)
    for item in planned:
        assert isinstance(item, dict)
        intervals[str(item["machine_id"])].append(
            (
                date.fromisoformat(str(item["drift_start"])),
                date.fromisoformat(str(item["failure_date"])) + timedelta(days=7),
            )
        )
    live = payload.get("live_scenario")
    if isinstance(live, dict):
        intervals[str(live["machine_id"])].append(
            (
                date.fromisoformat(str(live["drift_start"])),
                date.fromisoformat(str(live["end_date"])),
            )
        )
    return intervals


def _healthy_false_alarms(
    assess: Callable[[str, date], RiskAssessment],
    cfg: AppConfig,
    payload: dict[str, object],
) -> tuple[int, int]:
    params = payload["params"]
    assert isinstance(params, dict)
    end_date = date.fromisoformat(str(params["end_date"]))
    timeline_start = end_date - timedelta(days=int(params["days"]) - 1)
    required_days = cfg.thresholds.window_days + cfg.thresholds.baseline_days
    first_as_of = timeline_start + timedelta(days=required_days - 1)
    intervals = _historical_intervals(payload, cfg)
    healthy_days = 0
    false_alarms = 0
    for machine in cfg.machines:
        as_of = first_as_of
        while as_of <= end_date:
            window_start = as_of - timedelta(days=cfg.thresholds.window_days - 1)
            affected = any(
                drift_start <= as_of and window_start <= affected_end
                for drift_start, affected_end in intervals[machine.machine_id]
            )
            if not affected:
                healthy_days += 1
                if assess(machine.machine_id, as_of).risk.level is not RiskLevel.LOW:
                    false_alarms += 1
            as_of += timedelta(days=1)
    return false_alarms, healthy_days


def _show_replay(repo: Repository, cfg: AppConfig, ground_truth_path: Path) -> None:
    payload = json.loads(ground_truth_path.read_text(encoding="utf-8"))
    scorer = RiskScorer(repo, cfg)
    assessment_cache: dict[tuple[str, date], RiskAssessment] = {}
    status_counts: Counter[str] = Counter()

    def assess(machine_id: str, as_of: date) -> RiskAssessment:
        key = (machine_id, as_of)
        if key not in assessment_cache:
            assessment_cache[key] = scorer.assess(machine_id, as_of)
            status_counts[assessment_cache[key].status] += 1
        return assessment_cache[key]

    planned = payload["planned_failures"]
    assert isinstance(planned, list)
    rows: list[list[str]] = []
    detected = 0
    warning_days_by_mode: dict[str, list[int]] = defaultdict(list)
    for item in planned:
        assert isinstance(item, dict)
        failure_date = date.fromisoformat(str(item["failure_date"]))
        drift_start = date.fromisoformat(str(item["drift_start"]))
        machine_id = str(item["machine_id"])
        mode_id = str(item["failure_mode"])
        before_failure = assess(machine_id, failure_date - timedelta(days=1))
        is_detected = before_failure.risk.level is not RiskLevel.LOW
        detected += int(is_detected)
        effect_signals = {effect.signal for effect in cfg.get_failure_mode(mode_id).signal_effects}
        signal_match = any(
            trigger.signal in effect_signals for trigger in before_failure.risk.triggers
        )
        first_detection: date | None = None
        as_of = drift_start
        while as_of <= failure_date:
            if assess(machine_id, as_of).risk.level is not RiskLevel.LOW:
                first_detection = as_of
                break
            as_of += timedelta(days=1)
        days = None if first_detection is None else (failure_date - first_detection).days
        if days is not None:
            warning_days_by_mode[mode_id].append(days)
        rows.append(
            [
                str(item["event_id"]),
                machine_id,
                mode_id,
                before_failure.risk.level.value,
                "-" if days is None else str(days),
                "yes" if signal_match else "no",
            ]
        )

    print("Historical failure replay")
    print(
        _table(
            ["event", "machine", "mode", "level at failure-1", "warning days", "signal match"],
            rows,
        )
    )
    rate = detected / len(planned) * 100.0 if planned else 0.0
    print("\nReplay summary:")
    print(f"  detection at failure-1: {detected}/{len(planned)} ({rate:.1f}%)")
    print("\nDays of warning by failure mode:")
    print(
        _table(
            ["mode", "min", "median", "max"],
            [
                [
                    mode.id,
                    "-"
                    if not warning_days_by_mode[mode.id]
                    else str(min(warning_days_by_mode[mode.id])),
                    "-"
                    if not warning_days_by_mode[mode.id]
                    else f"{median(warning_days_by_mode[mode.id]):g}",
                    "-"
                    if not warning_days_by_mode[mode.id]
                    else str(max(warning_days_by_mode[mode.id])),
                ]
                for mode in cfg.failure_modes
            ],
        )
    )

    live = payload.get("live_scenario")
    final_false_alarms = 0
    if isinstance(live, dict):
        live_machine = str(live["machine_id"])
        end_date = date.fromisoformat(str(live["end_date"]))
        for offset in range(13, -1, -1):
            as_of = end_date - timedelta(days=offset)
            for machine in cfg.machines:
                if machine.machine_id == live_machine:
                    continue
                if assess(machine.machine_id, as_of).risk.level is not RiskLevel.LOW:
                    final_false_alarms += 1
        print(f"  final-14-day non-live false alarms: {final_false_alarms}")

        assessment = assess(live_machine, end_date)
        print(f"\nLive scenario: {live_machine} on {end_date} — {assessment.risk.level.value}")
        live_rows = [
            [
                signal,
                f"{feature.baseline_mean:.3f}",
                f"{feature.recent_mean:.3f}",
                f"{feature.latest_value:.3f}",
                f"{feature.pct_change_vs_baseline:+.3f}",
                f"{feature.slope_pct_per_day:+.3f}",
            ]
            for signal, feature in assessment.features.items()
        ]
        print(
            _table(
                ["signal", "baseline", "recent", "latest", "change %", "slope %/day"],
                live_rows,
            )
        )

    healthy_alarms, healthy_days = _healthy_false_alarms(assess, cfg, payload)
    healthy_rate = healthy_alarms / healthy_days * 100.0 if healthy_days else 0.0
    print(f"  healthy-period false alarms: {healthy_alarms}/{healthy_days} ({healthy_rate:.2f}%)")
    print("  assessment statuses:")
    for status in ("ok", "config_baseline", "recently_serviced"):
        print(f"    {status}: {status_counts[status]}")


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    cfg = get_app_config()
    settings = get_settings()
    with get_repository(settings) as repository:
        if args.replay:
            _show_replay(repository, cfg, settings.data_dir / "ground_truth.json")
        else:
            _show_fleet(repository, cfg, args.as_of)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
