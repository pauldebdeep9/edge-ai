"""Evaluate retrieval against planted warning links and failure modes."""

import argparse
import json
import runpy
import tempfile
from collections.abc import Sequence
from dataclasses import dataclass
from datetime import UTC, date, datetime, timedelta
from pathlib import Path
from statistics import mean
from typing import cast

from maint_rec.config import get_settings
from maint_rec.config_loader import get_app_config
from maint_rec.db import Repository, get_repository
from maint_rec.llm import Embedder, OllamaEmbedder
from maint_rec.retrieval import Indexer, Retriever, build_query
from maint_rec.risk import RiskScorer


@dataclass(frozen=True, slots=True)
class EvaluationRow:
    label: str
    mode: str
    eligible: bool
    incident_hit: bool | None
    top1_mode: bool | None
    comment_hits: int
    comment_total: int
    comment_recall: float | None


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--fake-embedder",
        action="store_true",
        help="build a temporary index with deterministic test embeddings",
    )
    return parser


def _fake_embedder() -> Embedder:
    path = Path(__file__).resolve().parents[1] / "tests" / "fakes.py"
    factory = runpy.run_path(str(path))["FakeEmbedder"]
    return cast(Embedder, factory())


def _table(headers: list[str], rows: list[list[str]]) -> str:
    widths = [
        max(len(header), *(len(row[index]) for row in rows)) for index, header in enumerate(headers)
    ]
    return "\n".join(
        [
            "  ".join(header.ljust(widths[index]) for index, header in enumerate(headers)),
            "  ".join("-" * width for width in widths),
            *[
                "  ".join(value.ljust(widths[index]) for index, value in enumerate(row))
                for row in rows
            ],
        ]
    )


def _warning_ids_in_window(
    repo: Repository,
    warning_ids: list[str],
    start: datetime,
    end: datetime,
) -> set[str]:
    return {
        comment_id
        for comment_id in warning_ids
        if start <= repo.get_comment(comment_id).timestamp <= end
    }


def _evaluate_one(
    *,
    label: str,
    mode: str,
    machine_id: str,
    as_of: date,
    before: date,
    warning_ids: list[str],
    repo: Repository,
    retriever: Retriever,
    scorer: RiskScorer,
    comment_window_days: int,
    top_k_incidents: int,
    top_k_comments: int,
) -> EvaluationRow:
    cfg = scorer.cfg
    machine = cfg.get_machine(machine_id)
    end = datetime.combine(as_of, datetime.max.time(), tzinfo=UTC)
    recent_comments = repo.get_recent_comments(machine_id, comment_window_days, end=end)
    query = build_query(
        cfg.machine_types[machine.type].name,
        scorer.assess(machine_id, as_of),
        recent_comments,
    )
    incidents = retriever.similar_incidents(
        query,
        machine.type,
        top_k_incidents,
        before=before,
    )
    comments = retriever.relevant_comments(
        query,
        machine_id,
        top_k_comments,
        comment_window_days,
        end=end,
    )
    eligible = any(
        event.machine_type == machine.type and event.failure_mode == mode and event.date < before
        for event in repo.list_failures()
    )
    expected = _warning_ids_in_window(
        repo,
        warning_ids,
        end - timedelta(days=comment_window_days),
        end,
    )
    retrieved_comment_ids = {comment.comment_id for comment in comments}
    comment_hits = len(expected & retrieved_comment_ids)
    return EvaluationRow(
        label=label,
        mode=mode,
        eligible=eligible,
        incident_hit=(any(item.failure_mode == mode for item in incidents) if eligible else None),
        top1_mode=(bool(incidents and incidents[0].failure_mode == mode) if eligible else None),
        comment_hits=comment_hits,
        comment_total=len(expected),
        comment_recall=comment_hits / len(expected) if expected else None,
    )


def _format_bool(value: bool | None) -> str:
    return "-" if value is None else "yes" if value else "no"


def _print_results(rows: list[EvaluationRow], live: EvaluationRow) -> None:
    print("Historical retrieval evaluation")
    print(
        _table(
            ["event", "mode", "eligible", "hit@k", "top-1", "comments", "recall@k"],
            [
                [
                    row.label,
                    row.mode,
                    "yes" if row.eligible else "no",
                    _format_bool(row.incident_hit),
                    _format_bool(row.top1_mode),
                    f"{row.comment_hits}/{row.comment_total}",
                    "-" if row.comment_recall is None else f"{row.comment_recall:.2f}",
                ]
                for row in rows
            ],
        )
    )
    eligible = [row for row in rows if row.eligible]
    recalls = [row.comment_recall for row in rows if row.comment_recall is not None]
    hit_rate = mean(bool(row.incident_hit) for row in eligible) if eligible else 0.0
    top1_rate = mean(bool(row.top1_mode) for row in eligible) if eligible else 0.0
    recall = mean(recalls) if recalls else 0.0
    print("\nHistorical summary:")
    print(f"  incident eligible events: {len(eligible)}/{len(rows)}")
    print(f"  incident hit@k: {hit_rate:.1%}")
    print(f"  incident top-1 mode accuracy: {top1_rate:.1%}")
    print(f"  mean comment recall@k: {recall:.1%}")
    print("\nLive scenario:")
    print(f"  mode: {live.mode}")
    print(f"  incident eligible: {'yes' if live.eligible else 'no'}")
    print(f"  incident hit@k: {_format_bool(live.incident_hit)}")
    print(f"  incident top-1 mode: {_format_bool(live.top1_mode)}")
    print(f"  comment warnings retrieved: {live.comment_hits}/{live.comment_total}")
    print(
        "  comment recall@k: "
        + ("-" if live.comment_recall is None else f"{live.comment_recall:.1%}")
    )


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    settings = get_settings()
    cfg = get_app_config()
    payload = json.loads((settings.data_dir / "ground_truth.json").read_text(encoding="utf-8"))
    temporary: tempfile.TemporaryDirectory[str] | None = None
    embedder: Embedder
    if args.fake_embedder:
        temporary = tempfile.TemporaryDirectory(prefix="maintenance-retrieval-")
        chroma_dir = Path(temporary.name)
        embedder = _fake_embedder()
        model_name = "fake-embedder"
        print("Using FakeEmbedder; offline evaluation metrics are expected to be lower.")
    else:
        chroma_dir = settings.chroma_dir
        embedder = OllamaEmbedder.from_settings(settings)
        model_name = settings.embed_model

    try:
        with get_repository(settings) as repository:
            if args.fake_embedder:
                Indexer(chroma_dir, embedder, model_name, cfg).build(repository)
            retriever = Retriever(chroma_dir, embedder, model_name, repository)
            scorer = RiskScorer(repository, cfg)
            rows = []
            for item in payload["planned_failures"]:
                failure_date = date.fromisoformat(item["failure_date"])
                rows.append(
                    _evaluate_one(
                        label=item["event_id"],
                        mode=item["failure_mode"],
                        machine_id=item["machine_id"],
                        as_of=failure_date - timedelta(days=1),
                        before=failure_date,
                        warning_ids=item["warning_comment_ids"],
                        repo=repository,
                        retriever=retriever,
                        scorer=scorer,
                        comment_window_days=settings.comment_window_days,
                        top_k_incidents=settings.top_k_incidents,
                        top_k_comments=settings.top_k_comments,
                    )
                )
            live_truth = payload["live_scenario"]
            live_end = date.fromisoformat(live_truth["end_date"])
            live = _evaluate_one(
                label="LIVE",
                mode=live_truth["failure_mode"],
                machine_id=live_truth["machine_id"],
                as_of=live_end,
                before=live_end + timedelta(days=1),
                warning_ids=payload["live_warning_comment_ids"],
                repo=repository,
                retriever=retriever,
                scorer=scorer,
                comment_window_days=settings.comment_window_days,
                top_k_incidents=settings.top_k_incidents,
                top_k_comments=settings.top_k_comments,
            )
            _print_results(rows, live)
    finally:
        close = getattr(embedder, "close", None)
        if callable(close):
            close()
        if temporary is not None:
            temporary.cleanup()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
