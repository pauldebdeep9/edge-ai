"""Build the persistent failure-event and operator-comment retrieval indexes."""

import argparse
import runpy
import time
from collections.abc import Sequence
from pathlib import Path
from typing import cast

from maint_rec.config import ensure_dirs, get_settings
from maint_rec.db import get_repository
from maint_rec.llm import Embedder, OllamaEmbedder
from maint_rec.retrieval import Indexer


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reset", dest="reset", action="store_true", default=True)
    parser.add_argument("--no-reset", dest="reset", action="store_false")
    parser.add_argument(
        "--fake-embedder",
        action="store_true",
        help="use deterministic test embeddings instead of Ollama",
    )
    return parser


def _fake_embedder() -> Embedder:
    path = Path(__file__).resolve().parents[1] / "tests" / "fakes.py"
    factory = runpy.run_path(str(path))["FakeEmbedder"]
    return cast(Embedder, factory())


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    settings = get_settings()
    ensure_dirs(settings)
    embedder = _fake_embedder() if args.fake_embedder else OllamaEmbedder.from_settings(settings)
    model_name = "fake-embedder" if args.fake_embedder else settings.embed_model
    started = time.perf_counter()
    try:
        with get_repository(settings) as repository:
            indexer = Indexer(settings.chroma_dir, embedder, model_name)
            counts = indexer.build(repository, reset=args.reset)
        elapsed = time.perf_counter() - started
        print(f"Index directory: {settings.chroma_dir}")
        print(f"Embedding model: {model_name}")
        print(f"Embedding dimension: {embedder.dimension}")
        print(f"Failure events: {counts['failure_events']}")
        print(f"Operator comments: {counts['operator_comments']}")
        print(f"Elapsed: {elapsed:.2f} s")
    finally:
        close = getattr(embedder, "close", None)
        if callable(close):
            close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
