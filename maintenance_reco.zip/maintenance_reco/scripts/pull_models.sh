#!/usr/bin/env bash
set -euo pipefail

env_value() {
    local key="$1"
    local fallback="$2"
    local value=""
    if [[ -f .env ]]; then
        value="$(sed -n "s/^${key}=//p" .env | tail -n 1)"
        value="${value%\"}"
        value="${value#\"}"
        value="${value%\'}"
        value="${value#\'}"
    fi
    printf '%s' "${value:-$fallback}"
}

if ! command -v ollama >/dev/null 2>&1; then
    echo "Ollama is not installed or is not on PATH." >&2
    exit 1
fi

base_url="$(env_value MAINT_OLLAMA_BASE_URL http://localhost:11434)"
llm_model="$(env_value MAINT_LLM_MODEL llama3.1:8b)"
embed_model="$(env_value MAINT_EMBED_MODEL nomic-embed-text)"

if ! curl --fail --silent --show-error --max-time 5 "${base_url%/}/api/version" >/dev/null; then
    echo "Ollama is not reachable at ${base_url}; is 'ollama serve' running?" >&2
    exit 1
fi

echo "Pulling chat model: ${llm_model}"
ollama pull "${llm_model}"
echo "Pulling embedding model: ${embed_model}"
ollama pull "${embed_model}"
