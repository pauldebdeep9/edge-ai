"""Initialize and seed the maintenance recommendation SQLite database."""

import argparse
import logging
from collections.abc import Sequence
from pathlib import Path

from maint_rec.config import ensure_dirs, get_settings
from maint_rec.config_loader import get_app_config
from maint_rec.db import Repository

LOGGER = logging.getLogger(__name__)


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reset", action="store_true", help="drop and recreate all tables")
    parser.add_argument("--db", type=Path, help="override the configured database path")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    """Initialize the selected database and seed its machine records."""
    args = _parser().parse_args(argv)
    settings = get_settings()
    if args.db is None:
        ensure_dirs(settings)
        db_path = settings.db_path
    else:
        db_path = args.db.expanduser().resolve()
        db_path.parent.mkdir(parents=True, exist_ok=True)

    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    with Repository(db_path) as repository:
        if args.reset:
            LOGGER.info("Resetting database schema")
            repository.reset()
        else:
            LOGGER.info("Initializing database schema")
            repository.init()
        repository.upsert_machines(get_app_config().machines)
        counts = repository.counts()

    print(f"Database: {db_path}\nCounts: {counts}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
