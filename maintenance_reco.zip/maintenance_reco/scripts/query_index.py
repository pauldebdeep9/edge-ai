"""Query the retrieval index directly or preview the live CNC-02 context."""

import argparse
import time
from collections.abc import Sequence
from datetime import UTC, date, datetime

from maint_rec.config import get_settings
from maint_rec.config_loader import get_app_config
from maint_rec.db import get_repository
from maint_rec.llm import OllamaEmbedder
from maint_rec.recommend.schemas import Comment, Incident
from maint_rec.retrieval import Retriever, build_query
from maint_rec.risk import RiskScorer


def _date(value: str) -> date:
    try:
        return date.fromisoformat(value)
    except ValueError as error:
        raise argparse.ArgumentTypeError(f"invalid ISO date: {value}") from error


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("query", nargs="?", help="plain-language search query")
    parser.add_argument("--machine-type", default="cnc_mill")
    parser.add_argument("--machine", default="CNC-02")
    parser.add_argument("--k", type=int, default=5)
    parser.add_argument("--before", type=_date)
    parser.add_argument("--comments", action="store_true", help="search comments")
    parser.add_argument("--live", action="store_true", help="preview live CNC-02 evidence")
    return parser


def _preview(text: str, limit: int = 120) -> str:
    return text if len(text) <= limit else text[: limit - 3] + "..."


def _print_incidents(items: list[Incident]) -> None:
    print("Incidents:")
    if not items:
        print("  none")
    for item in items:
        print(
            f"  {item.similarity:.4f}  {item.event_id}  {item.date}  "
            f"{item.failure_mode}  {_preview(item.symptoms)}"
        )


def _print_comments(items: list[Comment]) -> None:
    print("Comments:")
    if not items:
        print("  none")
    for item in items:
        print(
            f"  {item.similarity:.4f}  {item.comment_id}  {item.timestamp.isoformat()}  "
            f"{_preview(item.comment_text)}"
        )


def main(argv: Sequence[str] | None = None) -> int:
    parser = _parser()
    args = parser.parse_args(argv)
    if not args.live and not args.query:
        parser.error("query text is required unless --live is used")

    settings = get_settings()
    cfg = get_app_config()
    with get_repository(settings) as repository, OllamaEmbedder.from_settings(settings) as embedder:
        retriever = Retriever(settings.chroma_dir, embedder, settings.embed_model, repository)
        if args.live:
            machine = cfg.get_machine("CNC-02")
            as_of = repository.get_latest_date(machine.machine_id)
            if as_of is None:
                raise ValueError("CNC-02 has no sensor data")
            assessment = RiskScorer(repository, cfg).assess(machine.machine_id, as_of)
            end = datetime.combine(as_of, datetime.max.time(), tzinfo=UTC)
            recent = repository.get_recent_comments(
                machine.machine_id,
                settings.comment_window_days,
                end=end,
            )
            query = build_query(
                cfg.machine_types[machine.type].name,
                assessment,
                recent,
            )
            print("Live query:")
            print(query)
            started = time.perf_counter()
            incidents = retriever.similar_incidents(
                query,
                machine.type,
                settings.top_k_incidents,
                before=as_of + date.resolution,
            )
            incident_ms = (time.perf_counter() - started) * 1000.0
            started = time.perf_counter()
            comments = retriever.relevant_comments(
                query,
                machine.machine_id,
                settings.top_k_comments,
                settings.comment_window_days,
                end=end,
            )
            comment_ms = (time.perf_counter() - started) * 1000.0
            _print_incidents(incidents)
            _print_comments(comments)
            print(f"Incident query latency (embed + search): {incident_ms:.1f} ms")
            print(f"Comment query latency (embed + search): {comment_ms:.1f} ms")
        elif args.comments:
            started = time.perf_counter()
            comments = retriever.relevant_comments(
                args.query,
                args.machine,
                args.k,
                settings.comment_window_days,
            )
            _print_comments(comments)
            print(
                f"Query latency (embed + search): {(time.perf_counter() - started) * 1000:.1f} ms"
            )
        else:
            started = time.perf_counter()
            incidents = retriever.similar_incidents(
                args.query,
                args.machine_type,
                args.k,
                before=args.before,
            )
            _print_incidents(incidents)
            print(
                f"Query latency (embed + search): {(time.perf_counter() - started) * 1000:.1f} ms"
            )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
