"""Generate the deterministic synthetic maintenance dataset."""

import argparse
import logging
from collections.abc import Sequence
from datetime import date
from pathlib import Path

from maint_rec.config import Settings, get_settings
from maint_rec.datagen import GenParams, build_dataset
from maint_rec.db import get_repository


def _date_arg(value: str) -> date:
    try:
        return date.fromisoformat(value)
    except ValueError as error:
        raise argparse.ArgumentTypeError("expected an ISO date (YYYY-MM-DD)") from error


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--end-date", type=_date_arg, default=date(2026, 9, 20))
    parser.add_argument("--days", type=int, default=240)
    parser.add_argument("--n-failures", type=int, default=20)
    parser.add_argument("--db", type=Path, help="override the configured database path")
    parser.add_argument("--no-live", action="store_true", help="skip the unfinished live fault")
    parser.add_argument("--no-comments", action="store_true", help="skip operator comments")
    return parser


def _settings_for_db(path: Path | None) -> Settings:
    if path is None:
        return get_settings()
    db_path = path.expanduser().resolve()
    return Settings(
        data_dir=db_path.parent,
        db_path=db_path,
        chroma_dir=db_path.parent / "chroma",
    )


def main(argv: Sequence[str] | None = None) -> int:
    """Generate data, replace database contents, and print a compact summary."""
    args = _parser().parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    settings = _settings_for_db(args.db)
    params = GenParams(
        seed=args.seed,
        end_date=args.end_date,
        days=args.days,
        n_failures=args.n_failures,
        live_enabled=not args.no_live,
        comments_enabled=not args.no_comments,
        ground_truth_path=settings.data_dir / "ground_truth.json",
    )
    with get_repository(settings) as repository:
        summary = build_dataset(params, repository)

    print("Table counts:")
    for table, count in summary.table_counts.items():
        print(f"  {table}: {count}")
    print("\nHistorical events:")
    print("  event_id  machine  failure_mode          drift_start  failure_date")
    for item, event in zip(summary.planned_failures, summary.failure_events, strict=True):
        print(
            f"  {event.event_id:<9} {event.machine_id:<8} {event.failure_mode:<21} "
            f"{item.drift_start}   {item.failure_date}"
        )
    print("\nEvents per mode:")
    for mode, count in summary.events_per_mode.items():
        print(f"  {mode}: {count}")
    print("\nComments per category:")
    for category, count in summary.comment_counts.items():
        print(f"  {category}: {count}")
    print("\nComments per machine:")
    for machine_id, count in summary.comments_per_machine.items():
        print(f"  {machine_id}: {count}")
    print(f"\n{params.live_machine_id} final 14 days — vibration_rms:")
    reference = (
        summary.live_scenario.live_reference_mean if summary.live_scenario is not None else None
    )
    if reference is not None:
        print(f"  live_reference_mean: {reference:.3f}")
        print("  date        value  change_vs_reference")
    for row in summary.live_sensor_tail:
        change = (
            "n/a" if reference is None else f"{(row.vibration_rms / reference - 1.0) * 100:+.1f}%"
        )
        print(f"  {row.date}  {row.vibration_rms:.3f}  {change:>8}")
    print(f"\nLatest 5 comments on {params.live_machine_id}:")
    recent = [
        comment for comment in summary.comments if comment.machine_id == params.live_machine_id
    ][-5:]
    for comment in reversed(recent):
        print(
            f"  {comment.timestamp.isoformat()}  {comment.shift}  "
            f"{comment.operator}: {comment.comment_text}"
        )
    if not recent:
        print("  (none)")
    print(f"\nGround truth: {summary.ground_truth_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
