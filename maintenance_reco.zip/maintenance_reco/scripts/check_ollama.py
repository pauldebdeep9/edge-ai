"""Run live Ollama embedding and structured-chat smoke checks."""

import argparse
import asyncio
import json
import math
from collections.abc import Sequence
from datetime import UTC, datetime

from maint_rec.config import get_settings
from maint_rec.config_loader import get_app_config
from maint_rec.db import get_repository
from maint_rec.llm import LLMError, OllamaClient, OllamaEmbedder
from maint_rec.llm.prompts import build_recommendation_messages, render_context
from maint_rec.recommend.schemas import (
    Comment,
    Incident,
    RecommendationDraft,
    RiskLevel,
    RiskResult,
    RiskTrigger,
)


def _cosine(left: list[float], right: list[float]) -> float:
    numerator = sum(a * b for a, b in zip(left, right, strict=True))
    left_norm = math.sqrt(sum(value * value for value in left))
    right_norm = math.sqrt(sum(value * value for value in right))
    return numerator / (left_norm * right_norm)


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--show-prompt", action="store_true", help="print the rendered context")
    return parser


async def _run(show_prompt: bool) -> int:
    settings = get_settings()
    cfg = get_app_config()
    async with OllamaClient.from_settings(settings) as client:
        if not await client.is_alive():
            print(
                f"Ollama is unavailable at {settings.ollama_base_url}; is `ollama serve` running?"
            )
            return 1
        version = await client.version()
        missing = await client.missing_models([settings.llm_model, settings.embed_model])
        print(f"Ollama server: reachable (version {version or 'unknown'})")
        if missing:
            print(f"Missing models: {', '.join(missing)}. Run `make models` first.")
            return 1
        print(f"Models present: {settings.llm_model}, {settings.embed_model}")

        documents = [
            "Grinding noise at high speed on spindle bearing",
            "Coolant leak near hydraulic seal",
            "Belt squeal on conveyor startup",
        ]
        query_text = "bearing rumble and rising vibration"
        with OllamaEmbedder.from_settings(settings) as embedder:
            document_vectors = embedder.embed_documents(documents)
            query_vector = embedder.embed_query(query_text)
            similarities = [_cosine(query_vector, vector) for vector in document_vectors]
            print(f"Embedding dimension: {embedder.dimension}")
            print("Embedding cosine similarities:")
            for document, similarity in sorted(
                zip(documents, similarities, strict=True),
                key=lambda item: item[1],
                reverse=True,
            ):
                print(f"  {similarity:.4f}  {document}")

        machine = cfg.get_machine("CNC-02")
        risk = RiskResult(
            machine_id=machine.machine_id,
            level=RiskLevel.HIGH,
            triggers=[
                RiskTrigger(
                    signal="vibration_rms",
                    metric="pct_change_vs_baseline",
                    value=60.0,
                    threshold=50.0,
                    level=RiskLevel.HIGH,
                )
            ],
            window_days=14,
            computed_at=datetime(2026, 9, 20, 12, 0, tzinfo=UTC),
        )
        with get_repository(settings) as repository:
            incidents = [
                Incident.model_validate(event.model_dump() | {"similarity": None})
                for event in repository.list_failures()
                if event.failure_mode == "bearing_wear"
            ]
            comments = [
                Comment.model_validate(comment.model_dump() | {"similarity": None})
                for comment in repository.get_recent_comments("CNC-02", days=10)
            ]
        candidate_modes = cfg.modes_for_type(machine.type)
        machine_type_name = cfg.machine_types[machine.type].name
        messages = build_recommendation_messages(
            machine,
            machine_type_name,
            risk,
            candidate_modes,
            incidents,
            comments,
        )
        print(
            "RiskResult note: hand-made for the WBS-04 smoke check; "
            "the deterministic scorer arrives in WBS-05."
        )
        if show_prompt:
            print("\n--- RENDERED PROMPT ---")
            print(
                render_context(
                    machine,
                    machine_type_name,
                    risk,
                    candidate_modes,
                    incidents,
                    comments,
                )
            )
            print("--- END PROMPT ---\n")
        draft, meta = await client.chat_json(messages, RecommendationDraft)
        print("Recommendation draft:")
        print(json.dumps(draft.model_dump(mode="json"), indent=2))
        print(f"Attempts: {meta.attempts}")
        print(f"Latency: {meta.latency_ms} ms")
        print(f"Tokens: prompt={meta.prompt_tokens}, completion={meta.completion_tokens}")
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        return asyncio.run(_run(args.show_prompt))
    except LLMError as error:
        print(f"Ollama check failed: {error}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
