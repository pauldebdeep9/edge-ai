"""Deterministic test doubles shared by later work packages."""

import hashlib
import math
import re
from collections import deque
from collections.abc import Iterable

from pydantic import BaseModel, ValidationError

from maint_rec.llm.base import ChatMeta, LLMInvalidOutputError, ModelT


class FakeLLMClient:
    """Queue-backed structured-output client that records every prompt attempt."""

    def __init__(
        self,
        responses: Iterable[BaseModel | str | Exception],
        *,
        model: str = "fake-maintenance-model",
        max_retries: int = 1,
    ) -> None:
        self.model = model
        self.max_retries = max_retries
        self._responses = deque(responses)
        self.messages_received: list[list[dict[str, str]]] = []

    async def is_alive(self) -> bool:
        return True

    async def chat_json(
        self, messages: list[dict[str, str]], schema: type[ModelT]
    ) -> tuple[ModelT, ChatMeta]:
        working = [dict(message) for message in messages]
        raw_output = ""
        errors: list[str] = []
        for attempt in range(1, self.max_retries + 2):
            self.messages_received.append([dict(message) for message in working])
            if not self._responses:
                raise RuntimeError("FakeLLMClient response queue is empty")
            response = self._responses.popleft()
            if isinstance(response, Exception):
                raise response
            if isinstance(response, BaseModel):
                result = schema.model_validate(response.model_dump())
            else:
                raw_output = response
                try:
                    result = schema.model_validate_json(raw_output)
                except ValidationError as error:
                    errors = [item["msg"] for item in error.errors(include_url=False)]
                    if attempt > self.max_retries:
                        raise LLMInvalidOutputError(
                            f"fake output invalid after {attempt} attempts",
                            raw_output=raw_output,
                            validation_errors=errors,
                        ) from error
                    working.extend(
                        [
                            {"role": "assistant", "content": raw_output},
                            {
                                "role": "user",
                                "content": (
                                    f"Your previous response was invalid: {'; '.join(errors)}. "
                                    "Return only a JSON object that matches the schema."
                                ),
                            },
                        ]
                    )
                    continue
            return result, ChatMeta(
                model=self.model,
                latency_ms=5 * attempt,
                attempts=attempt,
                prompt_tokens=100,
                completion_tokens=50,
            )
        raise AssertionError("unreachable")


class FakeEmbedder:
    """Hashed, normalized bag-of-words embeddings without external dependencies."""

    def __init__(
        self,
        *,
        dimension: int = 64,
        document_prefix: str = "search_document: ",
        query_prefix: str = "search_query: ",
    ) -> None:
        self.dimension = dimension
        self.document_prefix = document_prefix
        self.query_prefix = query_prefix

    def embed_documents(self, texts: list[str]) -> list[list[float]]:
        return [self._embed(text) for text in texts]

    def embed_query(self, text: str) -> list[float]:
        return self._embed(text)

    def _embed(self, text: str) -> list[float]:
        vector = [0.0] * self.dimension
        for token in re.findall(r"[a-z0-9]+", text.lower()):
            digest = hashlib.sha256(token.encode()).digest()
            index = int.from_bytes(digest[:8], "big") % self.dimension
            vector[index] += 1.0
        norm = math.sqrt(sum(value * value for value in vector))
        return vector if norm == 0 else [value / norm for value in vector]
