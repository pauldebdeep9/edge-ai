from pathlib import Path

import pytest

from maint_rec.config import Settings, ensure_dirs


def test_defaults_load() -> None:
    settings = Settings()

    assert settings.llm_model == "llama3.1:8b"
    assert settings.llm_timeout_s == 120.0
    assert settings.llm_temperature == 0.1
    assert settings.llm_num_ctx == 8192
    assert settings.llm_seed == 42
    assert settings.llm_keep_alive == "30m"
    assert settings.llm_max_retries == 1
    assert settings.embed_batch_size == 32
    assert settings.comment_window_days == 14
    assert settings.db_path == settings.project_root / "data" / "maintenance.db"
    assert settings.chroma_dir == settings.project_root / "data" / "chroma"


def test_environment_overrides_llm_model(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("MAINT_LLM_MODEL", "test-model")

    assert Settings().llm_model == "test-model"


def test_relative_db_path_resolves_under_project_root(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("MAINT_PROJECT_ROOT", str(tmp_path))
    monkeypatch.setenv("MAINT_DB_PATH", "state/demo.db")

    assert Settings().db_path == tmp_path / "state" / "demo.db"


def test_ensure_dirs_creates_runtime_folders(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    settings = Settings()
    monkeypatch.setattr(settings, "data_dir", tmp_path / "runtime")
    monkeypatch.setattr(settings, "chroma_dir", tmp_path / "runtime" / "chroma")

    ensure_dirs(settings)

    assert settings.data_dir.is_dir()
    assert settings.chroma_dir.is_dir()
