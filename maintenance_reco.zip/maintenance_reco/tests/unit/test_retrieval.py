from collections.abc import Callable
from datetime import UTC, date, datetime
from pathlib import Path

import pytest
from fakes import FakeEmbedder

from maint_rec.db import Repository
from maint_rec.recommend.schemas import FailureEvent, OperatorComment, SensorDaily
from maint_rec.retrieval import Indexer, IndexMismatchError, Retriever


def _seed_repository(
    repo: Repository,
    make_failure: Callable[..., FailureEvent],
    make_comment: Callable[..., OperatorComment],
    make_sensor_rows: Callable[..., list[SensorDaily]],
) -> None:
    repo.insert_sensor_rows(make_sensor_rows(start=date(2026, 1, 1), n_days=45))
    repo.insert_failure_events(
        [
            make_failure(
                event_id="EVT-001",
                machine_id="CNC-01",
                machine_type="cnc_mill",
                date=date(2026, 1, 10),
                failure_mode="bearing_wear",
                symptoms="Grinding bearing noise and vibration",
            ),
            make_failure(
                event_id="EVT-002",
                machine_id="CNC-02",
                machine_type="cnc_mill",
                date=date(2026, 1, 20),
                failure_mode="spindle_misalignment",
                symptoms="Poor finish and spindle runout",
            ),
            make_failure(
                event_id="EVT-003",
                machine_id="CNV-01",
                machine_type="conveyor_drive",
                date=date(2026, 1, 15),
                failure_mode="belt_slippage",
                symptoms="Belt squeal at startup",
            ),
        ]
    )
    repo.insert_comments(
        [
            make_comment(
                comment_id="CMT-001",
                machine_id="CNC-01",
                timestamp=datetime(2026, 1, 1, 12, 0, tzinfo=UTC),
                comment_text="Routine cleanup completed",
            ),
            make_comment(
                comment_id="CMT-002",
                machine_id="CNC-01",
                timestamp=datetime(2026, 1, 18, 12, 0, tzinfo=UTC),
                comment_text="Grinding bearing noise getting worse",
            ),
            make_comment(
                comment_id="CMT-003",
                machine_id="CNC-02",
                timestamp=datetime(2026, 1, 19, 12, 0, tzinfo=UTC),
                comment_text="Spindle finish looks uneven",
            ),
        ]
    )


@pytest.fixture
def retrieval_env(
    repo: Repository,
    tmp_path: Path,
    make_failure: Callable[..., FailureEvent],
    make_comment: Callable[..., OperatorComment],
    make_sensor_rows: Callable[..., list[SensorDaily]],
) -> tuple[Repository, Path, FakeEmbedder, Indexer, Retriever]:
    _seed_repository(repo, make_failure, make_comment, make_sensor_rows)
    chroma_dir = tmp_path / "chroma"
    embedder = FakeEmbedder()
    indexer = Indexer(chroma_dir, embedder, "fake-embedder")
    indexer.build(repo)
    retriever = Retriever(chroma_dir, embedder, "fake-embedder", repo)
    return repo, chroma_dir, embedder, indexer, retriever


def test_build_counts_idempotency_and_reset(
    retrieval_env: tuple[Repository, Path, FakeEmbedder, Indexer, Retriever],
    make_comment: Callable[..., OperatorComment],
) -> None:
    repo, _, _, indexer, _ = retrieval_env
    expected = {"failure_events": 3, "operator_comments": 3}

    assert indexer.counts() == expected
    assert indexer.build(repo, reset=False) == expected
    ghost = make_comment(comment_id="CMT-999", comment_text="temporary indexed note")
    indexer.add_comment(ghost, "cnc_mill")
    assert indexer.counts()["operator_comments"] == 4
    assert indexer.build(repo, reset=True) == expected


def test_incident_filters_machine_type_and_strict_before_date(
    retrieval_env: tuple[Repository, Path, FakeEmbedder, Indexer, Retriever],
) -> None:
    *_, retriever = retrieval_env
    results = retriever.similar_incidents(
        "bearing grinding vibration",
        "cnc_mill",
        k=10,
        before=date(2026, 1, 20),
    )

    assert [item.event_id for item in results] == ["EVT-001"]
    assert all(item.machine_type == "cnc_mill" for item in results)
    assert all(item.date < date(2026, 1, 20) for item in results)


def test_comment_filters_machine_window_and_defaults_to_latest_end(
    retrieval_env: tuple[Repository, Path, FakeEmbedder, Indexer, Retriever],
) -> None:
    *_, retriever = retrieval_env
    explicit = retriever.relevant_comments(
        "grinding bearing noise",
        "CNC-01",
        k=10,
        days=5,
        end=datetime(2026, 1, 20, 12, 0, tzinfo=UTC),
    )
    defaulted = retriever.relevant_comments("grinding bearing noise", "CNC-01", k=10, days=5)

    assert [item.comment_id for item in explicit] == ["CMT-002"]
    assert [item.comment_id for item in defaulted] == ["CMT-002"]


def test_similarity_is_present_sorted_and_shared_text_ranks_first(
    retrieval_env: tuple[Repository, Path, FakeEmbedder, Indexer, Retriever],
) -> None:
    *_, retriever = retrieval_env
    results = retriever.similar_incidents("grinding bearing noise and vibration", "cnc_mill", k=10)

    assert results[0].event_id == "EVT-001"
    similarities = [item.similarity for item in results]
    assert all(value is not None for value in similarities)
    assert similarities == sorted(similarities, reverse=True)


def test_add_comment_is_immediately_retrievable(
    retrieval_env: tuple[Repository, Path, FakeEmbedder, Indexer, Retriever],
    make_comment: Callable[..., OperatorComment],
) -> None:
    repo, _, _, indexer, retriever = retrieval_env
    comment = make_comment(
        comment_id="CMT-004",
        machine_id="CNC-01",
        timestamp=datetime(2026, 1, 21, 12, 0, tzinfo=UTC),
        comment_text="Unique bearing rumble vibration",
    )
    repo.insert_comments([comment])
    indexer.add_comment(comment, "cnc_mill")

    results = retriever.relevant_comments("unique bearing rumble vibration", "CNC-01", k=1, days=2)
    assert results[0].comment_id == "CMT-004"


def test_fewer_matches_than_k_returns_available_records(
    retrieval_env: tuple[Repository, Path, FakeEmbedder, Indexer, Retriever],
) -> None:
    *_, retriever = retrieval_env
    results = retriever.similar_incidents(
        "belt squeal", "conveyor_drive", k=50, before=date(2026, 2, 1)
    )
    assert len(results) == 1


def test_manifest_model_mismatch_and_missing_index(
    retrieval_env: tuple[Repository, Path, FakeEmbedder, Indexer, Retriever],
    tmp_path: Path,
) -> None:
    repo, chroma_dir, embedder, _, _ = retrieval_env

    with pytest.raises(IndexMismatchError, match="index built with.*run make index"):
        Retriever(chroma_dir, embedder, "different-model", repo)
    with pytest.raises(IndexMismatchError, match="missing.*run make index"):
        Retriever(tmp_path / "missing", embedder, "fake-embedder", repo)
