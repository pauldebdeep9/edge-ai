from collections.abc import Callable
from datetime import UTC, datetime, timedelta

from fakes import FakeEmbedder

from maint_rec.config_loader import get_app_config
from maint_rec.llm.prompts import (
    PROMPT_VERSION,
    build_recommendation_messages,
    render_context,
)
from maint_rec.recommend.schemas import (
    Comment,
    FailureEvent,
    Incident,
    OperatorComment,
    RiskLevel,
    RiskResult,
    RiskTrigger,
    Urgency,
)


def _risk() -> RiskResult:
    return RiskResult(
        machine_id="CNC-01",
        level=RiskLevel.HIGH,
        triggers=[
            RiskTrigger(
                signal="vibration_rms",
                metric="pct_change_vs_baseline",
                value=60.0,
                threshold=50.0,
                level=RiskLevel.HIGH,
            )
        ],
        window_days=14,
        computed_at=datetime(2026, 9, 20, 12, 0, tzinfo=UTC),
    )


def _inputs(
    make_failure: Callable[..., FailureEvent],
    make_comment: Callable[..., OperatorComment],
) -> tuple[list[Incident], list[Comment]]:
    incidents = [
        Incident.model_validate(
            make_failure(event_id="EVT-LOW").model_dump() | {"similarity": 0.35}
        ),
        Incident.model_validate(
            make_failure(event_id="EVT-HIGH").model_dump() | {"similarity": 0.91}
        ),
    ]
    base_time = datetime(2026, 9, 20, 12, 0, tzinfo=UTC)
    comments = [
        Comment.model_validate(
            make_comment(comment_id="CMT-OLD", timestamp=base_time - timedelta(days=1)).model_dump()
            | {"similarity": 0.4}
        ),
        Comment.model_validate(
            make_comment(comment_id="CMT-NEW", timestamp=base_time).model_dump()
            | {"similarity": 0.8}
        ),
    ]
    return incidents, comments


def _render(incidents: list[Incident], comments: list[Comment]) -> str:
    cfg = get_app_config()
    machine = cfg.get_machine("CNC-01")
    return render_context(
        machine,
        cfg.machine_types[machine.type].name,
        _risk(),
        cfg.failure_modes,
        incidents,
        comments,
    )


def test_prompt_has_only_applicable_modes_and_all_context_ids(
    make_failure: Callable[..., FailureEvent],
    make_comment: Callable[..., OperatorComment],
) -> None:
    incidents, comments = _inputs(make_failure, make_comment)
    text = _render(incidents, comments)

    assert PROMPT_VERSION == "v1"
    assert "bearing_wear" in text
    assert "spindle_misalignment" in text
    assert "overheating" in text
    assert "lubrication_failure" in text
    assert "hydraulic_leak" not in text
    assert "belt_slippage" not in text
    for record_id in ["EVT-LOW", "EVT-HIGH", "CMT-OLD", "CMT-NEW"]:
        assert record_id in text
    assert "60.0 vs threshold 50.0" in text


def test_normal_range_lists_exactly_untriggered_scored_signals() -> None:
    text = _render([], [])
    line = next(line for line in text.splitlines() if line.startswith("within normal range:"))
    assert line == "within normal range: temp_avg, temp_max, current_avg"


def test_empty_evidence_sections_render_none() -> None:
    text = _render([], [])
    assert "SIMILAR PAST INCIDENTS\nnone" in text
    assert "RECENT OPERATOR COMMENTS\nnone" in text
    assert "incident ids: none" in text
    assert "comment ids: none" in text


def test_long_comments_are_truncated_to_200_characters(
    make_comment: Callable[..., OperatorComment],
) -> None:
    long_text = "x" * 250
    comment = Comment.model_validate(
        make_comment(comment_id="CMT-LONG", comment_text=long_text).model_dump()
        | {"similarity": None}
    )
    text = _render([], [comment])
    rendered_line = next(line for line in text.splitlines() if "CMT-LONG" in line)
    rendered_comment = rendered_line.split(" | ", maxsplit=3)[-1]
    assert rendered_comment == "x" * 197 + "..."
    assert len(rendered_comment) == 200


def test_prompt_is_deterministic_and_sorts_evidence(
    make_failure: Callable[..., FailureEvent],
    make_comment: Callable[..., OperatorComment],
) -> None:
    incidents, comments = _inputs(make_failure, make_comment)
    first = _render(incidents, comments)
    second = _render(list(reversed(incidents)), list(reversed(comments)))

    assert first == second
    assert first.index("EVT-HIGH") < first.index("EVT-LOW")
    assert first.index("CMT-NEW") < first.index("CMT-OLD")


def test_allowed_values_lists_exact_urgencies() -> None:
    text = _render([], [])
    line = next(line for line in text.splitlines() if line.startswith("urgency values:"))
    rendered = line.removeprefix("urgency values: ").split(", ")
    assert rendered == [urgency.value for urgency in Urgency]


def test_message_builder_returns_system_and_user_messages() -> None:
    cfg = get_app_config()
    machine = cfg.get_machine("CNC-01")
    messages = build_recommendation_messages(
        machine,
        cfg.machine_types[machine.type].name,
        _risk(),
        cfg.failure_modes,
        [],
        [],
    )
    assert [message["role"] for message in messages] == ["system", "user"]
    assert messages[1]["content"] == _render([], [])


def test_fake_embedder_ranks_shared_terms_higher() -> None:
    embedder = FakeEmbedder()
    query = embedder.embed_query("bearing rumble vibration")
    related, unrelated = embedder.embed_documents(
        ["bearing vibration and rumble", "hydraulic seal coolant pressure"]
    )

    related_score = sum(left * right for left, right in zip(query, related, strict=True))
    unrelated_score = sum(left * right for left, right in zip(query, unrelated, strict=True))
    assert related_score > unrelated_score
