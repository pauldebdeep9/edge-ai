import json
from typing import Any

import httpx
import pytest

from maint_rec.llm import (
    LLMError,
    LLMInvalidOutputError,
    LLMUnavailableError,
    OllamaClient,
    OllamaEmbedder,
)
from maint_rec.recommend.schemas import RecommendationDraft


def _draft_payload() -> dict[str, Any]:
    return {
        "likely_failure_mode": "bearing_wear",
        "confidence": "High",
        "reasoning": (
            "Vibration is 60% above baseline while temperature remains normal. "
            "EVT-016 and CMT-333 support bearing wear."
        ),
        "recommended_actions": [
            {"action": "Inspect bearing condition", "urgency": "Within 48 hours"}
        ],
        "evidence": {
            "similar_incidents": ["EVT-016"],
            "operator_comments": ["CMT-333"],
        },
        "estimated_downtime_if_ignored_hours": 6.0,
    }


def _client(http_client: httpx.AsyncClient, *, max_retries: int = 1) -> OllamaClient:
    return OllamaClient(
        base_url="http://ollama.test",
        model="llama3.1:8b",
        timeout_s=5.0,
        temperature=0.1,
        num_ctx=8192,
        seed=42,
        keep_alive="30m",
        max_retries=max_retries,
        http_client=http_client,
    )


@pytest.mark.asyncio
async def test_valid_chat_response_and_request_body() -> None:
    requests: list[dict[str, Any]] = []

    async def handler(request: httpx.Request) -> httpx.Response:
        requests.append(json.loads(request.content))
        return httpx.Response(
            200,
            json={
                "message": {"content": json.dumps(_draft_payload())},
                "prompt_eval_count": 321,
                "eval_count": 87,
            },
        )

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as http_client:
        result, meta = await _client(http_client).chat_json(
            [{"role": "user", "content": "recommend"}], RecommendationDraft
        )

    assert result.likely_failure_mode == "bearing_wear"
    assert meta.model == "llama3.1:8b"
    assert meta.attempts == 1
    assert meta.prompt_tokens == 321
    assert meta.completion_tokens == 87
    body = requests[0]
    assert body["stream"] is False
    assert body["keep_alive"] == "30m"
    assert body["options"] == {"temperature": 0.1, "num_ctx": 8192, "seed": 42}
    assert isinstance(body["format"], dict)
    assert "$ref" not in json.dumps(body["format"])


@pytest.mark.asyncio
async def test_invalid_then_valid_retries_with_error_message() -> None:
    bodies: list[dict[str, Any]] = []
    outputs = iter(["not-json", json.dumps(_draft_payload())])

    async def handler(request: httpx.Request) -> httpx.Response:
        bodies.append(json.loads(request.content))
        return httpx.Response(200, json={"message": {"content": next(outputs)}})

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as http_client:
        result, meta = await _client(http_client).chat_json(
            [{"role": "user", "content": "recommend"}], RecommendationDraft
        )

    assert result.confidence.value == "High"
    assert meta.attempts == 2
    retry_messages = bodies[1]["messages"]
    assert retry_messages[-2] == {"role": "assistant", "content": "not-json"}
    assert "Your previous response was invalid:" in retry_messages[-1]["content"]
    assert "Return only a JSON object" in retry_messages[-1]["content"]


@pytest.mark.asyncio
async def test_invalid_after_retry_raises_with_raw_output() -> None:
    outputs = iter(["bad-one", "bad-two"])

    async def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"message": {"content": next(outputs)}})

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as http_client:
        with pytest.raises(LLMInvalidOutputError) as caught:
            await _client(http_client).chat_json(
                [{"role": "user", "content": "recommend"}], RecommendationDraft
            )

    assert caught.value.raw_output == "bad-two"
    assert caught.value.validation_errors


@pytest.mark.asyncio
async def test_connect_error_maps_to_unavailable_and_health_is_false() -> None:
    async def handler(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("connection refused", request=request)

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as http_client:
        client = _client(http_client)
        assert await client.is_alive() is False
        with pytest.raises(LLMUnavailableError, match="ollama serve"):
            await client.chat_json([{"role": "user", "content": "recommend"}], RecommendationDraft)


@pytest.mark.asyncio
async def test_missing_models_matches_implicit_latest_tag() -> None:
    async def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "models": [
                    {"name": "llama3.1:8b"},
                    {"name": "nomic-embed-text:latest"},
                ]
            },
        )

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as http_client:
        missing = await _client(http_client).missing_models(
            ["llama3.1:8b", "nomic-embed-text", "missing-model"]
        )

    assert missing == ["missing-model"]


def test_embedder_prefixes_batches_and_sets_dimension() -> None:
    requests: list[list[str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        body = json.loads(request.content)
        requests.append(body["input"])
        return httpx.Response(
            200,
            json={
                "embeddings": [[float(index), 1.0, 2.0] for index, _ in enumerate(body["input"])]
            },
        )

    with httpx.Client(transport=httpx.MockTransport(handler)) as http_client:
        embedder = OllamaEmbedder(
            "http://ollama.test",
            "nomic-embed-text",
            5.0,
            32,
            http_client=http_client,
        )
        vectors = embedder.embed_documents([f"document {index}" for index in range(70)])
        query = embedder.embed_query("bearing rumble")

    assert len(vectors) == 70
    assert len(requests) == 4
    assert [len(batch) for batch in requests] == [32, 32, 6, 1]
    assert all(text.startswith("search_document: ") for batch in requests[:3] for text in batch)
    assert requests[-1] == ["search_query: bearing rumble"]
    assert embedder.dimension == 3
    assert len(query) == 3


def test_embedder_rejects_inconsistent_dimensions() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"embeddings": [[1.0, 2.0], [1.0, 2.0, 3.0]]})

    with httpx.Client(transport=httpx.MockTransport(handler)) as http_client:
        embedder = OllamaEmbedder(
            "http://ollama.test",
            "nomic-embed-text",
            5.0,
            32,
            http_client=http_client,
        )
        with pytest.raises(LLMError, match="inconsistent embedding dimension"):
            embedder.embed_documents(["one", "two"])
