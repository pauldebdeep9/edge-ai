import hashlib
import json
import subprocess
import sys
from dataclasses import dataclass
from datetime import date, timedelta
from pathlib import Path

import pytest

from maint_rec.config_loader import AppConfig, get_app_config
from maint_rec.datagen.build import build_dataset
from maint_rec.datagen.comments import (
    COMMENT_CATEGORIES,
    OPERATORS_BY_SHIFT,
    CommentLinks,
    generate_comments,
)
from maint_rec.datagen.failures import (
    PlannedFailure,
    _phrase_matches_machine,
    plan_failures,
    to_failure_events,
)
from maint_rec.datagen.params import GenParams, spawn_rngs
from maint_rec.datagen.scenario import LiveScenario, apply_live_scenario
from maint_rec.datagen.sensors import generate_sensors
from maint_rec.db import Repository
from maint_rec.recommend.schemas import FailureEvent, OperatorComment, SensorDaily

_SENSOR_HASH = "2806db83064c3ae35bf3d2167c38309a1415b42ff09a3c6e937dff5bb109256e"
_EVENT_HASH = "7cc03a3b1496ec0347f54a9d95e1a9adc0a54b825704e2bf469a344728f59c58"


@dataclass(frozen=True, slots=True)
class GeneratedComments:
    cfg: AppConfig
    params: GenParams
    planned: list[PlannedFailure]
    events: list[FailureEvent]
    sensors: list[SensorDaily]
    live_scenario: LiveScenario
    comments: list[OperatorComment]
    links: CommentLinks


def _hash_records(records: list[SensorDaily] | list[FailureEvent]) -> str:
    payload = "\n".join(record.model_dump_json() for record in records) + "\n"
    return hashlib.sha256(payload.encode()).hexdigest()


def _generate() -> GeneratedComments:
    cfg = get_app_config()
    params = GenParams(seed=42)
    rngs = spawn_rngs(params.seed)
    planned = plan_failures(cfg, params, rngs["failures"])
    events = to_failure_events(planned, cfg, rngs["failures"])
    sensors = generate_sensors(cfg, params, planned, events, rngs["sensors"])
    sensors, live_scenario = apply_live_scenario(sensors, cfg, params, rngs["scenario"])
    comments, links = generate_comments(
        cfg, params, planned, events, live_scenario, rngs["comments"]
    )
    return GeneratedComments(cfg, params, planned, events, sensors, live_scenario, comments, links)


@pytest.fixture(scope="module")
def generated_comments() -> GeneratedComments:
    return _generate()


def test_comments_do_not_change_sensor_or_failure_output(
    generated_comments: GeneratedComments, tmp_path: Path
) -> None:
    generated = generated_comments
    assert _hash_records(generated.sensors) == _SENSOR_HASH
    assert _hash_records(generated.events) == _EVENT_HASH

    enabled_path = tmp_path / "with-comments.db"
    disabled_path = tmp_path / "without-comments.db"
    with Repository(enabled_path) as enabled_repo:
        enabled = build_dataset(
            GenParams(ground_truth_path=tmp_path / "with-comments.json"), enabled_repo
        )
        enabled_sensors = [
            row
            for machine in generated.cfg.machines
            for row in enabled_repo.get_sensor_range(
                machine.machine_id,
                generated.params.timeline()[0],
                generated.params.end_date,
            )
        ]
        enabled_events = enabled_repo.list_failures()
    with Repository(disabled_path) as disabled_repo:
        disabled = build_dataset(
            GenParams(
                comments_enabled=False,
                ground_truth_path=tmp_path / "without-comments.json",
            ),
            disabled_repo,
        )
        disabled_sensors = [
            row
            for machine in generated.cfg.machines
            for row in disabled_repo.get_sensor_range(
                machine.machine_id,
                generated.params.timeline()[0],
                generated.params.end_date,
            )
        ]
        disabled_events = disabled_repo.list_failures()

    assert enabled.failure_events == disabled.failure_events
    assert enabled_sensors == disabled_sensors == generated.sensors
    assert enabled_events == disabled_events == generated.events
    assert len(enabled.comments) > 0
    assert disabled.comments == []


def test_comment_total_and_category_shares(
    generated_comments: GeneratedComments,
) -> None:
    counts = generated_comments.links.counts_by_category()
    total = len(generated_comments.comments)

    assert 340 <= total <= 460
    assert sum(counts.values()) == total
    for category, target in {
        "routine": 60.0,
        "warning": 25.0,
        "repair": 8.0,
        "red_herring": 5.0,
    }.items():
        assert abs(counts[category] / total * 100.0 - target) <= 10.0


def test_comment_ids_timestamps_shifts_and_operators(
    generated_comments: GeneratedComments,
) -> None:
    comments = generated_comments.comments
    assert [comment.comment_id for comment in comments] == [
        f"CMT-{index:03d}" for index in range(1, len(comments) + 1)
    ]
    assert [comment.timestamp for comment in comments] == sorted(
        comment.timestamp for comment in comments
    )
    for comment in comments:
        hour = comment.timestamp.hour
        if comment.shift == "A":
            assert 6 <= hour < 14
        elif comment.shift == "B":
            assert 14 <= hour < 22
        else:
            assert hour >= 22 or hour < 6
        assert comment.operator in OPERATORS_BY_SHIFT[comment.shift]


def test_historical_warning_links_and_content(
    generated_comments: GeneratedComments,
) -> None:
    generated = generated_comments
    comments = {comment.comment_id: comment for comment in generated.comments}
    planned_by_event = dict(
        zip((event.event_id for event in generated.events), generated.planned, strict=True)
    )

    for event in generated.events:
        item = planned_by_event[event.event_id]
        ids = generated.links.warning_comment_ids[event.event_id]
        assert 2 <= len(ids) <= 5
        second_half = item.drift_start + timedelta(days=(item.lead_days + 1) // 2)
        mode = generated.cfg.get_failure_mode(item.failure_mode)
        compatible = [
            phrase
            for phrase in mode.symptom_phrases
            if _phrase_matches_machine(phrase, item.machine_type)
        ]
        incompatible = [
            phrase
            for candidate_mode in generated.cfg.failure_modes
            for phrase in candidate_mode.symptom_phrases
            if not _phrase_matches_machine(phrase, item.machine_type)
        ]
        for comment_id in ids:
            comment = comments[comment_id]
            assert comment.machine_id == item.machine_id
            assert second_half <= comment.timestamp.date() <= item.failure_date
            assert any(phrase.lower() in comment.comment_text.lower() for phrase in compatible)
            assert not any(
                phrase.lower() in comment.comment_text.lower() for phrase in incompatible
            )


def test_red_herrings_are_unlinked_and_outside_lead_windows(
    generated_comments: GeneratedComments,
) -> None:
    generated = generated_comments
    all_phrases = [
        phrase.lower() for mode in generated.cfg.failure_modes for phrase in mode.symptom_phrases
    ]
    red_herrings = [
        comment
        for comment in generated.comments
        if generated.links.category_by_comment_id[comment.comment_id] == "red_herring"
    ]
    for comment in red_herrings:
        assert not any(phrase in comment.comment_text.lower() for phrase in all_phrases)
        assert not any(
            item.machine_id == comment.machine_id
            and item.drift_start <= comment.timestamp.date() <= item.failure_date
            for item in generated.planned
        )
        if comment.machine_id == generated.live_scenario.machine_id:
            assert not (
                generated.live_scenario.drift_start
                <= comment.timestamp.date()
                <= generated.live_scenario.end_date
            )


def test_live_warning_window_and_recent_fleet_comments(
    generated_comments: GeneratedComments,
) -> None:
    generated = generated_comments
    comments = {comment.comment_id: comment for comment in generated.comments}
    live_comments = [
        comments[comment_id] for comment_id in generated.links.live_warning_comment_ids
    ]

    assert 3 <= len(live_comments) <= 4
    assert all(
        date(2026, 9, 14) <= comment.timestamp.date() <= generated.params.end_date
        for comment in live_comments
    )
    assert max(comment.timestamp.date() for comment in live_comments) >= (
        generated.params.end_date - timedelta(days=2)
    )
    assert not any(comment.timestamp.date() < date(2026, 9, 12) for comment in live_comments)
    live_routine = [
        comment
        for comment in generated.comments
        if comment.machine_id == generated.params.live_machine_id
        and generated.links.category_by_comment_id[comment.comment_id] == "routine"
        and date(2026, 9, 14) <= comment.timestamp.date() <= generated.params.end_date
    ]
    assert 1 <= len(live_routine) <= 2

    final_week = generated.params.end_date - timedelta(days=6)
    for machine in generated.cfg.machines:
        assert any(
            comment.machine_id == machine.machine_id and comment.timestamp.date() >= final_week
            for comment in generated.comments
        )

    final_14 = generated.params.end_date - timedelta(days=13)
    for comment in generated.comments:
        category = generated.links.category_by_comment_id[comment.comment_id]
        if comment.machine_id != generated.params.live_machine_id and category in {
            "warning",
            "red_herring",
        }:
            assert comment.timestamp.date() < final_14


def test_repository_recent_comments_include_live_warnings(
    generated_comments: GeneratedComments, tmp_path: Path
) -> None:
    params = GenParams(ground_truth_path=tmp_path / "ground_truth.json")
    db_path = tmp_path / "comments.db"
    with Repository(db_path) as repository:
        summary = build_dataset(params, repository)
        recent_ids = {
            comment.comment_id for comment in repository.get_recent_comments("CNC-02", days=10)
        }
    assert set(summary.comment_links.live_warning_comment_ids) <= recent_ids


def test_ground_truth_comment_ids_exist_in_database(tmp_path: Path) -> None:
    ground_truth_path = tmp_path / "ground_truth.json"
    with Repository(tmp_path / "ground-truth.db") as repository:
        build_dataset(GenParams(ground_truth_path=ground_truth_path), repository)
        database_ids = {comment.comment_id for comment in repository.list_comments()}

    payload = json.loads(ground_truth_path.read_text(encoding="utf-8"))
    linked_ids = set(payload["live_warning_comment_ids"])
    for event in payload["planned_failures"]:
        linked_ids.update(event["warning_comment_ids"])
    for category in COMMENT_CATEGORIES:
        linked_ids.update(payload["comment_ids_by_category"][category])
    assert linked_ids == database_ids


def test_no_comments_cli_skips_comment_generation(tmp_path: Path) -> None:
    db_path = tmp_path / "no-comments.db"
    project_root = Path(__file__).resolve().parents[2]
    result = subprocess.run(
        [
            sys.executable,
            "scripts/generate_data.py",
            "--db",
            str(db_path),
            "--no-comments",
        ],
        cwd=project_root,
        check=False,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, result.stderr
    with Repository(db_path) as repository:
        assert repository.counts()["operator_comments"] == 0
