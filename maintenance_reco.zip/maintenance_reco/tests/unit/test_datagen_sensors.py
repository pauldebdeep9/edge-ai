import json
import math
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import date, timedelta
from itertools import pairwise
from pathlib import Path
from statistics import mean

import pytest

from maint_rec.config_loader import get_app_config
from maint_rec.datagen.build import build_dataset
from maint_rec.datagen.failures import PlannedFailure, plan_failures, to_failure_events
from maint_rec.datagen.params import GenParams, spawn_rngs
from maint_rec.datagen.scenario import LiveScenario, apply_live_scenario
from maint_rec.datagen.sensors import generate_sensors
from maint_rec.db import Repository
from maint_rec.recommend.schemas import FailureEvent, SensorDaily


@dataclass(frozen=True, slots=True)
class GeneratedData:
    params: GenParams
    planned: list[PlannedFailure]
    events: list[FailureEvent]
    sensors: list[SensorDaily]
    live_scenario: LiveScenario


def _generate(seed: int = 42) -> GeneratedData:
    cfg = get_app_config()
    params = GenParams(seed=seed)
    rngs = spawn_rngs(seed)
    planned = plan_failures(cfg, params, rngs["failures"])
    events = to_failure_events(planned, cfg, rngs["failures"])
    sensors = generate_sensors(cfg, params, planned, events, rngs["sensors"])
    sensors, live_scenario = apply_live_scenario(sensors, cfg, params, rngs["scenario"])
    return GeneratedData(params, planned, events, sensors, live_scenario)


@pytest.fixture(scope="module")
def generated() -> GeneratedData:
    return _generate()


def _sensor_lookup(rows: list[SensorDaily]) -> dict[tuple[str, date], SensorDaily]:
    return {(row.machine_id, row.date): row for row in rows}


def test_generation_is_deterministic_and_seeded() -> None:
    first = _generate(seed=42)
    repeated = _generate(seed=42)
    changed = _generate(seed=43)

    assert first.planned == repeated.planned
    assert first.events == repeated.events
    assert first.sensors == repeated.sensors
    assert first.planned != changed.planned
    assert first.sensors != changed.sensors


def test_timeline_is_complete_and_contiguous(generated: GeneratedData) -> None:
    rows_by_machine: dict[str, list[SensorDaily]] = defaultdict(list)
    for row in generated.sensors:
        rows_by_machine[row.machine_id].append(row)

    assert set(rows_by_machine) == {machine.machine_id for machine in get_app_config().machines}
    for rows in rows_by_machine.values():
        dates = sorted(row.date for row in rows)
        assert len(dates) == generated.params.days
        assert dates == generated.params.timeline()


def test_failure_coverage_and_placement(generated: GeneratedData) -> None:
    cfg = get_app_config()
    params = generated.params
    counts = Counter(item.failure_mode for item in generated.planned)
    quiet_tail_start = params.timeline()[-params.quiet_tail_days]
    earliest_drift = params.timeline()[params.min_history_days]

    assert len(generated.planned) >= 18
    assert all(counts[mode.id] >= params.min_events_per_mode for mode in cfg.failure_modes)
    assert {
        item.machine_id for item in generated.planned if item.failure_mode == "bearing_wear"
    } >= {
        "CNC-01",
        "CNC-02",
    }
    for item in generated.planned:
        mode = cfg.get_failure_mode(item.failure_mode)
        assert item.machine_type in mode.applicable_types
        lead_min = math.ceil(
            mode.lead_time_days.min
            + params.lead_bias * (mode.lead_time_days.max - mode.lead_time_days.min)
        )
        assert lead_min <= item.lead_days <= mode.lead_time_days.max
        assert item.drift_start >= earliest_drift
        assert item.failure_date < quiet_tail_start

    by_machine: dict[str, list[PlannedFailure]] = defaultdict(list)
    for item in generated.planned:
        by_machine[item.machine_id].append(item)
    for items in by_machine.values():
        ordered = sorted(items, key=lambda item: item.drift_start)
        for previous, current in pairwise(ordered):
            assert current.drift_start > previous.failure_date + timedelta(
                days=params.cooldown_days
            )


def test_failure_reference_windows_have_no_same_signal_drift(
    generated: GeneratedData,
) -> None:
    cfg = get_app_config()
    params = generated.params

    for current in generated.planned:
        current_signals = {
            effect.signal for effect in cfg.get_failure_mode(current.failure_mode).signal_effects
        }
        reference_start = current.drift_start - timedelta(days=params.reference_days)
        reference_end = current.drift_start - timedelta(days=1)
        for other in generated.planned:
            if other is current or other.machine_id != current.machine_id:
                continue
            other_signals = {
                effect.signal for effect in cfg.get_failure_mode(other.failure_mode).signal_effects
            }
            if current_signals.isdisjoint(other_signals):
                continue
            assert not (
                other.drift_start <= reference_end and reference_start <= other.failure_date
            )


def test_event_ids_are_sequential_and_chronological(generated: GeneratedData) -> None:
    assert [event.event_id for event in generated.events] == [
        f"EVT-{index:03d}" for index in range(1, len(generated.events) + 1)
    ]
    assert [(event.date, event.machine_id) for event in generated.events] == sorted(
        (event.date, event.machine_id) for event in generated.events
    )


def test_healthy_days_stay_inside_baselines(generated: GeneratedData) -> None:
    cfg = get_app_config()
    historical_windows = {
        (item.machine_id, day)
        for item in generated.planned
        for day in (
            item.drift_start + timedelta(days=offset)
            for offset in range((item.failure_date - item.drift_start).days + 1)
        )
    }
    live_window = {
        (generated.live_scenario.machine_id, day)
        for day in (
            generated.live_scenario.drift_start + timedelta(days=offset)
            for offset in range(
                (generated.live_scenario.end_date - generated.live_scenario.drift_start).days + 1
            )
        )
    }
    excluded = historical_windows | live_window

    for row in generated.sensors:
        if (row.machine_id, row.date) in excluded:
            continue
        machine = cfg.get_machine(row.machine_id)
        for signal, baseline in cfg.machine_types[machine.type].baseline.items():
            assert baseline.min <= getattr(row, signal) <= baseline.max


def test_every_failure_effect_is_detectable(generated: GeneratedData) -> None:
    cfg = get_app_config()
    lookup = _sensor_lookup(generated.sensors)

    for item in generated.planned:
        for effect in cfg.get_failure_mode(item.failure_mode).signal_effects:
            baseline_mean = mean(
                getattr(
                    lookup[(item.machine_id, item.drift_start - timedelta(days=offset))],
                    effect.signal,
                )
                for offset in range(1, generated.params.reference_days + 1)
            )
            final_mean = mean(
                getattr(
                    lookup[(item.machine_id, item.failure_date - timedelta(days=offset))],
                    effect.signal,
                )
                for offset in range(3)
            )
            observed_pct = (final_mean / baseline_mean - 1.0) * 100.0
            directed_pct = observed_pct if effect.direction == "up" else -observed_pct
            assert directed_pct >= effect.magnitude_pct * 0.60


def test_repair_returns_to_healthy_range(generated: GeneratedData) -> None:
    cfg = get_app_config()
    lookup = _sensor_lookup(generated.sensors)

    for item in generated.planned:
        repair_date = item.failure_date + timedelta(days=1)
        row = lookup[(item.machine_id, repair_date)]
        baselines = cfg.machine_types[item.machine_type].baseline
        for signal, baseline in baselines.items():
            assert baseline.min <= getattr(row, signal) <= baseline.max


def test_temperature_relationship_holds_everywhere(generated: GeneratedData) -> None:
    assert all(row.temp_max >= row.temp_avg + 2.0 for row in generated.sensors)


def test_live_scenario_and_quiet_tail(generated: GeneratedData) -> None:
    cfg = get_app_config()
    params = generated.params
    lookup = _sensor_lookup(generated.sensors)
    scenario = generated.live_scenario
    thresholds = cfg.thresholds
    reference_start = params.end_date - timedelta(
        days=thresholds.window_days + thresholds.baseline_days - 1
    )
    live_reference_mean = mean(
        lookup[(scenario.machine_id, reference_start + timedelta(days=offset))].vibration_rms
        for offset in range(thresholds.baseline_days)
    )
    end_value = lookup[(scenario.machine_id, scenario.end_date)].vibration_rms
    observed_pct = (end_value / live_reference_mean - 1.0) * 100.0

    assert scenario.live_reference_mean == pytest.approx(live_reference_mean)
    assert scenario.pct_at_end == pytest.approx(observed_pct)
    assert observed_pct == pytest.approx(params.live_pct_at_end, abs=5.0)
    quiet_tail_start = params.timeline()[-params.quiet_tail_days]
    assert not any(
        item.failure_date >= quiet_tail_start or item.drift_start >= quiet_tail_start
        for item in generated.planned
    )
    for row in generated.sensors:
        if row.date < quiet_tail_start or row.machine_id == scenario.machine_id:
            continue
        machine = cfg.get_machine(row.machine_id)
        for signal, baseline in cfg.machine_types[machine.type].baseline.items():
            assert baseline.min <= getattr(row, signal) <= baseline.max


def test_live_scoring_interval_has_no_same_signal_historical_drift_or_failure(
    generated: GeneratedData,
) -> None:
    cfg = get_app_config()
    params = generated.params
    scenario = generated.live_scenario
    live_signals = {
        effect.signal for effect in cfg.get_failure_mode(scenario.failure_mode).signal_effects
    }
    clean_start = params.end_date - timedelta(
        days=cfg.thresholds.window_days + cfg.thresholds.baseline_days - 1
    )
    clean_end = params.end_date

    for historical in generated.planned:
        if historical.machine_id != scenario.machine_id:
            continue
        historical_signals = {
            effect.signal for effect in cfg.get_failure_mode(historical.failure_mode).signal_effects
        }
        if live_signals.isdisjoint(historical_signals):
            continue
        assert not (historical.drift_start <= clean_end and clean_start <= historical.failure_date)


def test_every_failure_mode_can_trigger_configured_thresholds() -> None:
    cfg = get_app_config()

    for mode in cfg.failure_modes:
        assert any(
            effect.signal in cfg.thresholds.signals
            and effect.magnitude_pct
            >= cfg.thresholds.signals[effect.signal].medium.pct_change_vs_baseline
            for effect in mode.signal_effects
        )


def test_build_writes_ground_truth_and_matching_database(tmp_path: Path) -> None:
    db_path = tmp_path / "maintenance.db"
    ground_truth_path = tmp_path / "ground_truth.json"
    params = GenParams(ground_truth_path=ground_truth_path)

    with Repository(db_path) as repository:
        summary = build_dataset(params, repository)
        database_ids = [event.event_id for event in repository.list_failures()]
        counts = repository.counts()

    payload = json.loads(ground_truth_path.read_text(encoding="utf-8"))
    truth_ids = [item["event_id"] for item in payload["planned_failures"]]
    assert summary.ground_truth_path == ground_truth_path
    assert truth_ids == database_ids
    assert payload["params"]["reference_days"] == params.reference_days
    assert payload["live_scenario"]["live_reference_mean"] == pytest.approx(
        summary.live_scenario.live_reference_mean
    )
    assert payload["live_scenario"]["pct_at_end"] == pytest.approx(summary.live_scenario.pct_at_end)
    assert counts["machines"] == 5
    assert counts["sensor_daily"] == params.days * 5
    assert counts["failure_events"] == len(summary.failure_events)
    assert counts["operator_comments"] == len(summary.comments)
