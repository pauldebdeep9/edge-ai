from collections.abc import Callable
from pathlib import Path
from typing import Any

import pytest
import yaml
from pydantic import ValidationError

from maint_rec.config import get_settings
from maint_rec.config_loader import load_app_config


def test_real_config_loads() -> None:
    config = load_app_config()

    assert len(config.machines) == 5
    assert len(config.machine_types) == 4
    assert len(config.failure_modes) == 6
    assert config.thresholds.maintenance_reset.min_baseline_days == 7
    assert config.thresholds.maintenance_reset.min_window_days == 7
    assert config.thresholds.direction_aware is True


def test_maintenance_threshold_options_have_backward_compatible_defaults(
    tmp_path: Path,
) -> None:
    def remove_new_options(
        _machines: dict[str, Any],
        _failures: dict[str, Any],
        thresholds: dict[str, Any],
    ) -> None:
        thresholds.pop("maintenance_reset")
        thresholds.pop("direction_aware")

    _write_broken_config(tmp_path, remove_new_options)
    config = load_app_config(tmp_path)

    assert config.thresholds.maintenance_reset.min_baseline_days == 7
    assert config.thresholds.maintenance_reset.min_window_days == 7
    assert config.thresholds.direction_aware is True


def test_every_mode_applies_to_a_machine_in_the_fleet() -> None:
    config = load_app_config()
    fleet_types = {machine.type for machine in config.machines}

    assert all(fleet_types.intersection(mode.applicable_types) for mode in config.failure_modes)


def test_modes_for_each_type_have_distinct_effect_signatures() -> None:
    config = load_app_config()

    for type_id in config.machine_types:
        signatures = [
            tuple(
                sorted(
                    (effect.signal, effect.direction, effect.magnitude_pct)
                    for effect in mode.signal_effects
                )
            )
            for mode in config.modes_for_type(type_id)
        ]
        assert len(signatures) == len(set(signatures))


def test_config_lookup_helpers() -> None:
    config = load_app_config()

    assert config.get_machine("CNC-02").type == "cnc_mill"
    assert config.get_failure_mode("bearing_wear").name == "Bearing wear"
    assert "spindle_misalignment" in {mode.id for mode in config.modes_for_type("cnc_mill")}
    with pytest.raises(KeyError, match="unknown machine id"):
        config.get_machine("UNKNOWN")
    with pytest.raises(KeyError, match="unknown failure mode id"):
        config.get_failure_mode("unknown_mode")
    with pytest.raises(KeyError, match="unknown machine type id"):
        config.modes_for_type("unknown_type")


def _write_broken_config(
    target: Path, mutate: Callable[[dict[str, Any], dict[str, Any], dict[str, Any]], None]
) -> None:
    source = get_settings().config_dir
    documents = []
    for filename in ("machines.yaml", "failure_modes.yaml", "thresholds.yaml"):
        with (source / filename).open(encoding="utf-8") as stream:
            documents.append(yaml.safe_load(stream))
    mutate(*documents)
    for filename, document in zip(
        ("machines.yaml", "failure_modes.yaml", "thresholds.yaml"), documents, strict=True
    ):
        (target / filename).write_text(yaml.safe_dump(document, sort_keys=False), encoding="utf-8")


@pytest.mark.parametrize(
    ("mutate", "message"),
    [
        (
            lambda machines, _failures, _thresholds: machines["machines"][0].update(
                {"type": "unknown_type"}
            ),
            "unknown machine type",
        ),
        (
            lambda machines, _failures, _thresholds: machines["machine_types"]["cnc_mill"][
                "baseline"
            ].pop("temp_avg"),
            "missing baseline signal",
        ),
        (
            lambda _machines, _failures, thresholds: thresholds["signals"]["temp_avg"][
                "high"
            ].update(
                {
                    "pct_change_vs_baseline": thresholds["signals"]["temp_avg"]["medium"][
                        "pct_change_vs_baseline"
                    ]
                }
            ),
            "high pct_change_vs_baseline threshold must exceed medium",
        ),
    ],
)
def test_cross_reference_validation(
    tmp_path: Path,
    mutate: Callable[[dict[str, Any], dict[str, Any], dict[str, Any]], None],
    message: str,
) -> None:
    _write_broken_config(tmp_path, mutate)

    with pytest.raises(ValidationError, match=message):
        load_app_config(tmp_path)
