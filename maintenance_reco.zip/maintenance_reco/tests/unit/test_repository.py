import runpy
import sqlite3
import sys
from collections.abc import Callable
from datetime import UTC, date, datetime
from pathlib import Path

import pytest

from maint_rec.config_loader import get_app_config
from maint_rec.db import Repository
from maint_rec.recommend.schemas import FailureEvent, OperatorComment, Recommendation, SensorDaily

SensorFactory = Callable[..., list[SensorDaily]]
FailureFactory = Callable[..., FailureEvent]
CommentFactory = Callable[..., OperatorComment]
RecommendationFactory = Callable[..., Recommendation]


def test_init_is_idempotent_and_reset_clears_data(
    repo: Repository, make_sensor_rows: SensorFactory
) -> None:
    repo.init()
    repo.insert_sensor_rows(make_sensor_rows())

    repo.reset()

    assert all(count == 0 for count in repo.counts().values())
    repo.upsert_machines(get_app_config().machines)
    assert repo.counts()["machines"] == 5
    assert repo.counts()["sensor_daily"] == 0


def test_machines_round_trip_and_unknown_raises(repo: Repository) -> None:
    expected = sorted(get_app_config().machines, key=lambda machine: machine.machine_id)

    assert repo.get_machines() == expected
    assert repo.get_machine("CNC-01") == get_app_config().get_machine("CNC-01")
    with pytest.raises(KeyError, match="unknown machine id"):
        repo.get_machine("UNKNOWN")


def test_sensor_range_is_ascending_and_inclusive(
    repo: Repository, make_sensor_rows: SensorFactory
) -> None:
    rows = make_sensor_rows(start=date(2020, 5, 1), n_days=5)
    repo.insert_sensor_rows(list(reversed(rows)))

    result = repo.get_sensor_range("CNC-01", date(2020, 5, 2), date(2020, 5, 4))

    assert result == rows[1:4]


def test_sensor_window_anchors_to_latest_database_date(
    repo: Repository, make_sensor_rows: SensorFactory
) -> None:
    rows = make_sensor_rows(start=date(2019, 1, 1), n_days=10)
    repo.insert_sensor_rows(rows)

    result = repo.get_sensor_window("CNC-01", days=3)

    assert [row.date for row in result] == [date(2019, 1, 8), date(2019, 1, 9), date(2019, 1, 10)]


def test_sensor_insert_replaces_same_machine_and_date(
    repo: Repository, make_sensor_rows: SensorFactory
) -> None:
    original = make_sensor_rows(n_days=1)[0]
    replacement = original.model_copy(update={"temp_avg": 99.0})

    repo.insert_sensor_rows([original])
    repo.insert_sensor_rows([replacement])

    assert repo.counts()["sensor_daily"] == 1
    assert repo.get_sensor_window("CNC-01", 1)[0].temp_avg == 99.0


def test_failures_get_and_filter(repo: Repository, make_failure: FailureFactory) -> None:
    cnc_failure = make_failure()
    press_failure = make_failure(
        event_id="EVT-002",
        machine_id="PRS-01",
        machine_type="hydraulic_press",
        failure_mode="hydraulic_leak",
    )
    repo.insert_failure_events([cnc_failure, press_failure])

    assert repo.get_failure("EVT-001") == cnc_failure
    assert repo.list_failures(machine_id="PRS-01") == [press_failure]
    assert repo.list_failures(machine_type="cnc_mill") == [cnc_failure]


def test_comment_ids_add_comment_and_recent_window(
    repo: Repository,
    make_sensor_rows: SensorFactory,
    make_comment: CommentFactory,
) -> None:
    assert repo.next_comment_id() == "CMT-001"
    first = make_comment()
    repo.insert_comments([first])
    assert repo.next_comment_id() == "CMT-002"

    repo.insert_sensor_rows(make_sensor_rows(start=date(2024, 1, 1), n_days=12))
    added = repo.add_comment("CNC-01", "New vibration", "B", "Blair")
    assert added.comment_id == "CMT-002"
    assert added.timestamp == datetime(2024, 1, 12, 12, 0, tzinfo=UTC)
    assert repo.get_comment(added.comment_id) == added

    older = make_comment(comment_id="CMT-003", timestamp=datetime(2024, 1, 9, 12, 0, tzinfo=UTC))
    recent = make_comment(comment_id="CMT-004", timestamp=datetime(2024, 1, 11, 12, 0, tzinfo=UTC))
    repo.insert_comments([older, recent])

    result = repo.get_recent_comments("CNC-01", days=2)

    assert [comment.comment_id for comment in result] == ["CMT-002", "CMT-004"]


def test_foreign_key_violation_raises(repo: Repository, make_comment: CommentFactory) -> None:
    unknown = make_comment(machine_id="UNKNOWN")

    with pytest.raises(sqlite3.IntegrityError):
        repo.insert_comments([unknown])


def test_recommendation_round_trip(
    repo: Repository, make_recommendation: RecommendationFactory
) -> None:
    recommendation = make_recommendation()

    row_id = repo.log_recommendation(recommendation)

    assert row_id == 1
    assert repo.list_recommendations() == [recommendation]
    assert repo.list_recommendations(machine_id="CNC-02") == []


def test_counts_reflect_inserts(
    repo: Repository,
    make_sensor_rows: SensorFactory,
    make_failure: FailureFactory,
    make_comment: CommentFactory,
    make_recommendation: RecommendationFactory,
) -> None:
    repo.insert_sensor_rows(make_sensor_rows(n_days=2))
    repo.insert_failure_events([make_failure()])
    repo.insert_comments([make_comment()])
    repo.log_recommendation(make_recommendation())

    assert repo.counts() == {
        "machines": 5,
        "sensor_daily": 2,
        "failure_events": 1,
        "operator_comments": 1,
        "recommendations_log": 1,
    }


def test_init_db_script_against_override_path(
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    db_path = tmp_path / "cli" / "maintenance.db"
    script_path = Path(__file__).resolve().parents[2] / "scripts" / "init_db.py"
    monkeypatch.setattr(sys, "argv", [str(script_path), "--reset", "--db", str(db_path)])

    with pytest.raises(SystemExit) as exc_info:
        runpy.run_path(str(script_path), run_name="__main__")

    assert exc_info.value.code == 0
    output = capsys.readouterr().out
    assert str(db_path) in output
    assert "'machines': 5" in output
    with Repository(db_path) as repository:
        assert repository.counts()["machines"] == 5
