from datetime import date, timedelta

import pytest

from maint_rec.recommend.schemas import SensorDaily
from maint_rec.risk import compute_features


def _rows(values: list[float], *, start: date = date(2026, 1, 1)) -> list[SensorDaily]:
    return [
        SensorDaily(
            machine_id="TEST-01",
            date=start + timedelta(days=index),
            temp_avg=value,
            temp_max=value + 10.0,
            vibration_rms=value,
            current_avg=value,
            runtime_hours=value,
        )
        for index, value in enumerate(values)
    ]


def test_flat_series_has_zero_change_and_slope() -> None:
    feature = compute_features(_rows([100.0] * 14), _rows([100.0] * 30), ["temp_avg"])["temp_avg"]

    assert feature.pct_change_vs_baseline == pytest.approx(0.0)
    assert feature.slope_pct_per_day == pytest.approx(0.0)


def test_linear_ramp_has_one_percent_slope_per_day() -> None:
    feature = compute_features(
        _rows([100.0 + index for index in range(14)]),
        _rows([100.0] * 30),
        ["temp_avg"],
    )["temp_avg"]

    assert feature.slope_pct_per_day == pytest.approx(1.0)


def test_slope_uses_actual_day_offsets() -> None:
    rows = _rows([100.0, 102.0, 105.0])
    rows[1] = rows[1].model_copy(update={"date": rows[0].date + timedelta(days=2)})
    rows[2] = rows[2].model_copy(update={"date": rows[0].date + timedelta(days=5)})

    feature = compute_features(rows, _rows([100.0] * 30), ["temp_avg"])["temp_avg"]

    assert feature.slope_pct_per_day == pytest.approx(1.0)


def test_recent_mean_uses_exactly_last_three_window_days() -> None:
    feature = compute_features(
        _rows([100.0] * 11 + [110.0, 120.0, 130.0]),
        _rows([100.0] * 30),
        ["temp_avg"],
    )["temp_avg"]

    assert feature.recent_mean == pytest.approx(120.0)
    assert feature.latest_value == pytest.approx(130.0)
    assert feature.pct_change_vs_baseline == pytest.approx(20.0)


def test_downward_drift_preserves_negative_metrics() -> None:
    feature = compute_features(
        _rows([100.0 - 2.0 * index for index in range(14)]),
        _rows([100.0] * 30),
        ["current_avg"],
    )["current_avg"]

    assert feature.pct_change_vs_baseline < 0
    assert feature.slope_pct_per_day == pytest.approx(-2.0)


def test_supplied_baseline_is_used_independently_of_window() -> None:
    feature = compute_features(
        _rows([120.0] * 14, start=date(2030, 1, 1)),
        _rows([80.0] * 30, start=date(1990, 1, 1)),
        ["temp_avg"],
    )["temp_avg"]

    assert feature.baseline_mean == pytest.approx(80.0)
    assert feature.pct_change_vs_baseline == pytest.approx(50.0)


def test_zero_baseline_mean_is_rejected() -> None:
    with pytest.raises(ValueError, match="baseline mean.*cannot be zero"):
        compute_features(_rows([1.0] * 14), _rows([0.0] * 30), ["temp_avg"])
