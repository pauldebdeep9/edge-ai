from collections.abc import Callable
from datetime import UTC, date, datetime, timedelta

import pytest

from maint_rec.config_loader import get_app_config
from maint_rec.db import Repository
from maint_rec.recommend.schemas import FailureEvent, RiskLevel, SensorDaily
from maint_rec.risk import InsufficientDataError, RiskScorer, SignalFeatures


def _features(**overrides: tuple[float, float]) -> dict[str, SignalFeatures]:
    values = {
        signal: SignalFeatures(
            signal=signal,
            baseline_mean=100.0,
            recent_mean=100.0,
            latest_value=100.0,
            pct_change_vs_baseline=metrics[0],
            slope_pct_per_day=metrics[1],
        )
        for signal, metrics in {
            "vibration_rms": (0.0, 0.0),
            "temp_avg": (0.0, 0.0),
            "temp_max": (0.0, 0.0),
            "current_avg": (0.0, 0.0),
        }.items()
    }
    for signal, metrics in overrides.items():
        values[signal] = SignalFeatures(
            signal=signal,
            baseline_mean=100.0,
            recent_mean=100.0 + metrics[0],
            latest_value=100.0 + metrics[0],
            pct_change_vs_baseline=metrics[0],
            slope_pct_per_day=metrics[1],
        )
    return values


@pytest.fixture
def scorer(repo: Repository) -> RiskScorer:
    return RiskScorer(repo, get_app_config())


def test_below_medium_is_low_without_triggers(scorer: RiskScorer) -> None:
    level, triggers = scorer.classify(_features(vibration_rms=(14.9, 1.4)))
    assert level is RiskLevel.LOW
    assert triggers == []


def test_exact_threshold_is_not_triggered(scorer: RiskScorer) -> None:
    level, triggers = scorer.classify(_features(vibration_rms=(15.0, 1.5)))
    assert level is RiskLevel.LOW
    assert triggers == []


def test_metric_above_high_records_high_threshold(scorer: RiskScorer) -> None:
    level, triggers = scorer.classify(_features(vibration_rms=(50.1, 0.0)))
    assert level is RiskLevel.HIGH
    assert len(triggers) == 1
    assert triggers[0].threshold == 50.0
    assert triggers[0].level is RiskLevel.HIGH


def test_two_metrics_on_one_medium_signal_do_not_escalate(scorer: RiskScorer) -> None:
    level, triggers = scorer.classify(_features(vibration_rms=(20.0, 1.6)))
    assert level is RiskLevel.MEDIUM
    assert len(triggers) == 2
    assert {trigger.metric for trigger in triggers} == {
        "pct_change_vs_baseline",
        "slope_pct_per_day",
    }


def test_two_medium_signals_escalate_to_high(scorer: RiskScorer) -> None:
    one_level, _ = scorer.classify(_features(temp_avg=(9.0, 0.0)))
    two_level, triggers = scorer.classify(_features(temp_avg=(9.0, 0.0), current_avg=(13.0, 0.0)))
    assert one_level is RiskLevel.MEDIUM
    assert two_level is RiskLevel.HIGH
    assert all(trigger.level is RiskLevel.MEDIUM for trigger in triggers)


def test_negative_metric_triggers_with_sign_preserved(scorer: RiskScorer) -> None:
    level, triggers = scorer.classify(_features(current_avg=(-15.0, 0.0)))
    assert level is RiskLevel.MEDIUM
    assert triggers[0].value == -15.0
    assert triggers[0].threshold == 12.0


def test_triggers_sort_high_first_then_absolute_value(scorer: RiskScorer) -> None:
    _, triggers = scorer.classify(
        _features(
            vibration_rms=(60.0, 2.5),
            temp_avg=(-35.0, 0.0),
            current_avg=(15.0, 0.0),
        )
    )
    assert [(trigger.level, trigger.value) for trigger in triggers] == [
        (RiskLevel.HIGH, 60.0),
        (RiskLevel.HIGH, -35.0),
        (RiskLevel.MEDIUM, 15.0),
        (RiskLevel.MEDIUM, 2.5),
    ]


def test_direction_filter_uses_machine_type_failure_signatures(scorer: RiskScorer) -> None:
    vibration_level, vibration_triggers = scorer.classify(
        _features(vibration_rms=(-20.0, 0.0)), {("vibration_rms", "up")}
    )
    current_down_level, current_down_triggers = scorer.classify(
        _features(current_avg=(-20.0, 0.0)), {("current_avg", "down")}
    )
    current_up_level, current_up_triggers = scorer.classify(
        _features(current_avg=(20.0, 0.0)), {("current_avg", "down")}
    )

    assert vibration_level is RiskLevel.LOW
    assert vibration_triggers == []
    assert current_down_level is RiskLevel.MEDIUM
    assert current_down_triggers[0].value == -20.0
    assert current_up_level is RiskLevel.LOW
    assert current_up_triggers == []


def test_assess_uses_separate_windows_and_injected_clock(
    repo: Repository,
    make_sensor_rows: Callable[..., list[SensorDaily]],
) -> None:
    start = date(2026, 1, 1)
    repo.insert_sensor_rows(make_sensor_rows(start=start, n_days=60))
    now = datetime(2030, 5, 1, 9, 30, tzinfo=UTC)
    assessment = RiskScorer(repo, get_app_config(), clock=lambda: now).assess("CNC-01")

    assert assessment.window_end == start + timedelta(days=59)
    assert assessment.window_start == assessment.window_end - timedelta(days=13)
    assert assessment.baseline_end == assessment.window_start - timedelta(days=1)
    assert assessment.baseline_start == assessment.baseline_end - timedelta(days=29)
    assert (
        len(repo.get_sensor_range("CNC-01", assessment.window_start, assessment.window_end)) == 14
    )
    assert (
        len(repo.get_sensor_range("CNC-01", assessment.baseline_start, assessment.baseline_end))
        == 30
    )
    assert assessment.risk.computed_at == now
    assert assessment.status == "ok"
    assert assessment.last_repair_date is None


def test_past_as_of_works_and_too_few_rows_raise(
    repo: Repository,
    make_sensor_rows: Callable[..., list[SensorDaily]],
) -> None:
    start = date(2026, 1, 1)
    repo.insert_sensor_rows(make_sensor_rows(start=start, n_days=60))
    scorer = RiskScorer(repo, get_app_config())

    assessment = scorer.assess("CNC-01", start + timedelta(days=50))
    assert assessment.window_end == start + timedelta(days=50)
    with pytest.raises(InsufficientDataError, match="needs 44 daily rows"):
        scorer.assess("CNC-01", start + timedelta(days=42))


def _insert_flat_history(
    repo: Repository,
    make_sensor_rows: Callable[..., list[SensorDaily]],
    start: date,
) -> None:
    repo.insert_sensor_rows(
        make_sensor_rows(
            start=start,
            n_days=60,
            temp_avg=48.0,
            temp_max=58.0,
            vibration_rms=1.0,
            current_avg=18.0,
            runtime_hours=14.0,
        )
    )


def test_repair_inside_baseline_excludes_pre_repair_days_with_ok_status(
    repo: Repository,
    make_sensor_rows: Callable[..., list[SensorDaily]],
    make_failure: Callable[..., FailureEvent],
) -> None:
    start = date(2026, 1, 1)
    _insert_flat_history(repo, make_sensor_rows, start)
    repair_date = start + timedelta(days=30)
    repo.insert_failure_events([make_failure(date=repair_date)])

    assessment = RiskScorer(repo, get_app_config()).assess("CNC-01")

    assert assessment.status == "ok"
    assert assessment.last_repair_date == repair_date
    assert assessment.baseline_start == repair_date + timedelta(days=1)
    assert assessment.baseline_end == start + timedelta(days=45)
    assert assessment.window_start == start + timedelta(days=46)


def test_short_post_repair_baseline_uses_configured_mean(
    repo: Repository,
    make_sensor_rows: Callable[..., list[SensorDaily]],
    make_failure: Callable[..., FailureEvent],
) -> None:
    start = date(2026, 1, 1)
    _insert_flat_history(repo, make_sensor_rows, start)
    repair_date = start + timedelta(days=40)
    repo.insert_failure_events([make_failure(date=repair_date)])

    assessment = RiskScorer(repo, get_app_config()).assess("CNC-01")

    configured = get_app_config().machine_types["cnc_mill"].baseline["vibration_rms"].mean
    assert assessment.status == "config_baseline"
    assert assessment.baseline_start == repair_date + timedelta(days=1)
    assert assessment.features["vibration_rms"].baseline_mean == configured


def test_recent_repair_returns_low_until_minimum_window_is_available(
    repo: Repository,
    make_sensor_rows: Callable[..., list[SensorDaily]],
    make_failure: Callable[..., FailureEvent],
) -> None:
    start = date(2026, 1, 1)
    _insert_flat_history(repo, make_sensor_rows, start)
    repair_date = start + timedelta(days=54)
    repo.insert_failure_events([make_failure(date=repair_date)])

    assessment = RiskScorer(repo, get_app_config()).assess("CNC-01")

    assert assessment.status == "recently_serviced"
    assert assessment.risk.level is RiskLevel.LOW
    assert assessment.risk.triggers == []
    assert assessment.window_start == repair_date + timedelta(days=1)
