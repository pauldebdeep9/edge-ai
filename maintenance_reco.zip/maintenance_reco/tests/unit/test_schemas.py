import json
from datetime import UTC, datetime
from typing import Any

import pytest
from pydantic import ValidationError

from maint_rec.recommend.schemas import (
    Action,
    Confidence,
    Evidence,
    Recommendation,
    RecommendationDraft,
    RecommendationSource,
    RiskLevel,
    RiskResult,
    RiskTrigger,
    Urgency,
    draft_json_schema,
)


def _draft() -> RecommendationDraft:
    return RecommendationDraft(
        likely_failure_mode="bearing_wear",
        confidence=Confidence.HIGH,
        reasoning="Vibration has risen sharply while temperatures remain stable.",
        recommended_actions=[
            Action(action="Inspect the spindle bearings", urgency=Urgency.IMMEDIATE),
            Action(action="Check shaft play", urgency=Urgency.NEXT_SHIFT),
            Action(action="Plan bearing replacement", urgency=Urgency.WITHIN_48_HOURS),
        ],
        evidence=Evidence(
            similar_incidents=["EVT-007", "EVT-019"],
            operator_comments=["CMT-281", "CMT-305"],
        ),
        estimated_downtime_if_ignored_hours=12.0,
    )


def _risk() -> RiskResult:
    return RiskResult(
        machine_id="CNC-02",
        level=RiskLevel.HIGH,
        triggers=[
            RiskTrigger(
                signal="vibration_rms",
                metric="pct_change_vs_baseline",
                value=67.0,
                threshold=50.0,
                level=RiskLevel.HIGH,
            )
        ],
        window_days=14,
        computed_at=datetime(2026, 9, 24, 5, 0, tzinfo=UTC),
    )


def test_full_recommendation_round_trip() -> None:
    recommendation = Recommendation.from_draft(
        _draft(),
        risk=_risk(),
        source=RecommendationSource.LLM,
        model="llama3.1:8b",
        latency_ms=842,
    )

    restored = Recommendation.model_validate_json(recommendation.model_dump_json())

    assert restored == recommendation
    assert restored.machine_id == "CNC-02"
    assert restored.likely_failure_mode == "bearing_wear"
    assert len(restored.recommended_actions) == 3


@pytest.mark.parametrize(
    "model, payload",
    [
        (Action, {"action": "Inspect bearing", "urgency": "Soon"}),
        (
            RiskResult,
            {
                "machine_id": "CNC-02",
                "level": "Critical",
                "triggers": [],
                "window_days": 14,
                "computed_at": "2026-09-24T05:00:00Z",
            },
        ),
    ],
)
def test_invalid_enum_values_are_rejected(model: type[Any], payload: dict[str, Any]) -> None:
    with pytest.raises(ValidationError):
        model.model_validate(payload)


def test_draft_rejects_extra_fields() -> None:
    payload = _draft().model_dump()
    payload["unexpected"] = "not allowed"

    with pytest.raises(ValidationError, match="Extra inputs are not permitted"):
        RecommendationDraft.model_validate(payload)


@pytest.mark.parametrize("action_count", [0, 5])
def test_draft_rejects_action_counts_outside_bounds(action_count: int) -> None:
    payload = _draft().model_dump()
    payload["recommended_actions"] = [
        {"action": f"Action {index}", "urgency": "Next shift"} for index in range(action_count)
    ]

    with pytest.raises(ValidationError):
        RecommendationDraft.model_validate(payload)


def test_from_draft_copies_risk_data() -> None:
    risk = _risk()

    recommendation = Recommendation.from_draft(
        _draft(),
        risk=risk,
        source=RecommendationSource.FALLBACK,
        model=None,
        latency_ms=None,
    )

    assert recommendation.machine_id == risk.machine_id
    assert recommendation.risk_level == risk.level
    assert recommendation.risk_triggers == risk.triggers


def test_draft_json_schema_is_self_contained_and_serializable() -> None:
    schema = draft_json_schema()

    assert isinstance(schema, dict)
    assert "$defs" not in schema
    assert '"likely_failure_mode"' in json.dumps(schema)

    def references(node: Any) -> list[str]:
        if isinstance(node, dict):
            found = [node["$ref"]] if "$ref" in node else []
            return found + [reference for value in node.values() for reference in references(value)]
        if isinstance(node, list):
            return [reference for value in node for reference in references(value)]
        return []

    assert references(schema) == []
