from datetime import UTC, date, datetime, timedelta

from maint_rec.recommend.schemas import OperatorComment, RiskLevel, RiskResult, RiskTrigger
from maint_rec.retrieval import build_query
from maint_rec.risk import RiskAssessment, SignalFeatures


def _assessment(triggers: list[RiskTrigger]) -> RiskAssessment:
    features = {
        signal: SignalFeatures(signal, 100.0, 100.0, 100.0, 0.0, 0.0)
        for signal in ("vibration_rms", "temp_avg", "temp_max", "current_avg")
    }
    return RiskAssessment(
        risk=RiskResult(
            machine_id="CNC-02",
            level=RiskLevel.HIGH if triggers else RiskLevel.LOW,
            triggers=triggers,
            window_days=14,
            computed_at=datetime(2026, 9, 20, tzinfo=UTC),
        ),
        features=features,
        status="ok",
        last_repair_date=None,
        window_start=date(2026, 9, 7),
        window_end=date(2026, 9, 20),
        baseline_start=date(2026, 8, 8),
        baseline_end=date(2026, 9, 6),
    )


def _comment(comment_id: str, timestamp: datetime, text: str) -> OperatorComment:
    return OperatorComment(
        comment_id=comment_id,
        machine_id="CNC-02",
        timestamp=timestamp,
        shift="A",
        operator="Luis Ortega",
        comment_text=text,
    )


def test_only_triggered_signals_use_direction_words_and_rounded_values() -> None:
    assessment = _assessment(
        [
            RiskTrigger(
                signal="vibration_rms",
                metric="pct_change_vs_baseline",
                value=61.46,
                threshold=50.0,
                level=RiskLevel.HIGH,
            ),
            RiskTrigger(
                signal="vibration_rms",
                metric="slope_pct_per_day",
                value=5.55,
                threshold=5.0,
                level=RiskLevel.HIGH,
            ),
            RiskTrigger(
                signal="current_avg",
                metric="pct_change_vs_baseline",
                value=-20.4,
                threshold=12.0,
                level=RiskLevel.MEDIUM,
            ),
        ]
    )

    query = build_query("CNC mill", assessment, [])

    assert "vibration increasing 61% vs baseline, rising 5.5% per day" in query
    assert "motor current decreasing 20% vs baseline" in query
    assert "average temperature" not in query
    assert "peak temperature" not in query


def test_no_triggers_reports_no_abnormal_signals() -> None:
    assert "No abnormal signals." in build_query("CNC mill", _assessment([]), [])
    assert "No abnormal signals." in build_query("CNC mill", None, [])


def test_comments_are_newest_first_and_limited() -> None:
    now = datetime(2026, 9, 20, 12, 0, tzinfo=UTC)
    comments = [
        _comment("CMT-001", now - timedelta(days=2), "old note"),
        _comment("CMT-003", now, "new note"),
        _comment("CMT-002", now - timedelta(days=1), "middle note"),
    ]

    query = build_query("CNC mill", _assessment([]), comments, max_comments=2)

    assert query.index("new note") < query.index("middle note")
    assert "old note" not in query


def test_query_builder_is_deterministic() -> None:
    now = datetime(2026, 9, 20, 12, 0, tzinfo=UTC)
    comments = [_comment("CMT-001", now, "steady grinding noise")]
    assessment = _assessment([])

    assert build_query("CNC mill", assessment, comments) == build_query(
        "CNC mill", assessment, list(reversed(comments))
    )
