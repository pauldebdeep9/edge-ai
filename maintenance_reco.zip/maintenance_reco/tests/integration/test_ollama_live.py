from collections.abc import AsyncIterator
from datetime import UTC, datetime

import pytest

from maint_rec.config import get_settings
from maint_rec.config_loader import get_app_config
from maint_rec.db import get_repository
from maint_rec.llm import OllamaClient, OllamaEmbedder
from maint_rec.llm.prompts import build_recommendation_messages
from maint_rec.recommend.schemas import (
    Comment,
    Incident,
    RecommendationDraft,
    RiskLevel,
    RiskResult,
    RiskTrigger,
)

pytestmark = pytest.mark.ollama


@pytest.fixture
async def live_client() -> AsyncIterator[OllamaClient]:
    client = OllamaClient.from_settings(get_settings())
    if not await client.is_alive():
        await client.aclose()
        pytest.skip("Ollama server is not reachable at the configured base URL")
    try:
        yield client
    finally:
        await client.aclose()


def _live_inputs() -> tuple[list[dict[str, str]], set[str], set[str], set[str]]:
    cfg = get_app_config()
    machine = cfg.get_machine("CNC-02")
    risk = RiskResult(
        machine_id=machine.machine_id,
        level=RiskLevel.HIGH,
        triggers=[
            RiskTrigger(
                signal="vibration_rms",
                metric="pct_change_vs_baseline",
                value=60.0,
                threshold=50.0,
                level=RiskLevel.HIGH,
            )
        ],
        window_days=14,
        computed_at=datetime(2026, 9, 20, 12, 0, tzinfo=UTC),
    )
    with get_repository() as repository:
        incidents = [
            Incident.model_validate(event.model_dump() | {"similarity": None})
            for event in repository.list_failures()
            if event.failure_mode == "bearing_wear"
        ]
        comments = [
            Comment.model_validate(comment.model_dump() | {"similarity": None})
            for comment in repository.get_recent_comments("CNC-02", days=10)
        ]
    modes = cfg.modes_for_type(machine.type)
    messages = build_recommendation_messages(
        machine,
        cfg.machine_types[machine.type].name,
        risk,
        modes,
        incidents,
        comments,
    )
    return (
        messages,
        {mode.id for mode in modes},
        {incident.event_id for incident in incidents},
        {comment.comment_id for comment in comments},
    )


@pytest.mark.asyncio
async def test_live_chat_returns_valid_grounded_draft(live_client: OllamaClient) -> None:
    messages, mode_ids, incident_ids, comment_ids = _live_inputs()
    draft, _ = await live_client.chat_json(messages, RecommendationDraft)

    assert draft.likely_failure_mode in mode_ids
    assert set(draft.evidence.similar_incidents) <= incident_ids
    assert set(draft.evidence.operator_comments) <= comment_ids


@pytest.mark.asyncio
async def test_live_embeddings_rank_bearing_document_first(
    live_client: OllamaClient,
) -> None:
    del live_client
    settings = get_settings()
    documents = [
        "Grinding noise at high speed on spindle bearing",
        "Coolant leak near hydraulic seal",
        "Belt squeal on conveyor startup",
    ]
    with OllamaEmbedder.from_settings(settings) as embedder:
        vectors = embedder.embed_documents(documents)
        query = embedder.embed_query("bearing rumble and rising vibration")

    scores = [sum(a * b for a, b in zip(query, vector, strict=True)) for vector in vectors]
    assert embedder.dimension is not None
    assert all(len(vector) == embedder.dimension for vector in vectors)
    assert scores.index(max(scores)) == 0
