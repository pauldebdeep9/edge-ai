import asyncio
import json
from collections.abc import Iterator
from datetime import UTC, datetime

import pytest

from maint_rec.config import get_settings
from maint_rec.config_loader import get_app_config
from maint_rec.db import get_repository
from maint_rec.llm import OllamaClient, OllamaEmbedder
from maint_rec.recommend.schemas import Comment, Incident
from maint_rec.retrieval import Indexer, Retriever, build_query
from maint_rec.risk import RiskScorer

pytestmark = pytest.mark.ollama


async def _ollama_is_alive(client: OllamaClient) -> bool:
    try:
        return await client.is_alive()
    finally:
        await client.aclose()


@pytest.fixture(scope="module")
def live_retrieval(
    tmp_path_factory: pytest.TempPathFactory,
) -> Iterator[tuple[list[Incident], list[Comment], set[str], str]]:
    settings = get_settings()
    health_client = OllamaClient.from_settings(settings)
    alive = asyncio.run(_ollama_is_alive(health_client))
    if not alive:
        pytest.skip("Ollama server is not reachable at the configured base URL")

    cfg = get_app_config()
    repository = get_repository(settings)
    embedder = OllamaEmbedder.from_settings(settings)
    chroma_dir = tmp_path_factory.mktemp("live_chroma")
    try:
        Indexer(chroma_dir, embedder, settings.embed_model, cfg).build(repository)
        retriever = Retriever(chroma_dir, embedder, settings.embed_model, repository)
        machine = cfg.get_machine("CNC-02")
        end_date = repository.get_latest_date(machine.machine_id)
        assert end_date is not None
        end = datetime.combine(end_date, datetime.max.time(), tzinfo=UTC)
        recent = repository.get_recent_comments(
            machine.machine_id, settings.comment_window_days, end=end
        )
        query = build_query(
            cfg.machine_types[machine.type].name,
            RiskScorer(repository, cfg).assess(machine.machine_id, end_date),
            recent,
        )
        incidents = retriever.similar_incidents(
            query,
            machine.type,
            settings.top_k_incidents,
            before=end_date + end_date.resolution,
        )
        comments = retriever.relevant_comments(
            query,
            machine.machine_id,
            settings.top_k_comments,
            settings.comment_window_days,
            end=end,
        )
        truth = json.loads((settings.data_dir / "ground_truth.json").read_text(encoding="utf-8"))
        yield incidents, comments, set(truth["live_warning_comment_ids"]), query
    finally:
        embedder.close()
        repository.close()


def test_live_top_incident_is_bearing_wear(
    live_retrieval: tuple[list[Incident], list[Comment], set[str], str],
) -> None:
    incidents, _, _, query = live_retrieval
    assert incidents and incidents[0].failure_mode == "bearing_wear", (
        query,
        [(item.event_id, item.failure_mode, item.similarity) for item in incidents],
    )


def test_live_comments_recall_and_incident_type_filter(
    live_retrieval: tuple[list[Incident], list[Comment], set[str], str],
) -> None:
    incidents, comments, warning_ids, query = live_retrieval
    retrieved_ids = {comment.comment_id for comment in comments}
    assert len(retrieved_ids & warning_ids) >= 2, (
        query,
        [(item.comment_id, item.comment_text, item.similarity) for item in comments],
        warning_ids,
    )
    assert all(item.machine_type == "cnc_mill" for item in incidents)
