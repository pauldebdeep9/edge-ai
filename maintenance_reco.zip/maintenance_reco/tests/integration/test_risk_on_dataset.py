import json
from collections import defaultdict
from collections.abc import Iterator
from datetime import date, timedelta
from statistics import median

import pytest

from maint_rec.config_loader import AppConfig, get_app_config
from maint_rec.datagen import GenParams, build_dataset
from maint_rec.db import Repository
from maint_rec.recommend.schemas import RiskLevel
from maint_rec.risk import RiskAssessment, RiskScorer


@pytest.fixture(scope="module")
def generated_risk_data(
    tmp_path_factory: pytest.TempPathFactory,
) -> Iterator[tuple[RiskScorer, AppConfig, dict[str, object]]]:
    directory = tmp_path_factory.mktemp("risk_dataset")
    repository = Repository(directory / "risk.db")
    repository.init()
    ground_truth_path = directory / "ground_truth.json"
    params = GenParams(ground_truth_path=ground_truth_path)
    cfg = get_app_config()
    build_dataset(params, repository, cfg)
    payload = json.loads(ground_truth_path.read_text(encoding="utf-8"))
    try:
        yield RiskScorer(repository, cfg), cfg, payload
    finally:
        repository.close()


def _feature_details(assessment: RiskAssessment) -> dict[str, tuple[float, float]]:
    return {
        signal: (feature.pct_change_vs_baseline, feature.slope_pct_per_day)
        for signal, feature in assessment.features.items()
    }


def test_live_machine_is_high_and_others_are_low(
    generated_risk_data: tuple[RiskScorer, AppConfig, dict[str, object]],
) -> None:
    scorer, cfg, payload = generated_risk_data
    live = payload["live_scenario"]
    assert isinstance(live, dict)
    end_date = date.fromisoformat(str(live["end_date"]))
    live_id = str(live["machine_id"])
    live_assessment = scorer.assess(live_id, end_date)

    assert live_assessment.risk.level is RiskLevel.HIGH
    assert any(
        trigger.signal == "vibration_rms" and trigger.value > 0
        for trigger in live_assessment.risk.triggers
    )
    assert not any(
        trigger.signal in {"temp_avg", "temp_max"} for trigger in live_assessment.risk.triggers
    )
    for machine in cfg.machines:
        if machine.machine_id == live_id:
            continue
        assessment = scorer.assess(machine.machine_id, end_date)
        assert assessment.risk.level is RiskLevel.LOW, (
            machine.machine_id,
            _feature_details(assessment),
        )


def test_historical_replay_detection_and_signal_match(
    generated_risk_data: tuple[RiskScorer, AppConfig, dict[str, object]],
) -> None:
    scorer, cfg, payload = generated_risk_data
    planned = payload["planned_failures"]
    assert isinstance(planned, list)
    detected: list[str] = []
    warning_days_by_mode: dict[str, list[int]] = defaultdict(list)
    failures: list[tuple[str, str, dict[str, tuple[float, float]]]] = []
    mismatches: list[str] = []
    for item in planned:
        assert isinstance(item, dict)
        as_of = date.fromisoformat(str(item["failure_date"])) - timedelta(days=1)
        assessment = scorer.assess(str(item["machine_id"]), as_of)
        if assessment.risk.level is RiskLevel.LOW:
            failures.append(
                (
                    str(item["event_id"]),
                    str(item["failure_mode"]),
                    _feature_details(assessment),
                )
            )
        else:
            detected.append(str(item["event_id"]))
            effect_signals = {
                effect.signal
                for effect in cfg.get_failure_mode(str(item["failure_mode"])).signal_effects
            }
            if not any(trigger.signal in effect_signals for trigger in assessment.risk.triggers):
                mismatches.append(str(item["event_id"]))

        first_detection: date | None = None
        drift_start = date.fromisoformat(str(item["drift_start"]))
        current = drift_start
        failure_date = date.fromisoformat(str(item["failure_date"]))
        while current <= failure_date:
            if scorer.score(str(item["machine_id"]), current).level is not RiskLevel.LOW:
                first_detection = current
                break
            current += timedelta(days=1)
        if first_detection is not None:
            warning_days_by_mode[str(item["failure_mode"])].append(
                (failure_date - first_detection).days
            )

    assert len(detected) / len(planned) >= 0.9, failures
    assert mismatches == []
    bearing_warning = warning_days_by_mode["bearing_wear"]
    assert median(bearing_warning) >= 7, warning_days_by_mode


def test_no_non_live_false_alarms_in_final_fourteen_days(
    generated_risk_data: tuple[RiskScorer, AppConfig, dict[str, object]],
) -> None:
    scorer, cfg, payload = generated_risk_data
    live = payload["live_scenario"]
    assert isinstance(live, dict)
    end_date = date.fromisoformat(str(live["end_date"]))
    live_id = str(live["machine_id"])
    alarms: list[tuple[str, date, dict[str, tuple[float, float]]]] = []
    for offset in range(13, -1, -1):
        as_of = end_date - timedelta(days=offset)
        for machine in cfg.machines:
            if machine.machine_id == live_id:
                continue
            assessment = scorer.assess(machine.machine_id, as_of)
            if assessment.risk.level is not RiskLevel.LOW:
                alarms.append((machine.machine_id, as_of, _feature_details(assessment)))
    assert alarms == []


def test_healthy_period_false_alarm_rate_is_at_most_two_percent(
    generated_risk_data: tuple[RiskScorer, AppConfig, dict[str, object]],
) -> None:
    scorer, cfg, payload = generated_risk_data
    params = payload["params"]
    planned = payload["planned_failures"]
    assert isinstance(params, dict)
    assert isinstance(planned, list)
    end_date = date.fromisoformat(str(params["end_date"]))
    timeline_start = end_date - timedelta(days=int(params["days"]) - 1)
    first_as_of = timeline_start + timedelta(
        days=cfg.thresholds.window_days + cfg.thresholds.baseline_days - 1
    )
    intervals = {machine.machine_id: [] for machine in cfg.machines}
    for item in planned:
        assert isinstance(item, dict)
        intervals[str(item["machine_id"])].append(
            (
                date.fromisoformat(str(item["drift_start"])),
                date.fromisoformat(str(item["failure_date"])) + timedelta(days=7),
            )
        )
    live = payload["live_scenario"]
    assert isinstance(live, dict)
    intervals[str(live["machine_id"])].append(
        (date.fromisoformat(str(live["drift_start"])), date.fromisoformat(str(live["end_date"])))
    )

    healthy_days = 0
    false_alarms: list[tuple[str, date, dict[str, tuple[float, float]]]] = []
    for machine in cfg.machines:
        as_of = first_as_of
        while as_of <= end_date:
            window_start = as_of - timedelta(days=cfg.thresholds.window_days - 1)
            affected = any(
                drift_start <= as_of and window_start <= affected_end
                for drift_start, affected_end in intervals[machine.machine_id]
            )
            if not affected:
                healthy_days += 1
                assessment = scorer.assess(machine.machine_id, as_of)
                if assessment.risk.level is not RiskLevel.LOW:
                    false_alarms.append((machine.machine_id, as_of, _feature_details(assessment)))
            as_of += timedelta(days=1)

    assert len(false_alarms) / healthy_days <= 0.02, (
        len(false_alarms),
        healthy_days,
        false_alarms,
    )
