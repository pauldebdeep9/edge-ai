from collections.abc import Callable, Iterator
from datetime import UTC, date, datetime, timedelta
from pathlib import Path
from typing import Any

import pytest

from maint_rec.config_loader import get_app_config
from maint_rec.db import Repository
from maint_rec.recommend.schemas import (
    Action,
    Confidence,
    Evidence,
    FailureEvent,
    OperatorComment,
    Recommendation,
    RecommendationSource,
    RiskLevel,
    RiskTrigger,
    SensorDaily,
    Urgency,
)

SensorFactory = Callable[..., list[SensorDaily]]
FailureFactory = Callable[..., FailureEvent]
CommentFactory = Callable[..., OperatorComment]
RecommendationFactory = Callable[..., Recommendation]


@pytest.fixture
def repo(tmp_path: Path) -> Iterator[Repository]:
    repository = Repository(tmp_path / "test.db")
    repository.init()
    repository.upsert_machines(get_app_config().machines)
    try:
        yield repository
    finally:
        repository.close()


@pytest.fixture
def make_sensor_rows() -> SensorFactory:
    def factory(
        machine_id: str = "CNC-01",
        start: date = date(2024, 1, 1),
        n_days: int = 3,
        **overrides: Any,
    ) -> list[SensorDaily]:
        return [
            SensorDaily.model_validate(
                {
                    "machine_id": machine_id,
                    "date": start + timedelta(days=offset),
                    "temp_avg": 48.0 + offset,
                    "temp_max": 58.0 + offset,
                    "vibration_rms": 0.8 + offset * 0.01,
                    "current_avg": 18.0 + offset * 0.1,
                    "runtime_hours": 14.0,
                    **overrides,
                }
            )
            for offset in range(n_days)
        ]

    return factory


@pytest.fixture
def make_failure() -> FailureFactory:
    def factory(**overrides: Any) -> FailureEvent:
        return FailureEvent.model_validate(
            {
                "event_id": "EVT-001",
                "machine_id": "CNC-01",
                "machine_type": "cnc_mill",
                "date": date(2024, 1, 10),
                "failure_mode": "bearing_wear",
                "symptoms": "Grinding noise at high speed",
                "root_cause": "Bearing surface fatigue",
                "action_taken": "Replaced spindle bearing",
                "parts_replaced": "Spindle bearing",
                "downtime_hours": 4.0,
                **overrides,
            }
        )

    return factory


@pytest.fixture
def make_comment() -> CommentFactory:
    def factory(**overrides: Any) -> OperatorComment:
        return OperatorComment.model_validate(
            {
                "comment_id": "CMT-001",
                "machine_id": "CNC-01",
                "timestamp": datetime(2024, 1, 10, 12, 0, tzinfo=UTC),
                "shift": "A",
                "operator": "Alex",
                "comment_text": "Grinding noise at high speed",
                **overrides,
            }
        )

    return factory


@pytest.fixture
def make_recommendation() -> RecommendationFactory:
    def factory(**overrides: Any) -> Recommendation:
        values: dict[str, Any] = {
            "machine_id": "CNC-01",
            "risk_level": RiskLevel.HIGH,
            "risk_triggers": [
                RiskTrigger(
                    signal="vibration_rms",
                    metric="pct_change_vs_baseline",
                    value=60.0,
                    threshold=50.0,
                    level=RiskLevel.HIGH,
                )
            ],
            "likely_failure_mode": "bearing_wear",
            "confidence": Confidence.HIGH,
            "reasoning": "Vibration is substantially above the healthy baseline.",
            "recommended_actions": [
                Action(action="Inspect spindle bearings", urgency=Urgency.IMMEDIATE)
            ],
            "evidence": Evidence(similar_incidents=["EVT-001"], operator_comments=["CMT-001"]),
            "estimated_downtime_if_ignored_hours": 10.0,
            "source": RecommendationSource.LLM,
            "model": "llama3.1:8b",
            "generated_at": datetime(2024, 1, 10, 12, 0, tzinfo=UTC),
            "latency_ms": 750,
        }
        values.update(overrides)
        return Recommendation.model_validate(values)

    return factory
