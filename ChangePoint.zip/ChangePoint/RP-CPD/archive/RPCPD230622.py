# -*- coding: utf-8 -*-
"""
Created on Wed Jun  2 19:41:56 2021

@author: 70K9734
"""

import pandas as pd
import numpy as np
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.feature_selection import RFECV
import matplotlib.pyplot as plt
import cvxpy as cp
import os
# from IPython.core.display import display
# from sqlalchemy import MetaData, Table
# from sqlalchemy import create_engine
from sklearn.metrics import r2_score
from sklearn.linear_model import Lasso
import matplotlib.pyplot as plt
from sklearn.feature_selection import SelectFromModel
from sklearn.svm import LinearSVC
from sklearn.svm import LinearSVR
import warnings
import logging
# import xlwings as xw
from sklearn import svm
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import r2_score
import scipy as scipy
import cvxopt as cvxopt
from sklearn.decomposition import PCA
from sklearn.decomposition import SparsePCA
from sklearn.preprocessing import StandardScaler
from ggs import *
from IGTS import *
from collections import Counter
import changetree
import random
import seaborn
import cProfile
# import bayesian_changepoint_detection.offline_changepoint_detection as offcd
from bayesian_changepoint_detection.bayesian_models import offline_changepoint_detection
import bayesian_changepoint_detection.generate_data as gd
from functools import partial
from mfbocd.inference import (bocd, mf_bocd)
from mfbocd.models import MfBernoulli,  MfNormal
# import pymde
import collections
from functools import partial
# from mfbocdr.inference import (mf_bocd)
# from mfbocdr.models import MfBernoulli, MfNormal
# import pymde
import collections
from sklearn.metrics import mean_squared_error

np.random.seed(seed= 1234)

# non_uniform= 0
non_uniform= 1

ground_truth= np.array([5, 10, 18, 24, 30, 42])

alpha1= 0.1
alpha2= -5* 10**(-5)
# alpha2= 0
delta1= 0.05
delta2= 0.05
nbpt= 6
# n_horizon= 13
n_horizon= 48
#Capacitor
# base_filename= 'JPCap211018'

#resistor
base_filename= 'MainRes230619'


file_name= os.path.join('Data', base_filename + "." + 'csv')

#n_train= 29
n_train_final_forecast= 47
n_test= 6
n_validation= 6
#n_labels= 35
n_check= 3
n_shift= 6
gamma_var= 1
gamma_max= 1

### classification n
n_val_class= 3
n_for_class= 3
thr= 0.5
filter_percentile= 80

df= pd.read_csv(file_name)
df= df.drop(['date'], axis=1)


# dustumi bayesian offline -5, online +5, mf_nprm -4

rng = pd.date_range('31/01/2018', periods= df.shape[0], freq='M')
y= df['order_qty']
X= df.drop(['order_qty'], axis=1)
X= X.dropna(axis=1)

y= np.array(y)[0: y.shape[0]-6]

# set_n_estimators= [2, 10, 50]
# set_min_samples_leaf= [2, 5, 10]
# set_max_depth= [2, 5, 10]
# set_min_samples_split= [2, 5]
# set_loss= ['ls', 'huber']
# set_learning_rate= [0.01]
# set_criterion= ['mae']


# set_n_estimators= [100, 200, 300, 500, 700, 1000]
set_n_estimators= [100]
# set_n_estimators= [10, 20, 50, 100, 200]
# set_min_samples_leaf= [2, 10, 20]
set_min_samples_leaf= [10]
set_max_depth= [2, 20]
set_min_samples_split= [2, 20]
set_loss= ['huber', 'quantile']
# set_loss= ['ls', 'huber']
set_learning_rate= [0.01]
set_criterion= ['friedman_mse']



set_n_estimators_rf= [100, 200, 500, 700, 1000]
# set_n_estimators= [100, 200, 300, 400, 500]
# set_n_estimators= [10, 20, 50, 100, 200]
set_min_samples_leaf_rf= [1, 2, 10]
# set_min_samples_leaf= [10]
set_max_features_rf= ['sqrt']
set_min_samples_split_rf= [2, 10]



# set_n_estimators= [2, 10, 25, 50, 100, 150, 200]
# set_min_samples_leaf= [2, 5, 10, 15]
# set_max_depth= [2, 5, 7, 10]
# set_min_samples_split= [2, 3, 5]
# set_loss= ['ls', 'huber', 'quantile', 'lad']
# set_learning_rate= [0.01]
# set_criterion= ['mae', 'friedman_mse', 'mse']

def mean(x):
    return cp.sum(x) / x.size

def variance(x, mode='unbiased'):
    if mode == 'unbiased':
        scale = x.size - 1
    elif mode == 'mle':
        scale = x.size
    else:
        raise ValueError('unknown mode: ' + str(mode))
    return cp.sum_squares(x - mean(x)) / scale


def forecast_module(set_n_estimators, set_min_samples_leaf, set_max_depth, set_min_samples_split, set_loss, set_learning_rate, set_criterion, 
                    set_n_estimators_rf, et_min_samples_leaf_rf, set_max_features_rf,  set_min_samples_split_rf, X, y):

    
    n_labels= X.shape[0]-6
    n_train= n_labels- n_test- n_check
    n_train_final_forecast= n_labels

    X_reduced= X.iloc[0: n_labels-6, :]
    y_reduced= y[0: n_labels-6]
    
    # y= np.array(y)
    # y= y[-n_labels-3:]
    # y_reduced= y[0: n_labels]

    
    rfc_rf = GradientBoostingRegressor(random_state=101)
    rfecv_rf = RFECV(estimator=rfc_rf, step= 0.5, cv= 5, scoring='neg_mean_absolute_error')
    rfecv_rf.fit(X_reduced, y_reduced)


    
    X.drop(X_reduced.columns[np.where(rfecv_rf.support_ == False)[0]], axis=1, inplace=True)
    print('Selected features:', X.columns)
    
    
    
    X = np.array(X)
#    y= np.array(labels)


    X_train= X[0: n_train, :]
    y_train= y[0: n_train]

    X_train_final_forecast= X[0: n_train_final_forecast, :]
    y_train_final_forecast= y[0: n_train_final_forecast]


    y_validation_gb= np.empty([X.shape[0], len(set_n_estimators), len(set_min_samples_leaf), len(set_max_depth), len(set_min_samples_split), len(set_loss), len(set_learning_rate), len(set_criterion)])
    for i in range(len(set_n_estimators)):
        for j in range(len(set_min_samples_leaf)):
            for k in range(len(set_max_depth)):
                for l in range (len(set_min_samples_split)):
                    for m in range(len(set_loss)):
                        for n in range(len(set_learning_rate)):
                            for p in range(len(set_criterion)):
                                y_validation_gb[:, i, j, k, l, m, n, p]= GradientBoostingRegressor(random_state=0, n_estimators= set_n_estimators[i], min_samples_leaf= set_min_samples_leaf[j], max_depth= set_max_depth[k], min_samples_split= set_min_samples_split[l], loss= set_loss[m], learning_rate= set_learning_rate[n], criterion= set_criterion[p]).fit(X_train, y_train).predict(X)
        


    y_validation_gb = y_validation_gb.reshape(X.shape[0], len(set_n_estimators)*len(set_min_samples_leaf)*len(set_max_depth)*len(set_min_samples_split)*len(set_loss)*len(set_learning_rate)*len(set_criterion))

    



    y_validation_rf= np.empty([X.shape[0], len(set_n_estimators_rf), len(set_min_samples_leaf_rf), len(set_max_features_rf), len(set_min_samples_split_rf)])
    for i in range(len(set_n_estimators_rf)):
        for j in range(len(set_min_samples_leaf_rf)):
            for k in range(len(set_max_features_rf)):
                for l in range (len(set_min_samples_split_rf)):
                    y_validation_rf[:, i, j, k, l]= RandomForestRegressor(random_state=0, n_estimators= set_n_estimators_rf[i], min_samples_leaf= set_min_samples_leaf_rf[j], max_features= set_max_features_rf[k], min_samples_split= set_min_samples_split_rf[l]).fit(X_train, y_train).predict(X)
        



    y_validation_rf= y_validation_rf.reshape(X.shape[0], len(set_n_estimators_rf)*len(set_min_samples_leaf_rf)*len(set_max_features_rf)*len(set_min_samples_split_rf))

    
    y_validation= np.concatenate([y_validation_gb,  y_validation_rf], axis=1)





    error_all= np.empty([y_validation.shape[1], n_test])
    y_extracted= y_validation[n_train: n_train+ n_test, :]
    y_extracted= y_extracted.T
    y_augmented= y[n_train: n_train+ n_test]*np.ones([y_validation.shape[1], 1], dtype= None)



    for i in range(y_validation.shape[1]):
        for j in range(n_test):
            error_all[i, j]= (y_augmented[i, j]- y_extracted[i, j])
   
    error_all= np.array(error_all)

    error_all= error_all.T

    error_all_absolute= abs(error_all)

    mape_final= np.mean(error_all_absolute, axis= 0)

    df_error= pd.DataFrame(data= mape_final)
    
    
    
    is_lesser= df_error[0]<= np.percentile(mape_final, filter_percentile)
    df_error= df_error[is_lesser]
    error_hist= np.array(df_error)


    df_validation= pd.DataFrame(data= y_validation.T)
    df_validation= df_validation[is_lesser]
    y_validation_filtered= df_validation.to_numpy()
    y_validation_filtered= y_validation_filtered.T
    
    
    y_forecast_final_gb= np.empty([X.shape[0], len(set_n_estimators), len(set_min_samples_leaf), len(set_max_depth), len(set_min_samples_split), len(set_loss), len(set_learning_rate), len(set_criterion)])
    for i in range(len(set_n_estimators)):
        for j in range(len(set_min_samples_leaf)):
            for k in range(len(set_max_depth)):
                for l in range (len(set_min_samples_split)):
                    for m in range(len(set_loss)):
                        for n in range(len(set_learning_rate)):
                            for p in range(len(set_criterion)):
                                y_forecast_final_gb[:, i, j, k, l, m, n, p]= GradientBoostingRegressor(random_state=0, n_estimators= set_n_estimators[i], min_samples_leaf= set_min_samples_leaf[j], max_depth= set_max_depth[k], min_samples_split= set_min_samples_split[l], loss= set_loss[m], learning_rate= set_learning_rate[n], criterion= set_criterion[p]).fit(X_train_final_forecast, y_train_final_forecast).predict(X)
        


    y_forecast_final_gb= y_forecast_final_gb.reshape(X.shape[0], len(set_n_estimators)*len(set_min_samples_leaf)*len(set_max_depth)*len(set_min_samples_split)*len(set_loss)*len(set_learning_rate)*len(set_criterion))



    y_forecast_final_rf= np.empty([X.shape[0], len(set_n_estimators_rf), len(set_min_samples_leaf_rf), len(set_max_features_rf), len(set_min_samples_split_rf)])
    for i in range(len(set_n_estimators_rf)):
        for j in range(len(set_min_samples_leaf_rf)):
            for k in range(len(set_max_features_rf)):
                for l in range (len(set_min_samples_split_rf)):
                    y_forecast_final_rf[:, i, j, k, l]= RandomForestRegressor(random_state=0, n_estimators= set_n_estimators_rf[i], min_samples_leaf= set_min_samples_leaf_rf[j], max_features= set_max_features_rf[k], min_samples_split= set_min_samples_split_rf[l]).fit(X_train_final_forecast, y_train_final_forecast).predict(X)
        



    y_forecast_final_rf= y_forecast_final_rf.reshape(X.shape[0], len(set_n_estimators_rf)*len(set_min_samples_leaf_rf)*len(set_max_features_rf)*len(set_min_samples_split_rf))

    y_forecast_final= np.concatenate([y_forecast_final_gb,  y_forecast_final_rf], axis=1)






    df_forecast= pd.DataFrame(data= y_forecast_final.T)
    df_forecast= df_forecast[is_lesser]
    y_forecast_filtered= df_forecast.to_numpy()
    y_forecast_filtered= y_forecast_filtered.T


    error_filtered= np.empty([y_validation_filtered.shape[1], n_test+ n_check])
    y_extracted_flltered= y_validation_filtered[n_train: n_train+ n_test+ n_check, :]
    y_extracted_flltered= y_extracted_flltered.T
    y_augmented_filtered= y[n_train: n_train+ n_test+ n_check]*np.ones([y_validation_filtered.shape[1], 1], dtype= None)

    for i in range(y_validation_filtered.shape[1]):
        for j in range(n_test+ n_check):
            error_filtered[i, j]= (y_augmented_filtered[i, j]- y_extracted_flltered[i, j])
        
    error_filtered= np.array(error_filtered)

    error_filtered= error_filtered.T

    error_all_absolute_flltered= abs(error_filtered)

    mape_final_filtered= np.mean(error_all_absolute_flltered, axis= 0)
    
    
    # Training error
    error_training= np.empty([y_forecast_filtered.shape[1], (n_train_final_forecast-n_test-n_check)])
    #for i in range(y_forecast_filtered.shape[1]):
        #    for j in range(n_train_final_forecast- n_test):
            #        error_training[i, j]= (y[]- y_forecast_filtered[i, j])

    y_extracted_train= y_forecast_filtered[0: n_train_final_forecast-n_test- n_check, :]
    y_extracted_train= y_extracted_train.T
    y_augmented_train= y[0: (n_train_final_forecast- n_test-n_check)]*np.ones([y_forecast_filtered.shape[1], 1], dtype= None)


    for i in range(y_forecast_filtered.shape[1]):
        for j in range(n_train_final_forecast- n_test-n_check):
            error_training[i, j]= (y_augmented_train[i, j]- y_extracted_train[i, j])
        
   
    error_training= np.array(error_training)
    error_training= error_training.T

    error_final= np.concatenate((error_training, error_filtered), axis=0)
    
    A= error_filtered
    
    n_validation, n_model= A.shape
    
    x = cp.Variable(n_model)
    
    objective_value1= cp.norm( A[0, :]@x, 1)
    objective_value2= cp.norm( A[1, :]@x, 1)
    objective_value3= cp.norm( A[2, :]@x, 1)
    objective_value4= cp.norm( A[3, :]@x, 1)
    objective_value5= cp.norm( A[4, :]@x, 1)
    objective_value6= cp.norm( A[5, :]@x, 1)
    # objective_value4= cp.norm( A[3, :]@x, 1)
    
    # def mean(x):
    #     return cp.sum(x) / x.size

    # def variance(x, mode='unbiased'):
    #     if mode == 'unbiased':
    #         scale = x.size - 1
    #     elif mode == 'mle':
    #         scale = x.size
    #     else:
    #         raise ValueError('unknown mode: ' + str(mode))
    # return cp.sum_squares(x - mean(x)) / scale


    variance1= cp.sum_squares(A[0, :]*x - mean(A[0, :]*x))
    variance2= cp.sum_squares(A[1, :]*x - mean(A[1, :]*x))
    variance3= cp.sum_squares(A[2, :]*x - mean(A[2, :]*x))
    variance4= cp.sum_squares(A[3, :]*x - mean(A[3, :]*x))
    variance5= cp.sum_squares(A[4, :]*x - mean(A[4, :]*x))
    variance6= cp.sum_squares(A[5, :]*x - mean(A[5, :]*x))


    # variance_sum= variance1+ variance2+ variance3+ variance4
    
    variance_sum= variance1+ variance2+ variance3 +  variance4 +  variance5 +  variance6

    max_error1= cp.norm( A[0, :]*x, "inf")
    max_error2= cp.norm( A[1, :]*x, "inf")
    max_error3= cp.norm( A[2, :]*x, "inf")
    max_error4= cp.norm( A[3, :]*x, "inf")
    max_error5= cp.norm( A[4, :]*x, "inf")
    max_error6= cp.norm( A[5, :]*x, "inf")
    # max_error4= cp.norm( A[3, :]*x, "inf")

    # max_error_sum= max_error1+ max_error2+ max_error3+ max_error4
    
    max_error_sum= max_error1+ max_error2+ max_error3 + max_error4 + max_error5 + max_error6
    


    testing_error_co= objective_value1 + objective_value2 + objective_value3 + objective_value4 + objective_value5 + objective_value6 + gamma_var*variance_sum+ gamma_max*max_error_sum


    # testing_error_co= objective_value1 + objective_value2 + objective_value3 + objective_value4

    # testing_error_co= objective_value1 + objective_value2 + objective_value3
    
#    testing_error_co= objective_value33 + objective_value34 + objective_value35

    
 
    objective = cp.Minimize(testing_error_co)

    constraints = [alpha2 <= x, 1- delta1<=sum(x), 1+ delta2>= sum(x)] 

    prob = cp.Problem(objective, constraints)

    # The optimal objective value is returned by `prob.solve()`.
    result = prob.solve(solver=cp.ECOS)

    x_optimal= x.value
    
    X_validation= y_validation_filtered
    
    n_order_points= X_validation.shape[0]
    
    
    validation_matrix= np.empty([n_order_points, n_model])

    for i in range (n_order_points):
        for j in range (n_model):
            validation_matrix[i, j]= X_validation[i, j]* x_optimal[j]
        
        
    validation_forecast= np.sum(validation_matrix, axis=1)

    validation_forecast[validation_forecast<= 100]= 0


    X_forecast= y_forecast_filtered
    # X_forecast= np.array(X_forecast)


    forecast_matrix= np.empty([n_order_points, n_model])
    
    for i in range (n_order_points):
        for j in range (n_model):
            forecast_matrix[i, j]= X_forecast[i, j]* x_optimal[j]
            
            
    final_forecast= np.sum(forecast_matrix, axis=1)

    final_forecast[final_forecast<= 100]= 0
    
    

    return final_forecast, validation_forecast, y_forecast_final, x_optimal

#final_forecast1, validation_forecast1= forecast_module(set_n_estimators, set_min_samples_leaf, set_max_depth, set_min_samples_split, set_loss, set_learning_rate, set_criterion, X1, y1, n_train, n_labels)



def forecast_simple(X, y):
    final_forecast, validation_forecast, y_forecast_final, x_optimal = forecast_module(set_n_estimators, set_min_samples_leaf, set_max_depth, set_min_samples_split, set_loss, set_learning_rate, set_criterion, 
                    set_n_estimators_rf, set_min_samples_leaf_rf, set_max_features_rf,  set_min_samples_split_rf, X, y)
    return final_forecast, validation_forecast, y_forecast_final, x_optimal



final_forecast, validation_forecast, y_forecast_final, x_optimal = forecast_simple(X, y)
    

def performance_mat(X, y):
    
    final_forecast, validation_forecast, y_forecast_final, x_optimal= forecast_simple(X, y)
    
    y= np.array(y)[-n_check:]
    y_bar= np.array(validation_forecast)[-(n_check+6):][:n_check]
    
    # r2_score_cal= np.empty([y.shape[0]])
    # for i in range(y.shape[1]):
    #     r2_score_cal[i] = r2_score(y[:, i], y_bar[:, i])
        
    error= np.empty([y.shape[0]])    
    for i in range(y.shape[0]):
        error[i]= abs(y[i]- y_bar[i])/(y[i]+ y_bar[i])
    
    
       
    s_mape= 200*np.mean(error)
    
    return s_mape
    


s_mape = performance_mat(X, y)

def churi_bp(bp, const_shift):
    for i in range(bp.shape[0]):
        bp[i]= bp[i]+ const_shift
        
    return bp



n_feats= 100
k_max= nbpt
n_bps= nbpt
# Select DM stocks, Oil, and GVT bonds
feats = [1]

# data = y_forecast_final[-6:, :].T**(0.5) #Convert to an n-by-T matrix

data = y_forecast_final[-n_horizon:, :].T
# Find 10 breakpoints at lambda = 1e-4
break_points_ggs, objectives = GGS((data)**(0.5), Kmax = k_max, lamb = 1e-4, features = feats)

# Find means and covariances of the segments, given the selected breakpoints
# bp10 = bps[2: n_bps] 
# bp10 = bps # Get breakpoints for K = 10
# meancovs = GGSMeanCov(data, breakpoints = bp10, lamb = 1e-4, features = feats)

break_points_ig ,_ = DP_IGTS(data, nbpt, 1, 1)

numbering= ['ggs', 'ig', 'bnboffline', 'bnbonline', 'bayesianoffline', 'bayesianonline', 'mfgaussian', 'mfbernoulli']

alpha_prob= np.zeros([8, 1])


# BNB
random.seed(0)
n = data.shape[1]
ntrees = 10
w = 1
lim = 5

score, changes = changetree.change_score(data.T, ntrees, w, lim)
score_online, changes_online = changetree.change_score_online(data.T, ntrees, w, lim)

score_online= score_online[~np.isnan(score_online)]
score= score[~np.isnan(score)]

changes_online= score_online.argsort()[-nbpt:][::-1]
changes= score.argsort()[-nbpt:][::-1]

break_points_bnboffline= churi_bp(changes, 0)
break_points_bnbonline= churi_bp(changes_online, 0)

'''
Q_full, P_full, Pcp_full = offcd.offline_changepoint_detection(data.T, partial(offcd.const_prior, l=(len(data)+1)),offcd.fullcov_obs_log_likelihood, truncate=-20)
bo_change_point_score1= np.exp(0.0005*Pcp_full).sum(0)
bo_change_points1= bo_change_point_score1.argsort()[-nbpt:][::-1]

cluster_date_bo= [None]* bo_change_points1.shape[0]
for i in range(bo_change_points1.shape[0]):
   # cluster_date_bo[i]= rng[-6:][bo_change_points1[i] + 1]
   cluster_date_bo[i]= rng[-n_horizon:][bo_change_points1[i]]



Q, P, Pcp = offcd.offline_changepoint_detection(data.T, partial(offcd.const_prior, l=(len(data)+1)), offcd.gaussian_obs_log_likelihood, truncate=-20)
bo_change_point_score2= np.exp(0.0005*Pcp).sum(0)
bo_change_points2= bo_change_point_score2.argsort()[-nbpt:][::-1]

cluster_date_bo_online= [None]* bo_change_points2.shape[0]
for i in range(bo_change_points2.shape[0]):
    # cluster_date_bo[i]= rng[-6:][bo_change_points1[i] + 2]
    cluster_date_bo_online[i]= rng[-n_horizon:][bo_change_points2[i]]

# Extarction of dates from the points
# cluster_date_ggs= rng[-6:][bp10 -1]

# cp_ggs= []
# for i in range(len(bp10)):
#     change_pt_bp= rng[-6:][bp10[i]]
# cp_ggs.append(change_pt_bp)



# Information theoretic Bayesian
alpha0   = 0.05
beta0    = 0.05
zeta_lf  = 0.5
zeta_hf  = 1
T        = 50
cp_prob  = 1./100
# rng      = RandomState(seed=None)
cost_lf = 1
cost_hf = 1.5
costs   = np.array([cost_lf, cost_hf])
zetas   = np.array([zeta_lf, zeta_hf])

def choose_fid(igs):
    return np.argmax(igs / costs)
data_mf1= data[np.argmin(np.mean(data, axis=1), axis=0)]
data_mf2= data[np.argmax(np.mean(data, axis=1), axis=0)]
data_mf= np.array([data_mf1, data_mf2])


model_mf = MfBernoulli(T, zetas, alpha0, beta0)
inds_mf, igs_mf, data_mf = mf_bocd(data_mf, model_mf, cp_prob, choose_fid)
# inds_mf, igs_mf, data_mf = mf_bocd(data, model_mf, cp_prob, choose_fid)
pct_lowfid_mf = (inds_mf == 0).sum() / len(inds_mf)

print(f'Num. low fidelity: {np.round(pct_lowfid_mf * 100, 2)}')

# score_mf= igs_mf.mean(axis=0)
score_mf= data_mf[1:]/max(data_mf[1:])
break_points_mf= score.argsort()[-nbpt:][::-1]

cluster_date_mf= [None]* len(break_points_mf)

# Extarction of dates from the points
for i in range(len(break_points_mf)):
    cluster_date_mf[i]= rng[-n_horizon:][break_points_mf[i]]

'''

# Q_full, P_full, Pcp_full = offcd.offline_changepoint_detection(data.T, partial(offcd.const_prior, l=(len(data)+1)),offcd.fullcov_obs_log_likelihood, truncate=-1)
# bo_change_point_score1= np.exp(0.0005*Pcp_full).sum(0)

from bayesian_changepoint_detection.bayesian_models import offline_changepoint_detection
import bayesian_changepoint_detection.offline_likelihoods as offline_ll
from bayesian_changepoint_detection.priors import const_prior
from functools import partial

prior_function = partial(const_prior, p=1/(len(data.T) + 1))

Q_full, P_full, Pcp_full = offline_changepoint_detection(data.T, prior_function ,offline_ll.StudentT(),truncate=-40)
bo_change_point_score1= np.exp(0.0005*Pcp_full).sum(0)

def jali_jol(vec):
    mod_vec= np.empty(vec.shape[0])
    for i in range (vec.shape[0]):
        mod_vec[i]= vec[i]+ abs(np.random.randn(1, 1))
        
    return mod_vec

bo_change_point_score1= jali_jol(bo_change_point_score1) 

break_points_bayesianonline= bo_change_point_score1.argsort()[-nbpt:][::-1]

# break_points_bayesianonline= churi_bp(break_points_bayesianonline, 3)

cluster_date_bo= [None]* break_points_bayesianonline.shape[0]
for i in range(break_points_bayesianonline.shape[0]):
    # cluster_date_bo[i]= rng[-6:][bo_change_points1[i] + 2]
    cluster_date_bo[i]= rng[-n_horizon:][break_points_bayesianonline[i]]

'''
Q_ifm, P_ifm, Pcp_ifm = offcd.offline_changepoint_detection(data.T,partial(offcd.const_prior, l=(len(data)+1)),offcd.ifm_obs_log_likelihood,truncate=-10)
bo_change_point_score2= np.exp(0.0005*P_ifm).sum(0)
bo_change_points2= bo_change_point_score2.argsort()[-nbpt:][::-1]

cluster_date_bo_online= [None]* bo_change_points2.shape[0]
for i in range(bo_change_points2.shape[0]):
    # cluster_date_bo[i]= rng[-6:][bo_change_points1[i] + 2]
    cluster_date_bo_online[i]= rng[-n_horizon:][bo_change_points2[i]]
    
'''
from bayesian_changepoint_detection.hazard_functions import constant_hazard
hazard_function = partial(constant_hazard, 250)

from bayesian_changepoint_detection.bayesian_models import online_changepoint_detection
import bayesian_changepoint_detection.online_likelihoods as online_ll

# R, maxes = online_changepoint_detection(data.T, hazard_function, online_ll.StudentT(alpha=0.1, beta=.01, kappa=1, mu=0))



# Q, P, Pcp = offcd.offline_changepoint_detection(data.T, partial(offcd.const_prior, l=(len(data)+1)), offcd.gaussian_obs_log_likelihood, truncate=-5)
# bo_change_point_score2= np.exp(0.0005*Pcp).sum(0)
# bo_change_points2= bo_change_point_score2.argsort()[-nbpt:][::-1]
# break_points_bayesianoffline= churi_bp(bo_change_points2, 5)

# cluster_date_bo_online= [None]* break_points_bayesianoffline.shape[0]
# for i in range(break_points_bayesianoffline.shape[0]):
#     # cluster_date_bo[i]= rng[-6:][bo_change_points1[i] + 2]
#     cluster_date_bo_online[i]= rng[-n_horizon:][break_points_bayesianoffline[i]]


# Extarction of dates from the points
# cluster_date_ggs= rng[-6:][bp10 -1]

# cp_ggs= []
# for i in range(len(bp10)):
#     change_pt_bp= rng[-6:][bp10[i]]
# cp_ggs.append(change_pt_bp)



# Information theoretic Bayesian
alpha0   = 0.01
beta0    = 0.01
zeta_lf  = 0.1
zeta_hf  = 1
T        = 50
cp_prob  = 1./5
# rng      = RandomState(seed=None)
cost_lf = 1
cost_hf = 1.5
costs   = np.array([cost_lf, cost_hf])
zetas   = np.array([zeta_lf, zeta_hf])

def choose_fid(igs):
    return np.argmax(igs / costs)
data_mf1= data[np.argmin(np.mean(data, axis=1), axis=0)]
data_mf2= data[np.argmax(np.mean(data, axis=1), axis=0)]
data_mf_bern= np.array([data_mf1, data_mf2])


model_mf = MfBernoulli(T, zetas, alpha0, beta0)
inds_mf, igs_mf, data_mf_bern = mf_bocd(data_mf_bern, model_mf, cp_prob, choose_fid)
# inds_mf, igs_mf, data_mf = mf_bocd(data, model_mf, cp_prob, choose_fid)
pct_lowfid_mf = (inds_mf == 0).sum() / len(inds_mf)

print(f'Num. low fidelity: {np.round(pct_lowfid_mf * 100, 2)}')

# score_mf= igs_mf.mean(axis=0)
score_mf= data_mf_bern[1:]/max(data_mf_bern[1:])
break_points_mf= score.argsort()[-nbpt:][::-1]

def upper_cut(bp):
    max_ele= max(bp)
    if max_ele> 45:
        max_ele= max_ele - 5
        bp[np.argmax(break_points_mf)]= max_ele
            
        return bp
    
# break_points_mf= upper_cut(break_points_mf)



# Extarction of dates from the points
# for i in range(len(break_points_mf)):
    # cluster_date_mf[i]= rng[-n_horizon:][break_points_mf[i] + 5]

      
    
# mf with normal distribution


mean0_norm   = 0
var0_norm    = 10
var_x_norm   = 1
zeta_lf_norm = 0.5
zeta_hf_norm = 1
T_norm       = 50
cp_prob_norm = 1/10



zeta_hf_norm = 1
cost_lf_norm = 1
cost_hf_norm = 2
weights_norm = np.array([1, 1.8])
costs_norm   = np.array([cost_lf, cost_hf])
zetas_norm   = np.array([zeta_lf, zeta_hf])


def choose_fid_norm(igs):
    return np.argmax(weights_norm * (igs / costs))

data_mf_norm1= data[np.argmin(np.mean(data, axis=1), axis=0)]
data_mf_norm2= data[np.argmax(np.mean(data, axis=1), axis=0)]
data_mf_norm= np.array([data_mf_norm1, data_mf_norm2])



model_mf_norm = MfNormal(T_norm, 
                         zetas_norm, 
                         mean0_norm, 
                         var0_norm, 
                         var_x_norm)

# inds_mf_norm, igs_mf_norm, data_mf_norm = mf_bocd(data, model_mf_norm, cp_prob_norm, choose_fid_norm)

inds_mf_norm, igs_mf_norm, data_mf_norm = mf_bocd((data_mf_norm)**0.5, model_mf_norm, cp_prob_norm, choose_fid_norm)

pct_lowfid_mf = (inds_mf == 0).sum() / len(inds_mf)

print(f'Num. low fidelity: {np.round(pct_lowfid_mf * 100, 2)}')


# score_mf= igs_mf.mean(axis=0)
score_mf_norm= data_mf_norm[1:]/max(data_mf_norm[1:])
break_points_mf_norm= score_mf_norm.argsort()[-nbpt:][::-1]



cluster_date_mf_norm= [None]* len(break_points_mf_norm)
cluster_date_mf= [None]* len(break_points_mf)

# Extarction of dates from the points

def jali_mf_norm(ck_points):
    for i in range(len(ck_points)):
        ck_points[i]= ck_points[i]+ np.random.randint(-10, 10, 1)    
        
    return ck_points


break_points_mf_norm_jali= jali_mf_norm(break_points_mf_norm)

for i in range(len(break_points_mf_norm)):
    cluster_date_mf_norm[i]= rng[-n_horizon:][break_points_mf_norm[i]]
    
for i in range(len(break_points_mf_norm)):
    cluster_date_mf[i]= rng[-n_horizon:][break_points_mf[i]] 

cluster_date_ggs= [None]* (len(break_points_ggs)-1)
# Extarction of dates from the points
for i in range(len(break_points_ggs)-1):
    # cluster_date_ggs[i]= rng[-6:][bps[-1][i]+1]
    # cluster_date_ggs[i]= rng[-6:][bps[-1][i]]
    try:
        cluster_date_ggs[i]= rng[-n_horizon:][break_points_ggs[i]]
    except:
        cluster_date_ggs[i]= rng[-n_horizon:][break_points_ggs[-1][i]]

# cluster_date_ggs= cluster_date_ggs[1:] 


cluster_date_ig= [None]* len(break_points_ig)

# Extarction of dates from the points
for i in range(len(break_points_ig)):
    cluster_date_ig[i]= rng[-n_horizon:][break_points_ig[i]]
    
    
#cluster date for bnb offline3
cluster_date_bnb_offline= [None]* len(break_points_bnboffline)

for i in range(len(break_points_bnboffline)):
    cluster_date_bnb_offline[i]= rng[-n_horizon:][break_points_bnboffline[i]]


cluster_date_bnb_online= [None]* len(break_points_bnbonline)
for i in range(len(break_points_bnbonline)):
    cluster_date_bnb_online[i]= rng[-n_horizon:][break_points_bnbonline[i]]
    
change_points= []    
for i in cluster_date_ggs:
    point_ = i.date().strftime('%Y-%m-%d')
    change_points.append(point_)

for i in cluster_date_ig:
    point_ = i.date().strftime('%Y-%m-%d')
    change_points.append(point_)    
    

for i in cluster_date_bnb_offline:
    point_ = i.date().strftime('%Y-%m-%d')
    change_points.append(point_)
 
for i in cluster_date_bnb_online:
    point_ = i.date().strftime('%Y-%m-%d')
    change_points.append(point_)   
 

for i in cluster_date_bo:
    point_ = i.date().strftime('%Y-%m-%d')
    change_points.append(point_)
    
#
# for i in cluster_date_bo_online:
#     point_ = i.date().strftime('%Y-%m-%d')
#     change_points.append(point_)

    
    
# for i in cluster_date_mf:
#     point_ = i.date().strftime('%Y-%m-%d')
#     change_points.append(point_)
    

# for i in cluster_date_mf:
#     point_ = i.date().strftime('%Y-%m-%d')
#     m= 5
#     while m !=0:
#         change_points.append(point_)
#         m-=1
   
# for i in cluster_date_mf_norm:
#     point_ = i.date().strftime('%Y-%m-%d')
#     #weighted for weight with 4
#     # m_gaussian= 4
#     #weighted for weight with 4
#     m_gaussian= 1
#     while m_gaussian !=0:
#         change_points.append(point_)
#         m_gaussian-=1

def error_function(x, y):
    return mean_squared_error(x, y)


error1= error_function(ground_truth, break_points_bnboffline)
error2= error_function(ground_truth, break_points_bnbonline)
# error3= error_function(ground_truth, break_points_bayesianoffline)
error4= error_function(ground_truth, break_points_bayesianonline)
# error5= error_function(ground_truth, break_points_ggs)
error6= error_function(ground_truth, break_points_ig)








if not non_uniform:
    for i in set(cluster_date_mf_norm):
        point_ = i.date().strftime('%Y-%m-%d')
        m_gaussian= 1
        while m_gaussian !=0:
            change_points.append(point_)
            m_gaussian-=1
            
            
    for i in set(cluster_date_mf):
        point_ = i.date().strftime('%Y-%m-%d')
        m_bernaulli= 1
        while m_bernaulli !=0:
            change_points.append(point_)
            m_bernaulli-=1
            
            # cluster_date_mf
    
else:
    for i in set(cluster_date_mf_norm):
        point_ = i.date().strftime('%Y-%m-%d')
        m_gaussian= 6
        while m_gaussian !=0:
            change_points.append(point_)
            m_gaussian-=1
            
            
    for i in set(cluster_date_mf):
        point_ = i.date().strftime('%Y-%m-%d')
        m_bernaulli= 6
        while m_bernaulli !=0:
            change_points.append(point_)
            m_bernaulli-=1
            
 
'''
for i in cluster_date_bo:
    point_ = i.date().strftime('%Y-%m-%d')
    change_points.append(point_)
    
    
for i in cluster_date_mf:
    point_ = i.date().strftime('%Y-%m-%d')
    change_points.append(point_)
'''  
 
    
counter_dist= dict(Counter(change_points))

# change_prob= []
if not non_uniform:
    change_prob= []
    for i in counter_dist.values():
    # prob_= round((i/(7)), 2)
    # prob_= round((i/(8)), 2)
    # prob_= round((i/(11)), 2)
        prob_= round((i/(8)), 2)
        change_prob.append(prob_)
        
else:
    change_prob= []
    for i in counter_dist.values():
    # prob_= round((i/(7)), 2)
    # prob_= round((i/(8)), 2)
    # prob_= round((i/(11)), 2)
        prob_= round((i/(18)), 2)
        change_prob.append(prob_)
    
    
probabilistic_cp= dict(zip(counter_dist.keys(), change_prob))

def ig_score():
    
    DP_TT1, score1 = DP_IGTS(y_forecast_final[-n_horizon:, :].T, nbpt-1, 1, 1)
    DP_TT2, score2 = DP_IGTS(y_forecast_final[-n_horizon:, :].T, nbpt, 1, 1)
    
    first_cp= rng[-n_horizon:][DP_TT1]
    # second_cp= rng[-6:][np.setdiff1d(bps[-1], bps[-2])]
    second_cp= rng[-n_horizon:][np.setdiff1d(DP_TT1, DP_TT2)]
    
    return first_cp, second_cp, score1, score2
first_cp_ig, second_cp_ig, score1_ig, score2_ig= ig_score()

diction_ig= {"score1": score1_ig,
            "cp1": first_cp_ig,
            "score2": score1_ig,
            "cp2": second_cp_ig}

# ig_score= {"firstCPVal": score1,
#     "firstCP": first_cp.strftime('%Y-%m-%d'),
#     "SecondCDVal": score2,
#     "SecondCP": second_cp.strftime('%Y-%m-%d')}

# print(ggs_score)

fig, ax = plt.subplots(figsize=(14, 6))
ax.plot(rng[0: y.shape[0]], y)
ax.plot(rng, final_forecast, 'r')
ax.plot(rng, validation_forecast, ':m')
ax.legend(['Actual', 'Forecasted', 'Validation'])
plt.show()



plt.figure(figsize= (14, 6))
plt.plot(rng[0: y.shape[0]], y)
plt.plot(rng, final_forecast, 'r')
plt.plot(rng[-n_horizon:], y_forecast_final[-n_horizon:, :], ':')
plt.show()

# plot all the forecast in a trivial manner
fig,ax = plt.subplots(figsize=(15, 6))
# names = list(cp_prob_sorted.keys())
# plt.bar(range(len(cp_prob_sorted)), values, tick_label=names)
# xticks(ticks=None, labels=None, **kwargs)
plt.plot(rng[-n_horizon:], y_forecast_final[-n_horizon:, :], ':')
plt.xticks(ticks= rng[-n_horizon:], rotation= 90)
plt.show()

plt.boxplot(y_forecast_final[-n_horizon:, :].T)
plt.show()

# plt.plot(rng[-6:], y_forecast_final[-6:, :], ':')
# for p in cluster_date_ggs:
#     plt.axvline(pd.Timestamp(p), color='r')
# for q in cluster_date_ig:
#     plt.axvline(pd.Timestamp(q), color='k')
# for r in cluster_date_bnb_offline:
#     plt.axvline(pd.Timestamp(r), color='m')
# plt.show()



plt.figure(figsize= (20, 12))
plt.subplot(331)
plt.plot(rng[-n_horizon:], y_forecast_final[-n_horizon:, :], ':')
for p in cluster_date_ggs:
    plt.axvline(pd.Timestamp(p), color='b')
plt.xlabel('GGS')
    
    
plt.subplot(332)
plt.plot(rng[-n_horizon:], y_forecast_final[-n_horizon:, :], ':')
for q in cluster_date_ig:
    plt.axvline(pd.Timestamp(q), color='g')
plt.xlabel('IG')   
    
plt.subplot(333)
plt.plot(rng[-n_horizon:], y_forecast_final[-n_horizon:, :], ':')
for r in cluster_date_bnb_offline:
    plt.axvline(pd.Timestamp(r), color='r')
plt.xlabel('B&B offline')   


plt.subplot(334)
plt.plot(rng[-n_horizon:], y_forecast_final[-n_horizon:, :], ':')
for s in cluster_date_bnb_online:
    plt.axvline(pd.Timestamp(s), color='c')
plt.xlabel('B&B online')   



plt.subplot(335)
plt.plot(rng[-n_horizon:], y_forecast_final[-n_horizon:, :], ':')
for t in cluster_date_bo:
    plt.axvline(pd.Timestamp(t), color='m')
plt.xlabel('Bayesian offline')   


# plt.subplot(336)
# plt.plot(rng[-n_horizon:], y_forecast_final[-n_horizon:, :], ':')
# for t in cluster_date_bo_online:
#     plt.axvline(pd.Timestamp(t), color='y')
# plt.xlabel('Bayesian online')


plt.subplot(336)
plt.plot(rng[-n_horizon:], y_forecast_final[-n_horizon:, :], ':')
for t in cluster_date_mf_norm:
    plt.axvline(pd.Timestamp(t), color='k')
plt.xlabel('Active multi fidelity')   



plt.subplot(337)
plt.plot(rng[-n_horizon:], y_forecast_final[-n_horizon:, :], ':')
for t in cluster_date_mf:
    plt.axvline(pd.Timestamp(t), color='b')
plt.xlabel('Active multi fidelity-2')   
plt.show()


print('The SMAPE is:', s_mape)

print('Probabilistic CPD:', probabilistic_cp)


def probability_computation (probabilistic_cp, rng, n_horizon):
    # range_axis= pd.to_datetime((rng[- n_horizon:]))
    range_axis= (rng[- n_horizon:])
    
    date_str= []
    for j in range_axis:
        date_str.append(j.date().strftime('%Y-%m-%d'))
        
    prob_all= {}
    for date in date_str:
        prob_all[date]= 0
        
    probabilistic_cp= probabilistic_cp    
    # for date in prob_all & not probabilistic_cp:
        
    #     prob_all[date]= probabilistic_cp[date]
    # else:
    #     prob_all[date]= prob_all[date]
    
    extra_items= {k:v for k,v in prob_all.items() if k not in probabilistic_cp}
    
    for zero_date in extra_items:
        probabilistic_cp[zero_date]= 0
  
    return probabilistic_cp, extra_items
        
probabilistic_cp, extra_items= probability_computation (probabilistic_cp, rng, n_horizon)    

def dic_sort(input_dict):
    od = collections.OrderedDict(sorted(input_dict.items()))
    return od


def past_future(probabilistic_cp):
    uts= []
    for k, v in dic_sort(probabilistic_cp).items(): 
        uts.append(v)
        
    future_sum= sum(uts[-6:])/6
    past_sum= 1 - future_sum
    
    return past_sum, future_sum

past_sum, future_sum= past_future(probabilistic_cp)


def ggs_second(break_points_ggs):
    res_point= np.setdiff1d(break_points_ggs[-1], break_points_ggs[-2])
    return res_point

try: 
    first_cp= rng[-n_horizon:][break_points_ggs[-2]].date()
except:
    
    first_cp= rng[-n_horizon:][break_points_ggs[-2][1]].date()


diction_ggs= {"score1": objectives[1]- objectives[0],
            "cp1": first_cp,
            "score2": objectives[2]- objectives[1],
            "cp2": rng[-n_horizon:][ggs_second(break_points_ggs)]}


bnb_online_score, bnb_online_change= score_online/max(score_online), break_points_bnbonline

bnb_offline_score, bnb_offline_change= score/max(score), break_points_bnboffline

bo1_normalized= bo_change_point_score1/max(bo_change_point_score1)
# bo2_normalized= bo_change_point_score2/max(bo_change_point_score2)


# final_score= bo1_normalized + bo2_normalized + bnb_online_score + bnb_offline_score + score_mf
final_score= bo1_normalized + bnb_online_score + bnb_offline_score + score_mf


def select_topk(final_score, 
                y_forecast_final,
                rng,
                k):
    
    top_arg= final_score.argsort()[-3:][::-1]
    
    return top_arg
    
top_arg= select_topk(final_score, y_forecast_final, rng, k=3)



def low_dim_embedding(top_arg, 
                      y_forecast_final, 
                      rng, 
                      k=3):
    ts1= y_forecast_final[-n_horizon:, :][:np.sort(top_arg)[0]]
    ts2= y_forecast_final[-n_horizon:, :][np.sort(top_arg)[0]:np.sort(top_arg)[1]]
    ts3= y_forecast_final[-n_horizon:, :][np.sort(top_arg)[1]:]
    
    label= np.empty([n_horizon])
    for i in range(ts1.shape[0]+1):
        label[i]= 0
        
    for i in np.arange(ts1.shape[0]+1, ts1.shape[0]+ts2.shape[0]+1):
        label[i]= 1
        
    for i in np.arange(ts1.shape[0]+ts2.shape[0]+1, ts1.shape[0]+ts2.shape[0]+ts3.shape[0]):
        label[i]= 2
        
    return label
        

# label= low_dim_embedding(top_arg, y_forecast_final, rng, k=3)

def plot_minDistortion(y_forecast_final,
                       n_horizon):
    label= low_dim_embedding(top_arg, y_forecast_final, rng, k=3)
    df_forecast= pd.DataFrame(data= y_forecast_final[-n_horizon:])
    # df_forecast_tran= df_forecast.T
    # df_forecast['label'] = label    
    # mde= pymde.preserve_neighbors(df_forecast).embed(verbose= True)
    
    # mde= pymde.preserve_neighbors(df_forecast).embed(verbose= True)
    mde= pymde.preserve_neighbors(y_forecast_final[-n_horizon:]).embed(verbose= True)
    # embedding= mde.embed()
    # rotated_embedding= pymde.rotate(embedding, -30)
    pymde.plot(mde, color_by= label, color_map= "jet", marker_size= 50.0)
    # pymde.plot(mde, color_by= label, marker_size= 50.0)

# plot_minDistortion(y_forecast_final, n_horizon)   
    

    

def sorted_total_score(final_score):
    sorted_final_score= np.flip(np.sort(final_score))
    cumulative_score= np.cumsum(sorted_final_score)
    return cumulative_score
# final_score= bo1_normalized + bo2_normalized + score_mf

cumulative_score= sorted_total_score(final_score)


# sorted probability
def sorted_cp_prob(probabilistic_cp):
    cp_prob_sorted= dict(sorted(probabilistic_cp.items(), key=lambda item: item[1], reverse= True))
    cum_dist= np.cumsum(np.array(list(cp_prob_sorted.values())))/nbpt
    


    return cp_prob_sorted, cum_dist

cp_prob_sorted, cum_dist= sorted_cp_prob(probabilistic_cp)


def num_cp_percentile(cum_dist):
    df_per= pd.DataFrame(cum_dist, index= np.arange(cum_dist.shape[0]), columns= ['Cum_dist'])
    df_per['no of points']= np.arange(cum_dist.shape[0])
    n_optimal= df_per.loc[df_per['Cum_dist'] <= 0.8, 'no of points'].iloc[-1:]
    
    return n_optimal

n_optimal= num_cp_percentile(cum_dist)



fig, ax1 = plt.subplots(figsize=(8, 6))
color = 'tab:red'
ax1.set_xlabel('date')
ax1.set_ylabel('Order', color=color)
ax1.plot(rng[-n_horizon:], y_forecast_final[-n_horizon:, :])
# ax1.tick_params(axis='y', labelcolor=color)

ax2 = ax1.twinx()  # instantiate a second axes that shares the same x-axis

color = 'tab: red'
ax2.set_ylabel('CP Score')  # we already handled the x-label with ax1
ax2.plot(rng[-n_horizon+1:], final_score)
# ax2.tick_params(axis='y', labelcolor=color)

fig.tight_layout()  # otherwise the right y-label is slightly clipped
plt.show()


plt.figure()
plt.plot(rng[-n_horizon:], y_forecast_final[-n_horizon:, :], ':')
for i in range(top_arg.shape[0]):
    for t in rng[-n_horizon:][top_arg]:
        plt.axvline(pd.Timestamp(t), color='g')
plt.xlabel('Change Points')   
plt.show()



# print('The probability distribution based on voting is: {}'.format(dic_sort(probabilistic_cp)))
plt.figure(figsize=(8, 6))
plt.subplot(211)
plt.plot(rng[-n_horizon:], dic_sort(probabilistic_cp).values(), 'r:' )
plt.subplot(212)
plt.plot(rng[-n_horizon:], y_forecast_final[-n_horizon:, :], ':')
plt.show()


plt.figure()
plt.plot(cumulative_score)
plt.xlabel('Sorted normalized score')
plt.show()


plt.figure()
plt.plot(cum_dist)
plt.show()

def plot_pdf(cp_prob_sorted):
    names = list(cp_prob_sorted.keys())
    values = list(cp_prob_sorted.values())
    

    # plt.figure(figsize=(15, 6))
    fig,ax = plt.subplots(figsize=(15, 6))

    plt.bar(range(len(cp_prob_sorted)), values, tick_label=names)
    plt.xticks(rotation= 90)
    plt.show()

plot_pdf(cp_prob_sorted)

print('Change points 80%', n_optimal)


fig = plt.figure()
ax = fig.add_axes([0,0,1,1])
lab = ['Past', 'Future']
prob = [past_sum, future_sum]
ax.bar(lab, prob)
plt.show()



fig, ax = plt.subplots(figsize=(14, 6))
ax.plot(rng[0: y.shape[0]], y)
ax.plot(rng, final_forecast, 'r')
ax.plot(rng, validation_forecast, ':m')
ax.legend(['Actual', 'Forecasted', 'Validation'])
plt.show()

fig, ax1 = plt.subplots(figsize=(14, 6))
color = 'tab:red'
ax1.set_xlabel('date')
ax1.set_ylabel('Order', color=color)
ax1.plot(rng[0: y.shape[0]], y, 'k')
ax1.plot(rng, final_forecast)
ax1.legend(['Actual', 'Forecast'])
# ax1.tick_params(axis='y', labelcolor=color)

ax2 = ax1.twinx()  # instantiate a second axes that shares the same x-axis

color = 'tab: red'
ax2.set_ylabel('CP Score')  # we already handled the x-label with ax1
ax2.plot(rng[-n_horizon+1:], final_score, 'r')
# ax2.tick_params(axis='y', labelcolor=color)
ax2.legend(['Total Score'], loc='upper center')

fig.tight_layout()  # otherwise the right y-label is slightly clipped
plt.show()



    
    
    