# -*- coding: utf-8 -*-
"""
Information Gain Temporal Segmentations (IGTS)

Authors: Shohreh Deldari and Sam Nolan
GitHub (reference): https://github.com/cruiseresearchgroup/IGTS-python
Matlab (reference): https://github.com/cruiseresearchgroup/IGTS-matlab
Paper: Sadri, Ren, Salim. "Information gain-based metric for recognizing transitions in human activities."
       Pervasive and Mobile Computing 38 (2017): 92-109.

This refactor preserves the original API & behavior:

Public functions:
- TopDown(Multivar_TS, k, step, double=1)
- DP_IGTS(Multivar_TS, k, step, double)
- SH_Entropy(x)
- IG_Cal_Incremental(IG_old, Integ_TS, pos_old, new_pos)
- IG_Cal(Integ_TS, pos, k)
- Clean_TS(O_Integ_TS, double)

Notes:
- Splits are interpreted as “after index i”.
- `Multivar_TS` is expected as array shaped (channels, time).
- `Clean_TS` prints scale values when double != 2, same as the legacy code.
"""

from __future__ import annotations

from typing import Tuple, Sequence
import numpy as np


# ---------------------------------------------------------------------
# Top-down greedy IGTS
# ---------------------------------------------------------------------
def TopDown(Multivar_TS: np.ndarray, k: int, step: int, double: int = 1) -> Tuple[np.ndarray, np.ndarray, int]:
    """
    Greedy (top-down) IGTS: iteratively add the split that maximizes incremental IG,
    up to k splits or early stop when no further gain is achieved.

    Parameters
    ----------
    Multivar_TS : (C, T) ndarray
        Multivariate time series (channels x time).
    k : int
        Number of splits to attempt (resulting segments = k + 1).
    step : int
        Step size for scanning candidate split positions.
    double : int
        Passed to Clean_TS (0/1/2), see Clean_TS docstring.

    Returns
    -------
    splits : (k+1,) int ndarray
        Working array where the first `n <= k` entries mark selected split indices,
        and the last entry stores T-1 (end index). The order reflects discovery.
    IG_arr : (k+1,) float ndarray
        Information gain after i splits in IG_arr[i].
    knee : int
        Knee index (<= number of discovered splits).
    """
    Integ_TS = Clean_TS(Multivar_TS, double)

    # Series length
    Len_TS = Integ_TS.shape[-1]

    # “Working” and best split arrays (store T-1 sentinel as last entry)
    maxTT = np.zeros(k + 1, dtype=int)
    tryTT = np.zeros(k + 1, dtype=int)

    # IG history
    IG_arr = np.zeros(k + 1, dtype=float)
    IG_arr[0] = 0.0

    # Curvature proxy (second-difference ratio)
    p_arr = np.zeros(k + 1, dtype=float)

    maxIG = 0.0

    for i in range(k):
        # Scan candidate split positions
        for j in range(0, Len_TS, step):
            tryTT[i + 1] = Len_TS - 1
            tryTT[i] = j

            IG = IG_Cal_Incremental(IG_arr[i], Integ_TS, tryTT[0:i], tryTT[i])
            if IG > maxIG:
                maxTT = tryTT.copy()
                maxIG = IG

        # Early stop if no improvement
        if maxIG == IG_arr[i]:
            break

        tryTT = maxTT.copy()
        IG_arr[i + 1] = maxIG

        # Compute “knee” proxy when possible
        if i >= 1 and (IG_arr[i + 1] - IG_arr[i]) != 0:
            p_arr[i] = (IG_arr[i] - IG_arr[i - 1]) / (IG_arr[i + 1] - IG_arr[i])

    knee = int(np.argmax(p_arr))
    return tryTT, IG_arr, knee


# ---------------------------------------------------------------------
# Dynamic programming IGTS
# ---------------------------------------------------------------------
def DP_IGTS(Multivar_TS: np.ndarray, k: int, step: int, double: int) -> Tuple[np.ndarray, float]:
    """
    Dynamic programming IGTS: globally optimal segmentation (w.r.t. IG)
    with step-grid candidate boundaries.

    Parameters
    ----------
    Multivar_TS : (C, T) ndarray
    k : int
        Number of splits (segments = k + 1).
    step : int
        Candidate positions are sampled every `step`.
    double : int
        Passed to Clean_TS.

    Returns
    -------
    expTT : (k,) int ndarray
        Optimal split positions (unsorted discovery order preserved).
    maxVAR : float
        Information gain value for the optimal segmentation.
    """
    Integ_TS = Clean_TS(Multivar_TS, double)

    if Integ_TS.ndim == 1:
        Num_TS = 1
        Len_TS = Integ_TS.shape[0]
        Integ_TS = Integ_TS.reshape(1, -1)
    else:
        Num_TS, Len_TS = Integ_TS.shape

    # cost[i, j, b] ~ weighted entropy for segment (i..j) with b splits used up to j
    cost = np.zeros((Len_TS, Len_TS, k + 1), dtype=float)
    TS_dist = np.zeros(Num_TS, dtype=float)
    pos = np.zeros((Len_TS, k + 1), dtype=int)
    expTT = np.zeros(k, dtype=int)

    # Precompute 0-split segment costs on a step grid
    for i in range(0, Len_TS, step):
        for j in range(i + 1, Len_TS, step):
            TS_dist[:] = Integ_TS[:, j] - Integ_TS[:, i]
            base = ((j - i) / float(Len_TS)) * SH_Entropy(TS_dist)
            cost[i : i + step, j : j + step, 0] = base

    # DP over number of splits
    for b in range(1, k + 1):
        for i in range(1, Len_TS):
            cost[0, i, b] = cost[0, i, b - 1].copy()
            pos[i, b] = 1
            for j in range(step, i - 1, step):
                cand = cost[0, j, b - 1] + cost[j + 1, i, 0]
                if cand <= cost[0, i, b]:
                    cost[0, i, b] = cand
                    pos[i, b] = j

    maxVAR = cost[0, Len_TS - 1, k].copy()

    # Backtrack optimal boundaries
    idx = Len_TS - 1
    for b in range(k, 0, -1):
        expTT[b - 1] = pos[idx, b].copy()
        idx = expTT[b - 1].copy()

    return expTT, float(maxVAR)


# ---------------------------------------------------------------------
# Entropy and IG utilities
# ---------------------------------------------------------------------
def SH_Entropy(x: np.ndarray) -> float:
    """
    Shannon entropy over a nonnegative vector (zeros ignored).

    Parameters
    ----------
    x : 1D ndarray

    Returns
    -------
    float
    """
    x = x[(x != 0)]
    if x.size == 0:
        return 0.0
    p = np.true_divide(x, np.sum(x))
    return float(-1.0 * np.sum(p * np.log(p)))


def IG_Cal_Incremental(
    IG_old: float,
    Integ_TS: np.ndarray,
    pos_old: Sequence[int] | np.ndarray,
    new_pos: int,
) -> float:
    """
    Incremental IG update when adding a new split to existing positions.

    Parameters
    ----------
    IG_old : float
        IG of the current segmentation.
    Integ_TS : (C, T) ndarray
        Cumulative-sum (integral) of the multivariate series.
    pos_old : sequence[int]
        Existing split positions (unsorted discovery order).
    new_pos : int
        New split to add.

    Returns
    -------
    float
        Updated IG value after including `new_pos`.
    """
    Num_TS, Len_TS = Integ_TS.shape

    TS_dist = np.zeros(Num_TS, dtype=float)

    # Boundaries around the new split
    lower = max([-1] + [x for x in pos_old if x <= new_pos])
    higher = min([Len_TS - 1] + [x for x in pos_old if x >= new_pos])

    # Entropy of the old segment (lower..higher)
    if lower == -1:
        TS_dist[:] = Integ_TS[:, higher]
    else:
        TS_dist[:] = Integ_TS[:, higher] - Integ_TS[:, lower]
    old_entropy = SH_Entropy(TS_dist)

    # Left segment (lower..new_pos)
    if lower == -1:
        TS_dist[:] = Integ_TS[:, new_pos]
    else:
        TS_dist[:] = Integ_TS[:, new_pos] - Integ_TS[:, lower]
    new_entropy_left = SH_Entropy(TS_dist)

    # Right segment (new_pos..higher)
    TS_dist[:] = Integ_TS[:, higher] - Integ_TS[:, new_pos]
    new_entropy_right = SH_Entropy(TS_dist)

    # Weighted entropy change
    weighted_right = (higher - new_pos) * new_entropy_right / float(Len_TS)
    weighted_old = (higher - lower) * old_entropy / float(Len_TS)
    weighted_left = (new_pos - lower) * new_entropy_left / float(Len_TS)

    entropy_change = weighted_old - weighted_left - weighted_right
    return float(IG_old + entropy_change)


def IG_Cal(Integ_TS: np.ndarray, pos: Sequence[int] | np.ndarray, k: int) -> float:
    """
    Full IG computation for the first (k+1) splits in `pos`.

    Parameters
    ----------
    Integ_TS : (C, T) ndarray
        Cumulative-sum series.
    pos : sequence[int]
        Split positions; only the first k+1 entries are considered.
    k : int
        Number of splits to evaluate.

    Returns
    -------
    float
        Information gain.
    """
    Num_TS, Len_TS = Integ_TS.shape
    pos_sorted = sorted(pos[0 : k + 1])
    TS_dist = np.zeros(Num_TS, dtype=float)

    # Entropy of whole series
    TS_dist[:] = Integ_TS[:, Len_TS - 1]
    IG = SH_Entropy(TS_dist)

    last_id = 0
    for i in range(k + 1):
        TS_dist[:] = Integ_TS[:, pos_sorted[i]] - Integ_TS[:, last_id]
        IG = IG - ((pos_sorted[i] - last_id) / float(Len_TS)) * SH_Entropy(TS_dist)
        last_id = pos_sorted[i]
    return float(IG)


# ---------------------------------------------------------------------
# Preprocessing
# ---------------------------------------------------------------------
def Clean_TS(O_Integ_TS: np.ndarray, double: int) -> np.ndarray:
    """
    Preprocess & integrate (cumsum) the time series across time axis.

    Modes (double):
      0: normalize each channel to [0, 1000] (affine to min/max, then scale).
      1: append the reversed series’ complement to mitigate positive correlation:
         - shift by min to >=0
         - scale to sum==1000 (prints the scale like the original code)
         - append (max - series) similarly normalized
      2: keep zeros as zeros, scale so that max==1000 (min treated as 0).

    Notes
    -----
    - Preserves original print side-effect when double != 2.
    - Returns cumulative sum along time (axis=1).

    Parameters
    ----------
    O_Integ_TS : (C, T) or (T,) ndarray
        Original (non-integrated) time series.
    double : int
        Mode selector as described above.

    Returns
    -------
    Integ_TS : (C', T) ndarray
        Preprocessed (possibly augmented) cumulative-sum series.
    """
    Integ_TS = np.array(O_Integ_TS, dtype=float, copy=True)

    # Ensure shape (C, T)
    if Integ_TS.ndim == 1:
        Integ_TS = Integ_TS.reshape(1, -1)

    Num_TS, Len_TS = Integ_TS.shape

    rows = [Integ_TS[i, :].copy() for i in range(Num_TS)]
    out_rows = []

    for row in rows:
        # shift by min
        min_val = float(np.min(row))
        if double == 2:
            # treat min as 0 (do not shift)
            shifted = row.copy()
        else:
            shifted = row - min_val

        if double != 2:
            # scale so sum == 1000 (legacy prints retained)
            sum_val = float(np.sum(shifted)) / 1000.0 if np.sum(shifted) != 0 else 1.0
            print(sum_val)
            scaled = shifted / (sum_val if sum_val != 0 else 1.0)
        else:
            # scale so max == 1000, keeping zeros at 0
            max_val = float(np.max(shifted)) if np.max(shifted) != 0 else 1.0
            scaled = (shifted / max_val) * 1000.0

        out_rows.append(scaled)

        if double == 1:
            # append complement of the (shifted) series, normalized to sum==1000
            max_val = float(np.max(scaled)) if np.max(scaled) != 0 else 1.0
            complement = max_val - scaled
            comp_sum = float(np.sum(complement)) / 1000.0 if np.sum(complement) != 0 else 1.0
            to_append = complement / (comp_sum if comp_sum != 0 else 1.0)
            out_rows.append(to_append)

    out = np.vstack(out_rows)
    return np.cumsum(out, axis=1)
