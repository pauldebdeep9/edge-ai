# -*- coding: utf-8 -*-
"""
Main RP-CPD pipeline

Includes:
 - Ensemble forecasting (GB + RF grids, feature selection, convex blend)
 - Single-best model selection/refit for apples-to-apples comparison
 - Ensemble percentile bands (p10/p50/p90) and optional trimmed-mean baseline
 - Change-point detection via GGS / IGTS / Branch&Bound (changetree) / simple Bayesian stub
 - Multi-panel and overlay plots of change points from all methods

Requires in repo:
  - ggs.py   (GGS, GGSMeanCov)
  - IGTS.py  (DP_IGTS)
  - changetree.py (change_score, change_score_online)

Data:
  - Data/MainRes230619.csv  (as used previously)
"""

import os
import math
import random
import collections
from collections import Counter

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.feature_selection import RFECV
from sklearn.metrics import mean_squared_error
import cvxpy as cp

# local modules
from ggs import GGS
from IGTS import DP_IGTS
import changetree


# ----------------------------
# Global config (kept)
# ----------------------------
np.random.seed(1234)

non_uniform = 1  # keep prior voting behavior for MF duplication
ground_truth = np.array([5, 10, 18, 24, 30, 42])

alpha1 = 0.1
alpha2 = -5 * 10 ** (-5)  # <= x lower bound (kept as-is)
delta1 = 0.05
delta2 = 0.05
nbpt = 6           # number of CPs to extract
n_horizon = 48     # number of points to visualize in CP panels

base_filename = 'MainRes230619'
file_name = os.path.join('Data', base_filename + "." + 'csv')

# validation config (matching your previous code)
n_test = 6
n_validation = 6
n_check = 3
n_shift = 6
gamma_var = 1
gamma_max = 1

# classification knobs (kept)
n_val_class = 3
n_for_class = 3
thr = 0.5
filter_percentile = 80  # ensemble candidate filter (% keep)

# Model grids (kept)
set_n_estimators = [100]
set_min_samples_leaf = [10]
set_max_depth = [2, 20]
set_min_samples_split = [2, 20]
set_loss = ['huber', 'quantile']
set_learning_rate = [0.01]
set_criterion = ['friedman_mse']

set_n_estimators_rf = [100, 200, 500, 700, 1000]
set_min_samples_leaf_rf = [1, 2, 10]
set_max_features_rf = ['sqrt']
set_min_samples_split_rf = [2, 10]


# -------------
# Small helpers
# -------------
def mean(x):
    return cp.sum(x) / x.size


def smape(y_true, y_pred, eps=1e-8):
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    num = np.abs(y_true - y_pred)
    den = np.maximum(np.abs(y_true) + np.abs(y_pred), eps)
    return 200.0 * np.mean(num / den)


# ==========================================
# Forecast ensemble (existing behavior kept)
# ==========================================
def forecast_module(set_n_estimators, set_min_samples_leaf, set_max_depth, set_min_samples_split, set_loss, set_learning_rate, set_criterion,
                    set_n_estimators_rf, set_min_samples_leaf_rf, set_max_features_rf, set_min_samples_split_rf, X, y):
    """
    Builds all GB & RF candidates, filters by validation MAPE percentile,
    re-trains on full train slice, then convex-combines via cvxpy.
    Returns:
      final_forecast, validation_forecast, y_forecast_final (all models), x_optimal weights,
      y_validation_filtered, y_forecast_filtered, is_lesser mask
    """
    n_labels = X.shape[0] - 6
    n_train = n_labels - n_test - n_check
    n_train_final_forecast = n_labels

    X_reduced = X.iloc[0: n_labels - 6, :]
    y_reduced = y[0: n_labels - 6]

    # RFECV feature selection (kept)
    rfc_rf = GradientBoostingRegressor(random_state=101)
    rfecv_rf = RFECV(estimator=rfc_rf, step=0.5, cv=5, scoring='neg_mean_absolute_error')
    rfecv_rf.fit(X_reduced, y_reduced)
    X = X.drop(X_reduced.columns[np.where(rfecv_rf.support_ == False)[0]], axis=1, inplace=False)
    print('Selected features:', list(X.columns))

    X = np.asarray(X)

    X_train = X[0: n_train, :]
    y_train = y[0: n_train]

    X_train_final_forecast = X[0: n_train_final_forecast, :]
    y_train_final_forecast = y[0: n_train_final_forecast]

    # ----- Build GB validation predictions -----
    y_validation_gb = np.empty([
        X.shape[0],
        len(set_n_estimators), len(set_min_samples_leaf),
        len(set_max_depth), len(set_min_samples_split),
        len(set_loss), len(set_learning_rate), len(set_criterion)
    ])

    for i in range(len(set_n_estimators)):
        for j in range(len(set_min_samples_leaf)):
            for k in range(len(set_max_depth)):
                for l in range(len(set_min_samples_split)):
                    for m in range(len(set_loss)):
                        for n in range(len(set_learning_rate)):
                            for p in range(len(set_criterion)):
                                est = GradientBoostingRegressor(
                                    random_state=0,
                                    n_estimators=set_n_estimators[i],
                                    min_samples_leaf=set_min_samples_leaf[j],
                                    max_depth=set_max_depth[k],
                                    min_samples_split=set_min_samples_split[l],
                                    loss=set_loss[m],
                                    learning_rate=set_learning_rate[n],
                                    criterion=set_criterion[p]
                                ).fit(X_train, y_train)
                                y_validation_gb[:, i, j, k, l, m, n, p] = est.predict(X)

    y_validation_gb = y_validation_gb.reshape(
        X.shape[0],
        len(set_n_estimators) * len(set_min_samples_leaf) * len(set_max_depth) * len(set_min_samples_split) * len(set_loss) * len(set_learning_rate) * len(set_criterion)
    )

    # ----- Build RF validation predictions -----
    y_validation_rf = np.empty([
        X.shape[0],
        len(set_n_estimators_rf), len(set_min_samples_leaf_rf),
        len(set_max_features_rf), len(set_min_samples_split_rf)
    ])

    for i in range(len(set_n_estimators_rf)):
        for j in range(len(set_min_samples_leaf_rf)):
            for k in range(len(set_max_features_rf)):
                for l in range(len(set_min_samples_split_rf)):
                    est = RandomForestRegressor(
                        random_state=0,
                        n_estimators=set_n_estimators_rf[i],
                        min_samples_leaf=set_min_samples_leaf_rf[j],
                        max_features=set_max_features_rf[k],
                        min_samples_split=set_min_samples_split_rf[l],
                        n_jobs=-1
                    ).fit(X_train, y_train)
                    y_validation_rf[:, i, j, k, l] = est.predict(X)

    y_validation_rf = y_validation_rf.reshape(
        X.shape[0],
        len(set_n_estimators_rf) * len(set_min_samples_leaf_rf) * len(set_max_features_rf) * len(set_min_samples_split_rf)
    )

    # stack all models
    y_validation = np.concatenate([y_validation_gb, y_validation_rf], axis=1)

    # ----- Build validation errors on the holdout window -----
    error_all = np.empty([y_validation.shape[1], n_test])
    y_extracted = y_validation[n_train: n_train + n_test, :].T
    y_augmented = y[n_train: n_train + n_test] * np.ones([y_validation.shape[1], 1], dtype=None)

    for i in range(y_validation.shape[1]):
        for j in range(n_test):
            error_all[i, j] = (y_augmented[i, j] - y_extracted[i, j])

    error_all = error_all.T
    error_all_absolute = np.abs(error_all)
    mape_final = np.mean(error_all_absolute, axis=0)

    # percentile filter
    df_error = pd.DataFrame(data=mape_final)
    is_lesser = df_error[0] <= np.percentile(mape_final, filter_percentile)
    df_error = df_error[is_lesser]
    _ = np.array(df_error)  # kept for consistency

    # filtered candidate predictions (train+val+future)
    df_validation = pd.DataFrame(data=y_validation.T)
    df_validation = df_validation[is_lesser.values]
    y_validation_filtered = df_validation.to_numpy().T  # shape (T, M)

    # ----- Refit all candidates on the final-train and build "forecast_final" for entire timeline -----
    # GB
    y_forecast_final_gb = np.empty([
        X.shape[0],
        len(set_n_estimators), len(set_min_samples_leaf),
        len(set_max_depth), len(set_min_samples_split),
        len(set_loss), len(set_learning_rate), len(set_criterion)
    ])
    for i in range(len(set_n_estimators)):
        for j in range(len(set_min_samples_leaf)):
            for k in range(len(set_max_depth)):
                for l in range(len(set_min_samples_split)):
                    for m in range(len(set_loss)):
                        for n in range(len(set_learning_rate)):
                            for p in range(len(set_criterion)):
                                est = GradientBoostingRegressor(
                                    random_state=0,
                                    n_estimators=set_n_estimators[i],
                                    min_samples_leaf=set_min_samples_leaf[j],
                                    max_depth=set_max_depth[k],
                                    min_samples_split=set_min_samples_split[l],
                                    loss=set_loss[m],
                                    learning_rate=set_learning_rate[n],
                                    criterion=set_criterion[p]
                                ).fit(X_train_final_forecast, y_train_final_forecast)
                                y_forecast_final_gb[:, i, j, k, l, m, n, p] = est.predict(X)

    y_forecast_final_gb = y_forecast_final_gb.reshape(
        X.shape[0],
        len(set_n_estimators) * len(set_min_samples_leaf) * len(set_max_depth) * len(set_min_samples_split) * len(set_loss) * len(set_learning_rate) * len(set_criterion)
    )

    # RF
    y_forecast_final_rf = np.empty([
        X.shape[0],
        len(set_n_estimators_rf), len(set_min_samples_leaf_rf),
        len(set_max_features_rf), len(set_min_samples_split_rf)
    ])
    for i in range(len(set_n_estimators_rf)):
        for j in range(len(set_min_samples_leaf_rf)):
            for k in range(len(set_max_features_rf)):
                for l in range(len(set_min_samples_split_rf)):
                    est = RandomForestRegressor(
                        random_state=0,
                        n_estimators=set_n_estimators_rf[i],
                        min_samples_leaf=set_min_samples_leaf_rf[j],
                        max_features=set_max_features_rf[k],
                        min_samples_split=set_min_samples_split_rf[l],
                        n_jobs=-1
                    ).fit(X_train_final_forecast, y_train_final_forecast)
                    y_forecast_final_rf[:, i, j, k, l] = est.predict(X)

    y_forecast_final_rf = y_forecast_final_rf.reshape(
        X.shape[0],
        len(set_n_estimators_rf) * len(set_min_samples_leaf_rf) * len(set_max_features_rf) * len(set_min_samples_split_rf)
    )

    y_forecast_final = np.concatenate([y_forecast_final_gb, y_forecast_final_rf], axis=1)

    # keep only filtered candidate columns for forecast
    df_forecast = pd.DataFrame(data=y_forecast_final.T)
    df_forecast = df_forecast[is_lesser.values]
    y_forecast_filtered = df_forecast.to_numpy().T  # (T, M_filtered)

    # ----- Compute filtered error matrix for validation+check -----
    error_filtered = np.empty([y_validation_filtered.shape[1], n_test + n_check])
    y_extracted_filtered = y_validation_filtered[n_train: n_train + n_test + n_check, :].T
    y_augmented_filtered = y[n_train: n_train + n_test + n_check] * np.ones([y_validation_filtered.shape[1], 1], dtype=None)

    for i in range(y_validation_filtered.shape[1]):
        for j in range(n_test + n_check):
            error_filtered[i, j] = (y_augmented_filtered[i, j] - y_extracted_filtered[i, j])

    error_filtered = error_filtered.T

    # Training error (for convex objective)
    error_training = np.empty([y_forecast_filtered.shape[1], (n_train_final_forecast - n_test - n_check)])
    y_extracted_train = y_forecast_filtered[0: n_train_final_forecast - n_test - n_check, :].T
    y_augmented_train = y[0: (n_train_final_forecast - n_test - n_check)] * np.ones([y_forecast_filtered.shape[1], 1], dtype=None)

    for i in range(y_forecast_filtered.shape[1]):
        for j in range(n_train_final_forecast - n_test - n_check):
            error_training[i, j] = (y_augmented_train[i, j] - y_extracted_train[i, j])

    error_training = error_training.T
    _ = np.concatenate((error_training, error_filtered), axis=0)  # kept placeholder (unused later)

    # ----- convex blend (kept) -----
    A = error_filtered
    n_validation_pts, n_model = A.shape

    x = cp.Variable(n_model)

    # per-step L1, variance and max error penalties (kept)
    objective_value = 0
    variance_sum = 0
    max_error_sum = 0
    for r in range(min(6, A.shape[0])):  # safeguard if fewer than 6 rows
        objective_value += cp.norm(A[r, :] @ x, 1)
        variance_sum += cp.sum_squares(A[r, :] * x - mean(A[r, :] * x))
        max_error_sum += cp.norm(A[r, :] * x, "inf")

    testing_error_co = objective_value + gamma_var * variance_sum + gamma_max * max_error_sum
    constraints = [alpha2 <= x, 1 - delta1 <= cp.sum(x), 1 + delta2 >= cp.sum(x)]

    prob = cp.Problem(cp.Minimize(testing_error_co), constraints)
    _ = prob.solve(solver=cp.ECOS)
    x_optimal = x.value

    # Validation forecast from filtered candidates + weights
    X_validation = y_validation_filtered
    n_order_points = X_validation.shape[0]
    validation_matrix = np.empty([n_order_points, n_model])
    for i in range(n_order_points):
        for j in range(n_model):
            validation_matrix[i, j] = X_validation[i, j] * x_optimal[j]
    validation_forecast = np.sum(validation_matrix, axis=1)
    validation_forecast[validation_forecast <= 100] = 0

    # Final (full) forecast
    X_forecast = y_forecast_filtered
    forecast_matrix = np.empty([n_order_points, n_model])
    for i in range(n_order_points):
        for j in range(n_model):
            forecast_matrix[i, j] = X_forecast[i, j] * x_optimal[j]
    final_forecast = np.sum(forecast_matrix, axis=1)
    final_forecast[final_forecast <= 100] = 0

    return (final_forecast, validation_forecast, y_forecast_final, x_optimal,
            y_validation_filtered, y_forecast_filtered, is_lesser.values)


def forecast_simple(X, y):
    return forecast_module(
        set_n_estimators, set_min_samples_leaf, set_max_depth, set_min_samples_split,
        set_loss, set_learning_rate, set_criterion,
        set_n_estimators_rf, set_min_samples_leaf_rf, set_max_features_rf, set_min_samples_split_rf,
        X, y
    )


# ============================================
# NEW: Single best model + ensemble band utils
# ============================================
def single_best_model_forecast(X_df, y,
                               set_n_estimators, set_min_samples_leaf, set_max_depth, set_min_samples_split, set_loss, set_learning_rate, set_criterion,
                               set_n_estimators_rf, set_min_samples_leaf_rf, set_max_features_rf, set_min_samples_split_rf,
                               n_test=6, n_check=3, metric="mae"):
    """
    Evaluate all GB/RF configs on the validation window, pick the best,
    refit on the full train slice, return full-length forecast + metadata.
    """

    # mirror the ensemble's feature selection
    n_labels = X_df.shape[0] - 6
    n_train = n_labels - n_test - n_check
    n_train_final = n_labels

    X_reduced = X_df.iloc[0:n_labels - 6, :]
    y_reduced = y[0:n_labels - 6]
    rfc_rf = GradientBoostingRegressor(random_state=101)
    rfecv_rf = RFECV(estimator=rfc_rf, step=0.5, cv=5, scoring='neg_mean_absolute_error')
    rfecv_rf.fit(X_reduced, y_reduced)
    X_df = X_df.drop(X_reduced.columns[np.where(rfecv_rf.support_ == False)[0]], axis=1, inplace=False)

    X = np.asarray(X_df)
    X_train = X[0:n_train, :]
    y_train = y[0:n_train]
    X_train_final = X[0:n_train_final, :]
    y_train_final = y[0:n_train_final]

    val_slice_pred = slice(n_train, n_train + n_test)
    val_true = y[n_train:n_train + n_test]

    def score_err(true, pred):
        if metric == "mae":
            return float(np.mean(np.abs(true - pred)))
        if metric == "mape":
            denom = np.maximum(np.abs(true), 1e-9)
            return float(np.mean(np.abs(true - pred) / denom))
        # rmse
        return float(np.sqrt(np.mean((true - pred) ** 2)))

    best = {"fam": None, "params": None, "val_error": np.inf, "model": None}

    # GB grid
    for ne in set_n_estimators:
        for msl in set_min_samples_leaf:
            for md in set_max_depth:
                for mss in set_min_samples_split:
                    for loss in set_loss:
                        for lr in set_learning_rate:
                            for crit in set_criterion:
                                try:
                                    est = GradientBoostingRegressor(
                                        random_state=0,
                                        n_estimators=ne,
                                        min_samples_leaf=msl,
                                        max_depth=md,
                                        min_samples_split=mss,
                                        loss=loss,
                                        learning_rate=lr,
                                        criterion=crit
                                    ).fit(X_train, y_train)
                                    preds = est.predict(X)
                                    err = score_err(val_true, preds[val_slice_pred])
                                    if err < best["val_error"]:
                                        best = {
                                            "fam": "GB",
                                            "params": dict(n_estimators=ne, min_samples_leaf=msl, max_depth=md,
                                                           min_samples_split=mss, loss=loss, learning_rate=lr, criterion=crit),
                                            "val_error": err,
                                            "model": est
                                        }
                                except Exception:
                                    pass

    # RF grid
    for ne in set_n_estimators_rf:
        for msl in set_min_samples_leaf_rf:
            for mf in set_max_features_rf:
                for mss in set_min_samples_split_rf:
                    try:
                        est = RandomForestRegressor(
                            random_state=0, n_estimators=ne, min_samples_leaf=msl,
                            max_features=mf, min_samples_split=mss, n_jobs=-1
                        ).fit(X_train, y_train)
                        preds = est.predict(X)
                        err = score_err(val_true, preds[val_slice_pred])
                        if err < best["val_error"]:
                            best = {
                                "fam": "RF",
                                "params": dict(n_estimators=ne, min_samples_leaf=msl, max_features=mf,
                                               min_samples_split=mss),
                                "val_error": err,
                                "model": est
                            }
                    except Exception:
                        pass

    # refit winner on full train
    if best["fam"] == "GB":
        p = best["params"]
        model = GradientBoostingRegressor(random_state=0, **p).fit(X_train_final, y_train_final)
    elif best["fam"] == "RF":
        p = best["params"]
        model = RandomForestRegressor(random_state=0, n_jobs=-1, **p).fit(X_train_final, y_train_final)
    else:
        raise RuntimeError("No valid single best model found.")

    y_pred_full = model.predict(X)
    y_pred_full = y_pred_full.copy()
    y_pred_full[y_pred_full <= 100] = 0

    meta = {"family": best["fam"], "params": best["params"], "val_error": best["val_error"]}
    return y_pred_full, meta, model, X_df  # return X_df in case caller wants aligned features


def ensemble_percentile_bands(y_forecast_filtered: np.ndarray, qs=(10, 50, 90)):
    """Per-timestamp quantile bands across filtered candidate forecasts."""
    yF = np.asarray(y_forecast_filtered)
    return {int(q): np.percentile(yF, q, axis=1) for q in qs}


def trimmed_mean_forecast(y_forecast_filtered: np.ndarray, trim_frac: float = 0.1):
    """Robust per-timestamp trimmed mean across filtered models."""
    yF = np.asarray(y_forecast_filtered)
    M = yF.shape[1]
    k = int(np.floor(trim_frac * M))
    sorted_vals = np.sort(yF, axis=1)
    if k == 0:
        return sorted_vals.mean(axis=1)
    return sorted_vals[:, k:M - k].mean(axis=1)


# ============================================
# NEW: CP plotting helpers (multi-panel + overlay)
# ============================================
def _ax_with_traces(ax, rng, yF, n_horizon, title=""):
    """Utility: plot all candidate forecasts (last horizon) on one axes."""
    ax.plot(rng[-n_horizon:], yF[-n_horizon:, :], ":", lw=1)
    ax.set_title(title)
    for label in ax.get_xticklabels():
        label.set_rotation(90)


def _vlines(ax, dates, color="g", alpha=0.9):
    """Draw vertical lines for a list of date-like items."""
    if dates is None:
        return
    for d in dates:
        ts = pd.Timestamp(d) if not isinstance(d, pd.Timestamp) else d
        ax.axvline(ts, color=color, alpha=alpha)


def plot_change_point_panels(
    rng,
    y_forecast_final,
    n_horizon,
    cluster_date_ggs=None,
    cluster_date_ig=None,
    cluster_date_bnb_offline=None,
    cluster_date_bnb_online=None,
    cluster_date_bo=None,
    cluster_date_mf_norm=None,
    cluster_date_mf=None,
):
    """Multi-panel CP view with per-method vertical lines."""
    panels = [
        ("GGS",              cluster_date_ggs,        "b"),
        ("IG",               cluster_date_ig,         "g"),
        ("B&B offline",      cluster_date_bnb_offline,"r"),
        ("B&B online",       cluster_date_bnb_online, "c"),
        ("Bayesian offline", cluster_date_bo,         "m"),
        ("Active multi fidelity (Normal)",   cluster_date_mf_norm, "k"),
        ("Active multi fidelity (Bernoulli)",cluster_date_mf,      "tab:blue"),
    ]

    fig, axes = plt.subplots(3, 3, figsize=(20, 12))
    axes = axes.ravel()

    filled = 0
    for title, dates, color in panels:
        if dates is None:
            continue
        ax = axes[filled]
        _ax_with_traces(ax, rng, y_forecast_final, n_horizon, title=title)
        _vlines(ax, dates, color=color)
        filled += 1

    for k in range(filled, len(axes)):
        axes[k].axis("off")

    plt.tight_layout()
    plt.show()


def plot_change_points_overlay(
    rng,
    y_forecast_final,
    n_horizon,
    methods_dict,
):
    """Single overlay of last horizon with all methods' CP lines together."""
    plt.figure(figsize=(16, 6))
    plt.plot(rng[-n_horizon:], y_forecast_final[-n_horizon:, :], ":", lw=1)

    # add each method's lines and a legend handle
    for label, (dates, color) in methods_dict.items():
        if dates is None:
            continue
        for d in dates:
            ts = pd.Timestamp(d) if not isinstance(d, pd.Timestamp) else d
            plt.axvline(ts, color=color, alpha=0.9)
        plt.plot([], [], color=color, label=label)

    plt.legend(loc="upper left", ncol=2, frameon=False)
    plt.title("All change-point methods (overlay, last horizon)")
    plt.xticks(rotation=90)
    plt.tight_layout()
    plt.show()


def plot_ensemble_band_vs_single(rng, y_actual, bands, single_forecast, ensemble_forecast, n_horizon):
    T_full = len(rng)
    T_y = len(y_actual)

    plt.figure(figsize=(14, 6))
    plt.plot(rng[:T_y], y_actual, 'k', lw=1.5, label="Actual")
    plt.plot(rng, ensemble_forecast, label="Ensemble (weighted)", alpha=0.9)
    plt.plot(rng, single_forecast, label="Single best", alpha=0.9)

    idx_start = T_full - n_horizon
    p10 = bands.get(10)
    p50 = bands.get(50)
    p90 = bands.get(90)
    if p10 is not None and p50 is not None and p90 is not None:
        plt.fill_between(rng[idx_start:], p10[idx_start:], p90[idx_start:], alpha=0.15, label="Ensemble band (p10–p90)")
        plt.plot(rng[idx_start:], p50[idx_start:], linestyle='--', alpha=0.8, label="Ensemble median")

    plt.title("Ensemble band vs Single-best")
    plt.legend()
    plt.tight_layout()
    plt.show()


# =======================
# Main run orchestration
# =======================
if __name__ == "__main__":
    # ----- Load data -----
    df = pd.read_csv(file_name)
    df = df.drop(['date'], axis=1)

    rng = pd.date_range('31/01/2018', periods=df.shape[0], freq='M')
    y = df['order_qty'].to_numpy()
    X = df.drop(['order_qty'], axis=1)
    X = X.dropna(axis=1)

    # y shortened by 6 (kept)
    y = y[0: y.shape[0] - 6]

    # ----- Ensemble forecast -----
    (final_forecast, validation_forecast, y_forecast_final, x_optimal,
     y_validation_filtered, y_forecast_filtered, mask_cols) = forecast_simple(X, y)

    # SMAPE on last n_check (kept logic)
    y_true_last = np.array(y)[-n_check:]
    y_val_from_ens = np.array(validation_forecast)[-(n_check + 6):][:n_check]
    s_mape = smape(y_true_last, y_val_from_ens)
    print('The SMAPE is:', s_mape)

    # ----- Change-point detection inputs -----
    feats = [1]
    data = y_forecast_final[-n_horizon:, :].T  # (M, T_h)

    # GGS
    break_points_ggs, objectives = GGS((data) ** (0.5), Kmax=nbpt, lamb=1e-4, features=feats)
    # IGTS
    break_points_ig, _ = DP_IGTS(data, nbpt, 1, 1)

    # B&B (changetree)
    random.seed(0)
    ntrees = 10
    w = 1
    lim = 5
    print("starting change detection")
    score, changes = changetree.change_score(data.T, ntrees, w, lim)
    print("finishing learning forest")
    print("finished scoring")
    score_online, changes_online = changetree.change_score_online(data.T, ntrees, w, lim)
    score_online = score_online[~np.isnan(score_online)]
    score = score[~np.isnan(score)]
    changes_online = score_online.argsort()[-nbpt:][::-1]
    changes = score.argsort()[-nbpt:][::-1]
    break_points_bnboffline = changes
    break_points_bnbonline = changes_online

    # Simple Bayesian "offline" stub using variance energy
    bo_change_point_score1 = np.sum((data - data.mean(axis=1, keepdims=True)) ** 2, axis=0)
    bo_change_point_score1 = bo_change_point_score1 / (bo_change_point_score1.max() + 1e-9)
    break_points_bayesianonline = bo_change_point_score1.argsort()[-nbpt:][::-1]

    # map points to dates for voting & plotting
    cluster_date_ggs = []
    for i in range(len(break_points_ggs) - 1):
        try:
            cluster_date_ggs.append(rng[-n_horizon:][break_points_ggs[i]])
        except Exception:
            cluster_date_ggs.append(rng[-n_horizon:][break_points_ggs[-1][i]])

    cluster_date_ig = [rng[-n_horizon:][bp] for bp in break_points_ig]
    cluster_date_bnb_offline = [rng[-n_horizon:][bp] for bp in break_points_bnboffline]
    cluster_date_bnb_online = [rng[-n_horizon:][bp] for bp in break_points_bnbonline]
    cluster_date_bo = [rng[-n_horizon:][bp] for bp in break_points_bayesianonline]

    # ----- Voting distribution -----
    change_points = []
    for arr in [cluster_date_ggs, cluster_date_ig, cluster_date_bnb_offline, cluster_date_bnb_online, cluster_date_bo]:
        for dt in arr:
            change_points.append(dt.date().strftime('%Y-%m-%d'))

    # Include MF-weighted votes (kept behavior as a simple duplicate of IG dates)
    repeat = 6 if non_uniform else 1
    for dt in set(cluster_date_ig):
        s = dt.date().strftime('%Y-%m-%d')
        for _ in range(repeat):
            change_points.append(s)

    counter_dist = dict(Counter(change_points))
    denom = 18.0 if non_uniform else 8.0
    probabilistic_cp = {k: round(v / denom, 2) for k, v in counter_dist.items()}
    print('Probabilistic CPD:', probabilistic_cp)

    def probability_computation(probabilistic_cp, rng, n_horizon):
        date_str = [d.date().strftime('%Y-%m-%d') for d in rng[-n_horizon:]]
        prob_all = {d: 0 for d in date_str}
        extras = {k: v for k, v in prob_all.items() if k not in probabilistic_cp}
        out = dict(probabilistic_cp)
        for z in extras:
            out[z] = 0
        return out, extras

    probabilistic_cp, _ = probability_computation(probabilistic_cp, rng, n_horizon)

    def dic_sort(input_dict):
        return collections.OrderedDict(sorted(input_dict.items()))

    def past_future(probabilistic_cp):
        uts = list(dic_sort(probabilistic_cp).values())
        future_sum = sum(uts[-6:]) / 6.0
        past_sum = 1 - future_sum
        return past_sum, future_sum

    past_sum, future_sum = past_future(probabilistic_cp)
    print(f"Past/Future shares: {past_sum:.2f}/{future_sum:.2f}")

    # =========================
    # Single-best + Bands
    # =========================
    single_forecast, single_meta, single_model, X_used = single_best_model_forecast(
        X, y,
        set_n_estimators, set_min_samples_leaf, set_max_depth, set_min_samples_split,
        set_loss, set_learning_rate, set_criterion,
        set_n_estimators_rf, set_min_samples_leaf_rf, set_max_features_rf, set_min_samples_split_rf,
        n_test=n_test, n_check=n_check, metric="mae"
    )
    print("Single best model:", single_meta)

    bands = ensemble_percentile_bands(y_forecast_filtered, qs=(10, 50, 90))
    _trimmed_mean = trimmed_mean_forecast(y_forecast_filtered, trim_frac=0.1)  # optional baseline

    # Comparison plot (band vs single vs ensemble)
    plot_ensemble_band_vs_single(rng, y, bands, single_forecast, final_forecast, n_horizon)

    # quick validation comparison on last n_check
    y_val_true = np.array(y)[-n_check:]
    y_val_pred_single = single_forecast[len(single_forecast) - n_horizon: len(single_forecast) - n_horizon + n_check]
    print("SMAPE (ensemble validation):", smape(y_val_true, y_val_from_ens))
    print("SMAPE (single   validation):", smape(y_val_true, y_val_pred_single))

    # -------------
    # Multi-panel CP plots and overlay (all methods)
    # -------------
    plot_change_point_panels(
        rng,
        y_forecast_final,
        n_horizon,
        cluster_date_ggs=cluster_date_ggs,
        cluster_date_ig=cluster_date_ig,
        cluster_date_bnb_offline=cluster_date_bnb_offline,
        cluster_date_bnb_online=cluster_date_bnb_online,
        cluster_date_bo=cluster_date_bo,
        # If you later add these, pass them in:
        # cluster_date_mf_norm=cluster_date_mf_norm,
        # cluster_date_mf=cluster_date_mf,
    )

    methods_dict = {
        "GGS":              (cluster_date_ggs,        "b"),
        "IG":               (cluster_date_ig,         "g"),
        "B&B offline":      (cluster_date_bnb_offline,"r"),
        "B&B online":       (cluster_date_bnb_online, "c"),
        "Bayesian offline": (cluster_date_bo,         "m"),
        # "Active MF (Normal)":   (cluster_date_mf_norm, "k"),
        # "Active MF (Bernoulli)":(cluster_date_mf,      "tab:blue"),
    }
    plot_change_points_overlay(rng, y_forecast_final, n_horizon, methods_dict)

    # -------------
    # A few compact plots (kept)
    # -------------
    fig, ax = plt.subplots(figsize=(14, 6))
    ax.plot(rng[0: y.shape[0]], y, 'k')
    ax.plot(rng, final_forecast, 'r')
    ax.plot(rng, validation_forecast, ':m')
    ax.legend(['Actual', 'Ensemble forecast', 'Validation'])
    plt.tight_layout()
    plt.show()

    plt.figure(figsize=(14, 6))
    plt.plot(rng[0: y.shape[0]], y)
    plt.plot(rng, final_forecast, 'r')
    plt.plot(rng[-n_horizon:], y_forecast_final[-n_horizon:, :], ':')
    plt.title("All candidate forecasts (last horizon)")
    plt.tight_layout()
    plt.show()

    # Probability curve (ordered)
    plt.figure(figsize=(8, 4))
    ordered = dic_sort(probabilistic_cp)
    plt.plot(rng[-n_horizon:], list(ordered.values()), 'r:')
    plt.title("Change-point probability (voting)")
    plt.tight_layout()
    plt.show()
