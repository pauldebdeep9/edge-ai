#!/usr/bin/env python3
# save as find_orphans.py (repo root)
import ast
import sys
from pathlib import Path

SKIP_DIRS = {
    "archive", ".git", ".hg", ".svn", ".mypy_cache", ".pytest_cache",
    "__pycache__", ".ipynb_checkpoints", "env", "venv", ".venv",
    "build", "dist", ".tox", ".eggs", ".idea", ".vscode",
}
ROOT = Path(__file__).resolve().parent

def collect_py_files(root: Path):
    files = []
    for p in root.rglob("*.py"):
        rel = p.relative_to(root)
        if any(part in SKIP_DIRS for part in rel.parts):
            continue
        files.append(p)
    return files

def safe_read(p: Path) -> str:
    try:
        return p.read_text(encoding="utf-8")
    except Exception:
        try:
            return p.read_bytes().decode("utf-8", errors="ignore")
        except Exception:
            return ""

def parse_imports(p: Path):
    src = safe_read(p)
    if not src.strip():
        return set()
    try:
        tree = ast.parse(src, filename=str(p))
    except SyntaxError:
        return set()
    out = set()
    for n in ast.walk(tree):
        if isinstance(n, ast.Import):
            for a in n.names:
                out.add(a.name)                 # e.g. "mfbocd.models"
        elif isinstance(n, ast.ImportFrom):
            if n.module:
                out.add(n.module)               # e.g. "mfbocd.models"
    return out

def build_module_index(py_files):
    """
    Map module names to paths.
    Supports packages (dir with __init__.py) and individual modules.
    """
    mod_to_paths = {}
    pkg_roots = set()

    # record packages
    for p in py_files:
        if p.name == "__init__.py":
            pkg_roots.add(p.parent)

    # add package modules
    for p in py_files:
        rel = p.relative_to(ROOT)
        parts = rel.with_suffix('').parts  # ('mfbocd','models','normal')
        # only consider modules under a package root
        # find nearest ancestor that is a package root
        anc = p.parent
        while anc != ROOT and anc not in pkg_roots:
            anc = anc.parent
        if anc in pkg_roots:
            # module name is package path from ROOT to file (dots)
            mod = ".".join(rel.with_suffix('').parts)
            mod_to_paths.setdefault(mod, set()).add(p)

    # add top-level modules (non-package single py files)
    for p in py_files:
        rel = p.relative_to(ROOT)
        if p.name != "__init__.py" and p.parent not in pkg_roots:
            mod = rel.with_suffix('').name
            mod_to_paths.setdefault(mod, set()).add(p)

    return mod_to_paths

def resolve_import_to_paths(name: str, mod_index: dict[str, set[Path]]):
    """
    Try to resolve an import like 'mfbocd.models' to known file(s).
    We attempt exact match, then progressively shorter prefixes.
    """
    parts = name.split(".")
    candidates = set()
    for i in range(len(parts), 0, -1):
        key = ".".join(parts[:i])
        if key in mod_index:
            candidates |= mod_index[key]
            break
    return candidates

def bfs_reachable(entry: Path, mod_index: dict[str, set[Path]]):
    seen_files = set([entry])
    queue = [entry]
    while queue:
        f = queue.pop()
        for mod in parse_imports(f):
            for target in resolve_import_to_paths(mod, mod_index):
                if target not in seen_files:
                    seen_files.add(target)
                    queue.append(target)
    return seen_files

def main():
    entry = ROOT / "main.py"
    if not entry.exists():
        print(f"[!] main.py not found at {entry}")
        sys.exit(1)

    py_files = collect_py_files(ROOT)
    mod_index = build_module_index(py_files)
    reachable = bfs_reachable(entry, mod_index)

    orphans = [p for p in py_files if p not in reachable and p.name != Path(__file__).name]
    print("Repo root:", ROOT)
    print("Entry    :", entry.relative_to(ROOT))
    print("\nOrphan candidates:")
    if not orphans:
        print("  (none 🎉)")
    else:
        for p in sorted(orphans):
            print(" -", p.relative_to(ROOT))

if __name__ == "__main__":
    main()
