# -*- coding: utf-8 -*-
"""
Greedy Gaussian Segmentation (GGS) utilities.

Public API (unchanged):
- GGS(data, Kmax, lamb, features=[], verbose=False)
- GGSCrossVal(data, Kmax=25, lambList=[0.1, 1, 10], features=[], verbose=False)
- GGSMeanCov(data, breakpoints, lamb, features=[], verbose=False)

Notes:
- `data` is expected as (features x samples) in the original code, and is transposed
  at function entry to shape (samples x features) internally.
- This refactor keeps that behavior for backward compatibility.
"""

from __future__ import annotations

import math
import random
import multiprocessing
from typing import List, Sequence, Tuple

import numpy as np


# =========================
# Core public entry points
# =========================

def GGS(
    data: np.ndarray,
    Kmax: int,
    lamb: float,
    features: Sequence[int] | List[int] = (),
    verbose: bool = False,
):
    """
    Find up to Kmax breakpoints on `data` at regularization `lamb`.

    Parameters
    ----------
    data : np.ndarray
        Array of shape (p x T) (features x samples). The function internally
        transposes to (T x p).
    Kmax : int
        Maximum number of breakpoints to add.
    lamb : float
        Covariance regularization parameter (lambda).
    features : sequence of int
        Indices of features to include. If empty, use all.
    verbose : bool
        If True, print progress.

    Returns
    -------
    breakPoints : list[list[int]]
        A list where each element is the cumulative list of break indices
        [0, ..., T+1] after each iteration. (Includes 0 and T+1.)
    plotPoints : list[float]
        Corresponding (regularized) negative log-likelihood values per iteration.
    """
    X = data.T  # (samples x features)
    # Select desired features
    if not features:
        features = range(X.shape[1])
    X = X[:, list(features)]

    T, p = X.shape

    # Initialize breakpoints list with [0, T+1]
    breaks = [0, T + 1]
    break_points = [breaks[:]]
    plot_points = [calculateLikelihood(X, breaks, lamb)]

    # Main greedy loop
    for z in range(Kmax):
        num_segs = z + 1
        best_idx = -1
        best_val = +1.0  # LL delta is "val"; lower is better; initialized to +1

        # For each current segment, find the best internal breakpoint
        for i in range(num_segs):
            seg = X[breaks[i] : breaks[i + 1], :]
            idx, val = addBreak(seg, lamb)
            if val < best_val:
                best_idx = idx + breaks[i]
                best_val = val

        # If no improvement, stop
        if best_val == 0:
            if verbose:
                print("No more improvements; stopping.")
                print(breaks)
            return breaks, plot_points

        # Add the new breakpoint
        breaks.append(int(best_idx))
        breaks.sort()

        if verbose:
            print(f"Breakpoint at sample {best_idx}, ΔLL = {best_val}")
            print(f"{len(breaks) - 2} breaks: {breaks}")

        # Adjust breakpoints (local refinement)
        breaks = adjustBreaks(X, breaks, [best_idx], lamb, verbose)[:]

        # Compute current (regularized) negative log-likelihood
        ll = calculateLikelihood(X, breaks, lamb)
        break_points.append(breaks[:])
        plot_points.append(ll)

    return break_points, plot_points


def GGSCrossVal(
    data: np.ndarray,
    Kmax: int = 25,
    lambList: Sequence[float] | List[float] = (0.1, 1.0, 10.0),
    features: Sequence[int] | List[int] = (),
    verbose: bool = False,
):
    """
    10-fold cross-validation for GGS up to Kmax and multiple lambdas.

    Returns
    -------
    trainTestResults : list[tuple[float, tuple[list[float], list[float]]]]
        For each lambda, a tuple: (lambda, (train_avg_per_K, test_avg_per_K)).
    """
    X = data.T  # (samples x features)
    if not features:
        features = range(X.shape[1])
    X = X[:, list(features)]
    origSize, p = X.shape

    # Shuffle sample ordering deterministically
    rng = np.random.default_rng(seed=0)
    ordering = list(range(origSize))
    rng.shuffle(ordering)

    train_test_results = []

    # Run 10 folds in parallel per lambda
    num_processes = min(multiprocessing.cpu_count(), 10)
    pool = multiprocessing.Pool(processes=num_processes)

    try:
        for lamb in lambList:
            mseList = []
            trainList = []
            # Prepare 10 tasks (folds)
            tasks = [
                (fold, X, Kmax, lamb, verbose, origSize, p, ordering) for fold in range(10)
            ]
            results = pool.map(multi_run_wrapper, tasks)

            # Accumulate fold results
            for fold_res in results:
                mseList.extend(fold_res[0])
                trainList.extend(fold_res[1])

            # Average test per K
            # mseList contains tuples: (K, score)
            if not mseList:
                train_test_results.append((lamb, ([], [])))
                continue

            ks_test, vals_test = list(zip(*mseList))
            maxK = max(ks_test) + 1
            testAvg = []
            for k in range(maxK):
                sel = [v for kk, v in zip(ks_test, vals_test) if kk == k]
                testAvg.append(float(sum(sel)) / len(sel))

            # Average train per K
            ks_train, vals_train = list(zip(*trainList))
            trainAvg = []
            for k in range(maxK):
                sel = [v for kk, v in zip(ks_train, vals_train) if kk == k]
                trainAvg.append(float(sum(sel)) / len(sel))

            train_test_results.append((lamb, (trainAvg, testAvg)))
    finally:
        # Always clean up the pool
        pool.close()
        pool.join()

    return train_test_results


def GGSMeanCov(
    data: np.ndarray,
    breakpoints: Sequence[int] | List[int],
    lamb: float,
    features: Sequence[int] | List[int] = (),
    verbose: bool = False,
):
    """
    Compute (mean, regularized covariance) for each segment defined by `breakpoints`.

    Returns
    -------
    mean_covs : list[tuple[np.ndarray, np.ndarray]]
        For each segment, a tuple (empMean, regularizedCov).
    """
    X = data.T
    if not features:
        features = range(X.shape[1])
    X = X[:, list(features)]

    numSegments = len(breakpoints) - 1
    mean_covs = []
    for i in range(numSegments):
        seg = X[breakpoints[i] : breakpoints[i + 1], :]
        m, n = seg.shape
        empMean = np.mean(seg, axis=0)
        empCov = np.cov(seg.T, bias=True)
        regularizedCov = empCov + float(lamb) * np.identity(n) / max(m, 1)
        mean_covs.append((empMean, regularizedCov))

    return mean_covs


# =================
# Helper functions
# =================

def calculateLikelihood(X: np.ndarray, breaks: Sequence[int], lamb: float) -> float:
    """
    Compute the (regularized) negative log-likelihood across all segments.

    The per-segment contribution is:
        m * logdet(Sigma + (lambda/m) I) - lambda * tr( (Sigma + (lambda/m) I)^{-1} )
    where Sigma is the empirical covariance of the segment.

    Lower is better.
    """
    ll = 0.0
    for i in range(len(breaks) - 1):
        seg = X[breaks[i] : breaks[i + 1], :]
        m, n = seg.shape
        if m <= 1:
            # Degenerate segment; contribute nothing
            continue
        empCov = np.cov(seg.T, bias=True)
        reg = float(lamb) * np.identity(n) / m
        A = empCov + reg
        sign, logdet = np.linalg.slogdet(A)
        # slogdet returns log|A|; sign should be +1 for posdef
        ll += -(m * logdet - float(lamb) * np.trace(np.linalg.inv(A)))
    return ll


def addBreak(seg: np.ndarray, lamb: float) -> Tuple[int, float]:
    """
    For a single segment (m x n), scan all interior positions and return the
    index (relative to the segment start) that yields the largest improvement
    (i.e., lowest objective value). Also return the improvement (delta).

    Returns
    -------
    (minInd, minLL - origLL)
    """
    m, n = seg.shape
    if m <= 3:
        # Not enough points to split; return no improvement
        return 0, 0.0

    # Original (regularized) objective for the whole segment
    origMean = np.mean(seg, axis=0)
    origCov = np.cov(seg.T, bias=True)
    A0 = origCov + float(lamb) * np.identity(n) / m
    sign0, logdet0 = np.linalg.slogdet(A0)
    if sign0 <= 0:
        # Shouldn't happen if A0 is PD; guard for numeric issues
        logdet0 = np.log(np.abs(np.linalg.det(A0)) + 1e-20)
    origLL = m * logdet0 - float(lamb) * np.trace(np.linalg.inv(A0))

    # Precompute totals
    totSum = m * (origCov + np.outer(origMean, origMean))

    # Running stats for left/right partitions
    muLeft = seg[0, :] / n
    muRight = (m * origMean - seg[0, :]) / (m - 1)
    runSum = np.outer(seg[0, :], seg[0, :])

    minLL = origLL
    minInd = 0

    # Scan interior split points
    for i in range(2, m - 1):
        x_prev = seg[i - 1, :]
        runSum += np.outer(x_prev, x_prev)

        # Update means
        muLeft = ((i - 1) * muLeft + x_prev) / i
        muRight = ((m - i + 1) * muRight - x_prev) / (m - i)

        # Covariances
        sigLeft = runSum / i - np.outer(muLeft, muLeft)
        sigRight = (totSum - runSum) / (m - i) - np.outer(muRight, muRight)

        # Regularize and Cholesky
        A_left = sigLeft + float(lamb) * np.identity(n) / i
        A_right = sigRight + float(lamb) * np.identity(n) / (m - i)

        # Cholesky-based logdet (stable)
        try:
            Lleft = np.linalg.cholesky(A_left)
            llLeft = 2.0 * np.sum(np.log(np.diag(Lleft)))
        except np.linalg.LinAlgError:
            # Fall back if not PD due to numerical issues
            signL, llLeft = np.linalg.slogdet(A_left)
            if signL <= 0:
                continue

        try:
            Lright = np.linalg.cholesky(A_right)
            llRight = 2.0 * np.sum(np.log(np.diag(Lright)))
        except np.linalg.LinAlgError:
            signR, llRight = np.linalg.slogdet(A_right)
            if signR <= 0:
                continue

        trLeft = 0.0
        trRight = 0.0
        if lamb > 0:
            # ||inv(L)||_F^2 equals trace( (A)^{-1} ), but we keep the original
            # expression to preserve exact behavior.
            invLleft = np.linalg.inv(Lleft)
            invLright = np.linalg.inv(Lright)
            trLeft = float(np.linalg.norm(invLleft) ** 2)
            trRight = float(np.linalg.norm(invLright) ** 2)

        LL = i * llLeft - float(lamb) * trLeft + (m - i) * llRight - float(lamb) * trRight

        if LL < minLL:
            minLL = LL
            minInd = i

    return int(minInd), float(minLL - origLL)


def adjustBreaks(
    X: np.ndarray,
    breakpoints: Sequence[int] | List[int],
    newInd: Sequence[int] | List[int],
    lamb: float = 0.0,
    verbose: bool = False,
    maxShuffles: int = 250,
):
    """
    Local refinement pass that nudges breakpoints for better objective.

    Returns
    -------
    list[int] : refined breakpoints (including 0 and T+1)
    """
    bp = list(breakpoints)
    random.seed(0)

    # If only one breakpoint (i.e., breaks = [0, T+1, k]), nothing to adjust
    if len(bp) == 3:
        return bp

    # Track which breakpoints changed in the previous / current pass
    lastPass = {b: 0 for b in bp}
    thisPass = {b: 0 for b in bp}
    for i in newInd:
        thisPass[int(i)] = 1

    for _ in range(maxShuffles):
        lastPass = dict(thisPass)
        thisPass = {b: 0 for b in bp}
        switched = False

        order = list(range(1, len(bp) - 1))
        random.shuffle(order)

        for i in order:
            left_b, cur_b, right_b = bp[i - 1], bp[i], bp[i + 1]
            # Only adjust if neighbors moved in last/this pass
            if (
                lastPass.get(left_b, 0) == 1
                or lastPass.get(right_b, 0) == 1
                or thisPass.get(left_b, 0) == 1
                or thisPass.get(right_b, 0) == 1
            ):
                seg = X[left_b:right_b, :]
                idx, val = addBreak(seg, lamb)
                new_b = int(idx + left_b)

                if cur_b != new_b and val != 0:
                    # Update pass-change tracking
                    lastPass[new_b] = lastPass.get(cur_b, 0)
                    lastPass.pop(cur_b, None)
                    thisPass.pop(cur_b, None)
                    thisPass[new_b] = 1

                    if verbose:
                        print(f"Moving {cur_b} -> {new_b} (seg len={seg.shape[0]}, idx={idx})")

                    bp[i] = new_b
                    switched = True

        if not switched:
            return bp

    return bp


# =========
# CV helpers
# =========

def multi_run_wrapper(args):
    return oneFold(*args)


def oneFold(
    fold: int,
    X: np.ndarray,
    breakpoints: int,
    lamb: float,
    verbose: bool,
    origSize: int,
    n_features: int,
    ordering: List[int],
):
    """
    One 10% holdout CV fold. Returns:
      - mseList: list of (K, avg test log-likelihood)
      - trainList: list of (K, avg train log-likelihood)
    """
    mseList = []
    trainList = []

    # Determine fold slice (use integer division)
    start = (fold * origSize) // 10
    end = ((fold + 1) * origSize) // 10
    test_idx = np.sort(np.array(ordering[start:end], dtype=int))

    mask = np.ones(origSize, dtype=bool)
    mask[test_idx] = False

    trainData = X[mask, :]
    testSize = test_idx.size
    trainSize = origSize - testSize

    # Run GGS on training data
    bp_list = GGS(trainData.T, breakpoints, lamb, [], verbose)[0]  # list of break arrays

    # For each breakpoint configuration in the path
    for b in bp_list:
        i = b  # break array including [0, ..., T+1]
        # --- Test likelihood ---
        mse = 0.0
        currBreak = 1

        # Initial segment stats
        seg = trainData[0 : i[1], :]
        empMean = np.mean(seg, axis=0)
        empCov = np.cov(seg.T, bias=True) + float(lamb) * np.identity(n_features) / max(seg.shape[0], 1)
        invCov = np.linalg.inv(empCov)

        for j in range(testSize):
            # Find which break the (adjusted) index belongs to
            adj = int(test_idx[j] - j)  # shift for removed train points
            cb = max(sum(1 for k in i if k < adj), 1)
            if currBreak != cb:
                currBreak = cb
                seg = trainData[i[currBreak - 1] : i[currBreak], :]
                seg_m = max(seg.shape[0], 1)
                empMean = np.mean(seg, axis=0)
                empCov = np.cov(seg.T, bias=True) + float(lamb) * np.identity(n_features) / seg_m
                invCov = np.linalg.inv(empCov)

            # Gaussian log-likelihood (up to additive constant)
            ldet = 0.5 * np.linalg.slogdet(invCov)[1]
            diff = (X[test_idx[j]] - empMean)
            ll = ldet - 0.5 * diff.dot(invCov).dot(diff) - n_features * math.log(2 * math.pi) / 2.0
            mse += ll

        mseList.append((len(i) - 2, mse / max(testSize, 1)))

        # --- Train likelihood ---
        tErr = 0.0
        currBreak = 1

        seg = trainData[0 : i[1], :]
        seg_m = max(seg.shape[0], 1)
        empMean = np.mean(seg, axis=0)
        empCov = np.cov(seg.T, bias=True) + float(lamb) * np.identity(n_features) / seg_m
        invCov = np.linalg.inv(empCov)

        for j in range(1, trainSize):
            if j in i:
                currBreak += 1
                seg = trainData[i[currBreak - 1] : i[currBreak], :]
                seg_m = max(seg.shape[0], 1)
                empMean = np.mean(seg, axis=0)
                empCov = np.cov(seg.T, bias=True) + float(lamb) * np.identity(n_features) / seg_m
                invCov = np.linalg.inv(empCov)

            ldet = 0.5 * np.linalg.slogdet(invCov)[1]
            diff = (trainData[j] - empMean)
            ll = ldet - 0.5 * diff.dot(invCov).dot(diff) - n_features * math.log(2 * math.pi) / 2.0
            tErr += ll

        trainList.append((len(i) - 2, tErr / max(trainSize, 1)))

    return mseList, trainList
