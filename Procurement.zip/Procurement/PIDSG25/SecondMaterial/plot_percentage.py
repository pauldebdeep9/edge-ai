#!/usr/bin/env python3
"""
pidsg25Evaluation.xlsx (last sheet) -> Separate storage plot
Figures:
  1) Procurement & Total — Without storage (bars, linear)
  2) Storage — Without storage (bars, symlog)
  3) Procurement & Total — With storage (bars, linear)        [if block 2 exists]
  4) Storage — With storage (bars, symlog)                    [if block 2 exists]
"""

import re
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

XLSX = "pidsg25Evaluation.xlsx"

# ---------- helpers ----------
def clean_str(x): 
    return "" if pd.isna(x) else str(x).strip()

def find_header_row(df_raw: pd.DataFrame):
    for i in range(min(len(df_raw), 30)):
        row = [clean_str(v).lower() for v in df_raw.iloc[i].tolist()]
        if not any(row): 
            continue
        joined = " ".join(row)
        if ("savings" in joined) and (("proc" in joined) or ("procurement" in joined)) \
           and (("stor" in joined) or ("storage" in joined)) and ("total" in joined):
            return i
    return None

def coerce_numeric(col: pd.Series) -> pd.Series:
    s = col.copy()
    if s.dtype == "O":
        s = s.astype(str).str.replace(r"[,%\s]", "", regex=True)
        s = s.str.replace("−", "-", regex=False)  # unicode minus
        s = s.replace({"": np.nan})
    return pd.to_numeric(s, errors="coerce")

def find_savings_cols(df: pd.DataFrame):
    # try by name
    def pick(frag1, frag2=None):
        frag1 = frag1.lower()
        frag2 = frag2.lower() if frag2 else None
        for c in df.columns:
            cl = str(c).lower()
            if frag1 in cl and ("savings" in cl) and (frag2 is None or frag2 in cl):
                return c
        return None
    c_proc = pick("proc") or pick("procurement")
    c_stor = pick("stor") or pick("storage")
    c_total = pick("total")
    if c_proc and c_stor and c_total:
        return c_proc, c_stor, c_total

    # fallback: rightmost 3 numeric columns
    usable = []
    for c in reversed(df.columns.tolist()):
        if coerce_numeric(df[c]).notna().sum() >= 1:
            usable.append(c)
        if len(usable) == 3:
            break
    if len(usable) < 3:
        raise ValueError("Could not find three savings columns.")
    return tuple(reversed(usable))

def find_month_col(df: pd.DataFrame):
    for c in df.columns:
        cl = str(c).lower()
        if any(k in cl for k in ["month", "date", "period"]):
            return c
    return None

def split_blocks(df: pd.DataFrame, value_cols):
    mask = df[value_cols].apply(lambda s: coerce_numeric(s).notna(), axis=0).any(axis=1)
    if not mask.any():
        return []
    grp = (mask & ~mask.shift(fill_value=False)).cumsum()
    return [g.copy() for _, g in df[mask].groupby(grp)]

def month_labels(block: pd.DataFrame, month_col: str | None):
    if month_col and month_col in block.columns:
        s = block[month_col]
        dt = pd.to_datetime(s, errors="coerce", infer_datetime_format=True)
        if dt.notna().mean() > 0.5:
            return dt.dt.to_period("M").astype(str).tolist()
        return s.astype(str).tolist()
    return [f"M{i+1}" for i in range(len(block))]

def pct_formatter():
    return FuncFormatter(lambda y, _: f"{y:.0f}%")

def add_value_labels(ax, rects, fmt="{:.1f}%"):
    for r in rects:
        h = r.get_height()
        if np.isfinite(h):
            ax.annotate(fmt.format(h),
                        xy=(r.get_x() + r.get_width()/2, h),
                        xytext=(0, 4 if h >= 0 else -14),
                        textcoords="offset points",
                        ha='center', va='bottom' if h >= 0 else 'top',
                        fontsize=8)

# ---------- plotting ----------
def plot_proc_total(block, month_col, c_proc, c_total, title):
    sub = pd.DataFrame({
        c_proc:  coerce_numeric(block[c_proc]),
        c_total: coerce_numeric(block[c_total]),
    }).dropna(how="all")
    if sub.empty:
        print(f"[WARN] '{title}' has no numeric data.")
        return

    labels = month_labels(block.loc[sub.index], month_col)
    x = np.arange(len(sub)); w = 0.35
    fig, ax = plt.subplots(figsize=(12, 6))
    r1 = ax.bar(x - w/2, sub[c_proc],  width=w, alpha=0.9, label=c_proc)
    r2 = ax.bar(x + w/2, sub[c_total], width=w, alpha=0.9, label=c_total)

    ax.axhline(0, color="black", lw=0.7)
    ax.set_xticks(x); ax.set_xticklabels(labels, rotation=45, ha="right")
    ax.set_xlabel("Month"); ax.set_ylabel("Percent")
    ax.yaxis.set_major_formatter(pct_formatter())
    ax.legend(loc="best"); ax.set_title(title)
    add_value_labels(ax, r1); add_value_labels(ax, r2)
    fig.tight_layout(); plt.show()

def plot_storage_only(block, month_col, c_stor, title, symlog=True, linthresh=5.0):
    sub = pd.DataFrame({c_stor: coerce_numeric(block[c_stor])}).dropna(how="all")
    if sub.empty:
        print(f"[WARN] '{title}' has no numeric data.")
        return

    labels = month_labels(block.loc[sub.index], month_col)
    x = np.arange(len(sub)); w = 0.5
    fig, ax = plt.subplots(figsize=(12, 5))
    bars = ax.bar(x, sub[c_stor], width=w, alpha=0.8, label=c_stor)

    ax.axhline(0, color="black", lw=0.7)
    ax.set_xticks(x); ax.set_xticklabels(labels, rotation=45, ha="right")
    ax.set_xlabel("Month"); ax.set_ylabel("Percent (Storage)")
    ax.yaxis.set_major_formatter(pct_formatter())
    if symlog:
        ax.set_yscale("symlog", linthresh=linthresh, linscale=1.0, base=10)
        ax.set_ylabel("Percent (Storage — symlog)")
    ax.legend(loc="best"); ax.set_title(title)
    add_value_labels(ax, bars)
    fig.tight_layout(); plt.show()

# ---------- main ----------
def main():
    xl = pd.ExcelFile(XLSX)
    last_sheet = xl.sheet_names[-1]
    df_raw = xl.parse(last_sheet, header=None)

    hdr = find_header_row(df_raw)
    if hdr is not None:
        cols = df_raw.iloc[hdr].astype(str).tolist()
        df = df_raw.iloc[hdr+1:].copy(); df.columns = cols
    else:
        df = xl.parse(last_sheet)

    # drop empty 'Unnamed' columns
    df = df.loc[:, ~df.columns.astype(str).str.match(r"^Unnamed", case=False)]

    c_proc, c_stor, c_total = find_savings_cols(df)
    mcol = find_month_col(df)
    blocks = split_blocks(df, [c_proc, c_stor, c_total])
    if not blocks:
        raise ValueError("No data blocks found.")

    # Block 1 — Without storage
    plot_proc_total(blocks[0], mcol, c_proc, c_total, "Procurement & Total — Without storage")
    plot_storage_only(blocks[0], mcol, c_stor, "Storage — Without storage", symlog=True, linthresh=5.0)

    # Block 2 — With storage (if present)
    if len(blocks) > 1:
        plot_proc_total(blocks[1], mcol, c_proc, c_total, "Procurement & Total — With storage")
        plot_storage_only(blocks[1], mcol, c_stor, "Storage — With storage", symlog=True, linthresh=5.0)
    else:
        print("[INFO] Only one block present; skipping 'With storage' plots.")

if __name__ == "__main__":
    main()
