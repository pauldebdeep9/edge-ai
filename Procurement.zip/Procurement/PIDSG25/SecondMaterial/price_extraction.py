#!/usr/bin/env python3
"""
Auto-run copper price plotter (Historical + Forecast).
Runs directly from VS Code (Ctrl+F5) or via CLI.
Displays two charts:
  1) Historical (and mixed) series from price*.csv
  2) Forecast series from price_forecast.csv (if present)
"""

from pathlib import Path
import sys
import pandas as pd
import matplotlib.pyplot as plt
import argparse

# ========= CONFIG (edit once) =========
DEFAULT_HIST_PATTERN = "price*.csv"      # e.g., price_cu.csv
DEFAULT_FORECAST_PATH = "price_forecast.csv"
HIST_TITLE = "Copper Monthly Average Price — Historical"
FORECAST_TITLE = "Copper Monthly Average Price — Forecast"
FIG_W, FIG_H = 18, 6                     # figure size in inches
# =====================================

def _auto_find_first(start_dir: Path, pattern: str) -> Path:
    matches = sorted(start_dir.glob(pattern))
    if not matches:
        raise FileNotFoundError(f"No CSV matching '{pattern}' in {start_dir}")
    return matches[0]

def _prep_df(df: pd.DataFrame) -> pd.DataFrame:
    if "MonthStr" not in df.columns or "Price_USD_lb" not in df.columns:
        raise SystemExit("CSV must contain MonthStr and Price_USD_lb columns.")
    df = df.copy()
    df["Date"] = pd.to_datetime(df["MonthStr"], format="%Y-%m")
    df = df.sort_values("Date").reset_index(drop=True)
    df["Rolling3M_USD_lb"] = df["Price_USD_lb"].rolling(window=3, min_periods=1).mean()
    return df

def _plot_series(df: pd.DataFrame, title: str, is_forecast: bool = False):
    plt.figure(figsize=(FIG_W, FIG_H))
    # Main line
    ls = "--" if is_forecast else "-"
    plt.plot(df["Date"], df["Price_USD_lb"], linewidth=2.0, linestyle=ls,
             marker="o", markersize=3,
             label=("Forecast avg (USD/lb)" if is_forecast else "Monthly avg (USD/lb)"))
    # Rolling
    plt.plot(df["Date"], df["Rolling3M_USD_lb"], linewidth=2.4, linestyle=":",
             label=("3-month avg (forecast)" if is_forecast else "3-month avg"))

    # Points (Observed/Anchor)
    if "Type" in df.columns:
        pts_mask = df["Type"].isin(["Observed", "Anchor"])
        if pts_mask.any():
            plt.scatter(df.loc[pts_mask, "Date"], df.loc[pts_mask, "Price_USD_lb"],
                        marker="s", s=30, label="Observed/Anchor points")

    plt.title(title)
    plt.xlabel("Date")
    plt.ylabel("Price (USD per pound)")
    plt.grid(True, linestyle=":", linewidth=0.8)
    plt.legend()
    plt.tight_layout()
    plt.show()

def run_auto_mode():
    here = Path(__file__).resolve().parent

    # Historical figure
    hist_csv = _auto_find_first(here, DEFAULT_HIST_PATTERN)
    print(f"[Historical] Input : {hist_csv.name}")
    hist_df = _prep_df(pd.read_csv(hist_csv))
    _plot_series(hist_df, HIST_TITLE, is_forecast=False)

    # Forecast figure (optional)
    fpath = here / DEFAULT_FORECAST_PATH
    if fpath.exists():
        print(f"[Forecast]   Input : {fpath.name}")
        fc_df = _prep_df(pd.read_csv(fpath))
        _plot_series(fc_df, FORECAST_TITLE, is_forecast=True)
    else:
        print(f"[Forecast]   Skipped — {DEFAULT_FORECAST_PATH} not found.")

def run_cli_mode(argv):
    p = argparse.ArgumentParser(description="Plot historical and/or forecast copper prices")
    p.add_argument("--csv", help="Historical CSV (MonthStr, Price_USD_lb, [Type])")
    p.add_argument("--forecast_csv", help="Forecast CSV (MonthStr, Price_USD_lb, [Type])")
    p.add_argument("--hist_title", default=HIST_TITLE)
    p.add_argument("--forecast_title", default=FORECAST_TITLE)
    args = p.parse_args(argv)

    if not args.csv and not args.forecast_csv:
        raise SystemExit("Provide at least one of --csv or --forecast_csv (or run with no args for auto mode).")

    if args.csv:
        hdf = _prep_df(pd.read_csv(args.csv))
        _plot_series(hdf, args.hist_title, is_forecast=False)
    if args.forecast_csv:
        fdf = _prep_df(pd.read_csv(args.forecast_csv))
        _plot_series(fdf, args.forecast_title, is_forecast=True)

def main():
    argv = sys.argv[1:]
    if argv and any(a.startswith("--") for a in argv):
        run_cli_mode(argv)
    else:
        run_auto_mode()

if __name__ == "__main__":
    main()
