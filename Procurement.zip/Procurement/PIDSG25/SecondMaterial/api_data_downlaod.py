#!/usr/bin/env python3
import time, sys
from datetime import datetime, timedelta
import pandas as pd

START, END = "2024-04-01", "2025-03-31"  # inclusive
Y_TICKER = "HG=F"       # Yahoo (COMEX copper futures, USD/lb)
S_SYMBOL = "HG.F"       # Stooq symbol (best-effort)
CHUNK_DAYS = 30         # smaller to be gentle on Yahoo
MAX_RETRIES = 6
BASE_SLEEP = 3.0
AUTO_ADJUST = False
OUT_DAILY = "copper_daily_20240401_20250331.csv"
OUT_WEEKLY = "copper_weekly_20240401_20250331.csv"
LBS_PER_TONNE = 2204.62262

def chunks(s, e, step_days):
    cur = s
    while cur < e:
        nxt = min(cur + timedelta(days=step_days), e)
        yield cur, nxt
        cur = nxt

def fetch_yahoo():
    import yfinance as yf
    s = datetime.fromisoformat(START)
    e = datetime.fromisoformat(END) + timedelta(days=1)  # inclusive
    frames = []
    for a, b in chunks(s, e, CHUNK_DAYS):
        tries = 0
        while True:
            try:
                df = yf.download(
                    Y_TICKER,
                    start=a.strftime("%Y-%m-%d"),
                    end=b.strftime("%Y-%m-%d"),
                    progress=False,
                    auto_adjust=AUTO_ADJUST,
                    threads=False,
                )
                if df is None or df.empty:
                    raise RuntimeError("Empty frame (Yahoo rate-limit or no data).")
                df["Source"] = "Yahoo"
                frames.append(df)
                break
            except Exception as ex:
                tries += 1
                if tries > MAX_RETRIES:
                    raise
                sleep_s = BASE_SLEEP * (2 ** (tries - 1))
                print(f"[Yahoo] {a.date()}..{b.date()} failed: {ex} — retry {tries}/{MAX_RETRIES} in {sleep_s:.1f}s")
                time.sleep(sleep_s)
    out = pd.concat(frames).sort_index()
    out = out[~out.index.duplicated(keep="last")]
    return out

def fetch_stooq():
    from pandas_datareader import data as pdr
    s = datetime.fromisoformat(START); e = datetime.fromisoformat(END)
    df = pdr.DataReader(S_SYMBOL, "stooq", s, e).sort_index()
    # Harmonize caps if needed
    ren = {c.upper():c for c in ["Open","High","Low","Close","Adj Close","Volume"]}
    df = df.rename(columns={k:v for k,v in ren.items() if k in df.columns})
    df["Source"] = "Stooq"
    return df

def compute_and_write(df):
    need = ["High","Low","Close"]
    if not all(c in df.columns for c in need):
        raise RuntimeError(f"Missing OHLC columns in data: have {list(df.columns)}")
    daily = df.copy()
    daily["DailyAvg_USD_per_lb"] = daily[["High","Low","Close"]].mean(axis=1)
    daily["Close_USD_per_lb"] = daily["Close"]
    daily["DailyAvg_USD_per_tonne"] = daily["DailyAvg_USD_per_lb"] * LBS_PER_TONNE
    daily["Close_USD_per_tonne"] = daily["Close_USD_per_lb"] * LBS_PER_TONNE
    daily = daily.loc[(daily.index >= START) & (daily.index <= END)]
    daily = daily[["DailyAvg_USD_per_lb","Close_USD_per_lb",
                   "DailyAvg_USD_per_tonne","Close_USD_per_tonne","Source"]]
    daily = daily.reset_index().rename(columns={"index":"Date"})
    daily["Date"] = pd.to_datetime(daily["Date"]).dt.date.astype(str)
    daily.to_csv(OUT_DAILY, index=False)
    print(f"Saved daily:  {OUT_DAILY} (rows={len(daily)})")

    # Weekly: Monday label; mean of daily averages within week
    w = (pd.to_datetime(daily["Date"])
           .to_frame(name="Date")
           .join(daily.drop(columns=["Date"]))
           .set_index("Date")
           .resample("W-MON").mean().reset_index())
    # Keep the same columns
    w.to_csv(OUT_WEEKLY, index=False)
    print(f"Saved weekly: {OUT_WEEKLY} (rows={len(w)})")

def main():
    try:
        df = fetch_yahoo()
        print(f"[Yahoo] rows: {len(df)}")
    except Exception as ex:
        print(f"[Yahoo] failed after retries: {ex}")
        try:
            df = fetch_stooq()
            if df is None or df.empty:
                raise RuntimeError("Stooq returned no data.")
            print(f"[Stooq] rows: {len(df)}")
        except Exception as ex2:
            print(f"[Stooq] fallback failed: {ex2}")
            sys.exit("No data from Yahoo or Stooq. Try again later or change symbol.")
    compute_and_write(df)

if __name__ == "__main__":
    main()
