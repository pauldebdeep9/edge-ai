#!/usr/bin/env python3
"""
Generate 99 perturbed price vectors from original price column.

Each new column = X + 0.1 * X * Normal(0,1)
"""

import pandas as pd
import numpy as np

# 1) Load CSV
df = pd.read_csv("price_forecast.csv")

# 2) Ensure column exists
if "Price_USD_lb" not in df.columns:
    raise ValueError("Column 'Price_USD_lb' not found in the CSV.")

# 3) Extract the base price vector
base_price = df["Price_USD_lb"].values

# 4) Generate 99 perturbed columns
n_samples = 99
for i in range(1, n_samples + 1):
    noise = np.random.normal(loc=0.0, scale=1.0, size=len(base_price))
    perturbed = base_price + 0.1 * base_price * noise
    df[f"Price_USD_lb_sim{i}"] = perturbed

# 5) Save new CSV
df.to_csv("price_samples.csv", index=False)

print("✅ Done! Created 99 new columns and saved to 'price_samples.csv'")
print(df.head())
