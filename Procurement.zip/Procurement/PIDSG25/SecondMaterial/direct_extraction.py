#!/usr/bin/env python3
import pandas as pd, numpy as np
from pathlib import Path
import sys

# ========================= CONFIG (edit these once & hit Ctrl+F5) =========================
DEFAULT_CSV_PATTERN = "*FY2025 Material Control.csv"   # auto-pick first match in this folder
DEFAULT_MATERIAL    = "Copper Wire"                     # case-insensitive match on column 1
DEFAULT_OUT_NAME    = "Copper_Wire_timeseries.csv"      # output CSV name
DO_PLOT             = True                              # save a wide plot next to CSV
FIG_W, FIG_H        = 20, 5.5                           # inches (controls “width”)
# =========================================================================================

def _coerce_number(x):
    if pd.isna(x): return np.nan
    if isinstance(x, (int, float)): return float(x)
    s = str(x).strip().replace(",", "")
    try: return float(s)
    except Exception: return np.nan

def load_multiheader_csv(path):
    """
    Assumes a multi-row header:
      - Row 6: month labels (e.g., 'Apr-25'), sparse; forward-filled.
      - Row 7: attribute names (e.g., 'Pur','Consumption','C/B','Inv Days'); blank cells inherit previous attr.
      - Row 8: sublabels ('L/F','T/F','Act' or blank) -> planned vs actual.
    """
    df = pd.read_csv(path, header=None)
    months = df.iloc[6].copy().ffill()
    attrs  = df.iloc[7].copy()
    subs   = df.iloc[8].copy()

    # forward-fill attribute within a month block
    attrs_ffill, last_attr = attrs.copy(), None
    for j in range(len(attrs_ffill)):
        if pd.notna(attrs_ffill.iloc[j]):
            last_attr = attrs_ffill.iloc[j]
        elif pd.notna(months.iloc[j]) and last_attr is not None:
            attrs_ffill.iloc[j] = last_attr

    def status_from_sub(x):
        x = str(x).strip() if pd.notna(x) else ""
        return "planned" if x in {"L/F", "T/F"} else "actual"

    status = subs.apply(status_from_sub)

    header = pd.DataFrame({
        "month": months,
        "attribute": attrs_ffill,
        "sub": subs,
        "status": status
    })
    return df, header

def extract_material_row(df, material_name):
    mask = df.iloc[:, 1].astype(str).str.strip().str.lower() == material_name.strip().lower()
    if not mask.any():
        raise ValueError(f"Material '{material_name}' not found in column 1.")
    idx = mask.idxmax()
    return df.iloc[idx]

def build_timeseries_for_material(
    csv_path,
    material="Copper Wire",
    months_keep=("Apr-25","May-25","Jun-25","Jul-25","Aug-25","Sep-25",
                 "Oct-25","Nov-25","Dec-25","Jan-26","Feb-26","Mar-26")
):
    df, header = load_multiheader_csv(csv_path)
    row = extract_material_row(df, material)

    tidy = header.copy()
    tidy["value"] = row.values  # align with all columns
    tidy = tidy[tidy["month"].isin(months_keep)].copy()

    def norm_attr(a):
        a = str(a).strip().lower()
        if a in {"pur", "purchase", "purch"}: return "purchase"
        if a in {"consumption", "cons"}: return "consumption"
        if a in {"c/b", "cb", "closing balance", "closing_bal", "c_b"}: return "cb"
        if a in {"inv days", "invdays", "inventory days", "inventory_days"}: return "inv_days"
        return a

    tidy["attribute"] = tidy["attribute"].apply(norm_attr)
    tidy["value"] = tidy["value"].apply(_coerce_number)

    wanted = []
    for attr in ["purchase", "consumption", "cb"]:
        for stat in ["planned", "actual"]:
            wanted.append((attr, stat))
    wanted.append(("inv_days", "actual"))

    records = []
    for m in months_keep:
        rec = {"month": m}
        for attr, stat in wanted:
            val = tidy.loc[
                (tidy["month"] == m) &
                (tidy["attribute"] == attr) &
                (tidy["status"] == stat),
                "value"
            ]
            rec[f"{attr}_{stat}"] = float(val.iloc[0]) if len(val) else np.nan
        records.append(rec)

    out = pd.DataFrame.from_records(records).set_index("month")
    return out

def plot_timeseries(df, out_png="timeseries.png", width=16, height=5):
    import matplotlib.pyplot as plt
    ycols = [c for c in df.columns if c.endswith("_actual")]
    plt.figure(figsize=(width, height))
    for c in ycols:
        plt.plot(df.index, df[c], marker="o", linewidth=1.8, label=c)
    plt.title("Monthly series — planned vs actual")
    plt.xlabel("Month"); plt.ylabel("Value"); plt.grid(True, linestyle=":", linewidth=0.8)
    plt.xticks(rotation=45, ha="right"); plt.legend(ncol=2)
    plt.tight_layout()
    plt.savefig(out_png, dpi=180, bbox_inches="tight")
    print("Saved plot:", out_png)

def _auto_find_csv(start_dir: Path, pattern: str) -> Path:
    matches = sorted(start_dir.glob(pattern))
    if not matches:
        raise FileNotFoundError(f"No file matching '{pattern}' in {start_dir}")
    return matches[0]

def main(argv=None):
    # If run without CLI args (Ctrl+F5), use CONFIG defaults & auto-discovery
    here = Path(__file__).resolve().parent
    try:
        csv_path = _auto_find_csv(here, DEFAULT_CSV_PATTERN)
    except Exception as e:
        print(e)
        print("Tip: adjust DEFAULT_CSV_PATTERN at the top of the script.")
        sys.exit(2)

    out_csv = here / DEFAULT_OUT_NAME
    print(f"Input : {csv_path.name}")
    print(f"Material: {DEFAULT_MATERIAL}")

    df = build_timeseries_for_material(str(csv_path), DEFAULT_MATERIAL)
    df.to_csv(out_csv, index=True)
    print(f"Saved : {out_csv}")

    if DO_PLOT:
        out_png = out_csv.with_suffix(".png")
        plot_timeseries(df, out_png=str(out_png), width=FIG_W, height=FIG_H)

if __name__ == "__main__":
    # If you *do* pass CLI args, keep your original interface working:
    if len(sys.argv) > 1 and any(a.startswith("--") for a in sys.argv[1:]):
        import argparse
        p = argparse.ArgumentParser(description="Extract monthly timeseries from a multi-row header CSV.")
        p.add_argument("--csv", required=True)
        p.add_argument("--material", default=DEFAULT_MATERIAL)
        p.add_argument("--out", default=DEFAULT_OUT_NAME)
        p.add_argument("--no-plot", action="store_true")
        p.add_argument("--fig-w", type=float, default=FIG_W)
        p.add_argument("--fig-h", type=float, default=FIG_H)
        a = p.parse_args()
        df = build_timeseries_for_material(a.csv, a.material)
        pd.Path = Path  # (no-op; keeps symmetry)
        out_csv = Path(a.out)
        df.to_csv(out_csv, index=True)
        print(f"Saved: {out_csv}")
        if not a.no-plot:
            plot_timeseries(df, out_png=str(out_csv.with_suffix(".png")), width=a.fig_w, height=a.fig_h)
    else:
        main()