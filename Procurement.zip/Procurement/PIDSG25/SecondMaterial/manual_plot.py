#!/usr/bin/env python3
"""
Fig 1: purchase_planned & |consumption_planned| (bars) + Price_USD_lb (dotted, sec axis)
Fig 2: Inventory trajectory inv_t = inv_{t-1} + purchase_planned_t − |consumption_planned_t|

- Robust month handling + index-based fallback merge
- Price legend positioned upper-center but inside the figure
"""

import pandas as pd
import matplotlib.pyplot as plt

COPPER_CSV = "Copper_Wire_timeseries.csv"
PRICE_CSV  = "price_forecast.csv"

def coerce_monthstr_from_any(series: pd.Series) -> pd.Series:
    """Coerce month column to 'YYYY-MM' robustly."""
    s = series.astype(str).str.strip()
    if s.str.match(r"^\d{4}-\d{2}$").mean() > 0.8:
        return s.str.slice(0, 7)
    dt = pd.to_datetime(s, errors="coerce", infer_datetime_format=True)
    if dt.notna().mean() > 0.8:
        return dt.dt.to_period("M").astype(str)
    return s  # fallback (may trigger index fallback merge later)

def compute_inventory(df_cu_sorted: pd.DataFrame, months_order: pd.Series) -> pd.Series:
    """
    Compute inventory over the provided months_order (YYYY-MM).
    inv_t = inv_{t-1} + purchase_planned_t − |consumption_planned_t|
    """
    # Align copper rows to months_order (inner join to keep only months we plot)
    cu_small = pd.merge(
        months_order.to_frame("MonthStr"),
        df_cu_sorted[["MonthStr", "purchase_planned", "consumption_planned", "cb_planned"] if "cb_planned" in df_cu_sorted.columns else ["MonthStr", "purchase_planned", "consumption_planned"]],
        on="MonthStr",
        how="left"
    )

    # Signals (fillna to 0 to avoid breaking the recursion)
    proc = cu_small["purchase_planned"].fillna(0.0).astype(float).values
    demand = cu_small["consumption_planned"].abs().fillna(0.0).astype(float).values

    # Initial stock: use first cb_planned if present; else 0
    if "cb_planned" in cu_small.columns and pd.notna(cu_small.loc[0, "cb_planned"]):
        init_stock = float(cu_small.loc[0, "cb_planned"])
    else:
        init_stock = 1.33*270

    inv = []
    current = init_stock
    for p, d in zip(proc, demand):
        current = current + p - d
        inv.append(current)
    return pd.Series(inv, index=months_order.index, name="inventory_calc")

def main():
    # Load
    df_cu = pd.read_csv(COPPER_CSV)
    df_px = pd.read_csv(PRICE_CSV)

    # Drop unnamed filler columns
    df_cu = df_cu.loc[:, ~df_cu.columns.str.contains(r"^Unnamed", case=False)]

    # Basic checks
    for c in ["month", "purchase_planned", "consumption_planned"]:
        if c not in df_cu.columns:
            raise ValueError(f"Missing column '{c}' in {COPPER_CSV}")
    if "Price_USD_lb" not in df_px.columns:
        raise ValueError("Missing column 'Price_USD_lb' in price_forecast.csv")
    if "MonthStr" not in df_px.columns and "Month" not in df_px.columns:
        raise ValueError("price_forecast.csv must have 'MonthStr' or 'Month'")

    # Prepare keys
    px_key = df_px["MonthStr"] if "MonthStr" in df_px.columns else df_px["Month"]
    px_key = px_key.astype(str).str.slice(0, 7)
    df_px = df_px.assign(MonthStr=px_key)

    cu_key = coerce_monthstr_from_any(df_cu["month"]).astype(str).str.slice(0, 7)
    df_cu = df_cu.assign(MonthStr=cu_key)

    # Absolute consumption
    df_cu["consumption_planned"] = df_cu["consumption_planned"].abs()

    # Try merging on MonthStr
    merged = pd.merge(
        df_cu[["MonthStr", "purchase_planned", "consumption_planned"]],
        df_px[["MonthStr", "Price_USD_lb"]],
        on="MonthStr",
        how="inner"
    )

    # Fallback if merge too small
    if len(merged) < 3:
        df_px_sorted = df_px.copy()
        df_px_sorted["_sort"] = pd.to_datetime(df_px_sorted["MonthStr"] + "-01", errors="coerce")
        df_px_sorted = df_px_sorted.sort_values(["_sort", "MonthStr"]).reset_index(drop=True)
        n = min(len(df_cu), len(df_px_sorted))
        merged = pd.DataFrame({
            "MonthStr": df_px_sorted.loc[:n-1, "MonthStr"],
            "purchase_planned": df_cu.loc[:n-1, "purchase_planned"].values,
            "consumption_planned": df_cu.loc[:n-1, "consumption_planned"].values,
            "Price_USD_lb": df_px_sorted.loc[:n-1, "Price_USD_lb"].values,
        })

    # Sort chronologically
    merged["_sort"] = pd.to_datetime(merged["MonthStr"] + "-01", errors="coerce")
    merged = merged.sort_values(["_sort", "MonthStr"]).drop(columns="_sort").reset_index(drop=True)

    # ---------- FIGURE 1: Bars + Price line ----------
    xlab = merged["MonthStr"]
    idx = range(len(merged))
    fig1, ax1 = plt.subplots(figsize=(12, 6))
    bar_w = 0.4

    ax1.bar([i - bar_w/2 for i in idx], merged["purchase_planned"], width=bar_w,
            label="Purchase Planned", alpha=0.85)
    ax1.bar([i + bar_w/2 for i in idx], merged["consumption_planned"], width=bar_w,
            label="Consumption Planned (abs)", alpha=0.85)

    ax1.set_xlabel("Month")
    ax1.set_ylabel("Planned Volume")
    ax1.set_xticks(list(idx))
    ax1.set_xticklabels(xlab, rotation=45, ha="right")

    ax2 = ax1.twinx()
    ax2.plot(list(idx), merged["Price_USD_lb"], linestyle="dotted", linewidth=2,
             marker="o", markersize=4, label="Price (USD/lb)")
    ax2.set_ylabel("Price (USD/lb)")

    ax1.legend(loc="upper left")
    ax2.legend(loc="upper center", bbox_to_anchor=(0.5, 0.90), frameon=True, framealpha=0.9, borderpad=0.4)

    fig1.suptitle("Planned Purchase & Consumption vs Price (USD/lb)")
    fig1.tight_layout(rect=(0, 0, 1, 0.96))  # room for top legend/title

    # ---------- FIGURE 2: Inventory ----------
    # Make a copper-sorted DF to feed inventory computation
    df_cu_sorted = df_cu.copy()
    df_cu_sorted["_sort"] = pd.to_datetime(df_cu_sorted["MonthStr"] + "-01", errors="coerce")
    df_cu_sorted = df_cu_sorted.sort_values(["_sort", "MonthStr"]).drop(columns="_sort").reset_index(drop=True)

    inventory = compute_inventory(df_cu_sorted, merged["MonthStr"])

    fig2, ax = plt.subplots(figsize=(12, 5))
    ax.plot(range(len(inventory)), inventory.values, linewidth=2, marker="o", label="Inventory (calc)")
    ax.set_xticks(list(range(len(inventory))))
    ax.set_xticklabels(merged["MonthStr"], rotation=45, ha="right")
    ax.set_xlabel("Month")
    ax.set_ylabel("Inventory (units)")
    ax.set_title("Inventory: inv_t = inv_{t-1} + purchase_planned_t − |consumption_planned_t|")
    ax.grid(True, alpha=0.3)
    ax.legend(loc="best")
    fig2.tight_layout()

    # Show both figures
    plt.show()

if __name__ == "__main__":
    main()
