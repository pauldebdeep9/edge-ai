
import pandas as pd
import numpy as np
from datetime import datetime

# Load the Excel file
file_path = 'pidsg25-lt.xlsx'  # Replace with your file path
xls = pd.ExcelFile(file_path)

# Load the 'demand' sheet
demand_df = xls.parse('demand')

# Extract the first column after 'time' (assumed to be 'Demand')
first_col_values = demand_df.iloc[:, 1].values

# Get the number of rows
num_rows = len(first_col_values)

# Compute mean and variance of the first column
mean_val = np.mean(first_col_values)
var_val = 1.2*np.var(first_col_values)

# Generate a new DataFrame with the same number of rows and 100 columns
# Each column contains values sampled from a normal distribution with the computed mean and variance
data = np.random.normal(loc=mean_val, scale=np.sqrt(var_val), size=(num_rows, 100)) 
df_generated = pd.DataFrame(data)

# Optional: Save to CSV
# df_generated.to_csv('generated_data.csv', index=False)

# Show preview
print(df_generated.head())

# Create a timestamped filename and save as CSV
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
filename = f"generated_data_{timestamp}.csv"
df_generated.to_csv(filename, index=False)

print(f"File saved as {filename}")