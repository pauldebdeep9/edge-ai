import pandas as pd


df= pd.read_excel('pidsg25Evaluation.xlsx', sheet_name= 'Eval07Clean')
print(df.head())

price_df= df[['Hedged price', 'Unhedged price']]
print(price_df.head())

