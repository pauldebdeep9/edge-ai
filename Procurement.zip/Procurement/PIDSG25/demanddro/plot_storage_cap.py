# plots_storage_capacity.py
# Full script: all cost plots + ORDER (bars) + PRICE (dotted) plots; secondary axis hidden.

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

FILE = "storage_cap08.xlsx"
SHEET_WITH = "storage_con"       # 2nd sheet
SHEET_WO   = "wo_storage_con"    # 3rd sheet

# ---- cost columns (case-insensitive) ----
COL_HEDGED   = "Hedged price"
COL_UNHEDGED = "Unhedged price"
COL_STORAGE  = "storage cost"    # appears lowercase in your file

# ---- candidate names / tokens for order + price + time columns ----
ORDER_HEDGED_CANDS   = ["Order-AI-Hedged","Order Hedged","Hedged order",
                        "DRO Demand Hedged","Hedged demand","Hedged qty","Hedged quantity"]
ORDER_UNHEDGED_CANDS = ["Order-AI-Unhedged","Order Unhedged","Unhedged order",
                        "DRO Demand Unhedged","Unhedged demand","Unhedged qty","Unhedged quantity"]
PRICE_HEDGED_CANDS   = ["Hedged price","Price Hedged","Hedged unit price"]
PRICE_UNHEDGED_CANDS = ["Unhedged price","Price Unhedged","Unhedged unit price"]
TIME_CANDS           = ["Date","Time","Time Period","Month","Period"]

ORDER_H_TOKENS  = [["order","hedged"],["demand","hedged"],["qty","hedged"],["quantity","hedged"]]
ORDER_UH_TOKENS = [["order","unhedged"],["demand","unhedged"],["qty","unhedged"],["quantity","unhedged"]]
PRICE_H_TOKENS  = [["price","hedged"],["unit","price","hedged"]]
PRICE_UH_TOKENS = [["price","unhedged"],["unit","price","unhedged"]]
TIME_TOKENS     = [["date"],["month"],["period"],["time"]]

# ---------- helpers ----------
def _ci_lookup(df: pd.DataFrame, name: str):
    want = name.strip().lower()
    for c in df.columns:
        if str(c).strip().lower() == want:
            return c
    return None

def _find_by_tokens(df: pd.DataFrame, token_alternatives: list[list[str]]):
    cols = [str(c) for c in df.columns]
    cols_tokens = [set(c.lower().replace("-", " ").replace("_", " ").split()) for c in cols]
    for tokens in token_alternatives:
        tset = set(tokens)
        for col, toks in zip(cols, cols_tokens):
            if tset.issubset(toks):
                return col
    return None

def find_col(df: pd.DataFrame, name: str) -> str:
    c = _ci_lookup(df, name)
    if c is None:
        raise KeyError(f"Column '{name}' not found. Available: {list(df.columns)}")
    return c

def find_any(df: pd.DataFrame, candidates: list[str], token_alts: list[list[str]] | None = None) -> str:
    for n in candidates:
        c = _ci_lookup(df, n)
        if c is not None:
            return c
    if token_alts:
        c = _find_by_tokens(df, token_alts)
        if c is not None:
            return c
    raise KeyError(f"None of {candidates} (or token patterns) found. Available: {list(df.columns)}")

def series(df: pd.DataFrame, name: str, cumulative: bool) -> pd.Series:
    col = find_col(df, name)
    s = pd.to_numeric(df[col], errors="coerce").fillna(0.0)
    return s.cumsum() if cumulative else s

def sum_series(df: pd.DataFrame, names: list[str], cumulative: bool) -> pd.Series:
    s = sum(series(df, n, cumulative=False) for n in names)
    return s.cumsum() if cumulative else s

def plot_two(y_with: pd.Series, y_wo: pd.Series, title: str, ylabel: str = ""):
    plt.figure(figsize=(9, 4.8))
    plt.plot(y_with.index, y_with.values, label=SHEET_WITH)
    plt.plot(y_wo.index,   y_wo.values,   label=SHEET_WO)
    plt.title(title); plt.xlabel("Period")
    if ylabel: plt.ylabel(ylabel)
    plt.grid(True); plt.legend(); plt.tight_layout(); plt.show()

def get_time_index(df: pd.DataFrame):
    for cand in TIME_CANDS:
        c = _ci_lookup(df, cand)
        if c:
            xlab = df[c]
            try:
                dt = pd.to_datetime(xlab, errors="coerce")
                if dt.notna().all():
                    xlab = dt.dt.strftime("%b-%y")
            except Exception:
                pass
            return np.arange(len(df)), list(xlab.astype(str))
    c = _find_by_tokens(df, TIME_TOKENS)
    if c:
        xlab = df[c]
        try:
            dt = pd.to_datetime(xlab, errors="coerce")
            if dt.notna().all():
                xlab = dt.dt.strftime("%b-%y")
        except Exception:
            pass
        return np.arange(len(df)), list(xlab.astype(str))
    n = len(df); return np.arange(n), list(range(n))

def plot_orders_and_prices(df: pd.DataFrame, sheet_label: str):
    col_q_h  = find_any(df, ORDER_HEDGED_CANDS,   ORDER_H_TOKENS)
    col_q_uh = find_any(df, ORDER_UNHEDGED_CANDS, ORDER_UH_TOKENS)
    col_p_h  = find_any(df, PRICE_HEDGED_CANDS,   PRICE_H_TOKENS)
    col_p_uh = find_any(df, PRICE_UNHEDGED_CANDS, PRICE_UH_TOKENS)

    Qh  = pd.to_numeric(df[col_q_h],  errors="coerce").fillna(0.0)
    Quh = pd.to_numeric(df[col_q_uh], errors="coerce").fillna(0.0)
    Ph  = pd.to_numeric(df[col_p_h],  errors="coerce").fillna(0.0)
    Puh = pd.to_numeric(df[col_p_uh], errors="coerce").fillna(0.0)

    x, xlabels = get_time_index(df)
    width = 0.4

    fig, ax1 = plt.subplots(figsize=(12, 5.5))
    ax1.bar(x - width/2, Qh.values,  width=width, label="Order Hedged")
    ax1.bar(x + width/2, Quh.values, width=width, label="Order Unhedged")
    ax1.set_ylabel("Order Quantity")
    ax1.set_xlabel("Time Period")
    ax1.set_xticks(x)
    ax1.set_xticklabels(xlabels, rotation=45, ha="right")
    ax1.set_title(f"Order Quantities and Supplier Prices — {sheet_label}")

    # secondary axis for price lines (completely hidden)
    ax2 = ax1.twinx()
    line1, = ax2.plot(x, Ph.values,  linestyle=":", marker="o", label="Price Hedged")
    line2, = ax2.plot(x, Puh.values, linestyle=":", marker="s", label="Price Unhedged")
    ax2.set_axis_off()                 # hide axis, ticks, labels, spine
    ax2.grid(False)
    ax2.set_zorder(0)                  # keep bars visually on top of hidden axis

    # combined legend (use handles from both axes)
    h1, l1 = ax1.get_legend_handles_labels()
    h2, l2 = [line1, line2], ["Price Hedged", "Price Unhedged"]
    ax1.legend(h1 + h2, l1 + l2, loc="upper left")

    ax1.grid(True, axis="y", linestyle="--", alpha=0.5)
    fig.tight_layout()
    plt.show()

# ---------- main ----------
def main():
    with_df = pd.read_excel(FILE, sheet_name=SHEET_WITH)
    wo_df   = pd.read_excel(FILE, sheet_name=SHEET_WO)

    # 1) cumulative (Hedged + Unhedged)
    plot_two(sum_series(with_df,[COL_HEDGED,COL_UNHEDGED],True),
             sum_series(wo_df,[COL_HEDGED,COL_UNHEDGED],True),
             "Cumulative Hedged + Unhedged cost")

    # 2) cumulative Unhedged
    plot_two(series(with_df,COL_UNHEDGED,True),
             series(wo_df,COL_UNHEDGED,True),
             "Cumulative Unhedged cost")

    # 2b) cumulative Hedged
    plot_two(series(with_df,COL_HEDGED,True),
             series(wo_df,COL_HEDGED,True),
             "Cumulative Hedged cost")

    # 3) periodwise (Hedged + Unhedged)
    plot_two(sum_series(with_df,[COL_HEDGED,COL_UNHEDGED],False),
             sum_series(wo_df,[COL_HEDGED,COL_UNHEDGED],False),
             "Periodwise Hedged + Unhedged cost")

    # 4) periodwise storage
    plot_two(series(with_df,COL_STORAGE,False),
             series(wo_df,COL_STORAGE,False),
             "Periodwise Storage cost")

    # 5) cumulative storage
    plot_two(series(with_df,COL_STORAGE,True),
             series(wo_df,COL_STORAGE,True),
             "Cumulative Storage cost")

    # 6) cumulative total (hedged + unhedged + storage)
    plot_two(sum_series(with_df,[COL_HEDGED,COL_UNHEDGED,COL_STORAGE],True),
             sum_series(wo_df,[COL_HEDGED,COL_UNHEDGED,COL_STORAGE],True),
             "Cumulative Total cost")

    # 7) Orders (bars) + Prices (dotted), secondary axis hidden
    plot_orders_and_prices(with_df, "with_capacity")
    plot_orders_and_prices(wo_df,   "w/o_capacity")

if __name__ == "__main__":
    main()
