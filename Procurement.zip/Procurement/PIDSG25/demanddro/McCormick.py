
import numpy as np
import pandas as pd
from pulp import *
from pulp import LpMinimize, LpProblem, LpVariable, lpSum, LpBinary, LpContinuous, value
from datetime import datetime
from collections import defaultdict
import matplotlib.pyplot as plt
import re
# from sample_generation import *
import warnings
# Disable all warnings
warnings.filterwarnings('ignore')

from FigOrder import plot_order, plot_manual, plot_order_matrix


h = 5 # inventory holding cost
b = 50 # backlog cost
I_0 = 3*5000 # starting inventory level
B_0 = 0
R = 0
M_max= 25000
input_data_file = 'pidsg25-lt.xlsx'
# input_data_file = 'data_input_Random.xlsx'
#define variables with experiment, eg sample size N and Wass ball radius epsilon
N = 100
epsilon = 200
planning_horizon= 12

should_plot= True


class WDROModel:
    def __init__(self, h, b, I_0, B_0, R, input_data_file, N, epsilon):
        # Read Excel file sheets
        data_price = pd.read_excel(input_data_file, sheet_name='price')
        data_supplier = pd.read_excel(input_data_file, sheet_name='supplier')
        data_capacity = pd.read_excel(input_data_file, sheet_name='capacity')
        data_t_demand = pd.read_excel(input_data_file, sheet_name='demand', index_col= 0)
        # synthetic= generate_demand(data_t_demand_['Demand'].values, 30)
        # data_t_demand= pd.concat([data_t_demand_, synthetic], axis=1)

        # Initialize selfeters
        self.h = h
        self.b = b
        self.I_0 = I_0
        self.B_0 = B_0
        self.N = N
        self.R = R
        self.Nlist = list(range(1, N + 1))
        self.epsilon = epsilon
        self.historical_demand= pd.read_excel(input_data_file, sheet_name='demand', index_col= 0)
       

        self.time = data_price['time'].values
        self.supplier, self.order_cost, self.lead_time, self.quality_level = self.get_suppliers(data_supplier)
        self.prices, self.capacities = self.get_time_suppliers(data_price, data_capacity)
        self.demand = self.get_demand(data_t_demand)
        

        self.t_n = self.get_structure(self.time, self.Nlist)
        self.t_supplier = self.get_structure(self.time, self.supplier)
        self.t_supplier_tprime = self.get_structure(self.time, self.supplier, self.time)
        self.t_N = self.get_structure(self.time, self.Nlist)

    def get_structure(self, *args):
        if len(args) == 2:
            result = [(a, b) for a in args[0] for b in args[1]]
        elif len(args) == 3:
            result = [(a, b, c) for a in args[0] for b in args[1] for c in args[2]]
        return result

    def get_suppliers(self, data_supplier):
        supplier = data_supplier['supplier'].values
        order_cost = makeDict([supplier], data_supplier['order_cost'].values, 0)
        lead_time = makeDict([supplier], data_supplier['lead_time'].values, 0)
        quality_level = makeDict([supplier], data_supplier['quality_level'].values, 0)
        return supplier, order_cost, lead_time, quality_level

    def get_time_suppliers(self, data_price, data_capacity):
        prices, capacities = {}, {}

        for s in self.supplier:
            supplier_prices = data_price[s].values
            supplier_capacities = data_capacity[s].values

            for t in self.time:
                prices[(t, s)] = supplier_prices[t - 1]
                capacities[(t, s)] = supplier_capacities[t - 1]

        return prices, capacities

    def get_demand(self, data_t_demand):
        data_t_demand.columns = range(1, len(data_t_demand.columns) + 1)
        
        #selected = data_t_demand.iloc[:, :self.N].unstack().reset_index()
        selected = data_t_demand.unstack().loc[:self.N, :].reset_index()
        demand = {}
        for j in range(len(selected)):
            demand[(selected.iloc[j, 1], selected.iloc[j, 0])] = selected.iloc[j, 2]
        return demand
    
    # def include_empirical_dist(self):
    #     self.data_t_
    
    def display_data(self):
        print("Supplier Dictionary:", self.supplier)
        print("Order Cost Dictionary:", self.order_cost)
        print("Lead Time:", self.lead_time)
        print("Quality Level Dictionary:", self.quality_level)
        print("Prices Dictionary:", self.prices)
        print("Capacities Dictionary:", self.capacities)
        print("Input_demand:", self.demand)
    
    def optimize(self):
        model = LpProblem(name="WDRO_model", sense=LpMinimize)
        
        Q = LpVariable.dicts("order_quantity", self.t_supplier_tprime, lowBound=0, cat="Integer")
        theta = LpVariable.dicts("arrive_quantity", self.t_supplier, lowBound=0, cat="Integer")
        Y = LpVariable.dicts("if_make_order_arrive", self.t_supplier_tprime, cat="Binary")

        alpha = LpVariable.dicts("alpha", self.Nlist, cat="Continuous")
        beta = LpVariable("beta", lowBound=0, cat="Continuous")
        delta = LpVariable.dicts("delta", self.t_N, lowBound=0, cat="Continuous")
        sigma = LpVariable.dicts("sigma", self.t_N, lowBound=0, cat="Continuous")
        gamma = LpVariable.dicts("gamma", self.t_N, lowBound=0, cat="Continuous")
        tau = LpVariable.dicts("tau", self.t_N, lowBound=0, cat="Continuous")
        phi = LpVariable.dicts("phi", self.t_N, lowBound=0, cat="Continuous")
        xi = LpVariable.dicts("xi", self.t_N, lowBound=0, cat="Continuous")
        zeta = LpVariable.dicts("zeta", self.t_N, lowBound=0, cat="Continuous")
        varphi = LpVariable.dicts("varphi", self.t_N, lowBound=0, cat="Continuous")
        eta = LpVariable.dicts("eta", self.t_N, lowBound=0, cat="Continuous")

        d_upper = {}
        d_lower = {}
        for period in self.time:
            d_upper[period] = max(value for (key1, key2), value in self.demand.items() if key1 == period)
            d_lower[period] = min(value for (key1, key2), value in self.demand.items() if key1 == period)

        print("Upper Demand Bounds:", d_upper, "\nLower Demand Bounds:", d_lower)

        # Large constant for constraints
        large_M = M_max #self.demand[max(self.demand, key=self.demand.get)] * 48 
        P_I = self.I_0 - self.B_0
        b = self.b
        h = self.h

        # 1) Objective function
        obj = lpSum(self.order_cost[s] * Y[t, s, t_prime] + self.prices[(t, s)] * Q[(t, s, t_prime)] for t, s, t_prime in self.t_supplier_tprime)
        obj += (1 / self.N) * lpSum(alpha[n] for n in self.Nlist) + beta * self.epsilon
        model += obj

        T = self.time[-1] # Last time period

        # 2.1) DRO-related constraints
        for n in self.Nlist:
            model += (
                (b + h) * lpSum(tau[t, n] for t in self.time if t < T)
                + T * h * P_I
                + lpSum(
                    (delta[t, n] - sigma[t, n]) * self.demand[(t, n)]
                    + (T-t+1) * h * lpSum(theta[t, s] for s in self.supplier)
                    + xi[t, n] * (T-t+1) * (b+h) * d_upper[t]
                    - zeta[t, n] * (T-t+1) * (b+h) * d_lower[t]
                    + eta[t, n] * (T-t+1) * (b+h)
                    for t in self.time
                )
                <= alpha[n]
            )

            model += lpSum(delta[t, n] + sigma[t, n] for t in self.time) <= beta

            for t in self.time: # note: t, n in self.t_N: 
                model += 1 + phi[t, n] + xi[t, n] - zeta[t, n] - varphi[t, n] <= 0
                model += (sigma[t, n] - delta[t, n] + (zeta[t, n] - xi[t, n]) * (T-t+1) * (h+b) - (T-t+1) * h <= 0)

                if t == 1:
                    model += (
                        gamma[t, n]
                        - tau[t, n]
                        - phi[t, n] * d_lower[t]
                        - xi[t, n] * d_upper[t]
                        + zeta[t, n] * d_lower[t]
                        + varphi[t, n] * d_upper[t]
                        - eta[t, n]
                        - lpSum(theta[t, s] for s in self.supplier)
                        - P_I
                        <= 0
                    )
                elif t == T:
                    model += (
                        tau[t - 1, n]
                        - gamma[t - 1, n]
                        - phi[t, n] * d_lower[t]
                        - xi[t, n] * d_upper[t]
                        + zeta[t, n] * d_lower[t]
                        + varphi[t, n] * d_upper[t]
                        - eta[t, n]
                        - lpSum(theta[t, s] for s in self.supplier)
                        <= 0
                    )
                else:
                    model += (
                        gamma[t, n]
                        - tau[t, n]
                        + tau[t - 1, n]
                        - gamma[t - 1, n]
                        - phi[t, n] * d_lower[t]
                        - xi[t, n] * d_upper[t]
                        + zeta[t, n] * d_lower[t]
                        + varphi[t, n] * d_upper[t]
                        - eta[t, n]
                        - lpSum(theta[t, s] for s in self.supplier)
                        <= 0
                    )

        # 2.2) Original model constraints with Q/Y/theta
        for s in self.supplier:
            for t_prime in self.time:
                model += (
                    lpSum(t * Y[t, s, t_prime] for t in self.time if t <= t_prime)
                    == lpSum(Y[t, s, t_prime] for t in self.time if t <= t_prime)
                    * (t_prime - self.lead_time[s])
                )
                model += lpSum(Y[t, s, t_prime] for t in self.time if t <= t_prime) <= 1
                model += (theta[t_prime, s] == lpSum(Q[(t, s, t_prime)] for t in self.time if t <= t_prime))

            for t in self.time:
                model += lpSum(Y[t, s, t_prime] for t_prime in self.time if t_prime >= t) <= 1

        for t, s, t_prime in self.t_supplier_tprime:
            model += Q[t, s, t_prime] <= large_M * Y[t, s, t_prime]
        
        model += (
            lpSum(self.quality_level[s] * lpSum(Q[t, s, t_prime] for t in self.time if t <= t_prime) for s in self.supplier)
            >= self.R * lpSum(lpSum(Q[t, s, t_prime] for t in self.time if t <= t_prime) for s in self.supplier)
        )

        for t in self.time:
            for s in self.supplier:
                model += (
                    lpSum(Q[t, s, t_prime] for t_prime in self.time if t_prime >= t)
                    <= self.capacities[(t, s)]
                )

        model.writeLP("wdro_pulp.lp")
        model.solve()

        print(f"Status: {LpStatus[model.status]}, Total Cost = {value(model.objective)}")

        variables = model.variables()
        df_result = pd.DataFrame(
            [(var.name, var.varValue) for var in variables],
            columns=["variable_name", "value"]
        )

    
        return {"cost": value(model.objective), "prob": model, "Q": Q, "theta": theta, "Y": Y, "df_result": df_result}
    

wdro_model = WDROModel(h, b, I_0, B_0, R, input_data_file, N, epsilon)

solution_ty = wdro_model.optimize()

print("cost:", solution_ty['cost'])
# print(solution_ty['df_result'])
solution_ty['df_result'].to_csv('pidsg_results.csv')

def extract_action(input_str):
    df = pd.read_csv('pidsg_results.csv')
    filtered_df = df[df['variable_name'].str.startswith(input_str)]
    filtered_df['time'] = filtered_df['variable_name'].str.extract(r'np.int64\((\d+)\)')  # Extract time (t) r'np.int64\((\d+)\)'
    filtered_df['supplier'] = filtered_df['variable_name'].str.extract(r"'([^']+)'")  # Extract supplier ('s1', 's2', etc.) r"'([^']+)'"
    total_orders = filtered_df.groupby('time')['value'].sum().reset_index()
    total_orders.columns = ['Time', 'Total_Order']
    total_orders['Time'] = total_orders['Time'].astype(int)  # Ensure 'Time' is treated as integer for proper sorting
    total_orders = total_orders.sort_values(by='Time')
    print(filtered_df.head())
    return total_orders, filtered_df


df= solution_ty['df_result']
filtered_df = df[df['variable_name'].str.startswith('order_quantity')]
filtered_df_nonzero = filtered_df[filtered_df['value'] != 0]

# print(filtered_df_nonzero.head())


input_str= 'arrive_quantity'
tot_arr_order, orders_arrived= extract_action(input_str)

# def extract_time_supplier(df):
#     # Ensure 'variable_name' column is string
#     df['variable_name'] = df['variable_name'].astype(str)
#     # Corrected regex to handle np.int64(...) format
#     # pattern = r"np\.int64\((\d+)\).*?'([^']+)'.*?np\.int64\((\d+)\)"
#     pattern = r"arrive_quantity_\((\d+),_'([^']+)'\)"
#     # Extract the values using regex
#     # df[['t_order', 'supplier', 't_arrive']] = df['variable_name'].str.extract(pattern)
#     # Only two groups, so assign to two columns
#     df[['t_order', 'supplier']] = df['variable_name'].str.extract(pattern)
#     df['t_arrive'] = df['t_order'].astype(int) + 3
#    # Convert extracted columns to integers, handling NaN cases
#     df['t_order'] = df['t_order'].astype(float).astype('Int64')  
#     df['t_arrive'] = df['t_arrive'].astype(float).astype('Int64')
#     return df

def extract_time_supplier(df):
    # Ensure 'variable_name' column is string
    df['variable_name'] = df['variable_name'].astype(str)

    # Regex pattern for: arrive_quantity_(num,_'supplier')
    pattern = r"arrive_quantity_\((\d+),_'([^']+)'\)"

    # Extract t_order and supplier columns
    df[['t_order', 'supplier']] = df['variable_name'].str.extract(pattern)

    # Drop rows where extraction failed (t_order is NaN)
    df = df.dropna(subset=['t_order']).copy()

    # Convert to integer (nullable Int64)
    df['t_order'] = df['t_order'].astype('Int64')

    # Compute arrival time
    df['t_arrive'] = df['t_order'] + 3

    return df


# Apply the function
extracted_order = extract_time_supplier(filtered_df_nonzero)
print(extracted_order.head())



# compute order placed
def Order_placed(df_org):
    df= df_org.drop(columns=['variable_name'])
    df_grouped = df.groupby(['t_order', 'supplier'], as_index=False).agg({'value': 'first'})
    pivot_df = df_grouped.pivot(index='t_order', columns='supplier', values='value')
    full_t_order = pd.Series(range(1, planning_horizon + 1))
    pivot_df = pivot_df.reindex(full_t_order)
    pivot_df = pivot_df.fillna(0)
    pivot_df = pivot_df.reindex(columns=['s1', 's2'], fill_value=0)
    pivot_df = pivot_df.reindex(columns=['s1', 's2'], fill_value=0)
    pivot_df = pivot_df.reset_index()
    tot_ord_placed= pivot_df[['s1', 's2']].sum(axis=1)
    pivot_df['total_order']= tot_ord_placed
    return pivot_df

order_placed= Order_placed(extracted_order)
order_placed.head()


df_price= pd.read_excel(input_data_file, sheet_name='price')
order_placed_red= order_placed.drop(columns= ['index'])

def compute_procurement_cost(df1, df2):
    # Element-wise multiplication
    result = df1 * df2

# Row-wise sum
    row_sum = result.sum(axis=1)
    return row_sum

def calc_total_procurement_cost(df_price, order_matrix):
    # Rename for easy merge if needed
    df1 = df_price.rename(columns={'time': 'placement'}).copy()
    df2 = order_matrix.copy()
    # Merge on placement/time (inner join by default)
    merged = pd.merge(df1, df2, on='placement', suffixes=('_price', '_order'))
    # Calculate total cost for each supplier at each time
    merged['cost_s1'] = merged['s1_price'] * merged['s1_order']
    merged['cost_s2'] = merged['s2_price'] * merged['s2_order']
    # Sum across all time periods
    total_cost = merged['cost_s1'].sum() + merged['cost_s2'].sum()
    return total_cost, merged[['placement', 'cost_s1', 'cost_s2']]


# compute dynamic inventory
def calculate_stock(order, N):
# Define input vectors (example)
    actual_demand= pd.read_excel(input_data_file, sheet_name='demand', index_col= 0).iloc[:, 0].values
    initial_inventory = I_0  # Initial inventory (i0)

# Calculate dynamic stock quantity
    stock_quantity = np.zeros(len(order) + 1)  # +1 for initial stock

# Set the initial stock
    stock_quantity[0] = initial_inventory

# Calculate stock quantity for each time period
    for t in range(1, len(stock_quantity)):
        stock_quantity[t] = stock_quantity[t-1] + order[t-1] - actual_demand[t-1]

    return stock_quantity


actual_demand= pd.read_excel(input_data_file, sheet_name='demand', index_col= 0).iloc[:, 0].values

stock_quantity= calculate_stock(np.array(tot_arr_order['Total_Order']), N)[1:]
print(stock_quantity)

def compute_storage_cost(stocks, h, b):
    total_cumulative_cost = 0  # Initialize the cumulative cost

    for stock in stocks:
        if stock >= 0:
            # Compute storage cost when stock is positive or zero
            storage_cost = h * stock
            total_cumulative_cost += storage_cost
        else:
            # Compute backlog cost when stock is negative
            backlog_cost = b * (-stock)
            total_cumulative_cost += backlog_cost

    return total_cumulative_cost


def compute_storage_and_backlog_costs(stocks, h, b):
    total_storage_cost = 0  # Initialize storage cost
    total_backlog_cost = 0  # Initialize backlog cost

    for stock in stocks:
        if stock >= 0:
            # Compute storage cost when stock is positive or zero
            storage_cost = h * stock
            total_storage_cost += storage_cost
        else:
            # Compute backlog cost when stock is negative
            backlog_cost = b * (-stock)
            total_backlog_cost += backlog_cost

    # Total cost is the sum of storage and backlog costs
    total_cumulative_cost = total_storage_cost + total_backlog_cost

    return {'Storage': total_storage_cost, 
            'Backlog': total_backlog_cost, 
            'Risk/Cashflow': total_cumulative_cost}


stock_quantity= stock_quantity
storage_backlog_cost = compute_storage_and_backlog_costs(stock_quantity, h, b)

print(storage_backlog_cost)

def extract_time_supplier(df):
    # Ensure 'variable_name' column is string
    df['variable_name'] = df['variable_name'].astype(str)

    # Corrected regex to handle np.int64(...) format
    # pattern = r"np\.int64\((\d+)\).*?'([^']+)'.*?np\.int64\((\d+)\)"
    pattern = r"(?:np\.int64\()?(\d+)\)?,_'([^']+)',_(?:np\.int64\()?(\d+)\)?"

    # Extract the values using regex
    df[['t_order', 'supplier', 't_arrive']] = df['variable_name'].str.extract(pattern)

    # Convert extracted columns to integers, handling NaN cases
    df['t_order'] = df['t_order'].astype(float).astype('Int64')  
    df['t_arrive'] = df['t_arrive'].astype(float).astype('Int64')

    return df

# Apply the function
extracted_order = extract_time_supplier(filtered_df_nonzero)
print(extracted_order.head())

# --- CREATE ORDER MATRIX: placement, arrival, s1, s2 ---
# Only use rows where extraction succeeded
# def extract_order_matrix(extracted_order):

#     eo_valid = extracted_order.dropna(subset=['t_order', 'supplier', 't_arrive']).copy()
#     eo_valid['placement'] = eo_valid['t_order'].astype(int)
#     eo_valid['arrival'] = eo_valid['t_arrive'].astype(int)
#     eo_valid['value'] = eo_valid['value'].fillna(0)

#     # Pivot so each (placement, arrival) is a row, with s1/s2 columns
#     wide_order = eo_valid.pivot_table(
#         index=['placement', 'arrival'],
#         columns='supplier',
#         values='value',
#         fill_value=0
#     ).reset_index()

#     for supplier in ['s1', 's2']:
#         if supplier not in wide_order.columns:
#             wide_order[supplier] = 0

#     order_matrix = wide_order[['placement', 'arrival', 's1', 's2']].sort_values(by='placement')
#     print(order_matrix.head(10))  # Or save to csv for checking
#     return order_matrix

def extract_order_matrix(extracted_order, planning_horizon= planning_horizon):
    eo_valid = extracted_order.dropna(subset=['t_order', 'supplier', 't_arrive']).copy()
    eo_valid['placement'] = eo_valid['t_order'].astype(int)
    eo_valid['arrival'] = eo_valid['t_arrive'].astype(int)
    eo_valid['value'] = eo_valid['value'].fillna(0)

    # Pivot so each (placement, arrival) is a row, with s1/s2 columns
    wide_order = eo_valid.pivot_table(
        index=['placement', 'arrival'],
        columns='supplier',
        values='value',
        fill_value=0
    ).reset_index()

    for supplier in ['s1', 's2']:
        if supplier not in wide_order.columns:
            wide_order[supplier] = 0

    # Ensure placement covers full planning horizon
    full_range = pd.DataFrame({'placement': range(1, planning_horizon + 1)})
    # For arrival, fill with placement + 3 as default (adjust if needed)
    full_range['arrival'] = full_range['placement'] + 3

    # Merge to ensure all placements present, fill missing with 0
    order_matrix = pd.merge(full_range, wide_order, on=['placement', 'arrival'], how='left')
    for supplier in ['s1', 's2']:
        order_matrix[supplier] = order_matrix[supplier].fillna(0)

    order_matrix = order_matrix[['placement', 'arrival', 's1', 's2']].sort_values(by='placement')
    print(order_matrix.head(10))
    return order_matrix



def comp_stock_outsample(demand, order):
# Define input vectors (example)
    initial_inventory = I_0  # Initial inventory (i0)
# Calculate dynamic stock quantity
    stock_quantity = np.zeros(len(order) + 1)  # +1 for initial stock
# Set the initial stock
    stock_quantity[0] = initial_inventory
# Calculate stock quantity for each time period
    for t in range(1, len(stock_quantity)):
        stock_quantity[t] = stock_quantity[t-1] + order[t-1] - demand[t-1]
    return stock_quantity


def compute_total_cost(demand):
    # stock_quantity_= comp_stock_outsample(demand, tot_arr_order)
    stock_quantity_ = comp_stock_outsample(demand, tot_arr_order['Total_Order'].values)

    stock_quantity= stock_quantity_[3:]
    storage_backlog_cost = compute_storage_and_backlog_costs(stock_quantity, h, b)
    storage_cost= storage_backlog_cost['Storage']
    backlog_cost= storage_backlog_cost['Backlog']

    proc_cost= compute_procurement_cost(df_price, order_placed_red) 
    
    total_cost= storage_cost + backlog_cost + np.sum(np.array(proc_cost))
    # print(storage_cost)
    print('Total cost:', total_cost)
    return {'Procurement cost': np.sum(np.array(proc_cost)),
            'storage cost': storage_cost,
            'backlog cost': backlog_cost,
            'Total cost': total_cost }


actual_cost= compute_total_cost(actual_demand)
order_matrix= extract_order_matrix(extracted_order)
# print(actual_cost)


# plot_order(order_matrix,
#                df_price)

# plot_manual(1, df_price)

plot_order_matrix(order_matrix, df_price)
order_matrix.to_csv('Order.csv')

# Usage example:
total, detail = calc_total_procurement_cost(df_price, order_matrix)
print("Total procurement cost:", total)
print(detail.head())
