
import numpy as np
import pandas as pd
from typing import List, Tuple
from itertools import chain
import matplotlib.pyplot as plt


#  Config
T= 12
I0= 441*4
order= 100*np.ones([T, 1])
h, b= 5, 10
n= 1000
proc_man= 74438
proc_dro= 69150
proc_saa= 84454

order_df= pd.read_csv('Order250123.csv')
order_dro= order_df[['DRO']].values
order_saa= order_df[['SAA']].values
order_manual= order_df[['Manual']].values


def generate_demand(X: np.array,
                    n: int,
                    alpha: float) -> np.array:
    T= X.shape[0]
    synthetic_demand= np.mean(X) + alpha*np.mean(X)*np.random.randn(T, n)
    return pd.DataFrame(np.array(synthetic_demand), columns= [f"Sample{i+1}" for i in range(n)]) 



def compute_stock(demand: np.array, 
                  arriving_orders: np.array,
                  h: float, 
                  b: float, 
                  initial_stock: np.array= I0, ) -> np.array:
    stock = [initial_stock]
    for t in range(len(demand)):
        current_stock = stock[-1] + arriving_orders[t] - demand[t]
        stock.append(current_stock)
        
    stock= np.array(stock[1:])
    # Remove the initial stock for alignment with demand and arriving_orders timeseries
    storage_cost = sum(max(0, s) * h for s in stock)
    backlog_cost = sum(abs(min(0, s)) * b for s in stock)
    return np.array(stock), storage_cost, backlog_cost

def flatten(X):
    return [item[0] if isinstance(item, np.ndarray) else item for item in X]

hist_demand = pd.read_excel('pidsg22.xlsx', sheet_name='demand', index_col= 0)
synthetic= generate_demand(hist_demand['Demand'].values, n, 1)
# cost_dro= 


def consider_proc_cost():
    proc_cost= {}
    proc_cost['Manual']= proc_man
    proc_cost['DRO']= proc_dro
    proc_cost['saa']= proc_saa
    return proc_cost


def compute_different_costs(order: np.array) -> Tuple[List, List, List, List]:
    stock_all= []
    storage_cost_all= []
    backlog_cost_all= []
    total_cost_all= []
    for i in range(synthetic.shape[1]):
        stock, storage, backlog= compute_stock(demand= synthetic.iloc[:, i].values,
                                           arriving_orders= order,
                                           h= h,
                                           b= b,
                                           initial_stock= I0)
        total_cost= storage + backlog
 

        stock_all.append(stock)
        storage_cost_all.append(storage)
        backlog_cost_all.append(backlog)
        total_cost_all.append(total_cost)
        total_cost_all= flatten(total_cost_all)
        backlog_cost_all= flatten(backlog_cost_all)
    return stock_all, storage_cost_all, backlog_cost_all, total_cost_all





# data_t_demand= pd.concat([data_t_demand_, synthetic], axis=1)

def plot_hist(X: list, var_name: str = 'X') -> None:
    plt.hist(np.array(X), bins=50)
# Add labels and title
    plt.title(f'Histogram of {var_name}')
    plt.xlabel('Value')
    plt.ylabel('Frequency')
# Display the histogram
    plt.show()



def plot_histograms(data1, data2, data3, labels=None, bins=30, title= None):
    # plt.figure(figsize=(10, 6))  # Set figure size

    # # Plot the histograms
    # plt.hist(data1, bins=bins, alpha=0.5, label=labels[0] if labels else "Data 1", color="red", edgecolor="black")
    # plt.hist(data2, bins=bins, alpha=0.5, label=labels[1] if labels else "Data 2", color="blue", edgecolor="black")
    # plt.hist(data3, bins=bins, alpha=0.5, label=labels[2] if labels else "Data 3", color="green", edgecolor="black")

    # # Add title and labels
    # plt.title(title)
    # plt.xlabel("Value")
    # plt.ylabel("Frequency")
    
    # # Add a legend if labels are provided
    # if labels:
    #     plt.legend()

   
    fig, axs = plt.subplots(3, 1, figsize=(8, 12), sharex=True)

    # First histogram
    axs[0].hist(data1, bins=bins, color="red", edgecolor="black", alpha=0.7)
    axs[0].axvline(np.mean(data1), color="black", linestyle="--", label=f"Mean: {np.mean(data1):.1f}")
    axs[0].set_title("DRO")
    axs[0].set_ylabel("Frequency")

    # Second histogram
    axs[1].hist(data2, bins=bins, color="blue", edgecolor="black", alpha=0.7)
    axs[1].axvline(np.mean(data2), color="black", linestyle="--", label=f"Mean: {np.mean(data2):.1f}")
    axs[1].set_title("SAA")
    axs[1].set_ylabel("Frequency")

    # Third histogram
    axs[2].hist(data3, bins=bins, color="green", edgecolor="black", alpha=0.7)
    axs[2].axvline(np.mean(data3), color="black", linestyle="--", label=f"Mean: {np.mean(data3):.1f}")
    axs[2].set_title("Manual")
    axs[2].set_xlabel("Value")
    axs[2].set_ylabel("Frequency")

    # Adjust layout for better spacing
    plt.tight_layout()
    # plt.show()

    # Show the plot
    plt.show()

stock_dro, storage_dro, backlog_dro, total_cost_dro = compute_different_costs(order_dro)
stock_saa, storage_saa, backlog_saa, total_cost_saa = compute_different_costs(order_saa)
stock_manual, storage_manual, backlog_manual, total_cost_manual = compute_different_costs(order_manual)

proc_cost= consider_proc_cost()

# plot_hist(total_cost_dro, 'total_cost_dro')
# plot_hist(total_cost_saa, 'total_cost_SAA')
# plot_hist(total_cost_manual, 'total_cost_Manual')


# plot_hist(backlog_dro, 'backlog_dro')
# plot_hist(backlog_saa, 'backlog_saa')
# plot_hist(backlog_manual, 'backlog_manual')


plot_histograms(backlog_dro, backlog_saa, backlog_manual, 
                labels= ['DRO', 'SAA', 'Manual'], 
                bins=30, title="Risk")

plot_histograms(total_cost_dro, total_cost_saa, total_cost_manual, 
                labels= ['DRO', 'SAA', 'Manual'], 
                bins=30, title="Total cost")
