import pandas as pd
import matplotlib.pyplot as plt

# filepath= 'pidsg25Evaluation.xlsx'
# sheetname= 'Eval07Clean'

"""
for storage capacity constraints
"""

filepath= 'storage_cap08.xlsx'
sheetname= 'result08'

# 1. Load Data
def load_data(filepath, sheetname= sheetname):
    df = pd.read_excel(filepath, sheet_name= sheetname)  # or pd.read_csv for CSV
    # Optionally parse dates: df['Date'] = pd.to_datetime(df['Date'], format='%d/%m/%y')
    return df


df= load_data(filepath)
print(df.head())
# 2. Compute cumulative cost

def total_cost(df):
    df['Total proc man']= 31.104*(df['Hedged price']*df['Order-Manual-Hedged'] + df['Unhedged price']*df['Order-Manual-Unhedged'])
    df['Total proc AI']= 31.104*(df['Hedged price']*df['Order-AI-Hedged'] + df['Unhedged price']*df['Order-AI-Unhedged'])
    print(df.head())
    return df

def compute_cumulative(df, cols):
    cum_costs = {}
    for col in cols:
        cum_costs[col] = df[col].cumsum()
    return cum_costs

# 3. Plot cumulative cost(s)
def plot_cumulative(cum_costs, dates, title):
    plt.figure(figsize=(12, 6))
    for label, values in cum_costs.items():
        plt.plot(dates, values, label=label)
    plt.xlabel('Date')
    plt.ylabel('Cumulative Cost')
    plt.title(title)
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()

def plot_stock_levels(df):
    # Parse 'Date' column if needed
    df['Date'] = pd.to_datetime(df['Date'], format='%d/%m/%y')

    plt.figure(figsize=(14, 6))
    plt.plot(df['Date'], df['Manual-stock'], marker='o', label='Manual-stock')
    plt.plot(df['Date'], df['AI-Stock'], marker='s', label='AI-Stock')

    plt.xlabel('Date')
    plt.ylabel('Stock Level')
    plt.title('Manual-stock vs AI-Stock over Time')
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()


# 4. Main execution
if __name__ == "__main__":
    # --- Path to your Excel or CSV file ---
    # data_path = 'your_file.xlsx'
    df = load_data(filepath, sheetname= sheetname)
    
    # --- Specify cost columns to process ---
    cost_cols = [
        'Order-Manual Total', 'Manual-storage-cost',
        'Order-AI-Total', 'AI-storage-cost'
    ]
    
    # Optionally, sum procurement+storage as new cols
    df= total_cost(df)
    df['Manual_Total_Cost'] = df['Total proc man'] + df['Manual-storage-cost']
    df['AI_Total_Cost'] = df['Total proc AI'] + df['AI-storage-cost']
    
    cum_costs = compute_cumulative(df, ['Total proc man', 'Total proc AI'])
    cum_costs_total = compute_cumulative(df, ['Manual_Total_Cost', 'AI_Total_Cost'])
    cum_costs_storage = compute_cumulative(df, ['Manual-storage-cost', 'AI-storage-cost'])
    plot_cumulative(cum_costs, df['Date'], 'Total procurement cost')
    plot_cumulative(cum_costs_total, df['Date'], 'Total procurement+storage cost')
    plot_cumulative(cum_costs_storage, df['Date'], 'Storage cost')
    plot_stock_levels(df)
