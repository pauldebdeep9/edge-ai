from pathlib import Path

import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import pandas as pd

from extraction01 import load_material_metric_series

user_inputs = {"h": 5, "b": 50}
cumulative_demand_usd= 2797

'''
includes codes for generating plots and evidances to 
establish the validation of the cost saving claims as of 26-01 for the rest 
of FY2025.
'''

def load_sheet_12(path: str) -> pd.DataFrame:
    return pd.read_excel(path, sheet_name="12", engine="openpyxl")


def drop_nan_columns(df: pd.DataFrame) -> pd.DataFrame:
    return df.dropna(axis=1, how="all")


def compute_inventory_series(
    orders: pd.Series,
    demand: pd.Series,
    I0: float,
) -> pd.Series:
    """Compute cumulative inventory period-by-period."""
    inventory = pd.Series(index=orders.index, dtype=float)
    if len(orders) == 0:
        return inventory
    inventory.iloc[0] = I0 + orders.iloc[0] - demand.iloc[0]
    for i in range(1, len(orders)):
        inventory.iloc[i] = inventory.iloc[i - 1] + orders.iloc[i] - demand.iloc[i]
    return inventory


def compute_strategy_costs(
    df: pd.DataFrame,
    *,
    demand_col: str,
    price_hedged_col: str,
    price_unhedged_col: str,
    ai_hedged_col: str,
    ai_unhedged_col: str,
    manual_hedged_col: str,
    manual_unhedged_col: str,
    h: float,
    b: float,
    demand_series: pd.Series | None = None,
) -> pd.DataFrame:
    df = drop_nan_columns(df).copy()

    numeric_cols = [
        price_hedged_col,
        price_unhedged_col,
        ai_hedged_col,
        ai_unhedged_col,
        manual_hedged_col,
        manual_unhedged_col,
    ]
    if demand_series is None:
        numeric_cols.insert(0, demand_col)
    for col in numeric_cols:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    if demand_series is None:
        demand_values = df[demand_col]
    else:
        demand_values = pd.to_numeric(demand_series, errors="coerce").reindex(df.index)

    ai_total = df[ai_hedged_col] + df[ai_unhedged_col]
    manual_total = df[manual_hedged_col] + df[manual_unhedged_col]

    ai_procure = (
        df[ai_hedged_col] * df[price_hedged_col]
        + df[ai_unhedged_col] * df[price_unhedged_col]
    )
    manual_procure = (
        df[manual_hedged_col] * df[price_hedged_col]
        + df[manual_unhedged_col] * df[price_unhedged_col]
    )

    # Use cumulative inventory calculation (matching reoptimize2601.py)
    ai_inventory = compute_inventory_series(ai_total, demand_values, I0=4000)
    manual_inventory = compute_inventory_series(manual_total, demand_values, I0=0)

    # Calculate storage cost (for comparison/reporting, matching reoptimize2601.py)
    storage_scale = 50
    ai_storage_cost = (
        ai_inventory.clip(lower=0) * h + (-ai_inventory).clip(lower=0) * b
    ) / storage_scale
    manual_storage_cost = (
        manual_inventory.clip(lower=0) * h + (-manual_inventory).clip(lower=0) * b
    ) / storage_scale

    # Use holding cost for total_cost calculation (matching reoptimize2601.py)
    holding_cost_rate = 0.05
    ai_holding_cost = holding_cost_rate * ai_inventory
    manual_holding_cost = holding_cost_rate * manual_inventory

    df["ai_total_order"] = ai_total
    df["manual_total_order"] = manual_total
    df["ai_procure_cost"] = ai_procure
    df["manual_procure_cost"] = manual_procure
    df["ai_storage_cost"] = ai_storage_cost
    df["manual_storage_cost"] = manual_storage_cost
    df["ai_holding_cost"] = ai_holding_cost
    df["manual_holding_cost"] = manual_holding_cost
    df["ai_inventory"] = ai_inventory
    df["manual_inventory"] = manual_inventory
    df["ai_total_cost"] = ai_procure + ai_holding_cost
    df["manual_total_cost"] = manual_procure + manual_holding_cost

    return df


def plot_strategy_costs(df: pd.DataFrame, *, x_col: str | None = None) -> None:
    x = df[x_col] if x_col else df.index
    x_values = pd.Series(x)
    fig_size = (10, 5)
    line_style = {"linestyle": ":", "marker": "*"}
    saa_color = "steelblue"   # SAA (was AI)
    capsaa_color = "darkorange"  # Cap-SAA (was Reoptimized)
    manual_color = "green"    # Manual
    cost_style = {"linestyle": "-", "marker": "o"}

    def format_date_axis(ax: plt.Axes) -> None:
        if pd.api.types.is_datetime64_any_dtype(x_values):
            ax.xaxis.set_major_formatter(mdates.DateFormatter("%b-%y"))

    ai_procure_cum = df["ai_procure_cost"].cumsum()
    manual_procure_cum = df["manual_procure_cost"].cumsum()
    ai_holding_cum = df["ai_holding_cost"].cumsum()
    manual_holding_cum = df["manual_holding_cost"].cumsum()
    ai_total_cum = df["ai_total_cost"].cumsum()
    manual_total_cum = df["manual_total_cost"].cumsum()

    def add_end_of_year_diff(ax: plt.Axes, ai_series: pd.Series, manual_series: pd.Series) -> None:
        ai_final = ai_series.iloc[-1]
        manual_final = manual_series.iloc[-1]
        if pd.notna(ai_final) and pd.notna(manual_final) and manual_final != 0:
            pct_diff = (ai_final - manual_final) / manual_final * 100
            direction = "increase" if pct_diff >= 0 else "decrease"
            diff_label = (
                f"End-of-year {direction} of AI wrt Manual: {pct_diff:+.1f}%"
            )
        else:
            diff_label = "End-of-year increase/decrease of AI wrt Manual: n/a"
        ax.text(
            0.5,
            0.98,
            diff_label,
            transform=ax.transAxes,
            ha="center",
            va="top",
        )

    plt.figure(figsize=fig_size)
    plt.plot(x, ai_procure_cum, label="SAA procurement", color=saa_color, **line_style)
    plt.plot(x, manual_procure_cum, label="Manual procurement", color=manual_color, **line_style)
    plt.title("Cumulative Procurement Cost")
    plt.legend()
    plt.xlabel(x_col if x_col else "Index")
    plt.ylabel("Cost")
    procurement_ax = plt.gca()
    format_date_axis(procurement_ax)
    add_end_of_year_diff(procurement_ax, ai_procure_cum, manual_procure_cum)

    # Cumulative procurement cost with cumulative quantity fraction on secondary axis
    ai_cum_qty = df["ai_total_order"].cumsum()
    manual_cum_qty = df["manual_total_order"].cumsum()
    ai_qty_frac = (
        ai_cum_qty / ai_cum_qty.iloc[-1] if ai_cum_qty.iloc[-1] != 0 else ai_cum_qty * float("nan")
    )
    manual_qty_frac = (
        manual_cum_qty / manual_cum_qty.iloc[-1] if manual_cum_qty.iloc[-1] != 0 else manual_cum_qty * float("nan")
    )

    fig, ax_cost = plt.subplots(figsize=fig_size)
    cost_lines = []
    cost_lines.extend(
        ax_cost.plot(x, ai_procure_cum, label="SAA cumulative cost", color=saa_color, **cost_style)
    )
    cost_lines.extend(
        ax_cost.plot(x, manual_procure_cum, label="Manual cumulative cost", color=manual_color, **cost_style)
    )
    ax_cost.set_title("Cumulative Procurement Cost & Quantity Fraction")
    ax_cost.set_xlabel(x_col if x_col else "Index")
    ax_cost.set_ylabel("Cost")
    format_date_axis(ax_cost)
    ax_cost.grid(True, which="both", linestyle="--", alpha=0.4)

    ax_frac = ax_cost.twinx()
    frac_lines = []
    frac_lines.extend(
        ax_frac.plot(
            x,
            ai_qty_frac,
            label="SAA cumulative qty fraction",
            color=saa_color,
            linestyle=":",
            marker="*",
        )
    )
    frac_lines.extend(
        ax_frac.plot(
            x,
            manual_qty_frac,
            label="Manual cumulative qty fraction",
            color=manual_color,
            linestyle=":",
            marker="*",
        )
    )
    ax_frac.set_ylabel("Cumulative quantity fraction")
    ax_frac.set_ylim(0, 1.05)
    format_date_axis(ax_frac)

    combined_lines = cost_lines + frac_lines
    labels = [line.get_label() for line in combined_lines]
    ax_cost.legend(combined_lines, labels, loc="upper left")

    # Monthly procurement cost (bar chart)
    fig, ax = plt.subplots(figsize=fig_size)
    if pd.api.types.is_datetime64_any_dtype(x_values):
        bar_width = pd.Timedelta(days=12)
    else:
        bar_width = 0.35
    ax.bar(x_values - bar_width / 2, df["ai_procure_cost"], width=bar_width, color=saa_color, label="SAA procurement (monthly)")
    ax.bar(x_values + bar_width / 2, df["manual_procure_cost"], width=bar_width, color=manual_color, label="Manual procurement (monthly)")
    ax.set_title("Monthly Procurement Cost")
    ax.set_xlabel(x_col if x_col else "Index")
    ax.set_ylabel("Cost")
    format_date_axis(ax)
    ax.legend()

    plt.figure(figsize=fig_size)
    plt.plot(x, ai_holding_cum, label="SAA holding cost", **line_style)
    plt.plot(x, manual_holding_cum, label="Manual holding cost", **line_style)
    plt.title("Cumulative Holding Cost")
    plt.legend()
    plt.xlabel(x_col if x_col else "Index")
    plt.ylabel("Cost")
    storage_ax = plt.gca()
    format_date_axis(storage_ax)
    add_end_of_year_diff(storage_ax, ai_holding_cum, manual_holding_cum)

    plt.figure(figsize=fig_size)
    plt.plot(x, ai_total_cum, label="SAA total", **line_style)
    plt.plot(x, manual_total_cum, label="Manual total", **line_style)
    plt.title("Cumulative Total Cost")
    plt.legend()
    plt.xlabel(x_col if x_col else "Index")
    plt.ylabel("Cost")
    total_ax = plt.gca()
    format_date_axis(total_ax)
    add_end_of_year_diff(total_ax, ai_total_cum, manual_total_cum)

    fig, ax = plt.subplots(figsize=fig_size)
    ai_inventory_months = df["ai_inventory"] / 12000
    manual_inventory_months = df["manual_inventory"] / 12000
    
    # Load reoptimized inventory data
    reopt_files = sorted(Path(".").glob("reoptimize_output_*.csv"))
    if reopt_files:
        reopt_df = pd.read_csv(reopt_files[-1])  # Load most recent
        reopt_inventory_months = (reopt_df["inventory_optimized_plot"] / 12000).clip(upper=1.5)
    else:
        reopt_inventory_months = None
    
    if pd.api.types.is_datetime64_any_dtype(x_values):
        bar_width = pd.Timedelta(days=8)
    else:
        bar_width = 0.25
    
    if reopt_inventory_months is not None:
        # Three bars
        ax.bar(x_values - bar_width, manual_inventory_months, width=bar_width, label="Manual", color=manual_color, alpha=0.7)
        ax.bar(x_values, ai_inventory_months, width=bar_width, label="SAA", color=saa_color, alpha=0.7)
        ax.bar(x_values + bar_width, reopt_inventory_months, width=bar_width, label="Cap-SAA", color=capsaa_color, alpha=0.7)
    else:
        # Two bars (original)
        if pd.api.types.is_datetime64_any_dtype(x_values):
            bar_width = pd.Timedelta(days=12)
        else:
            bar_width = 0.35
        ax.bar(x_values - bar_width / 2, manual_inventory_months, width=bar_width, label="Manual", color=manual_color)
        ax.bar(x_values + bar_width / 2, ai_inventory_months, width=bar_width, label="SAA", color=saa_color)
    
    ax.set_title("Inventory")
    ax.legend()
    ax.set_xlabel(x_col if x_col else "Index")
    ax.set_ylabel("Months")
    format_date_axis(ax)
    
    # New plot: Cumulative Procurement Cost and Fraction for all strategies
    fig, ax_cost = plt.subplots(figsize=fig_size)
    
    # Calculate cumulative procurement fractions
    ai_procure_frac = (
        ai_procure_cum / ai_procure_cum.iloc[-1] if ai_procure_cum.iloc[-1] != 0 else ai_procure_cum * float("nan")
    )
    manual_procure_frac = (
        manual_procure_cum / manual_procure_cum.iloc[-1] if manual_procure_cum.iloc[-1] != 0 else manual_procure_cum * float("nan")
    )
    
    # Initialize variables for Cap-SAA data
    capsaa_procure_cum = None
    capsaa_procure_frac = None
    
    # Load Cap-SAA data if available
    if reopt_files:
        reopt_df_capsaa = pd.read_csv(reopt_files[-1])
        if "procurement_cost_optimized" in reopt_df_capsaa.columns:
            capsaa_procure_cum = reopt_df_capsaa["procurement_cost_optimized"].cumsum()
            capsaa_procure_frac = (
                capsaa_procure_cum / capsaa_procure_cum.iloc[-1] if capsaa_procure_cum.iloc[-1] != 0 else capsaa_procure_cum * float("nan")
            )
    
    # Plot cumulative procurement costs
    cost_lines = []
    cost_lines.extend(
        ax_cost.plot(x, manual_procure_cum, label="Manual cumulative cost", color=manual_color, **cost_style)
    )
    cost_lines.extend(
        ax_cost.plot(x, ai_procure_cum, label="SAA cumulative cost", color=saa_color, **cost_style)
    )
    if capsaa_procure_cum is not None:
        cost_lines.extend(
            ax_cost.plot(x, capsaa_procure_cum, label="Cap-SAA cumulative cost", color=capsaa_color, **cost_style)
        )
    
    ax_cost.set_title("Cumulative Procurement Cost & Procurement Fraction (All Strategies)")
    ax_cost.set_xlabel(x_col if x_col else "Index")
    ax_cost.set_ylabel("Cost")
    format_date_axis(ax_cost)
    ax_cost.grid(True, which="both", linestyle="--", alpha=0.4)
    
    # Add secondary axis for procurement fractions
    ax_frac = ax_cost.twinx()
    frac_lines = []
    frac_lines.extend(
        ax_frac.plot(
            x,
            manual_procure_frac,
            label="Manual cumulative procurement fraction",
            color=manual_color,
            linestyle=":",
            marker="*",
        )
    )
    frac_lines.extend(
        ax_frac.plot(
            x,
            ai_procure_frac,
            label="SAA cumulative procurement fraction",
            color=saa_color,
            linestyle=":",
            marker="*",
        )
    )
    if capsaa_procure_frac is not None:
        frac_lines.extend(
            ax_frac.plot(
                x,
                capsaa_procure_frac,
                label="Cap-SAA cumulative procurement fraction",
                color=capsaa_color,
                linestyle=":",
                marker="*",
            )
        )
    
    ax_frac.set_ylabel("Cumulative procurement fraction")
    ax_frac.set_ylim(0, 1.05)
    format_date_axis(ax_frac)
    
    combined_lines = cost_lines + frac_lines
    labels = [line.get_label() for line in combined_lines]
    ax_cost.legend(combined_lines, labels, loc="upper left")

    plt.show()


if __name__ == "__main__":
    df = load_sheet_12("data/pidsg26Evaluation12.xlsx")

    demand_col = "demand-12"  # Fallback column if extracted series not available
    price_hedged_col = "price-hedged"
    price_unhedged_col = "price-unhedged"
    ai_hedged_col = "AI-04-hedged"
    ai_unhedged_col = "AI-04-unhedged"
    manual_hedged_col = "manual-04-hedged"
    manual_unhedged_col = "manual-04-unhedged"

    # Extract consumption time series from CSV (default behavior)
    # Set use_extracted_demand=False to use demand_col from Excel instead
    use_extracted_demand = True
    
    if use_extracted_demand:
        demand_series = load_material_metric_series(
            path=Path("data/8.0 FY2025 Material Control.csv"),
            metric_name="Consumption",
        )
        # Consumption values are negative, convert to positive demand
        demand_series = demand_series.abs()
        
        # Create mapping from month strings to datetime
        # Apr-25 -> 2025-04-01, May-25 -> 2025-05-01, etc.
        month_mapping = {
            "Apr-25": pd.Timestamp("2025-04-01"),
            "May-25": pd.Timestamp("2025-05-01"),
            "Jun-25": pd.Timestamp("2025-06-01"),
            "Jul-25": pd.Timestamp("2025-07-01"),
            "Aug-25": pd.Timestamp("2025-08-01"),
            "Sep-25": pd.Timestamp("2025-09-01"),
            "Oct-25": pd.Timestamp("2025-10-01"),
            "Nov-25": pd.Timestamp("2025-11-01"),
            "Dec-25": pd.Timestamp("2025-12-01"),
            "Jan-26": pd.Timestamp("2026-01-01"),
            "Feb-26": pd.Timestamp("2026-02-01"),
            "Mar-26": pd.Timestamp("2026-03-01"),
        }
        
        # Reindex demand series with datetime index
        demand_series.index = demand_series.index.map(month_mapping)
        
        # Align with dataframe index
        if "date" in df.columns:
            demand_series = df["date"].map(demand_series)
        elif len(demand_series) == len(df):
            demand_series = demand_series.reset_index(drop=True)
            demand_series.index = df.index
        else:
            print("Warning: Could not align demand series, falling back to demand_col")
            demand_series = None
    else:
        demand_series = None

    df = compute_strategy_costs(
        df,
        demand_col=demand_col,
        price_hedged_col=price_hedged_col,
        price_unhedged_col=price_unhedged_col,
        ai_hedged_col=ai_hedged_col,
        ai_unhedged_col=ai_unhedged_col,
        manual_hedged_col=manual_hedged_col,
        manual_unhedged_col=manual_unhedged_col,
        h=user_inputs["h"],
        b=user_inputs["b"],
        demand_series=demand_series,
    )

    ai_procure_cum = df["ai_procure_cost"].cumsum()
    manual_procure_cum = df["manual_procure_cost"].cumsum()
    ai_procure_total = ai_procure_cum.iloc[-1]
    manual_procure_total = manual_procure_cum.iloc[-1]

    manual_storage_total = df["manual_storage_cost"].sum()
    if pd.notna(manual_procure_total) and manual_procure_total != 0:
        storage_cost_usd = (manual_storage_total * cumulative_demand_usd) / manual_procure_total
    else:
        storage_cost_usd = float("nan")
    df["storage_cost_usd"] = storage_cost_usd
    if pd.notna(manual_procure_total) and manual_procure_total != 0:
        proc_cost_saving_usd = (
            cumulative_demand_usd
            * ((manual_procure_total - ai_procure_total) / manual_procure_total * 100)
        )/100
    else:
        proc_cost_saving_usd = float("nan")
    if pd.notna(storage_cost_usd):
        storage_cost_saving_usd = storage_cost_usd * (-38.9) / 100
    else:
        storage_cost_saving_usd = float("nan")

    print(f"AI cumulative procurement cost: {ai_procure_total}")
    print(f"Manual cumulative procurement cost: {manual_procure_total}")
    print(f"Cumulative demand USD (manual ratio * 2797): {cumulative_demand_usd}")
    print(f"storage_cost_usd: {df['storage_cost_usd'].iloc[0]}")
    print(f"proc_cost_saving_usd: {proc_cost_saving_usd}")
    print(f"storage_cost_saving_usd: {storage_cost_saving_usd}")
    
    # Load Cap-SAA data and calculate percentage savings vs Manual
    reopt_files = sorted(Path(".").glob("reoptimize_output_*.csv"))
    if reopt_files:
        print("\n" + "="*80)
        print("PERCENTAGE SAVINGS: Manual vs Cap-SAA")
        print("Formula: (Manual - Cap-SAA) / Manual * 100%")
        print("="*80)
        
        reopt_df = pd.read_csv(reopt_files[-1])
        
        # Extract cumulative costs
        manual_total_procure = reopt_df["procurement_cost_manual"].sum()
        capsaa_total_procure = reopt_df["procurement_cost_optimized"].sum()
        
        manual_total_storage = reopt_df["storage_cost_manual"].sum()
        capsaa_total_storage = reopt_df["storage_cost_optimized"].sum()
        
        manual_total_cost = reopt_df["total_cost_manual"].sum()
        capsaa_total_cost = reopt_df["total_cost_optimized"].sum()
        
        # Calculate percentage savings
        pct_procure_saving = ((manual_total_procure - capsaa_total_procure) / manual_total_procure * 100) if manual_total_procure != 0 else 0
        pct_storage_saving = ((manual_total_storage - capsaa_total_storage) / manual_total_storage * 100) if manual_total_storage != 0 else 0
        pct_total_saving = ((manual_total_cost - capsaa_total_cost) / manual_total_cost * 100) if manual_total_cost != 0 else 0
        
        print(f"\n1. Procurement Cost:")
        print(f"   Manual:   ${manual_total_procure:,.2f}")
        print(f"   Cap-SAA:  ${capsaa_total_procure:,.2f}")
        print(f"   Savings:  ${manual_total_procure - capsaa_total_procure:,.2f} ({pct_procure_saving:+.2f}%)")
        
        print(f"\n2. Storage Cost:")
        print(f"   Manual:   ${manual_total_storage:,.2f}")
        print(f"   Cap-SAA:  ${capsaa_total_storage:,.2f}")
        print(f"   Savings:  ${manual_total_storage - capsaa_total_storage:,.2f} ({pct_storage_saving:+.2f}%)")
        
        print(f"\n3. Total Cost:")
        print(f"   Manual:   ${manual_total_cost:,.2f}")
        print(f"   Cap-SAA:  ${capsaa_total_cost:,.2f}")
        print(f"   Savings:  ${manual_total_cost - capsaa_total_cost:,.2f} ({pct_total_saving:+.2f}%)")
        
        print("\n" + "="*80)
    else:
        print("\nNote: No Cap-SAA data found. Run reoptimize2601.py to generate Cap-SAA comparison.")
    
    plot_strategy_costs(df, x_col="date")
