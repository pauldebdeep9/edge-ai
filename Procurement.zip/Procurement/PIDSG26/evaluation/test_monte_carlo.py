#!/usr/bin/env python3
"""Test a few Monte Carlo scenarios to verify the logic."""

import numpy as np
import pandas as pd
from reoptimize2601 import (
    load_eval_data, compute_inventory_series, 
    COLUMN_MAP, EXCEL_PATH, SHEET_NAME, I0, HOLDING_COST
)

np.random.seed(42)

# Load base data
df = load_eval_data(EXCEL_PATH, SHEET_NAME, COLUMN_MAP)

q_hedged = df[COLUMN_MAP['q_hedged']].to_numpy(float)
q_unhedged_saa = df[COLUMN_MAP['q_unhedged']].to_numpy(float)
q_manual_unhedged = df[COLUMN_MAP['q_manual_unhedged']].to_numpy(float)
demand = df[COLUMN_MAP['demand']].to_numpy(float)
price_hedged = df[COLUMN_MAP['price_hedged']].to_numpy(float)
price_unhedged_base = df[COLUMN_MAP['price_unhedged']].to_numpy(float)

n_months = len(demand)

# Holding costs (constant)
inv_manual = compute_inventory_series(q_hedged, q_manual_unhedged, demand, 0.0)
holding_manual = HOLDING_COST * np.sum(inv_manual)

inv_capsaa = compute_inventory_series(q_hedged, q_unhedged_saa, demand, I0)
holding_capsaa = HOLDING_COST * np.sum(inv_capsaa)

print("="*100)
print("TESTING MONTE CARLO SCENARIOS")
print("="*100)

# Test first 5 scenarios
for scenario_idx in range(5):
    # Generate random average price change between -10% and +30%
    avg_price_change_pct = np.random.uniform(-10, 30)
    
    # Generate individual month price changes around the average
    month_price_changes_pct = np.random.normal(avg_price_change_pct, 10, size=n_months)
    
    # Create modified price vector
    price_unhedged_scenario = price_unhedged_base * (1 + month_price_changes_pct / 100)
    
    # Calculate costs
    proc_manual = np.sum(price_hedged * q_hedged) + np.sum(price_unhedged_scenario * q_manual_unhedged)
    proc_capsaa = np.sum(price_hedged * q_hedged) + np.sum(price_unhedged_scenario * q_unhedged_saa)
    
    total_manual = proc_manual + holding_manual
    total_capsaa = proc_capsaa + holding_capsaa
    
    total_saving = total_manual - total_capsaa
    
    print(f"\nScenario {scenario_idx + 1}:")
    print(f"  Avg Price Change: {avg_price_change_pct:.2f}%")
    print(f"  Manual Total:  ${total_manual:,.2f}")
    print(f"  Cap-SAA Total: ${total_capsaa:,.2f}")
    print(f"  Saving:        ${total_saving:,.2f}")
    
    if total_saving < 0:
        print("  ⚠️  Cap-SAA is MORE expensive!")

print("\n" + "="*100)
print("KEY INSIGHT")
print("="*100)
print("\nThe baseline comparison shows:")
print(f"  Manual Total:  $189,926.93")
print(f"  Cap-SAA Total: $177,925.82")
print(f"  Baseline Saving: $12,001.11")
print("\nSince we use FIXED quantities, the relationship should be preserved")
print("across all scenarios (only the magnitude changes).")
print("\nIf Cap-SAA is better at baseline, it should be better in ALL scenarios")
print("(assuming proportional price changes maintain the relative advantage).")
