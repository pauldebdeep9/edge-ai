#!/usr/bin/env python3
"""Check if Manual ever beats Cap-SAA in the Monte Carlo scenarios."""

import numpy as np
import pandas as pd
from reoptimize2601 import (
    load_eval_data, compute_inventory_series, 
    COLUMN_MAP, EXCEL_PATH, SHEET_NAME, I0, HOLDING_COST
)

np.random.seed(42)

# Load base data
df = load_eval_data(EXCEL_PATH, SHEET_NAME, COLUMN_MAP)

q_hedged = df[COLUMN_MAP['q_hedged']].to_numpy(float)
q_unhedged_saa = df[COLUMN_MAP['q_unhedged']].to_numpy(float)
q_manual_unhedged = df[COLUMN_MAP['q_manual_unhedged']].to_numpy(float)
demand = df[COLUMN_MAP['demand']].to_numpy(float)
price_hedged = df[COLUMN_MAP['price_hedged']].to_numpy(float)
price_unhedged_base = df[COLUMN_MAP['price_unhedged']].to_numpy(float)

n_months = len(demand)

# Holding costs (constant)
inv_manual = compute_inventory_series(q_hedged, q_manual_unhedged, demand, 0.0)
holding_manual = HOLDING_COST * np.sum(inv_manual)

inv_capsaa = compute_inventory_series(q_hedged, q_unhedged_saa, demand, I0)
holding_capsaa = HOLDING_COST * np.sum(inv_capsaa)

n_scenarios = 10000
manual_wins = 0
manual_win_scenarios = []

print("Running 10,000 scenarios...")

for scenario_idx in range(n_scenarios):
    # Generate random average price change between -10% and +30%
    avg_price_change_pct = np.random.uniform(-10, 30)
    
    # Generate individual month price changes around the average
    month_price_changes_pct = np.random.normal(avg_price_change_pct, 10, size=n_months)
    
    # Create modified price vector
    price_unhedged_scenario = price_unhedged_base * (1 + month_price_changes_pct / 100)
    
    # Calculate costs
    proc_manual = np.sum(price_hedged * q_hedged) + np.sum(price_unhedged_scenario * q_manual_unhedged)
    proc_capsaa = np.sum(price_hedged * q_hedged) + np.sum(price_unhedged_scenario * q_unhedged_saa)
    
    total_manual = proc_manual + holding_manual
    total_capsaa = proc_capsaa + holding_capsaa
    
    total_saving = total_manual - total_capsaa
    
    if total_saving < 0:  # Manual is cheaper
        manual_wins += 1
        if len(manual_win_scenarios) < 10:  # Keep first 10 examples
            manual_win_scenarios.append({
                'scenario': scenario_idx + 1,
                'avg_price_change': avg_price_change_pct,
                'month_changes': month_price_changes_pct.copy(),
                'total_saving': total_saving,
                'manual_total': total_manual,
                'capsaa_total': total_capsaa
            })
    
    if (scenario_idx + 1) % 1000 == 0:
        print(f"  Completed {scenario_idx + 1:,} scenarios... Manual wins so far: {manual_wins}")

print("\n" + "="*100)
print("RESULTS")
print("="*100)
print(f"\nTotal scenarios: {n_scenarios:,}")
print(f"Cap-SAA wins: {n_scenarios - manual_wins:,} ({(n_scenarios - manual_wins)/n_scenarios*100:.2f}%)")
print(f"Manual wins: {manual_wins:,} ({manual_wins/n_scenarios*100:.2f}%)")

if manual_wins > 0:
    print("\n" + "="*100)
    print(f"SAMPLE SCENARIOS WHERE MANUAL BEATS CAP-SAA (First {min(10, len(manual_win_scenarios))})")
    print("="*100)
    
    for scenario in manual_win_scenarios:
        print(f"\nScenario {scenario['scenario']}:")
        print(f"  Avg price change: {scenario['avg_price_change']:.2f}%")
        print(f"  Manual total:  ${scenario['manual_total']:,.2f}")
        print(f"  Cap-SAA total: ${scenario['capsaa_total']:,.2f}")
        print(f"  Cap-SAA LOSES by: ${-scenario['total_saving']:,.2f}")
        print(f"  Month-by-month price changes: {scenario['month_changes']}")
else:
    print("\n✓ Cap-SAA wins in ALL 10,000 scenarios!")
    print("\nThis suggests the current sampling strategy doesn't create scenarios")
    print("where Manual's strategy becomes superior.")
