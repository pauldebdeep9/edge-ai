#!/usr/bin/env python3
"""Quick test of sensitivity analysis with correct logic."""

from price_sensitivity_analysis import run_sensitivity_analysis

# Run the corrected sensitivity analysis
price_increases = [-10, 0, 10]
affected_months = [8, 9, 10, 11]

results_df, df = run_sensitivity_analysis(price_increases, affected_months)

print("\n" + "="*100)
print("SENSITIVITY ANALYSIS RESULTS")
print("="*100)
print(results_df[['price_increase_pct', 'manual_total', 'capsaa_total', 'total_saving']].to_string(index=False))

print("\n" + "="*100)
print("CHECK: Is Cap-SAA ever worse than Manual?")
print("="*100)

capsaa_worse = results_df[results_df['total_saving'] < 0]
if len(capsaa_worse) > 0:
    print(f"\n⚠️  WARNING: Found {len(capsaa_worse)} scenarios where Cap-SAA is worse!")
    print(capsaa_worse[['price_increase_pct', 'total_saving']])
else:
    print("\n✓ Cap-SAA is better than Manual in ALL scenarios!")
