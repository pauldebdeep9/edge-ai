from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd

MONTHS = [
    "Apr-25",
    "May-25",
    "Jun-25",
    "Jul-25",
    "Aug-25",
    "Sep-25",
    "Oct-25",
    "Nov-25",
    "Dec-25",
    "Jan-26",
    "Feb-26",
    "Mar-26",
]


def normalize_cell(value: object) -> str:
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return ""
    return str(value).strip()


def parse_numeric(value: object) -> object:
    text = normalize_cell(value)
    if not text:
        return None
    cleaned = text.replace(",", "")
    if cleaned.startswith("(") and cleaned.endswith(")"):
        cleaned = f"-{cleaned[1:-1]}"
    try:
        return float(cleaned)
    except ValueError:
        return text


def find_row_with_token(df: pd.DataFrame, token: str) -> int:
    target = token.strip().lower()
    for idx in range(df.shape[0]):
        row = df.iloc[idx].astype(str).str.strip().str.lower()
        if (row == target).any():
            return idx
    raise ValueError(f"Could not find row containing {token!r}.")


def find_material_row(
    df: pd.DataFrame, *, row_number: int | None = None, material_name: str | None = None
) -> int:
    if material_name:
        target = material_name.strip().lower()
        matches = df.apply(
            lambda row: row.astype(str).str.strip().str.lower().eq(target).any(), axis=1
        )
        if matches.any():
            return int(matches.idxmax())

    if row_number is None:
        raise ValueError("row_number is required when material_name is not found.")

    return row_number - 1


def build_metric_columns(
    df: pd.DataFrame,
    *,
    month_row: int,
    metric_row: int,
    type_row: int,
    metric_name: str,
) -> dict[str, dict[str, int]]:
    mapping: dict[str, dict[str, int]] = {}
    target_metric = metric_name.strip().lower()
    
    # Find each month column, then scan forward to find Act/T/F columns for the metric.
    for col_idx in range(df.shape[1]):
        month = normalize_cell(df.iat[month_row, col_idx])
        if month not in MONTHS:
            continue
        
        # Scan the next several columns for the metric with Act or T/F
        for offset in range(15):  # Check next 15 columns
            check_col = col_idx + offset
            if check_col >= df.shape[1]:
                break
            
            # Check if this column's metric matches
            metric = normalize_cell(df.iat[metric_row, check_col])
            
            # If we've hit the next month or summary section, stop scanning
            next_month = normalize_cell(df.iat[month_row, check_col])
            if next_month and next_month != month:
                # Stop if it's another MONTHS entry or a summary period like "FY26 1H"
                if next_month in MONTHS or "FY" in next_month.upper():
                    break
            
            if metric.strip().lower() == target_metric:
                # Check the type in this column and the next column
                for sub_offset in range(2):
                    type_col = check_col + sub_offset
                    if type_col >= df.shape[1]:
                        break
                    value_type = normalize_cell(df.iat[type_row, type_col])
                    if value_type in {"Act", "T/F"}:
                        mapping.setdefault(month, {})[value_type] = type_col
    
    return mapping


def extract_metric_timeseries(
    df: pd.DataFrame, *, row_idx: int, columns: dict[str, dict[str, int]], metric_name: str = "Metric"
) -> pd.Series:
    data: dict[str, object] = {}
    for month in MONTHS:
        col_info = columns.get(month, {})
        value = None
        if "Act" in col_info:
            value = parse_numeric(df.iat[row_idx, col_info["Act"]])
        if value in (None, "") and "T/F" in col_info:
            value = parse_numeric(df.iat[row_idx, col_info["T/F"]])
        data[month] = value
    return pd.Series(data, name=metric_name)


def load_material_metric_series(
    *,
    path: Path,
    metric_name: str,
    material_name: str = "Silver Paste",
    row_number: int = 13,
) -> pd.Series:
    df = pd.read_csv(path, header=None, dtype=str, encoding="utf-8-sig")

    month_row = find_row_with_token(df, "Apr-25")
    metric_row = month_row + 1
    type_row = month_row + 2

    row_idx = find_material_row(df, row_number=row_number, material_name=material_name)
    columns = build_metric_columns(
        df,
        month_row=month_row,
        metric_row=metric_row,
        type_row=type_row,
        metric_name=metric_name,
    )
    return extract_metric_timeseries(
        df, row_idx=row_idx, columns=columns, metric_name=metric_name
    )


def main() -> None:
    path = Path("data/8.0 FY2025 Material Control.csv")
    series = load_material_metric_series(path=path, metric_name="Inv Days")
    consumption_series = load_material_metric_series(
        path=path,
        metric_name="Consumption",
        row_number=8,
    )
    abs_series = series.apply(lambda value: abs(value) if isinstance(value, (int, float)) else value)
    abs_consumption_series = consumption_series.apply(
        lambda value: abs(value) if isinstance(value, (int, float)) else value
    )
    output_path = Path("data/extracted_metrics_abs.csv")
    pd.DataFrame(
        {
            "Inv Days": abs_series,
            "Consumption": abs_consumption_series,
        }
    ).to_csv(output_path, index_label="Month")
    print(series)
    print(consumption_series)
    plt.figure()
    plt.plot(series.index, series.values, marker="o")
    plt.title("Silver Paste Inv Days (Apr-25 to Mar-26)")
    plt.xlabel("Month")
    plt.ylabel("Inv Days")
    plt.grid(True, axis="y", linestyle="--", alpha=0.4)
    plt.xticks(rotation=45, ha="right")
    plt.tight_layout()
    plt.show()

    plt.figure()
    plt.plot(consumption_series.index, consumption_series.values, marker="o")
    plt.title("Silver Paste Consumption (Apr-25 to Mar-26)")
    plt.xlabel("Month")
    plt.ylabel("Consumption")
    plt.grid(True, axis="y", linestyle="--", alpha=0.4)
    plt.xticks(rotation=45, ha="right")
    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    main()
