#!/usr/bin/env python3
"""
Reoptimize unhedged orders with an inventory band constraint.

- Reads order vectors from data/pidsg26Evaluation12.xlsx
- Fixes hedged orders, reoptimizes unhedged orders
- Supports hard inventory bands and/or soft inventory-month bands
"""

from __future__ import annotations

import datetime as dt
from pathlib import Path
from typing import Dict, Optional, Union
import numpy as np
import pandas as pd
import cvxpy as cp
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

from extraction01 import load_material_metric_series


# -------------------- Config --------------------
EXCEL_PATH = "data/pidsg26Evaluation12.xlsx"
SHEET_NAME = "12"  # e.g., "12" or "Eval12Clean"
COLUMN_MAP: Dict[str, str] = {
    "date": "date",
    "price_hedged": "price-hedged",
    "price_unhedged": "price-unhedged",
    "demand": "demand-12",
    "q_hedged": "AI-04-hedged",
    "q_unhedged": "AI-04-unhedged",
    "q_manual_unhedged": "manual-04-unhedged",
}

S_MIN = 5000.0
S_MAX = 18000.0
USE_HARD_INVENTORY_BAND = False  # set True to enforce S_MIN/S_MAX as hard constraints
INV_MONTHS_MIN = 0.5
INV_MONTHS_MAX = 1.5
INV_MONTHS_DENOM = 12000.0  # units per month used to compute inventory months
INV_MONTHS_PENALTY = 1000.0  # cost per month outside the inventory-month band
I0 = 0.0
K_LOCK = 4  # number of initial periods to lock to the original unhedged plan
KEEP_TOTAL = True  # preserve total unhedged volume
HOLDING_COST = 0.05
STORAGE_H = 5.0
STORAGE_B = 50.0
STORAGE_SCALE = 50.0
CAPACITY_UNHEDGED = 20000.0  # set to None for no cap
RELAX_MIN_INV = True  # allow softening inv >= S_MIN when infeasible
MIN_INV_PENALTY = 1000.0  # cost per unit of shortfall below S_MIN


# -------------------- Helpers --------------------
def choose_solver() -> Optional[str]:
    installed = set(cp.installed_solvers())
    for name in ("CLARABEL", "ECOS", "OSQP", "SCS"):
        if name in installed:
            return name
    return None


def load_eval_data(path: str, sheet_name: str, cols: Dict[str, str]) -> pd.DataFrame:
    df = pd.read_excel(path, sheet_name=sheet_name)

    missing = [k for k, col in cols.items() if col not in df.columns]
    if missing:
        missing_cols = [cols[k] for k in missing]
        raise ValueError(f"Missing columns in sheet '{sheet_name}': {missing_cols}")

    out = df[[cols["date"], cols["price_hedged"], cols["price_unhedged"],
              cols["demand"], cols["q_hedged"], cols["q_unhedged"], 
              cols["q_manual_unhedged"]]].copy()

    numeric_cols = [
        cols["price_hedged"],
        cols["price_unhedged"],
        cols["demand"],
        cols["q_hedged"],
        cols["q_unhedged"],
        cols["q_manual_unhedged"],
    ]
    for col in numeric_cols:
        out[col] = pd.to_numeric(out[col], errors="coerce")

    out[cols["q_hedged"]] = out[cols["q_hedged"]].fillna(0.0)
    out[cols["q_unhedged"]] = out[cols["q_unhedged"]].fillna(0.0)
    out[cols["q_manual_unhedged"]] = out[cols["q_manual_unhedged"]].fillna(0.0)

    required_non_null = [cols["price_hedged"], cols["price_unhedged"], cols["demand"]]
    out = out.dropna(subset=required_non_null)

    return out


def compute_inventory_series(
    q_hedged: np.ndarray,
    q_unhedged: np.ndarray,
    demand: np.ndarray,
    I0: float,
) -> np.ndarray:
    T = len(demand)
    inv = np.zeros(T, dtype=float)
    if T == 0:
        return inv
    inv[0] = I0 + q_hedged[0] + q_unhedged[0] - demand[0]
    for t in range(1, T):
        inv[t] = inv[t - 1] + q_hedged[t] + q_unhedged[t] - demand[t]
    return inv


def compute_storage_cost(
    inventory: np.ndarray,
    h: float,
    b: float,
    scale: float,
) -> np.ndarray:
    if scale <= 0:
        raise ValueError("storage scale must be > 0.")
    return (np.clip(inventory, 0, None) * h + np.clip(-inventory, 0, None) * b) / scale


def reoptimize_unhedged_with_inventory_band(
    q_hedged: np.ndarray,
    q_unhedged_base: np.ndarray,
    demand: np.ndarray,
    price_hedged: np.ndarray,
    price_unhedged: np.ndarray,
    s_min: Optional[float],
    s_max: Optional[float],
    I0: float,
    holding_cost: float,
    k_lock: int = 0,
    keep_total: bool = True,
    capacity_unhedged: Optional[np.ndarray] = None,
    relax_min_inventory: bool = False,
    min_inventory_penalty: float = 1000.0,
    inventory_months_min: Optional[float] = None,
    inventory_months_max: Optional[float] = None,
    inventory_months_denom: Optional[Union[float, np.ndarray]] = None,
    inventory_months_penalty: float = 0.0,
    solver: Optional[str] = None,
    verbose: bool = False,
) -> Dict[str, np.ndarray]:
    T = len(demand)
    if any(len(arr) != T for arr in (q_hedged, q_unhedged_base, price_hedged, price_unhedged)):
        raise ValueError("All input vectors must have the same length.")
    if not (0 <= k_lock <= T):
        raise ValueError("k_lock must be between 0 and T inclusive.")
    if s_min is not None and s_min < 0:
        raise ValueError("s_min must be >= 0.")
    if s_min is not None and s_max is not None and s_min > s_max:
        raise ValueError("s_min cannot exceed s_max.")
    if inventory_months_min is not None and inventory_months_min < 0:
        raise ValueError("inventory_months_min must be >= 0.")
    if inventory_months_max is not None and inventory_months_max < 0:
        raise ValueError("inventory_months_max must be >= 0.")
    if (
        inventory_months_min is not None
        and inventory_months_max is not None
        and inventory_months_min > inventory_months_max
    ):
        raise ValueError("inventory_months_min cannot exceed inventory_months_max.")

    months_scale = None
    if inventory_months_min is not None or inventory_months_max is not None:
        if inventory_months_denom is None:
            raise ValueError("inventory_months_denom is required when inventory months band is set.")
        months_scale = np.asarray(inventory_months_denom, dtype=float)
        if months_scale.ndim == 0:
            if months_scale <= 0:
                raise ValueError("inventory_months_denom must be > 0.")
        else:
            if len(months_scale) != T:
                raise ValueError("inventory_months_denom must be scalar or length T.")
            if np.any(months_scale <= 0):
                raise ValueError("inventory_months_denom must be > 0.")

    def build_problem(relax_min: bool):
        q_u = cp.Variable(T, nonneg=True, name="Q_unhedged")
        inv = cp.Variable(T, name="Inventory")
        min_slack = None
        months_below = None
        months_above = None
        constraints = []

        if k_lock > 0:
            constraints += [q_u[:k_lock] == q_unhedged_base[:k_lock]]

        if capacity_unhedged is not None:
            constraints += [q_u <= capacity_unhedged]

        constraints += [inv[0] == I0 + q_hedged[0] + q_u[0] - demand[0]]
        for t in range(1, T):
            constraints += [inv[t] == inv[t - 1] + q_hedged[t] + q_u[t] - demand[t]]

        if s_min is not None:
            if relax_min:
                min_slack = cp.Variable(T, nonneg=True, name="MinInvSlack")
                constraints += [inv + min_slack >= s_min]
            else:
                constraints += [inv >= s_min]

        if s_max is not None:
            constraints += [inv <= s_max]

        if months_scale is not None:
            inv_months = inv / months_scale
            if inventory_months_min is not None:
                months_below = cp.Variable(T, nonneg=True, name="InvMonthsBelow")
                constraints += [inv_months + months_below >= inventory_months_min]
            if inventory_months_max is not None:
                months_above = cp.Variable(T, nonneg=True, name="InvMonthsAbove")
                constraints += [inv_months - months_above <= inventory_months_max]

        if keep_total:
            constraints += [cp.sum(q_u) == float(np.sum(q_unhedged_base))]

        purchase_cost = cp.sum(cp.multiply(price_unhedged, q_u)) + float(np.dot(price_hedged, q_hedged))
        holding = holding_cost * cp.sum(inv)
        penalty = 0.0
        if min_slack is not None:
            penalty += min_inventory_penalty * cp.sum(min_slack)
        if months_below is not None:
            penalty += inventory_months_penalty * cp.sum(months_below)
        if months_above is not None:
            penalty += inventory_months_penalty * cp.sum(months_above)
        objective = cp.Minimize(purchase_cost + holding + penalty)

        return cp.Problem(objective, constraints), q_u, inv, min_slack, months_below, months_above

    problem, q_u, inv, min_slack, months_below, months_above = build_problem(relax_min=False)
    if solver:
        problem.solve(solver=solver, verbose=verbose)
    else:
        problem.solve(verbose=verbose)

    used_relaxation = False
    if problem.status not in ("optimal", "optimal_inaccurate") and relax_min_inventory:
        problem, q_u, inv, min_slack, months_below, months_above = build_problem(relax_min=True)
        if solver:
            problem.solve(solver=solver, verbose=verbose)
        else:
            problem.solve(verbose=verbose)
        used_relaxation = True

    if problem.status not in ("optimal", "optimal_inaccurate"):
        raise RuntimeError(f"Optimization failed: status={problem.status}")

    min_slack_val = (
        np.asarray(min_slack.value).reshape(-1) if min_slack is not None else np.zeros(T)
    )
    months_below_val = (
        np.asarray(months_below.value).reshape(-1) if months_below is not None else np.zeros(T)
    )
    months_above_val = (
        np.asarray(months_above.value).reshape(-1) if months_above is not None else np.zeros(T)
    )
    inv_val = np.asarray(inv.value).reshape(-1)
    if months_scale is not None:
        inv_months_val = inv_val / months_scale
    else:
        inv_months_val = np.zeros(T)

    return {
        "Q_unhedged_opt": np.asarray(q_u.value).reshape(-1),
        "Inventory": inv_val,
        "InventoryMonths": inv_months_val,
        "MinInvSlack": min_slack_val,
        "InvMonthsBelow": months_below_val,
        "InvMonthsAbove": months_above_val,
        "UsedRelaxation": used_relaxation,
        "Objective": float(problem.value),
    }


def plot_unhedged_orders(out: pd.DataFrame) -> None:
    """
    Create visualizations of unhedged orders over time.
    """
    # Figure 1: Three-bar comparison (Manual, SAA, Cap-SAA)
    fig1, ax1 = plt.subplots(figsize=(14, 8))

    # Convert dates to numeric positions
    x_pos = np.arange(len(out))
    width = 0.25  # Width for 3 bars

    # Create bars with proper spacing for 3 bars
    bars1 = ax1.bar(x_pos - width, out['order_manual_unhedged'], 
                   width, label='Manual', color='green', alpha=0.7)
    bars2 = ax1.bar(x_pos, out['order_unhedged_original'], 
                   width, label='SAA', color='steelblue', alpha=0.7)
    bars3 = ax1.bar(x_pos + width, out['order_unhedged_optimized'], 
                   width, label='Cap-SAA', color='darkorange', alpha=0.7)

    ax1.set_xlabel('Date', fontsize=12)
    ax1.set_ylabel('Unhedged Order Quantity', fontsize=12)
    ax1.set_title('Unhedged Orders: Manual vs SAA vs Cap-SAA', fontsize=14, fontweight='bold')
    ax1.legend(fontsize=11)
    ax1.grid(True, alpha=0.3, linestyle='--', axis='y')

    # Set x-ticks
    ax1.set_xticks(x_pos)
    ax1.set_xticklabels([d.strftime('%Y-%m') for d in out[COLUMN_MAP["date"]]], 
                        rotation=45, ha='right')

    plt.tight_layout()

    # Figure 2: Separate subplots for manual, SAA, and Cap-SAA
    fig2, (ax2, ax3, ax4) = plt.subplots(3, 1, figsize=(14, 14))

    # Plot 2a: Manual Unhedged Orders
    ax2.bar(x_pos, out['order_manual_unhedged'], 
            color='green', alpha=0.7, width=0.6)
    ax2.set_ylabel('Unhedged Order Quantity', fontsize=12)
    ax2.set_title('Manual Unhedged Orders Over Time', fontsize=14, fontweight='bold')
    ax2.grid(True, alpha=0.3, linestyle='--')
    ax2.set_xticks(x_pos)
    ax2.set_xticklabels([d.strftime('%Y-%m') for d in out[COLUMN_MAP["date"]]], 
                        rotation=45, ha='right')

    # Add value labels on top of bars (only for significant values)
    for i, value in enumerate(out['order_manual_unhedged']):
        if value > 1000:  # Only label significant values
            ax2.text(i, value, f'{value:.0f}', 
                    ha='center', va='bottom', fontsize=8)

    # Plot 2b: SAA Unhedged Orders
    ax3.bar(x_pos, out['order_unhedged_original'], 
            color='steelblue', alpha=0.7, width=0.6)
    ax3.set_ylabel('Unhedged Order Quantity', fontsize=12)
    ax3.set_title('SAA Unhedged Orders Over Time', fontsize=14, fontweight='bold')
    ax3.grid(True, alpha=0.3, linestyle='--')
    ax3.set_xticks(x_pos)
    ax3.set_xticklabels([d.strftime('%Y-%m') for d in out[COLUMN_MAP["date"]]], 
                        rotation=45, ha='right')

    # Add value labels on top of bars (only for significant values)
    for i, value in enumerate(out['order_unhedged_original']):
        if value > 1000:  # Only label significant values
            ax3.text(i, value, f'{value:.0f}', 
                    ha='center', va='bottom', fontsize=8)

    # Plot 2c: Cap-SAA Unhedged Orders
    ax4.bar(x_pos, out['order_unhedged_optimized'], 
            color='darkorange', alpha=0.7, width=0.6)
    ax4.set_xlabel('Date', fontsize=12)
    ax4.set_ylabel('Unhedged Order Quantity', fontsize=12)
    ax4.set_title('Cap-SAA Unhedged Orders Over Time', fontsize=14, fontweight='bold')
    ax4.grid(True, alpha=0.3, linestyle='--')
    ax4.set_xticks(x_pos)
    ax4.set_xticklabels([d.strftime('%Y-%m') for d in out[COLUMN_MAP["date"]]], 
                        rotation=45, ha='right')

    # Add value labels on top of bars (only for significant values)
    for i, value in enumerate(out['order_unhedged_optimized']):
        if value > 1000:  # Only label significant values
            ax4.text(i, value, f'{value:.0f}', 
                    ha='center', va='bottom', fontsize=8)

    plt.tight_layout()

    # Calculate cumulative costs
    cum_procurement_manual = out['procurement_cost_manual'].cumsum()
    cum_procurement_original = out['procurement_cost_original'].cumsum()
    cum_procurement_optimized = out['procurement_cost_optimized'].cumsum()
    cum_storage_manual = out['storage_cost_manual'].cumsum()
    cum_storage_original = out['storage_cost_original'].cumsum()
    cum_storage_optimized = out['storage_cost_optimized'].cumsum()
    cum_holding_manual = out['holding_cost_manual'].cumsum()
    cum_holding_original = out['holding_cost_original'].cumsum()
    cum_holding_optimized = out['holding_cost_optimized'].cumsum()
    cum_total_manual = out['total_cost_manual'].cumsum()
    cum_total_original = out['total_cost_original'].cumsum()
    cum_total_optimized = out['total_cost_optimized'].cumsum()
    
    # Figure 3: Cumulative Procurement Cost
    fig3, ax4 = plt.subplots(figsize=(14, 6))
    ax4.plot(x_pos, cum_procurement_manual, marker='^', linewidth=2, 
             label='Manual', color='green', markersize=6)
    ax4.plot(x_pos, cum_procurement_original, marker='o', linewidth=2, 
             label='SAA', color='steelblue', markersize=6)
    ax4.plot(x_pos, cum_procurement_optimized, marker='s', linewidth=2, 
             label='Cap-SAA', color='darkorange', markersize=6)
    ax4.set_xlabel('Date', fontsize=12)
    ax4.set_ylabel('Cumulative Procurement Cost', fontsize=12)
    ax4.set_title('Cumulative Procurement Cost: Manual vs SAA vs Cap-SAA', 
                  fontsize=14, fontweight='bold')
    ax4.legend(fontsize=11)
    ax4.grid(True, alpha=0.3, linestyle='--')
    ax4.set_xticks(x_pos)
    ax4.set_xticklabels([d.strftime('%Y-%m') for d in out[COLUMN_MAP["date"]]], 
                        rotation=45, ha='right')
    plt.tight_layout()
    
    # Figure 3b: Cumulative Procurement Cost with Quantity Fraction
    # Calculate cumulative quantities and fractions
    manual_total_order = out['order_hedged_fixed'] + out['order_manual_unhedged']
    original_total_order = out['order_hedged_fixed'] + out['order_unhedged_original']
    optimized_total_order = out['order_hedged_fixed'] + out['order_unhedged_optimized']
    
    cum_qty_manual = manual_total_order.cumsum()
    cum_qty_original = original_total_order.cumsum()
    cum_qty_optimized = optimized_total_order.cumsum()
    
    # Calculate fractions (cumulative qty / total qty)
    manual_qty_frac = cum_qty_manual / cum_qty_manual.iloc[-1] if cum_qty_manual.iloc[-1] != 0 else cum_qty_manual * 0
    original_qty_frac = cum_qty_original / cum_qty_original.iloc[-1] if cum_qty_original.iloc[-1] != 0 else cum_qty_original * 0
    optimized_qty_frac = cum_qty_optimized / cum_qty_optimized.iloc[-1] if cum_qty_optimized.iloc[-1] != 0 else cum_qty_optimized * 0
    
    fig3b, ax_cost = plt.subplots(figsize=(14, 6))
    
    # Plot cumulative costs on primary axis (Manual and Cap-SAA only)
    cost_lines = []
    cost_lines.extend(
        ax_cost.plot(x_pos, cum_procurement_manual, marker='^', linewidth=2, 
                    label='Manual cumulative cost', color='green', markersize=6)
    )
    cost_lines.extend(
        ax_cost.plot(x_pos, cum_procurement_optimized, marker='s', linewidth=2, 
                    label='Cap-SAA cumulative cost', color='darkorange', markersize=6)
    )
    ax_cost.set_xlabel('Date', fontsize=12)
    ax_cost.set_ylabel('Cost', fontsize=12)
    ax_cost.set_title('Cumulative Procurement Cost & Quantity Fraction', 
                      fontsize=14, fontweight='bold')
    ax_cost.grid(True, which='both', linestyle='--', alpha=0.4)
    ax_cost.set_xticks(x_pos)
    ax_cost.set_xticklabels([d.strftime('%Y-%m') for d in out[COLUMN_MAP["date"]]], 
                           rotation=45, ha='right')
    
    # Create secondary y-axis for quantity fractions (Manual and Cap-SAA only)
    ax_frac = ax_cost.twinx()
    frac_lines = []
    frac_lines.extend(
        ax_frac.plot(x_pos, manual_qty_frac, 
                    label='Manual cumulative qty fraction', 
                    color='green', linestyle=':', marker='*', markersize=6)
    )
    frac_lines.extend(
        ax_frac.plot(x_pos, optimized_qty_frac, 
                    label='Cap-SAA cumulative qty fraction', 
                    color='darkorange', linestyle=':', marker='*', markersize=6)
    )
    ax_frac.set_ylabel('Cumulative quantity fraction', fontsize=12)
    ax_frac.set_ylim(0, 1.05)
    
    # Combine legends from both axes
    combined_lines = cost_lines + frac_lines
    labels = [line.get_label() for line in combined_lines]
    ax_cost.legend(combined_lines, labels, loc='upper left', fontsize=10)
    
    plt.tight_layout()
    
    # Figure 4: Cumulative Holding Cost
    fig4, ax5 = plt.subplots(figsize=(14, 6))
    ax5.plot(x_pos, cum_holding_manual, marker='^', linewidth=2, 
             label='Manual', color='green', markersize=6)
    ax5.plot(x_pos, cum_holding_original, marker='o', linewidth=2, 
             label='SAA', color='steelblue', markersize=6)
    ax5.plot(x_pos, cum_holding_optimized, marker='s', linewidth=2, 
             label='Cap-SAA', color='darkorange', markersize=6)
    ax5.set_xlabel('Date', fontsize=12)
    ax5.set_ylabel('Cumulative Holding Cost', fontsize=12)
    ax5.set_title('Cumulative Holding Cost: Manual vs SAA vs Cap-SAA', 
                  fontsize=14, fontweight='bold')
    ax5.legend(fontsize=11)
    ax5.grid(True, alpha=0.3, linestyle='--')
    ax5.set_xticks(x_pos)
    ax5.set_xticklabels([d.strftime('%Y-%m') for d in out[COLUMN_MAP["date"]]], 
                        rotation=45, ha='right')
    plt.tight_layout()
    
    # Figure 5: Cumulative Total Cost
    fig5, ax6 = plt.subplots(figsize=(14, 6))
    ax6.plot(x_pos, cum_total_manual, marker='^', linewidth=2, 
             label='Manual', color='green', markersize=6)
    ax6.plot(x_pos, cum_total_original, marker='o', linewidth=2, 
             label='SAA', color='steelblue', markersize=6)
    ax6.plot(x_pos, cum_total_optimized, marker='s', linewidth=2, 
             label='Cap-SAA', color='darkorange', markersize=6)
    ax6.set_xlabel('Date', fontsize=12)
    ax6.set_ylabel('Cumulative Total Cost', fontsize=12)
    ax6.set_title('Cumulative Total Cost: Manual vs SAA vs Cap-SAA', 
                  fontsize=14, fontweight='bold')
    ax6.legend(fontsize=11)
    ax6.grid(True, alpha=0.3, linestyle='--')
    ax6.set_xticks(x_pos)
    ax6.set_xticklabels([d.strftime('%Y-%m') for d in out[COLUMN_MAP["date"]]], 
                        rotation=45, ha='right')
    plt.tight_layout()

    # Figure 6: Inventory Levels in Months (Bar Plot)
    fig6, ax7 = plt.subplots(figsize=(14, 6))
    
    # Convert inventory to months (using plot-only inventory values)
    inv_manual_months = out['inventory_manual_plot'] / INV_MONTHS_DENOM
    inv_original_months = out['inventory_original_plot'] / INV_MONTHS_DENOM
    inv_optimized_months = out['inventory_optimized_plot'] / INV_MONTHS_DENOM
    
    width = 0.25  # Width for 3 bars
    
    # Create bars with proper spacing for 3 bars
    bars1 = ax7.bar(x_pos - width, inv_manual_months, 
                   width, label='Manual', color='green', alpha=0.7)
    bars2 = ax7.bar(x_pos, inv_original_months, 
                   width, label='SAA', color='steelblue', alpha=0.7)
    bars3 = ax7.bar(x_pos + width, inv_optimized_months, 
                   width, label='Cap-SAA', color='darkorange', alpha=0.7)
    
    ax7.set_xlabel('Date', fontsize=12)
    ax7.set_ylabel('Inventory (Months)', fontsize=12)
    ax7.set_title('Inventory Levels: Manual vs SAA vs Cap-SAA', 
                  fontsize=14, fontweight='bold')
    ax7.legend(fontsize=11)
    ax7.grid(True, alpha=0.3, linestyle='--', axis='y')
    ax7.set_xticks(x_pos)
    ax7.set_xticklabels([d.strftime('%Y-%m') for d in out[COLUMN_MAP["date"]]], 
                        rotation=45, ha='right')
    plt.tight_layout()

    # Print summary statistics
    print("\n=== Summary Statistics ===")
    print(f"Total Original Unhedged: {out['order_unhedged_original'].sum():,.2f}")
    print(f"Total Optimized Unhedged: {out['order_unhedged_optimized'].sum():,.2f}")
    print(f"Difference: {out['order_unhedged_optimized'].sum() - out['order_unhedged_original'].sum():,.2f}")
    print(f"\nMax Original Unhedged: {out['order_unhedged_original'].max():,.2f}")
    print(f"Max Optimized Unhedged: {out['order_unhedged_optimized'].max():,.2f}")
    print(f"\nMin Original Unhedged: {out['order_unhedged_original'].min():,.2f}")
    print(f"Min Optimized Unhedged: {out['order_unhedged_optimized'].min():,.2f}")
    
    # Print percentage differences for cumulative costs
    print("\n=== Cost Comparison: % Difference (Original vs Capacity Constrained) ===")
    print("Formula: (Original - Cap Const) / Original * 100%")
    
    total_procurement_orig = cum_procurement_original.iloc[-1]
    total_procurement_opt = cum_procurement_optimized.iloc[-1]
    pct_diff_procurement = (total_procurement_orig - total_procurement_opt) / total_procurement_orig * 100
    print(f"\nCumulative Procurement Cost:")
    print(f"  Original: {total_procurement_orig:,.2f}")
    print(f"  Capacity Constrained: {total_procurement_opt:,.2f}")
    print(f"  % Difference: {pct_diff_procurement:.2f}%")
    
    total_storage_manual = cum_storage_manual.iloc[-1]
    total_storage_orig = cum_storage_original.iloc[-1]
    total_storage_opt = cum_storage_optimized.iloc[-1]
    pct_diff_storage = (total_storage_orig - total_storage_opt) / total_storage_orig * 100 if total_storage_orig != 0 else 0
    print(f"\nCumulative Storage Cost:")
    print(f"  Manual: {total_storage_manual:,.2f}")
    print(f"  Original: {total_storage_orig:,.2f}")
    print(f"  Capacity Constrained: {total_storage_opt:,.2f}")
    print(f"  % Difference (Orig vs Cap): {pct_diff_storage:.2f}%")
    
    total_holding_manual = cum_holding_manual.iloc[-1]
    total_holding_orig = cum_holding_original.iloc[-1]
    total_holding_opt = cum_holding_optimized.iloc[-1]
    pct_diff_holding = (total_holding_orig - total_holding_opt) / total_holding_orig * 100
    print(f"\nCumulative Holding Cost:")
    print(f"  Manual: {total_holding_manual:,.2f}")
    print(f"  Original: {total_holding_orig:,.2f}")
    print(f"  Capacity Constrained: {total_holding_opt:,.2f}")
    print(f"  % Difference (Orig vs Cap): {pct_diff_holding:.2f}%")
    
    total_total_manual = cum_total_manual.iloc[-1]
    total_total_orig = cum_total_original.iloc[-1]
    total_total_opt = cum_total_optimized.iloc[-1]
    pct_diff_total = (total_total_orig - total_total_opt) / total_total_orig * 100
    print(f"\nCumulative Total Cost:")
    print(f"  Manual: {total_total_manual:,.2f}")
    print(f"  Original: {total_total_orig:,.2f}")
    print(f"  Capacity Constrained: {total_total_opt:,.2f}")
    print(f"  % Difference (Orig vs Cap): {pct_diff_total:.2f}%")
    
    # Show all plots
    plt.show()


def main() -> None:
    df = load_eval_data(EXCEL_PATH, SHEET_NAME, COLUMN_MAP)

    q_hedged = df[COLUMN_MAP["q_hedged"]].to_numpy(float)
    q_unhedged_base = df[COLUMN_MAP["q_unhedged"]].to_numpy(float)
    q_manual_unhedged = df[COLUMN_MAP["q_manual_unhedged"]].to_numpy(float)
    demand = df[COLUMN_MAP["demand"]].to_numpy(float)
    price_hedged = df[COLUMN_MAP["price_hedged"]].to_numpy(float)
    price_unhedged = df[COLUMN_MAP["price_unhedged"]].to_numpy(float)

    if CAPACITY_UNHEDGED is None:
        capacity = None
    else:
        capacity = np.full(len(demand), float(CAPACITY_UNHEDGED))

    solver = choose_solver()

    if USE_HARD_INVENTORY_BAND:
        s_min = S_MIN
        s_max = S_MAX
    else:
        s_min = None
        s_max = None

    sol = reoptimize_unhedged_with_inventory_band(
        q_hedged=q_hedged,
        q_unhedged_base=q_unhedged_base,
        demand=demand,
        price_hedged=price_hedged,
        price_unhedged=price_unhedged,
        s_min=s_min,
        s_max=s_max,
        I0=I0,
        holding_cost=HOLDING_COST,
        k_lock=K_LOCK,
        keep_total=KEEP_TOTAL,
        capacity_unhedged=capacity,
        relax_min_inventory=RELAX_MIN_INV,
        min_inventory_penalty=MIN_INV_PENALTY,
        inventory_months_min=INV_MONTHS_MIN,
        inventory_months_max=INV_MONTHS_MAX,
        inventory_months_denom=INV_MONTHS_DENOM,
        inventory_months_penalty=INV_MONTHS_PENALTY,
        solver=solver,
        verbose=False,
    )

    out = df[[COLUMN_MAP["date"]]].copy()
    out["demand"] = demand
    out["price_hedged"] = price_hedged
    out["price_unhedged"] = price_unhedged
    out["order_hedged_fixed"] = q_hedged
    out["order_manual_unhedged"] = q_manual_unhedged
    out["order_unhedged_original"] = q_unhedged_base
    out["order_unhedged_optimized"] = sol["Q_unhedged_opt"]
    out["order_total_optimized"] = out["order_hedged_fixed"] + out["order_unhedged_optimized"]
    inventory_original = compute_inventory_series(q_hedged, q_unhedged_base, demand, I0)
    out["inventory_original"] = inventory_original
    out["inventory_optimized"] = sol["Inventory"]
    out["min_inventory_slack"] = sol["MinInvSlack"]
    if INV_MONTHS_MIN is not None or INV_MONTHS_MAX is not None:
        out["inventory_months"] = sol["InventoryMonths"]
        out["inventory_months_below_slack"] = sol["InvMonthsBelow"]
        out["inventory_months_above_slack"] = sol["InvMonthsAbove"]

    # Load extracted demand for inventory plot (poc-02 style)
    demand_series = load_material_metric_series(
        path=Path("data/8.0 FY2025 Material Control.csv"),
        metric_name="Consumption",
    )
    demand_series = demand_series.abs()
    
    # Map month strings to datetime
    month_mapping = {
        "Apr-25": pd.Timestamp("2025-04-01"),
        "May-25": pd.Timestamp("2025-05-01"),
        "Jun-25": pd.Timestamp("2025-06-01"),
        "Jul-25": pd.Timestamp("2025-07-01"),
        "Aug-25": pd.Timestamp("2025-08-01"),
        "Sep-25": pd.Timestamp("2025-09-01"),
        "Oct-25": pd.Timestamp("2025-10-01"),
        "Nov-25": pd.Timestamp("2025-11-01"),
        "Dec-25": pd.Timestamp("2025-12-01"),
        "Jan-26": pd.Timestamp("2026-01-01"),
        "Feb-26": pd.Timestamp("2026-02-01"),
        "Mar-26": pd.Timestamp("2026-03-01"),
    }
    demand_series.index = demand_series.index.map(month_mapping)
    demand_plot = out[COLUMN_MAP["date"]].map(demand_series)

    # Simple per-period inventory for plotting only (poc-02 style)
    out["inventory_manual_plot"] = (q_hedged + q_manual_unhedged) - demand_plot
    out["inventory_original_plot"] = (q_hedged + q_unhedged_base) - demand_plot + 4000
    out["inventory_optimized_plot"] = (q_hedged + sol["Q_unhedged_opt"]) - demand_plot + 4000

    out["cost_hedged"] = price_hedged * q_hedged
    out["cost_unhedged_original"] = price_unhedged * q_unhedged_base
    out["cost_unhedged_optimized"] = price_unhedged * sol["Q_unhedged_opt"]
    out["cost_unhedged_manual"] = price_unhedged * q_manual_unhedged
    out["procurement_cost_original"] = out["cost_hedged"] + out["cost_unhedged_original"]
    out["procurement_cost_optimized"] = out["cost_hedged"] + out["cost_unhedged_optimized"]
    out["procurement_cost_manual"] = out["cost_hedged"] + out["cost_unhedged_manual"]
    
    inventory_manual = compute_inventory_series(q_hedged, q_manual_unhedged, demand, I0)
    out["inventory_manual"] = inventory_manual
    
    out["storage_cost_original"] = compute_storage_cost(
        inventory_original,
        STORAGE_H,
        STORAGE_B,
        STORAGE_SCALE,
    )
    out["storage_cost_optimized"] = compute_storage_cost(
        sol["Inventory"],
        STORAGE_H,
        STORAGE_B,
        STORAGE_SCALE,
    )
    out["storage_cost_manual"] = compute_storage_cost(
        inventory_manual,
        STORAGE_H,
        STORAGE_B,
        STORAGE_SCALE,
    )
    out["holding_cost_optimized"] = HOLDING_COST * sol["Inventory"]
    out["holding_cost_original"] = HOLDING_COST * inventory_original
    out["holding_cost_manual"] = HOLDING_COST * inventory_manual
    out["total_cost_optimized"] = (
        out["cost_hedged"] + out["cost_unhedged_optimized"] + out["holding_cost_optimized"]
    )
    out["total_cost_original"] = (
        out["cost_hedged"] + out["cost_unhedged_original"] + out["holding_cost_original"]
    )
    out["total_cost_manual"] = (
        out["cost_hedged"] + out["cost_unhedged_manual"] + out["holding_cost_manual"]
    )

    print("Optimization complete")
    print(f"Objective: {sol['Objective']:.2f}")
    if USE_HARD_INVENTORY_BAND:
        print(f"Inventory band (units): [{S_MIN}, {S_MAX}]")
    if INV_MONTHS_MIN is not None or INV_MONTHS_MAX is not None:
        print(f"Inventory months band (soft): [{INV_MONTHS_MIN}, {INV_MONTHS_MAX}]")
    if sol["UsedRelaxation"]:
        slack_total = float(np.sum(sol["MinInvSlack"]))
        slack_max = float(np.max(sol["MinInvSlack"]))
        print(f"Min inventory relaxed: total shortfall={slack_total:.2f}, max shortfall={slack_max:.2f}")

    # Save output to CSV for use in other scripts
    timestamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    output_filename = f"reoptimize_output_{timestamp}.csv"
    out.to_csv(output_filename, index=False)
    print(f"\nOutput saved to: {output_filename}")

    # Generate plots
    print("\nGenerating visualizations...")
    plot_unhedged_orders(out)


if __name__ == "__main__":
    main()
