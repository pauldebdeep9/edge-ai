from pathlib import Path

import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# Conversion factor from grams to troy ounce
GM_TO_TOZ = 31.104


def load_historical_data(path: Path, sheet_name: str = "p1normal") -> pd.DataFrame:
    """Load historical price data from Excel file."""
    return pd.read_excel(path, sheet_name=sheet_name, engine="openpyxl")


def convert_gm_to_toz(df: pd.DataFrame) -> pd.DataFrame:
    """Convert all price columns from /gm to /toz by multiplying by 31.104."""
    df_converted = df.copy()
    # Convert all columns except 'time'
    numeric_cols = df.columns[df.columns != 'time']
    df_converted[numeric_cols] = df[numeric_cols] * GM_TO_TOZ
    return df_converted


def plot_price_band(df: pd.DataFrame, start_month: int = 4, actual_prices: pd.Series = None, actual_prices_jan26: pd.Series = None) -> None:
    """
    Plot a band showing price statistics from a given month onwards.
    
    Args:
        df: DataFrame with 'time' column (fiscal months 1-12) and price scenarios as columns
        start_month: Starting fiscal month for the plot (default: 4 for Aug-25)
        actual_prices: Optional Series with actual prices (already converted to /toz) to overlay
        actual_prices_jan26: Optional Series with Jan-26 prices (already converted to /toz) to overlay
    """
    # Filter data from start_month onwards (FY months 4-11: Aug-25 to Mar-26)
    df_filtered = df[(df['time'] >= start_month) & (df['time'] <= 11)].copy()
    
    if df_filtered.empty:
        raise ValueError(f"No data found for fiscal months {start_month} to 11")
    
    # Get all numeric columns (excluding 'time')
    price_cols = [col for col in df.columns if col != 'time']
    
    # Calculate statistics across scenarios for each time period
    prices = df_filtered[price_cols].values
    mean_prices = np.mean(prices, axis=1)
    min_prices = np.min(prices, axis=1)
    max_prices = np.max(prices, axis=1)
    percentile_25 = np.percentile(prices, 25, axis=1)
    percentile_75 = np.percentile(prices, 75, axis=1)
    
    # Create month labels - FY starts in May, so month 1=May-25, 4=Aug-25, 11=Mar-26
    months = df_filtered['time'].values
    # Fiscal year mapping: 1=May, 2=Jun, 3=Jul, 4=Aug, 5=Sep, 6=Oct, 7=Nov, 8=Dec, 9=Jan, 10=Feb, 11=Mar, 12=Apr
    fy_month_labels = {
        1: 'May-25', 2: 'Jun-25', 3: 'Jul-25', 4: 'Aug-25', 
        5: 'Sep-25', 6: 'Oct-25', 7: 'Nov-25', 8: 'Dec-25',
        9: 'Jan-26', 10: 'Feb-26', 11: 'Mar-26', 12: 'Apr-26'
    }
    month_labels = [fy_month_labels[m] for m in months]
    
    # Create the plot
    fig, ax = plt.subplots(figsize=(12, 6))
    
    # Plot the band (min to max)
    ax.fill_between(range(len(months)), min_prices, max_prices, 
                     alpha=0.2, label='Min-Max Range', color='lightblue')
    
    # Plot the interquartile range (25th to 75th percentile)
    ax.fill_between(range(len(months)), percentile_25, percentile_75, 
                     alpha=0.4, label='25th-75th Percentile', color='skyblue')
    
    # Plot the mean
    ax.plot(range(len(months)), mean_prices, 'b-', linewidth=2, 
            marker='o', label='price-25-08', markersize=6)
    
    # Plot actual prices if provided
    if actual_prices is not None:
        # Filter actual prices to match the month range (Aug-25 to Mar-26)
        # Assuming actual_prices index aligns with fiscal months (starting from month 4)
        actual_filtered = actual_prices[actual_prices.index >= start_month]
        # Limit to Mar-26 (8 months from Aug)
        actual_filtered = actual_filtered[:len(months)]
        if len(actual_filtered) > 0:
            ax.plot(range(len(actual_filtered)), actual_filtered.values, 'r-', linewidth=2.5, 
                    marker='s', label='price-25-12', markersize=7, zorder=10)
    
    # Plot Jan-26 prices if provided
    if actual_prices_jan26 is not None:
        # Filter Jan-26 prices to match the month range (Aug-25 to Mar-26)
        actual_jan26_filtered = actual_prices_jan26[actual_prices_jan26.index >= start_month]
        # Limit to Mar-26 (8 months from Aug)
        actual_jan26_filtered = actual_jan26_filtered[:len(months)]
        if len(actual_jan26_filtered) > 0:
            ax.plot(range(len(actual_jan26_filtered)), actual_jan26_filtered.values, 'g-', linewidth=2.5, 
                    marker='D', label='Price-26-01', markersize=7, zorder=10)
    
    # Customize the plot
    ax.set_xlabel('Month', fontsize=12)
    ax.set_ylabel('Price ($/toz)', fontsize=12)
    ax.set_title(f'Price Band Analysis ({fy_month_labels[start_month]} to Mar-26)', 
                 fontsize=14, fontweight='bold')
    ax.set_xticks(range(len(months)))
    ax.set_xticklabels(month_labels, rotation=45, ha='right')
    ax.legend(loc='best')
    ax.grid(True, alpha=0.3, linestyle='--')
    
    plt.tight_layout()
    plt.show()


def load_sheet_12(path: Path) -> pd.DataFrame:
    """Load sheet 12 from evaluation file."""
    return pd.read_excel(path, sheet_name="12", engine="openpyxl")


def plot_unhedged_prices(df: pd.DataFrame) -> None:
    """Plot unhedged price comparison between train and actual."""
    train_col = "price-unhedged-train"
    actual_col = "price-unhedged"

    if train_col not in df.columns or actual_col not in df.columns:
        missing = [col for col in (train_col, actual_col) if col not in df.columns]
        raise KeyError(f"Missing columns: {missing}")

    x = df["date"] if "date" in df.columns else df.index
    x_values = pd.Series(x)
    fig_size = (10, 5)
    line_style = {"linestyle": "-", "marker": "o"}

    plt.figure(figsize=fig_size)
    plt.plot(x, df[train_col], label="Unhedged price (train)", **line_style)
    plt.plot(x, df[actual_col], label="Unhedged price (actual)", **line_style)
    plt.title("Unhedged Price: Train vs Actual")
    plt.xlabel("Date" if "date" in df.columns else "Index")
    plt.ylabel("Price")
    plt.legend()
    ax = plt.gca()
    if pd.api.types.is_datetime64_any_dtype(x_values):
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%b-%y"))
    plt.tight_layout()
    plt.show()


def main() -> None:
    # Plot 1: Unhedged prices from evaluation file
    eval_path = Path("data/pidsg26Evaluation12.xlsx")
    df_eval = load_sheet_12(eval_path)
    plot_unhedged_prices(df_eval)
    
    # Plot 2: Band plot from historical data
    hist_path = Path("data/pidsg25-05_historical.xlsx")
    # Historical data from p1normal is already in /toz
    df_hist = load_historical_data(hist_path, sheet_name="p1normal")
    
    # Get actual prices from evaluation file (in /gm) and convert to /toz
    actual_prices_gm = df_eval['price-unhedged']
    actual_prices_toz = actual_prices_gm * GM_TO_TOZ
    
    # Get Jan-26 prices from evaluation file (in /gm) and convert to /toz
    actual_prices_jan26_gm = df_eval['price as of 25/01']
    actual_prices_jan26_toz = actual_prices_jan26_gm * GM_TO_TOZ
    
    # Plot the band starting from fiscal month 4 (Aug-25) with actual prices
    plot_price_band(df_hist, start_month=4, actual_prices=actual_prices_toz, actual_prices_jan26=actual_prices_jan26_toz)


if __name__ == "__main__":
    main()
