#!/usr/bin/env python3
"""Explain why Cap-SAA procurement cost doesn't change with -10% in Dec-Mar."""

import numpy as np
import pandas as pd
from reoptimize2601 import (
    load_eval_data, 
    COLUMN_MAP, EXCEL_PATH, SHEET_NAME
)

# Load base data
df = load_eval_data(EXCEL_PATH, SHEET_NAME, COLUMN_MAP)

q_hedged = df[COLUMN_MAP['q_hedged']].to_numpy(float)
q_unhedged_saa = df[COLUMN_MAP['q_unhedged']].to_numpy(float)
q_manual_unhedged = df[COLUMN_MAP['q_manual_unhedged']].to_numpy(float)
price_hedged = df[COLUMN_MAP['price_hedged']].to_numpy(float)
price_unhedged_base = df[COLUMN_MAP['price_unhedged']].to_numpy(float)

affected_months = [8, 9, 10, 11]  # Dec-Mar

print("="*100)
print("WHY DOESN'T CAP-SAA PROCUREMENT COST CHANGE WITH -10% IN DEC-MAR?")
print("="*100)

print("\nQuantities purchased in Dec-25 to Mar-26:")
print(f"{'Month':<12} {'Manual Qty':<15} {'Cap-SAA Qty':<15} {'Base Price':<15}")
print("-"*100)
for i in affected_months:
    month = df[COLUMN_MAP['date']].iloc[i].strftime('%b-%y')
    print(f"{month:<12} {q_manual_unhedged[i]:<15,.0f} {q_unhedged_saa[i]:<15,.0f} ${price_unhedged_base[i]:<14.4f}")

print("\n" + "="*100)
print("KEY INSIGHT: Cap-SAA buys ZERO in Dec-Mar!")
print("="*100)
print("\nCap-SAA's strategy:")
print("  - Buys heavily in Aug-Oct (early/cheaper months)")
print("  - Buys NOTHING in Dec-Mar (expensive months)")
print("  - Relies on inventory carried from earlier months")

print("\nManual's strategy:")
print("  - Buys some in Dec-Mar to meet demand")
print("  - Total purchased in Dec-Mar: ", sum(q_manual_unhedged[i] for i in affected_months))

print("\n" + "="*100)
print("IMPACT OF -10% PRICE DROP IN DEC-MAR")
print("="*100)

# Calculate procurement costs
proc_manual_base = np.sum(price_hedged * q_hedged) + np.sum(price_unhedged_base * q_manual_unhedged)
proc_capsaa_base = np.sum(price_hedged * q_hedged) + np.sum(price_unhedged_base * q_unhedged_saa)

# With -10% in Dec-Mar
price_unhedged_drop = price_unhedged_base.copy()
for i in affected_months:
    price_unhedged_drop[i] *= 0.9

proc_manual_drop = np.sum(price_hedged * q_hedged) + np.sum(price_unhedged_drop * q_manual_unhedged)
proc_capsaa_drop = np.sum(price_hedged * q_hedged) + np.sum(price_unhedged_drop * q_unhedged_saa)

print(f"\nBaseline (original prices):")
print(f"  Manual procurement:  ${proc_manual_base:,.2f}")
print(f"  Cap-SAA procurement: ${proc_capsaa_base:,.2f}")
print(f"  Difference:          ${proc_manual_base - proc_capsaa_base:,.2f}")

print(f"\nWith -10% in Dec-Mar:")
print(f"  Manual procurement:  ${proc_manual_drop:,.2f}  (DECREASED by ${proc_manual_base - proc_manual_drop:,.2f})")
print(f"  Cap-SAA procurement: ${proc_capsaa_drop:,.2f}  (NO CHANGE!)")
print(f"  Difference:          ${proc_manual_drop - proc_capsaa_drop:,.2f}")

print("\n" + "="*100)
print("EXPLANATION")
print("="*100)
print("\n✓ Cap-SAA procurement cost doesn't change because:")
print("    - Cap-SAA buys 0 units in Dec-Mar")
print("    - Price drops in those months have NO impact on Cap-SAA")
print("    - Cost = sum(price × quantity) = sum(dropped_price × 0) = 0")

print("\n✓ Manual procurement cost DECREASES because:")
print("    - Manual buys 19,758 units total in Dec-Mar")
print("    - 10% price drop saves Manual money")
print(f"    - Savings = ${proc_manual_base - proc_manual_drop:,.2f}")

print("\n✓ Result:")
print("    - The procurement saving GAP between Manual and Cap-SAA SHRINKS")
print(f"    - From ${proc_manual_base - proc_capsaa_base:,.2f} to ${proc_manual_drop - proc_capsaa_drop:,.2f}")
print("    - Manual gets to take advantage of the price drop in months it purchases")
print("    - Cap-SAA doesn't benefit because it already avoided those expensive months!")

print("\n" + "="*100)
print("STRATEGIC IMPLICATION")
print("="*100)
print("\nCap-SAA's advantage is:")
print("  1. Buying early when prices are LOW (Aug-Oct)")
print("  2. Avoiding expensive months (Dec-Mar) by using inventory")
print("\nWhen Dec-Mar prices DROP:")
print("  - Cap-SAA's advance-buying strategy becomes RELATIVELY less valuable")
print("  - Manual's 'buy-as-needed' gets CHEAPER in those months")
print("  - BUT Cap-SAA is STILL better overall (just by a smaller margin)")
