from pathlib import Path

import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import pandas as pd

from extraction01 import load_material_metric_series

user_inputs = {"h": 5, "b": 50}


def load_sheet_12(path: str) -> pd.DataFrame:
    return pd.read_excel(path, sheet_name="12", engine="openpyxl")


def drop_nan_columns(df: pd.DataFrame) -> pd.DataFrame:
    return df.dropna(axis=1, how="all")


def compute_strategy_costs(
    df: pd.DataFrame,
    *,
    demand_col: str,
    price_hedged_col: str,
    price_unhedged_col: str,
    ai_hedged_col: str,
    ai_unhedged_col: str,
    manual_hedged_col: str,
    manual_unhedged_col: str,
    h: float,
    b: float,
    demand_series: pd.Series | None = None,
) -> pd.DataFrame:
    df = drop_nan_columns(df).copy()

    numeric_cols = [
        price_hedged_col,
        price_unhedged_col,
        ai_hedged_col,
        ai_unhedged_col,
        manual_hedged_col,
        manual_unhedged_col,
    ]
    if demand_series is None:
        numeric_cols.insert(0, demand_col)
    for col in numeric_cols:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    if demand_series is None:
        demand_values = df[demand_col]
    else:
        demand_values = pd.to_numeric(demand_series, errors="coerce").reindex(df.index)

    ai_total = df[ai_hedged_col] + df[ai_unhedged_col]
    manual_total = df[manual_hedged_col] + df[manual_unhedged_col]

    ai_procure = (
        df[ai_hedged_col] * df[price_hedged_col]
        + df[ai_unhedged_col] * df[price_unhedged_col]
    )
    manual_procure = (
        df[manual_hedged_col] * df[price_hedged_col]
        + df[manual_unhedged_col] * df[price_unhedged_col]
    )

    ai_inventory = ai_total - demand_values + 4000
    manual_inventory = manual_total - demand_values

    storage_scale = 50
    ai_storage_cost = (
        ai_inventory.clip(lower=0) * h + (-ai_inventory).clip(lower=0) * b
    ) / storage_scale
    manual_storage_cost = (
        manual_inventory.clip(lower=0) * h + (-manual_inventory).clip(lower=0) * b
    ) / storage_scale

    df["ai_total_order"] = ai_total
    df["manual_total_order"] = manual_total
    df["ai_procure_cost"] = ai_procure
    df["manual_procure_cost"] = manual_procure
    df["ai_storage_cost"] = ai_storage_cost
    df["manual_storage_cost"] = manual_storage_cost
    df["ai_inventory"] = ai_inventory
    df["manual_inventory"] = manual_inventory
    df["ai_total_cost"] = ai_procure + ai_storage_cost
    df["manual_total_cost"] = manual_procure + manual_storage_cost

    return df


def plot_strategy_costs(df: pd.DataFrame, *, x_col: str | None = None) -> None:
    x = df[x_col] if x_col else df.index
    x_values = pd.Series(x)
    fig_size = (10, 5)
    line_style = {"linestyle": ":", "marker": "*"}

    def format_date_axis(ax: plt.Axes) -> None:
        if pd.api.types.is_datetime64_any_dtype(x_values):
            ax.xaxis.set_major_formatter(mdates.DateFormatter("%b-%y"))

    ai_procure_cum = df["ai_procure_cost"].cumsum()
    manual_procure_cum = df["manual_procure_cost"].cumsum()
    ai_storage_cum = df["ai_storage_cost"].cumsum()
    manual_storage_cum = df["manual_storage_cost"].cumsum()
    ai_total_cum = df["ai_total_cost"].cumsum()
    manual_total_cum = df["manual_total_cost"].cumsum()

    def add_end_of_year_diff(ax: plt.Axes, ai_series: pd.Series, manual_series: pd.Series) -> None:
        ai_final = ai_series.iloc[-1]
        manual_final = manual_series.iloc[-1]
        if pd.notna(ai_final) and pd.notna(manual_final) and manual_final != 0:
            pct_diff = (ai_final - manual_final) / manual_final * 100
            direction = "increase" if pct_diff >= 0 else "decrease"
            diff_label = (
                f"End-of-year {direction} of AI wrt Manual: {pct_diff:+.1f}%"
            )
        else:
            diff_label = "End-of-year increase/decrease of AI wrt Manual: n/a"
        ax.text(
            0.5,
            0.98,
            diff_label,
            transform=ax.transAxes,
            ha="center",
            va="top",
        )

    plt.figure(figsize=fig_size)
    plt.plot(x, ai_procure_cum, label="AI procurement", **line_style)
    plt.plot(x, manual_procure_cum, label="Manual procurement", **line_style)
    plt.title("Cumulative Procurement Cost")
    plt.legend()
    plt.xlabel(x_col if x_col else "Index")
    plt.ylabel("Cost")
    procurement_ax = plt.gca()
    format_date_axis(procurement_ax)
    add_end_of_year_diff(procurement_ax, ai_procure_cum, manual_procure_cum)

    plt.figure(figsize=fig_size)
    plt.plot(x, ai_storage_cum, label="AI storage/backlog", **line_style)
    plt.plot(x, manual_storage_cum, label="Manual storage/backlog", **line_style)
    plt.title("Cumulative Storage/Backlog Cost")
    plt.legend()
    plt.xlabel(x_col if x_col else "Index")
    plt.ylabel("Cost")
    storage_ax = plt.gca()
    format_date_axis(storage_ax)
    add_end_of_year_diff(storage_ax, ai_storage_cum, manual_storage_cum)

    plt.figure(figsize=fig_size)
    plt.plot(x, ai_total_cum, label="AI total", **line_style)
    plt.plot(x, manual_total_cum, label="Manual total", **line_style)
    plt.title("Cumulative Total Cost")
    plt.legend()
    plt.xlabel(x_col if x_col else "Index")
    plt.ylabel("Cost")
    total_ax = plt.gca()
    format_date_axis(total_ax)
    add_end_of_year_diff(total_ax, ai_total_cum, manual_total_cum)

    fig, ax = plt.subplots(figsize=fig_size)
    ai_inventory_months = df["ai_inventory"] / 12000
    manual_inventory_months = df["manual_inventory"] / 12000
    if pd.api.types.is_datetime64_any_dtype(x_values):
        bar_width = pd.Timedelta(days=12)
    else:
        bar_width = 0.35
    ax.bar(x_values - bar_width / 2, ai_inventory_months, width=bar_width, label="AI inventory")
    ax.bar(x_values + bar_width / 2, manual_inventory_months, width=bar_width, label="Manual inventory")
    ax.set_title("Inventory")
    ax.legend()
    ax.set_xlabel(x_col if x_col else "Index")
    ax.set_ylabel("Months")
    format_date_axis(ax)

    plt.show()


if __name__ == "__main__":
    df = load_sheet_12("data/pidsg26Evaluation12.xlsx")

    demand_col = "demand-12"  # Fallback column if extracted series not available
    price_hedged_col = "price-hedged"
    price_unhedged_col = "price-unhedged"
    ai_hedged_col = "AI-04-hedged"
    ai_unhedged_col = "AI-04-unhedged"
    manual_hedged_col = "manual-04-hedged"
    manual_unhedged_col = "manual-04-unhedged"

    # Extract consumption time series from CSV (default behavior)
    # Set use_extracted_demand=False to use demand_col from Excel instead
    use_extracted_demand = True
    
    if use_extracted_demand:
        demand_series = load_material_metric_series(
            path=Path("data/8.0 FY2025 Material Control.csv"),
            metric_name="Consumption",
        )
        # Consumption values are negative, convert to positive demand
        demand_series = demand_series.abs()
        
        # Create mapping from month strings to datetime
        # Apr-25 -> 2025-04-01, May-25 -> 2025-05-01, etc.
        month_mapping = {
            "Apr-25": pd.Timestamp("2025-04-01"),
            "May-25": pd.Timestamp("2025-05-01"),
            "Jun-25": pd.Timestamp("2025-06-01"),
            "Jul-25": pd.Timestamp("2025-07-01"),
            "Aug-25": pd.Timestamp("2025-08-01"),
            "Sep-25": pd.Timestamp("2025-09-01"),
            "Oct-25": pd.Timestamp("2025-10-01"),
            "Nov-25": pd.Timestamp("2025-11-01"),
            "Dec-25": pd.Timestamp("2025-12-01"),
            "Jan-26": pd.Timestamp("2026-01-01"),
            "Feb-26": pd.Timestamp("2026-02-01"),
            "Mar-26": pd.Timestamp("2026-03-01"),
        }
        
        # Reindex demand series with datetime index
        demand_series.index = demand_series.index.map(month_mapping)
        
        # Align with dataframe index
        if "date" in df.columns:
            demand_series = df["date"].map(demand_series)
        elif len(demand_series) == len(df):
            demand_series = demand_series.reset_index(drop=True)
            demand_series.index = df.index
        else:
            print("Warning: Could not align demand series, falling back to demand_col")
            demand_series = None
    else:
        demand_series = None

    df = compute_strategy_costs(
        df,
        demand_col=demand_col,
        price_hedged_col=price_hedged_col,
        price_unhedged_col=price_unhedged_col,
        ai_hedged_col=ai_hedged_col,
        ai_unhedged_col=ai_unhedged_col,
        manual_hedged_col=manual_hedged_col,
        manual_unhedged_col=manual_unhedged_col,
        h=user_inputs["h"],
        b=user_inputs["b"],
        demand_series=demand_series,
    )

    print(df.head())
    plot_strategy_costs(df, x_col="date")
