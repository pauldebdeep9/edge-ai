from pathlib import Path

import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import pandas as pd

TOZ_TO_KG = 31.104 / 1000  # 1 troy ounce = 31.104 grams


def load_sheet_12(path: str | Path) -> pd.DataFrame:
    return pd.read_excel(path, sheet_name="12", engine="openpyxl")


def plot_unhedged_bars(
    df: pd.DataFrame,
    *,
    x_col: str = "date",
    manual_col: str = "manual-04-unhedged",
    ai_col: str = "AI-04-unhedged",
) -> None:
    df = df.copy()
    df[manual_col] = pd.to_numeric(df[manual_col], errors="coerce") * TOZ_TO_KG
    df[ai_col] = pd.to_numeric(df[ai_col], errors="coerce") * TOZ_TO_KG

    if x_col in df.columns:
        x_values = pd.to_datetime(df[x_col], errors="coerce")
    else:
        x_values = pd.Series(df.index)

    fig, ax = plt.subplots(figsize=(10, 5))
    if pd.api.types.is_datetime64_any_dtype(x_values):
        bar_width = pd.Timedelta(days=12)
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%b-%y"))
    else:
        bar_width = 0.35

    ax.bar(x_values - bar_width / 2, df[manual_col], width=bar_width, label="Manual Aug unhedged")
    ax.bar(x_values + bar_width / 2, df[ai_col], width=bar_width, label="AI Aug unhedged")
    ax.set_title("Unhedged Orders (Manual vs AI)")
    ax.set_xlabel(x_col if x_col in df.columns else "Index")
    ax.set_ylabel("Quantity (KUSD)")
    ax.legend()
    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    df = load_sheet_12("data/pidsg26Evaluation12.xlsx")
    plot_unhedged_bars(df)
