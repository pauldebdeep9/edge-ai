#!/usr/bin/env python3
"""Debug the price sensitivity analysis to find the inconsistency."""

import numpy as np
import pandas as pd
from reoptimize2601 import (
    load_eval_data, compute_inventory_series, 
    COLUMN_MAP, EXCEL_PATH, SHEET_NAME, I0, HOLDING_COST
)

# Load base data
df = load_eval_data(EXCEL_PATH, SHEET_NAME, COLUMN_MAP)

q_hedged = df[COLUMN_MAP['q_hedged']].to_numpy(float)
q_unhedged_saa = df[COLUMN_MAP['q_unhedged']].to_numpy(float)
q_manual_unhedged = df[COLUMN_MAP['q_manual_unhedged']].to_numpy(float)
demand = df[COLUMN_MAP['demand']].to_numpy(float)
price_hedged = df[COLUMN_MAP['price_hedged']].to_numpy(float)
price_unhedged_base = df[COLUMN_MAP['price_unhedged']].to_numpy(float)

print("="*100)
print("BASELINE ANALYSIS (Original Prices)")
print("="*100)

# Compute baseline costs
proc_manual_base = np.sum(price_hedged * q_hedged) + np.sum(price_unhedged_base * q_manual_unhedged)
proc_capsaa_base = np.sum(price_hedged * q_hedged) + np.sum(price_unhedged_base * q_unhedged_saa)

inv_manual = compute_inventory_series(q_hedged, q_manual_unhedged, demand, 0.0)
holding_manual = HOLDING_COST * np.sum(inv_manual)

inv_capsaa = compute_inventory_series(q_hedged, q_unhedged_saa, demand, I0)
holding_capsaa = HOLDING_COST * np.sum(inv_capsaa)

total_manual_base = proc_manual_base + holding_manual
total_capsaa_base = proc_capsaa_base + holding_capsaa

print(f"\nManual:")
print(f"  Procurement: ${proc_manual_base:,.2f}")
print(f"  Holding:     ${holding_manual:,.2f}")
print(f"  Total:       ${total_manual_base:,.2f}")

print(f"\nCap-SAA:")
print(f"  Procurement: ${proc_capsaa_base:,.2f}")
print(f"  Holding:     ${holding_capsaa:,.2f}")
print(f"  Total:       ${total_capsaa_base:,.2f}")

print(f"\nSavings (Manual - CapSAA):")
print(f"  Procurement: ${proc_manual_base - proc_capsaa_base:,.2f}")
print(f"  Holding:     ${holding_manual - holding_capsaa:,.2f}")
print(f"  Total:       ${total_manual_base - total_capsaa_base:,.2f}")

print("\n" + "="*100)
print("QUANTITY DIFFERENCES BY MONTH")
print("="*100)
print(f"\n{'Month':<12} {'Manual':<12} {'Cap-SAA':<12} {'Diff (M-C)':<15} {'Price':<12} {'$ Impact':<15}")
print("-"*100)

for i in range(len(demand)):
    month = df[COLUMN_MAP['date']].iloc[i].strftime('%b-%y')
    diff = q_manual_unhedged[i] - q_unhedged_saa[i]
    impact = diff * price_unhedged_base[i]
    print(f"{month:<12} {q_manual_unhedged[i]:<12,.0f} {q_unhedged_saa[i]:<12,.0f} {diff:<15,.0f} ${price_unhedged_base[i]:<11.4f} ${impact:<14,.2f}")

print("\n" + "="*100)
print("SCENARIO 1: -10% Price Change in Dec-Mar (Months 8-11)")
print("="*100)

affected_months = [8, 9, 10, 11]
price_unhedged_scenario1 = price_unhedged_base.copy()
for month_idx in affected_months:
    price_unhedged_scenario1[month_idx] *= 0.9  # -10%

proc_manual_s1 = np.sum(price_hedged * q_hedged) + np.sum(price_unhedged_scenario1 * q_manual_unhedged)
proc_capsaa_s1 = np.sum(price_hedged * q_hedged) + np.sum(price_unhedged_scenario1 * q_unhedged_saa)

total_manual_s1 = proc_manual_s1 + holding_manual
total_capsaa_s1 = proc_capsaa_s1 + holding_capsaa

print(f"\nManual Total:  ${total_manual_s1:,.2f}")
print(f"Cap-SAA Total: ${total_capsaa_s1:,.2f}")
print(f"Saving:        ${total_manual_s1 - total_capsaa_s1:,.2f}")

if total_capsaa_s1 > total_manual_s1:
    print("⚠️  WARNING: Cap-SAA is MORE expensive than Manual!")

print("\n" + "="*100)
print("SCENARIO 2: Uniform -10% Price Change Across ALL Months")
print("="*100)

price_unhedged_scenario2 = price_unhedged_base * 0.9  # -10% all months

proc_manual_s2 = np.sum(price_hedged * q_hedged) + np.sum(price_unhedged_scenario2 * q_manual_unhedged)
proc_capsaa_s2 = np.sum(price_hedged * q_hedged) + np.sum(price_unhedged_scenario2 * q_unhedged_saa)

total_manual_s2 = proc_manual_s2 + holding_manual
total_capsaa_s2 = proc_capsaa_s2 + holding_capsaa

print(f"\nManual Total:  ${total_manual_s2:,.2f}")
print(f"Cap-SAA Total: ${total_capsaa_s2:,.2f}")
print(f"Saving:        ${total_manual_s2 - total_capsaa_s2:,.2f}")

if total_capsaa_s2 > total_manual_s2:
    print("⚠️  WARNING: Cap-SAA is MORE expensive than Manual!")

print("\n" + "="*100)
print("ANALYSIS: Why might Cap-SAA become worse with selective price drops?")
print("="*100)

print("\nLet's check the procurement cost formula:")
print("  procurement_saving = sum(price * (q_manual - q_capsaa))")
print("\nFor months where q_manual > q_capsaa:")
print("  - Lower prices REDUCE the saving (or increase Cap-SAA advantage)")
print("  - Higher prices INCREASE the saving (Manual benefits more)")
print("\nFor months where q_manual < q_capsaa:")
print("  - Lower prices INCREASE the advantage of Cap-SAA buying more")
print("  - Higher prices DECREASE the advantage of Cap-SAA")

print("\nMonths where Manual buys MORE than Cap-SAA:")
for i in range(len(demand)):
    diff = q_manual_unhedged[i] - q_unhedged_saa[i]
    if diff > 0:
        month = df[COLUMN_MAP['date']].iloc[i].strftime('%b-%y')
        in_affected = "  ← Dec-Mar" if i in affected_months else ""
        print(f"  {month}: Manual buys {diff:,.0f} MORE {in_affected}")

print("\nMonths where Cap-SAA buys MORE than Manual:")
for i in range(len(demand)):
    diff = q_manual_unhedged[i] - q_unhedged_saa[i]
    if diff < 0:
        month = df[COLUMN_MAP['date']].iloc[i].strftime('%b-%y')
        in_affected = "  ← Dec-Mar" if i in affected_months else ""
        print(f"  {month}: Cap-SAA buys {-diff:,.0f} MORE {in_affected}")
