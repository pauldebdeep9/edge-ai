#!/usr/bin/env python3
"""
pareto_finance_procurement_labeled.py

Fixes vs your screenshots
- Moves the right-edge labels (e.g., AAPL 100%, Hedged 0%) DOWN/LEFT so they don't clash with the colorbar.
- Moves the bottom-left label (e.g., AAPL 0%) a bit DOWN/RIGHT so it doesn’t clash with the formula.
- Adds a semi-transparent white bbox behind annotations + formula for readability.
- Adds small axis margins so labels aren’t clipped.

Outputs
1) Finance: Apple + Google efficient frontier (Return vs Risk) with weight color encoding + labeled key weights
2) Procurement: Hedged vs Unhedged efficient frontier (Cost vs Risk) with hedge ratio encoding + labeled key ratios
3) Finance tradeoff vs weight (w_AAPL): expected return & risk curves
4) Procurement tradeoff vs hedge ratio (h): expected cost & risk curves

Run
  python pareto_finance_procurement_labeled.py
  python pareto_finance_procurement_labeled.py --use_cvar
  python pareto_finance_procurement_labeled.py --save_prefix demo --no_show

Deps
  python -m pip install -U numpy pandas matplotlib
"""

from __future__ import annotations
import argparse
import math
from dataclasses import dataclass
from typing import Optional, Tuple, Dict

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


# -----------------------------
# Risk helpers
# -----------------------------
def cvar(x: np.ndarray, alpha: float = 0.95, higher_is_worse: bool = True) -> float:
    """
    CVaR of sample x.
    - For costs/losses (higher_is_worse=True): CVaR is mean of upper tail beyond VaR_alpha.
    - For returns (higher_is_worse=False): CVaR is mean of lower tail beyond VaR_(1-alpha).
    """
    x = np.asarray(x, dtype=float)
    if x.size == 0:
        return float("nan")
    if higher_is_worse:
        var = np.quantile(x, alpha)
        tail = x[x >= var]
    else:
        var = np.quantile(x, 1.0 - alpha)
        tail = x[x <= var]
    return float(np.mean(tail)) if tail.size else float(var)


def pareto_front_2d(x: np.ndarray, y: np.ndarray, *, minimize_x: bool, minimize_y: bool) -> np.ndarray:
    """
    Indices of Pareto-efficient points for 2 objectives.
    """
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    n = x.size
    keep = np.ones(n, dtype=bool)

    # transform to "minimize both"
    xx = x if minimize_x else -x
    yy = y if minimize_y else -y

    for i in range(n):
        if not keep[i]:
            continue
        dom = (xx <= xx[i]) & (yy <= yy[i]) & ((xx < xx[i]) | (yy < yy[i]))
        dom[i] = False
        if np.any(dom):
            keep[i] = False
    return np.where(keep)[0]


def weights_grid(n_points: int = 401) -> np.ndarray:
    return np.linspace(0.0, 1.0, max(2, int(n_points)))


# -----------------------------
# Annotation placement helpers
# -----------------------------
def _smart_offset(
    x: float,
    y: float,
    xlim: Tuple[float, float],
    ylim: Tuple[float, float],
    *,
    base_dx: int = 10,
    base_dy: int = 8,
) -> Tuple[int, int, str]:
    """
    Heuristic offsets to keep labels readable and away from edges/colorbars.
    Returns (dx, dy, align) where align is 'left' or 'right'.
    """
    xmin, xmax = xlim
    ymin, ymax = ylim
    xr = xmax - xmin
    yr = ymax - ymin

    # default: to the right-up
    dx, dy = base_dx, base_dy
    ha = "left"

    # near right edge -> move LEFT (to avoid colorbar)
    if x > xmax - 0.08 * xr:
        dx = -110
        ha = "right"
        dy = -8  # also slightly down

    # near left edge -> move RIGHT
    if x < xmin + 0.10 * xr:
        dx = 12
        ha = "left"

    # near top -> move DOWN a bit
    if y > ymax - 0.08 * yr:
        dy = -14

    # near bottom -> move UP a bit (but keep away from formula sometimes)
    if y < ymin + 0.12 * yr:
        dy = 10

    return dx, dy, ha


def annotate_point(
    ax: plt.Axes,
    x: float,
    y: float,
    text: str,
    *,
    dx: Optional[int] = None,
    dy: Optional[int] = None,
    ha: Optional[str] = None,
) -> None:
    """
    Draw label with consistent style. If dx/dy/ha not provided, auto place.
    """
    xlim = ax.get_xlim()
    ylim = ax.get_ylim()

    if dx is None or dy is None or ha is None:
        adx, ady, aha = _smart_offset(x, y, xlim, ylim)
        dx = adx if dx is None else dx
        dy = ady if dy is None else dy
        ha = aha if ha is None else ha

    ax.annotate(
        text,
        (x, y),
        textcoords="offset points",
        xytext=(dx, dy),
        ha=ha,
        va="center",
        fontsize=9,
        bbox=dict(boxstyle="round,pad=0.18", fc="white", ec="none", alpha=0.70),
        zorder=10,
    )


def put_formula_box(ax: plt.Axes, text: str, *, loc: str) -> None:
    """
    Place formula in a readable corner with a bbox.
    loc: 'bottom_left', 'bottom_right', 'top_left', 'top_right'
    """
    loc_map = {
        "bottom_left": (0.02, 0.03, "left", "bottom"),
        "bottom_right": (0.98, 0.03, "right", "bottom"),
        "top_left": (0.02, 0.97, "left", "top"),
        "top_right": (0.98, 0.97, "right", "top"),
    }
    x, y, ha, va = loc_map[loc]
    ax.text(
        x, y, text,
        transform=ax.transAxes,
        fontsize=9,
        ha=ha, va=va,
        bbox=dict(boxstyle="round,pad=0.25", fc="white", ec="none", alpha=0.70),
        zorder=9,
    )


# -----------------------------
# Finance synthetic model (Apple + Google)
# -----------------------------
@dataclass
class FinanceParams:
    mu_annual: Tuple[float, float] = (0.12, 0.08)   # Apple, Google (synthetic)
    vol_annual: Tuple[float, float] = (0.25, 0.18)  # Apple, Google (synthetic)
    rho: float = 0.30
    periods_per_year: int = 12


def simulate_finance_returns(n_scenarios: int, seed: int, p: FinanceParams) -> pd.DataFrame:
    rng = np.random.default_rng(seed)

    mu_m = np.array(p.mu_annual) / p.periods_per_year
    vol_m = np.array(p.vol_annual) / math.sqrt(p.periods_per_year)

    cov = np.array([
        [vol_m[0] ** 2, p.rho * vol_m[0] * vol_m[1]],
        [p.rho * vol_m[0] * vol_m[1], vol_m[1] ** 2],
    ])

    r = rng.multivariate_normal(mean=mu_m, cov=cov, size=n_scenarios)
    return pd.DataFrame(r, columns=["r_aapl", "r_googl"])


def finance_frontier(df_ret: pd.DataFrame, w_grid: np.ndarray, periods_per_year: int = 12) -> pd.DataFrame:
    r1 = df_ret["r_aapl"].to_numpy()
    r2 = df_ret["r_googl"].to_numpy()

    mu_a, vol_a, cvar95_loss = [], [], []

    for w in w_grid:
        rp = w * r1 + (1.0 - w) * r2
        mu_m = float(np.mean(rp))
        vol_m = float(np.std(rp, ddof=1))

        mu_a.append(mu_m * periods_per_year)
        vol_a.append(vol_m * math.sqrt(periods_per_year))
        cvar95_loss.append(cvar(-rp, alpha=0.95, higher_is_worse=True))

    return pd.DataFrame({
        "w_aapl": w_grid,
        "w_googl": 1.0 - w_grid,
        "exp_return_annual": mu_a,
        "vol_annual": vol_a,
        "cvar95_monthly_loss": cvar95_loss,
    })


# -----------------------------
# Procurement synthetic model (Hedged vs Unhedged)
# -----------------------------
@dataclass
class ProcurementParams:
    fixed_price: float = 78.0
    hedge_premium: float = 0.6
    base_spot: float = 78.0
    spot_vol: float = 0.40
    basis_vol: float = 0.15           # hedge basis risk (contract imperfection)
    basis_spot_corr: float = 0.10     # correlation between basis noise and spot
    demand_mean_oz: float = 1_200_000.0
    demand_vol: float = 0.15
    spot_demand_corr: float = 0.25


def simulate_procurement_scenarios(n_scenarios: int, seed: int, p: ProcurementParams) -> pd.DataFrame:
    rng = np.random.default_rng(seed)

    # 3 correlated factors: spot, demand, hedge basis noise
    corr = np.array([
        [1.0,                p.spot_demand_corr, p.basis_spot_corr],
        [p.spot_demand_corr, 1.0,                0.0],
        [p.basis_spot_corr,  0.0,                1.0],
    ])
    z = rng.multivariate_normal(mean=[0.0, 0.0, 0.0], cov=corr, size=n_scenarios)

    spot = p.base_spot * np.exp(p.spot_vol * z[:, 0] - 0.5 * p.spot_vol**2)
    demand = p.demand_mean_oz * np.exp(p.demand_vol * z[:, 1] - 0.5 * p.demand_vol**2)
    # Effective hedge price fluctuates around F due to basis risk
    F = p.fixed_price + p.hedge_premium
    hedge_price = F * np.exp(p.basis_vol * z[:, 2] - 0.5 * p.basis_vol**2)

    return pd.DataFrame({"spot": spot, "demand_oz": demand, "hedge_price": hedge_price})


def procurement_frontier(df_scen: pd.DataFrame, h_grid: np.ndarray, p: ProcurementParams, use_cvar: bool) -> pd.DataFrame:
    S = df_scen["spot"].to_numpy()
    D = df_scen["demand_oz"].to_numpy()
    H = df_scen["hedge_price"].to_numpy()  # stochastic hedge price (basis risk)

    exp_cost, risk_metric, std_cost, cvar_cost = [], [], [], []

    for h in h_grid:
        C = D * (h * H + (1.0 - h) * S)
        exp = float(np.mean(C))
        sd = float(np.std(C, ddof=1))
        cv = float(cvar(C, alpha=0.95, higher_is_worse=True))

        exp_cost.append(exp)
        std_cost.append(sd)
        cvar_cost.append(cv)
        risk_metric.append(cv if use_cvar else sd)

    return pd.DataFrame({
        "h": h_grid,
        "unhedged": 1.0 - h_grid,
        "exp_cost": exp_cost,
        "risk": risk_metric,
        "std_cost": std_cost,
        "cvar95_cost": cvar_cost,
    })


# -----------------------------
# Plotting
# -----------------------------
def plot_finance(front: pd.DataFrame, *, save_path: Optional[str], show: bool) -> None:
    x = front["vol_annual"].to_numpy()
    y = front["exp_return_annual"].to_numpy()
    w = front["w_aapl"].to_numpy()

    idx_pf = pareto_front_2d(x, y, minimize_x=True, minimize_y=False)

    fig, ax = plt.subplots(figsize=(11.5, 5.2))
    sc = ax.scatter(x, y, c=w, s=22, alpha=0.85)
    cb = plt.colorbar(sc, ax=ax)
    cb.set_label("Apple weight (w_AAPL)")

    ax.plot(x[idx_pf], y[idx_pf], linewidth=2.2, label="Efficient frontier (Pareto)")

    # Add slight margins so edge labels don't get clipped
    ax.margins(x=0.08, y=0.08)

    # Force recompute limits before smart offsets
    fig.canvas.draw()

    # Labeled allocations
    sel = np.array([0.0, 0.25, 0.50, 0.75, 1.0])

    # Manual micro-tweaks (optional) to guarantee clarity at problematic points
    # key: weight -> (dx, dy, ha)
    overrides: Dict[float, Tuple[int, int, str]] = {
        1.0: (-120, -16, "right"),  # top-right: move left/down from colorbar
        0.0: (18, -14, "left"),     # bottom-ish: move right/down away from formula
    }

    for ww in sel:
        j = int(np.abs(front["w_aapl"].to_numpy() - ww).argmin())
        ax.scatter([x[j]], [y[j]], s=70, marker="x", zorder=11)

        label = f"AAPL {front.iloc[j]['w_aapl']*100:.0f}% / GOOG {front.iloc[j]['w_googl']*100:.0f}%"
        if float(ww) in overrides:
            dx, dy, ha = overrides[float(ww)]
            annotate_point(ax, x[j], y[j], label, dx=dx, dy=dy, ha=ha)
        else:
            annotate_point(ax, x[j], y[j], label)

    formula = (
        r"$r_p = w\,r_{AAPL} + (1-w)\,r_{GOOG}$" "\n"
        r"$\mu_p = w\mu_{AAPL} + (1-w)\mu_{GOOG}$" "\n"
        r"$\sigma_p^2 = w^2\sigma_{AAPL}^2 + (1-w)^2\sigma_{GOOG}^2 + 2w(1-w)\rho\sigma_{AAPL}\sigma_{GOOG}$"
    )
    # Put formula bottom-right (keeps it away from left-lower labels/points)
    put_formula_box(ax, formula, loc="bottom_right")

    ax.set_title("Finance: Apple + Google Efficient Frontier (Return vs Risk) with Weight Encoding")
    ax.set_xlabel("Risk (Annualized Volatility)")
    ax.set_ylabel("Expected Return (Annualized)")
    ax.grid(True, alpha=0.25)
    ax.legend(loc="upper left")
    fig.tight_layout()

    if save_path:
        fig.savefig(save_path, dpi=170, bbox_inches="tight")
        print(f"[OK] saved: {save_path}")
    if show:
        plt.show()
    plt.close(fig)


def plot_finance_weight_tradeoff(front: pd.DataFrame, *, save_path: Optional[str], show: bool) -> None:
    w = front["w_aapl"].to_numpy()
    mu = front["exp_return_annual"].to_numpy()
    vol = front["vol_annual"].to_numpy()

    fig, ax = plt.subplots(figsize=(11.5, 4.7))
    ax.plot(w, mu, label="Expected return (annual)")
    ax.plot(w, vol, label="Risk (annual vol)")
    ax.set_title("Finance: Tradeoff vs Allocation (Apple weight w_AAPL)")
    ax.set_xlabel("Apple weight w_AAPL   (Google weight = 1 - w_AAPL)")
    ax.grid(True, alpha=0.25)
    ax.legend(loc="best")
    fig.tight_layout()

    if save_path:
        fig.savefig(save_path, dpi=170, bbox_inches="tight")
        print(f"[OK] saved: {save_path}")
    if show:
        plt.show()
    plt.close(fig)


def plot_procurement(front: pd.DataFrame, *, use_cvar: bool, save_path: Optional[str], show: bool) -> None:
    x = front["risk"].to_numpy()
    y = front["exp_cost"].to_numpy()
    h = front["h"].to_numpy()

    idx_pf = pareto_front_2d(x, y, minimize_x=True, minimize_y=True)

    fig, ax = plt.subplots(figsize=(11.5, 5.2))
    sc = ax.scatter(x, y, c=h, s=22, alpha=0.85)
    cb = plt.colorbar(sc, ax=ax)
    cb.set_label("Hedge ratio (h)")

    ax.plot(x[idx_pf], y[idx_pf], linewidth=2.2, label="Efficient frontier (Pareto)")

    ax.margins(x=0.08, y=0.08)
    fig.canvas.draw()

    # Key hedge ratios to label; 89% is optimal (min risk due to basis risk tradeoff)
    sel = np.array([0.0, 0.25, 0.50, 0.75, 0.89, 1.0])

    overrides: Dict[float, Tuple[int, int, str]] = {
        0.0:  (-120, -16, "right"),  # far-right (unhedged extreme): move left/down from colorbar
        1.0:  (40, -16, "left"),     # 100% hedged (non-optimal): far right/down to clear star
        0.89: (16, 14, "left"),      # optimal: right/up
    }

    # Plot optimal star first as its own legend entry
    j89 = int(np.abs(front["h"].to_numpy() - 0.89).argmin())
    ax.scatter([x[j89]], [y[j89]], s=200, marker="*", color="#d62728", edgecolors="black",
               linewidths=0.6, zorder=12, label=f"Optimal h* ≈ 89%")

    for hh in sel:
        j = int(np.abs(front["h"].to_numpy() - hh).argmin())

        # Mark optimal 89% with a star (already plotted above), others with x
        if abs(hh - 0.89) < 0.01:
            label = f"h = {front.iloc[j]['h']*100:.0f}% ★ Optimal"
        else:
            ax.scatter([x[j]], [y[j]], s=70, marker="x", color="#333333", zorder=11,
                       label="Key allocations" if hh == sel[0] else None)
            label = f"Hedged {front.iloc[j]['h']*100:.0f}% / Unhedged {front.iloc[j]['unhedged']*100:.0f}%"

        if float(hh) in overrides:
            dx, dy, ha = overrides[float(hh)]
            annotate_point(ax, x[j], y[j], label, dx=dx, dy=dy, ha=ha)
        else:
            annotate_point(ax, x[j], y[j], label)

    formula = (
        r"$C(h)=D\,[h\tilde{F} + (1-h)S]$" "\n"
        r"$\tilde{F} = F\,e^{\epsilon}$  (basis risk)" "\n"
        r"$h^* \approx 89\%$: balances spot exposure vs basis risk"
    )
    # Put formula top-left (keeps it away from bottom-left hedged point)
    put_formula_box(ax, formula, loc="top_left")

    ax.set_title("Procurement: Hedged vs Unhedged Efficient Frontier (Cost vs Risk) with Hedge Encoding")
    ax.set_xlabel("Risk (CVaR95 Cost)" if use_cvar else "Risk (Std Dev of Cost)")
    ax.set_ylabel("Expected Cost (USD)")
    ax.grid(True, alpha=0.25)
    ax.legend(loc="upper left")
    fig.tight_layout()

    if save_path:
        fig.savefig(save_path, dpi=170, bbox_inches="tight")
        print(f"[OK] saved: {save_path}")
    if show:
        plt.show()
    plt.close(fig)


def plot_procurement_tradeoff(front: pd.DataFrame, *, use_cvar: bool, save_path: Optional[str], show: bool) -> None:
    h = front["h"].to_numpy()
    exp_cost = front["exp_cost"].to_numpy()
    risk = front["risk"].to_numpy()

    fig, ax = plt.subplots(figsize=(11.5, 4.7))
    ax.plot(h, exp_cost, label="Expected cost")
    ax.plot(h, risk, label="Risk (CVaR95)" if use_cvar else "Risk (Std)")
    ax.set_title("Procurement: Tradeoff vs Hedge Ratio (h)")
    ax.set_xlabel("Hedge ratio h   (Unhedged = 1 - h)")
    ax.grid(True, alpha=0.25)
    ax.legend(loc="best")
    fig.tight_layout()

    if save_path:
        fig.savefig(save_path, dpi=170, bbox_inches="tight")
        print(f"[OK] saved: {save_path}")
    if show:
        plt.show()
    plt.close(fig)


# -----------------------------
# Main
# -----------------------------
def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=8000, help="Number of synthetic scenarios")
    ap.add_argument("--grid", type=int, default=401, help="Number of weight points in [0,1]")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--use_cvar", action="store_true", help="Use CVaR95 as procurement risk instead of Std")
    ap.add_argument("--save_prefix", default=None, help="If set, saves plots as <prefix>_*.png")
    ap.add_argument("--no_show", action="store_true")
    args = ap.parse_args()

    n = max(500, int(args.n))
    wgrid = weights_grid(args.grid)
    show = not args.no_show

    # Finance
    fin_p = FinanceParams()
    df_ret = simulate_finance_returns(n, args.seed, fin_p)
    fin_front = finance_frontier(df_ret, wgrid, periods_per_year=fin_p.periods_per_year)

    # Procurement
    proc_p = ProcurementParams()
    df_scen = simulate_procurement_scenarios(n, args.seed + 777, proc_p)
    proc_front = procurement_frontier(df_scen, wgrid, proc_p, use_cvar=args.use_cvar)

    sp = args.save_prefix
    f1 = f"{sp}_finance_frontier.png" if sp else None
    f2 = f"{sp}_finance_tradeoff.png" if sp else None
    p1 = f"{sp}_proc_frontier.png" if sp else None
    p2 = f"{sp}_proc_tradeoff.png" if sp else None

    plot_finance(fin_front, save_path=f1, show=show)
    plot_finance_weight_tradeoff(fin_front, save_path=f2, show=show)
    plot_procurement(proc_front, use_cvar=args.use_cvar, save_path=p1, show=show)
    plot_procurement_tradeoff(proc_front, use_cvar=args.use_cvar, save_path=p2, show=show)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
