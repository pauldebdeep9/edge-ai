#!/usr/bin/env python3
"""
silver_monthly_auto_allinone.py

End-to-end single script that:
1) Downloads the latest World Bank "Pink Sheet" monthly XLSX (with retries + failover link discovery)
2) Robustly parses the XLSX even if headers shift (title blocks / merged cells / multi-row headers)
3) Extracts SILVER monthly average prices ($/toz)
4) Appends requested historical window (default: 2025-04 .. 2026-01)
5) Auto-generates forecast window (default: current month .. 2026-09) with P10–P50–P90 band
   using a bootstrap of historical monthly log-returns (fallback to Gaussian if data is short)
6) Writes a single CSV + plots (PNG/PDF)
7) Optionally scrapes related Silver/commodity news from credible sources (Reuters/Bloomberg/CNBC/FT/WSJ/World Bank)

Install:
  python -m pip install -U pandas numpy matplotlib requests openpyxl

Run:
  python silver_monthly_auto_allinone.py
  python silver_monthly_auto_allinone.py --out_png silver.png --out_csv silver.csv --debug
"""

from __future__ import annotations

import argparse
import datetime as dt
import html
import io
import math
import os
import re
import sys
import time
import warnings
import xml.etree.ElementTree as ET
from email.utils import parsedate_to_datetime
from typing import Any, Callable, Dict, List, Optional, Tuple
from urllib.parse import quote_plus

# -----------------------------
# Imports with friendly errors
# -----------------------------
def _pip_hint() -> str:
    return "Install deps with:\n  python -m pip install -U pandas numpy matplotlib requests openpyxl\n"

try:
    import numpy as np
except Exception:
    print(_pip_hint(), file=sys.stderr)
    raise

try:
    import pandas as pd
except Exception:
    print(_pip_hint(), file=sys.stderr)
    raise

try:
    import requests
except Exception:
    print(_pip_hint(), file=sys.stderr)
    raise

try:
    import matplotlib.pyplot as plt
except Exception:
    print(_pip_hint(), file=sys.stderr)
    raise


# -----------------------------
# Retry helper (failover loops)
# -----------------------------
def retry(
    fn: Callable[[], Any],
    *,
    tries: int = 6,
    base_sleep_s: float = 0.7,
    backoff: float = 2.0,
    cap_sleep_s: float = 12.0,
    jitter_s: float = 0.25,
    label: str = "operation",
) -> Any:
    last_err: Optional[BaseException] = None
    for i in range(1, tries + 1):
        try:
            return fn()
        except Exception as e:
            last_err = e
            if i >= tries:
                break
            sleep_s = min(cap_sleep_s, base_sleep_s * (backoff ** (i - 1)))
            sleep_s = sleep_s * (0.75 + 0.5 * float(np.random.rand())) + (jitter_s * (i % 3))
            print(f"[WARN] {label} failed (attempt {i}/{tries}): {e} -> retry in {sleep_s:.2f}s", file=sys.stderr)
            time.sleep(sleep_s)
    raise RuntimeError(f"{label} failed after {tries} tries. Last error: {last_err}")


# -----------------------------
# HTTP + caching
# -----------------------------
PRIMARY_XLSX_URL = (
    "https://thedocs.worldbank.org/en/doc/"
    "5d903e848db1d1b83e0ec8f744e55570-0350012021/related/CMO-Historical-Data-Monthly.xlsx"
)
WB_LANDING_PAGE = "https://www.worldbank.org/en/research/commodity-markets"


def http_get(url: str, *, timeout_s: int = 30, headers: Optional[dict] = None) -> requests.Response:
    resp = requests.get(url, timeout=timeout_s, headers=headers)
    # Retryable statuses are handled by retry() via raising
    if resp.status_code == 429 or (500 <= resp.status_code <= 599):
        raise requests.HTTPError(f"Retryable HTTP {resp.status_code} for {url}")
    resp.raise_for_status()
    return resp


def find_latest_worldbank_monthly_xlsx_link(debug: bool = False) -> str:
    """
    Fallback: fetch World Bank commodity markets page and try to locate a link to the monthly XLSX.
    """
    def _fetch():
        return http_get(WB_LANDING_PAGE, timeout_s=30).text

    html = retry(_fetch, label="fetch WB landing page")

    # Gather candidate XLSX hrefs
    candidates: List[str] = []
    for m in re.finditer(r'href="([^"]+\.xlsx)"', html, flags=re.IGNORECASE):
        href = m.group(1).strip()
        if href:
            candidates.append(href)

    resolved: List[str] = []
    for c in candidates:
        if c.startswith("http"):
            resolved.append(c)
        else:
            # handle relative links
            resolved.append("https://www.worldbank.org" + c)

    # Prefer exact-ish file name
    for u in resolved:
        if "CMO-Historical-Data-Monthly" in u:
            if debug:
                print(f"[DEBUG] discovered preferred XLSX: {u}", file=sys.stderr)
            return u

    # Otherwise, pick first plausible
    if resolved:
        if debug:
            print(f"[DEBUG] discovered XLSX candidates: {resolved[:5]}", file=sys.stderr)
        return resolved[0]

    # Final fallback to known stable docs link
    if debug:
        print("[DEBUG] no XLSX link found on landing page; using PRIMARY_XLSX_URL", file=sys.stderr)
    return PRIMARY_XLSX_URL


def download_xlsx_bytes(*, debug: bool = False) -> bytes:
    """
    Download XLSX bytes using primary URL; fallback to link discovery.
    """
    def _primary():
        if debug:
            print(f"[INFO] downloading primary XLSX: {PRIMARY_XLSX_URL}", file=sys.stderr)
        return http_get(PRIMARY_XLSX_URL, timeout_s=40).content

    try:
        return retry(_primary, tries=4, label="download primary XLSX")
    except Exception as e:
        if debug:
            print(f"[WARN] primary download failed: {e}", file=sys.stderr)
        alt = find_latest_worldbank_monthly_xlsx_link(debug=debug)

        def _alt():
            if debug:
                print(f"[INFO] downloading fallback XLSX: {alt}", file=sys.stderr)
            return http_get(alt, timeout_s=40).content

        return retry(_alt, tries=4, label="download fallback XLSX")


def cache_paths(cache_dir: str) -> Tuple[str, str]:
    os.makedirs(cache_dir, exist_ok=True)
    latest_path = os.path.join(cache_dir, "worldbank_pinksheet_monthly_latest.xlsx")
    backup_path = os.path.join(cache_dir, "worldbank_pinksheet_monthly_backup.xlsx")
    return latest_path, backup_path


def load_xlsx_with_cache(cache_dir: str, *, debug: bool = False) -> bytes:
    """
    Try: download -> write cache (rotate backup). If download fails, fallback to cached file if exists.
    """
    latest_path, backup_path = cache_paths(cache_dir)

    try:
        data = download_xlsx_bytes(debug=debug)

        # rotate cache
        if os.path.exists(latest_path):
            try:
                os.replace(latest_path, backup_path)
            except Exception:
                pass

        with open(latest_path, "wb") as f:
            f.write(data)

        if debug:
            print(f"[INFO] cached XLSX -> {latest_path}", file=sys.stderr)

        return data

    except Exception as e:
        if debug:
            print(f"[WARN] download failed; trying cache. err={e}", file=sys.stderr)

        for path in (latest_path, backup_path):
            if os.path.exists(path) and os.path.getsize(path) > 0:
                if debug:
                    print(f"[INFO] using cached XLSX: {path}", file=sys.stderr)
                with open(path, "rb") as f:
                    return f.read()

        raise RuntimeError("Could not download XLSX and no cache file available.") from e


# -----------------------------
# News scraping (Bing RSS)
# -----------------------------
NEWS_USER_AGENT = "Mozilla/5.0 (compatible; SilverPriceNewsBot/1.0; +https://www.bing.com/news)"
NEWS_SOURCE_DOMAINS: Dict[str, str] = {
    "Reuters": "reuters.com",
    "Bloomberg": "bloomberg.com",
    "CNBC": "cnbc.com",
    "Financial Times": "ft.com",
    "Wall Street Journal": "wsj.com",
    "World Bank": "worldbank.org",
}
NEWS_DEFAULT_KEYWORDS: List[str] = [
    "silver",
    "precious metal",
    "bullion",
    "commodity",
]


def _normalize_source_name(name: str) -> str:
    return re.sub(r"[^a-z0-9]", "", name.lower())


def parse_news_sources_arg(spec: str) -> Dict[str, str]:
    """
    Parse --news_sources:
      - "all" (default): all sources
      - comma-separated names, e.g. "Reuters,CNBC,World Bank"
    """
    if not spec or spec.strip().lower() == "all":
        return dict(NEWS_SOURCE_DOMAINS)

    alias = {_normalize_source_name(k): k for k in NEWS_SOURCE_DOMAINS}
    selected: Dict[str, str] = {}
    for raw in spec.split(","):
        raw = raw.strip()
        if not raw:
            continue
        key = _normalize_source_name(raw)
        if key in alias:
            canonical = alias[key]
            selected[canonical] = NEWS_SOURCE_DOMAINS[canonical]
        else:
            print(f"[WARN] unknown news source ignored: {raw}", file=sys.stderr)

    if not selected:
        allowed = ", ".join(NEWS_SOURCE_DOMAINS.keys())
        raise ValueError(f"No valid news source selected. Allowed values: {allowed}")
    return selected


def parse_news_keywords_arg(spec: str) -> List[str]:
    if not spec.strip():
        return list(NEWS_DEFAULT_KEYWORDS)
    parts = [p.strip().lower() for p in spec.split(",") if p.strip()]
    return parts if parts else list(NEWS_DEFAULT_KEYWORDS)


def build_bing_news_rss_url(query: str) -> str:
    q = quote_plus(query)
    return f"https://www.bing.com/news/search?q={q}&format=RSS&setlang=en-us"


def _local_tag(tag: str) -> str:
    return tag.rsplit("}", 1)[-1].lower()


def _rss_child_text(item: ET.Element, *names: str) -> str:
    wanted = {n.lower() for n in names}
    for child in list(item):
        if _local_tag(child.tag) in wanted:
            txt = "".join(child.itertext()).strip()
            if txt:
                return txt
    return ""


def _rss_source_url(item: ET.Element) -> str:
    for child in list(item):
        if _local_tag(child.tag) == "source":
            return child.attrib.get("url", "").strip()
    return ""


def _strip_html_text(text: str) -> str:
    if not text:
        return ""
    clean = html.unescape(text)
    clean = re.sub(r"<[^>]+>", " ", clean)
    clean = re.sub(r"\s+", " ", clean).strip()
    return clean


def _parse_rss_datetime(raw: str) -> Optional[dt.datetime]:
    if not raw:
        return None
    try:
        d = parsedate_to_datetime(raw)
        if d.tzinfo is None:
            d = d.replace(tzinfo=dt.timezone.utc)
        return d.astimezone(dt.timezone.utc)
    except Exception:
        pass

    d2 = pd.to_datetime(raw, utc=True, errors="coerce")
    if pd.isna(d2):
        return None
    return d2.to_pydatetime()


def parse_rss_news_items(
    rss_text: str,
    *,
    source_label: str,
    source_domain: str,
    query: str,
    keywords: List[str],
    max_items: int,
    cutoff_utc: Optional[dt.datetime],
) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    try:
        root = ET.fromstring(rss_text)
    except Exception as e:
        raise RuntimeError(f"Invalid RSS/XML for source={source_label}: {e}") from e

    keywords_l = [k.lower() for k in keywords if k.strip()]
    for node in root.iter():
        if _local_tag(node.tag) != "item":
            continue

        title = _strip_html_text(_rss_child_text(node, "title"))
        link = _rss_child_text(node, "link").strip()
        summary = _strip_html_text(_rss_child_text(node, "description"))
        pub_raw = _rss_child_text(node, "pubDate", "published", "updated")
        published_dt = _parse_rss_datetime(pub_raw)
        src_name = _rss_child_text(node, "source") or source_label
        src_url = _rss_source_url(node)

        if not title and not link:
            continue

        text_blob = f"{title} {summary}".lower()
        if keywords_l and not any(k in text_blob for k in keywords_l):
            continue
        if cutoff_utc and published_dt and published_dt < cutoff_utc:
            continue

        rows.append(
            {
                "source": src_name,
                "source_domain": source_domain,
                "source_url": src_url,
                "title": title,
                "url": link,
                "summary": summary,
                "published_dt": published_dt,
                "query": query,
            }
        )
        if len(rows) >= max_items:
            break

    return rows


def scrape_related_news(
    *,
    base_query: str,
    selected_sources: Dict[str, str],
    keywords: List[str],
    per_source_limit: int = 20,
    max_items: int = 80,
    max_age_days: int = 30,
    debug: bool = False,
) -> pd.DataFrame:
    now_utc = dt.datetime.now(dt.timezone.utc)
    cutoff_utc = now_utc - dt.timedelta(days=max_age_days) if max_age_days > 0 else None
    headers = {
        "User-Agent": NEWS_USER_AGENT,
        "Accept": "application/rss+xml, application/xml;q=0.9, text/xml;q=0.8, */*;q=0.5",
    }

    all_rows: List[Dict[str, Any]] = []
    for source_name, domain in selected_sources.items():
        query = f"{base_query} site:{domain}"
        url = build_bing_news_rss_url(query)

        def _fetch():
            if debug:
                print(f"[INFO] fetching news rss source={source_name} url={url}", file=sys.stderr)
            return http_get(url, timeout_s=30, headers=headers).text

        try:
            rss_text = retry(_fetch, tries=4, label=f"fetch news rss ({source_name})")
            rows = parse_rss_news_items(
                rss_text,
                source_label=source_name,
                source_domain=domain,
                query=query,
                keywords=keywords,
                max_items=per_source_limit,
                cutoff_utc=cutoff_utc,
            )
            if debug:
                print(f"[DEBUG] news rows source={source_name}: {len(rows)}", file=sys.stderr)
            all_rows.extend(rows)
        except Exception as e:
            print(f"[WARN] news scrape failed for {source_name}: {e}", file=sys.stderr)

    columns = [
        "source",
        "source_domain",
        "source_url",
        "title",
        "published_utc",
        "url",
        "summary",
        "query",
        "scraped_at_utc",
    ]
    if not all_rows:
        return pd.DataFrame(columns=columns)

    df = pd.DataFrame(all_rows)
    df["published_dt"] = pd.to_datetime(df["published_dt"], utc=True, errors="coerce")
    df = df.sort_values("published_dt", ascending=False, na_position="last")
    df = df.drop_duplicates(subset=["url", "title"], keep="first")

    if max_items > 0:
        df = df.head(max_items).copy()
    else:
        df = df.copy()

    df["published_utc"] = df["published_dt"].dt.strftime("%Y-%m-%dT%H:%M:%SZ").fillna("")
    df["scraped_at_utc"] = now_utc.strftime("%Y-%m-%dT%H:%M:%SZ")
    return df[columns]


def scrape_news_and_print_preview(
    *,
    out_csv: str,
    base_query: str,
    news_sources: str,
    news_keywords: str,
    news_per_source: int,
    news_max_items: int,
    news_max_age_days: int,
    debug: bool,
) -> pd.DataFrame:
    selected_sources = parse_news_sources_arg(news_sources)
    keywords = parse_news_keywords_arg(news_keywords)
    news_df = scrape_related_news(
        base_query=base_query,
        selected_sources=selected_sources,
        keywords=keywords,
        per_source_limit=news_per_source,
        max_items=news_max_items,
        max_age_days=news_max_age_days,
        debug=debug,
    )
    if news_df.empty:
        print("[WARN] news scrape returned 0 rows (network/source/filter issue).", file=sys.stderr)
        return news_df

    news_df.to_csv(out_csv, index=False)
    print(f"[INFO] wrote news rows={len(news_df)} -> {out_csv}")
    print("\n[NEWS PREVIEW]")
    print(news_df.head(min(15, len(news_df))).to_string(index=False))
    return news_df


# -----------------------------
# Robust XLSX parsing
# -----------------------------
def _flatten_cols(cols) -> List[str]:
    if isinstance(cols, pd.MultiIndex):
        out = []
        for tup in cols.tolist():
            parts = [
                str(x).strip()
                for x in tup
                if x is not None and str(x).strip() and "unnamed" not in str(x).lower()
            ]
            out.append(" | ".join(parts) if parts else "")
        return out
    return [str(c).strip() for c in cols]


def _looks_like_units_row(row: pd.Series) -> bool:
    s = row.astype(str).str.lower()
    hits = s.str.contains(r"(?:\$/|index|toz|oz|ton|kg|bbl|mmbtu|percent|=)").sum()
    return int(hits) >= 3


def _sheet_header_row_candidates(pre: pd.DataFrame) -> List[int]:
    cand: List[int] = []
    nrows = min(len(pre), 140)
    ncols = pre.shape[1]
    for r in range(nrows):
        row = pre.iloc[r]
        row_str = row.astype(str).str.strip().str.lower()
        if row_str.str.contains(r"\b(?:date|month|time)\b").any():
            cand.append(r)
            continue
        nonempty = (row_str.replace({"nan": ""}) != "").sum()
        if nonempty >= max(6, int(0.25 * ncols)):
            cand.append(r)
    return cand


def _find_header_row_and_mode(pre: pd.DataFrame) -> Tuple[Optional[int], bool]:
    cand = _sheet_header_row_candidates(pre)

    # Prefer header rows where "silver" appears in this row or within next 2 rows
    for r in cand:
        window = pre.iloc[r : r + 3].astype(str).apply(lambda x: x.str.lower())
        if window.apply(lambda x: x.str.contains("silver").any(), axis=1).any():
            two_row = (r + 1 < len(pre)) and _looks_like_units_row(pre.iloc[r + 1])
            return r, two_row

    # Fallback: any row containing "silver"
    for r in range(min(len(pre), 140)):
        row = pre.iloc[r].astype(str).str.lower()
        if row.str.contains("silver").any():
            two_row = (r + 1 < len(pre)) and _looks_like_units_row(pre.iloc[r + 1])
            return r, two_row

    return None, False


def _find_silver_col(df: pd.DataFrame) -> str:
    cols = list(df.columns)
    for c in cols:
        if str(c).strip().lower() == "silver":
            return c
    for c in cols:
        if "silver" in str(c).strip().lower():
            return c
    raise KeyError(f"Could not find a 'Silver' column. Columns seen: {cols[:30]}...")


def _find_date_col(df: pd.DataFrame) -> str:
    cols = list(df.columns)
    for c in cols:
        cl = str(c).strip().lower()
        if cl in ("date", "month", "time") or re.search(r"\b(date|month|time)\b", cl):
            return c
    return cols[0]


def _best_datetime_parse(series: pd.Series) -> pd.Series:
    s = series.copy()
    # If it's already datetime-like
    if np.issubdtype(s.dtype, np.datetime64):
        return pd.to_datetime(s, errors="coerce").dt.to_period("M").dt.to_timestamp()

    s_str = s.astype(str).str.strip()

    candidates: List[pd.Series] = []

    # 2025M04 format
    if (s_str.str.match(r"^\d{4}M\d{2}$").mean() > 0.5):
        t = pd.to_datetime(s_str.str.replace("M", "-"), format="%Y-%m", errors="coerce")
        candidates.append(t)

    # YYYY-MM format
    if (s_str.str.match(r"^\d{4}-\d{2}$").mean() > 0.5):
        t = pd.to_datetime(s_str, format="%Y-%m", errors="coerce")
        candidates.append(t)

    # YYYY-MM-DD format
    if (s_str.str.match(r"^\d{4}-\d{2}-\d{2}$").mean() > 0.5):
        t = pd.to_datetime(s_str, format="%Y-%m-%d", errors="coerce")
        candidates.append(t)

    # last resort: dateutil (silence warning)
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", message="Could not infer format.*")
        t = pd.to_datetime(s_str, errors="coerce")
    candidates.append(t)

    best = max(candidates, key=lambda x: float(x.notna().mean()))
    return best.dt.to_period("M").dt.to_timestamp()


def load_worldbank_silver_monthly_robust(xlsx_bytes: bytes, *, debug: bool = False) -> pd.DataFrame:
    """
    Returns DataFrame with columns: month (Timestamp month-start), price (float)
    """
    bio = io.BytesIO(xlsx_bytes)
    xls = pd.ExcelFile(bio, engine="openpyxl")

    last_err: Optional[BaseException] = None

    for sheet in xls.sheet_names:
        try:
            # 1) Preview grid (no header) to detect true header row
            bio.seek(0)
            pre = pd.read_excel(bio, sheet_name=sheet, header=None, nrows=140, engine="openpyxl")
            hdr_row, two_row = _find_header_row_and_mode(pre)
            if hdr_row is None:
                if debug:
                    print(f"[DEBUG] sheet={sheet}: no header row detected", file=sys.stderr)
                continue

            # 2) Read full sheet with discovered header row
            bio.seek(0)
            if two_row:
                df = pd.read_excel(bio, sheet_name=sheet, header=[hdr_row, hdr_row + 1], engine="openpyxl")
            else:
                df = pd.read_excel(bio, sheet_name=sheet, header=hdr_row, engine="openpyxl")

            df.columns = _flatten_cols(df.columns)
            # If the first column name is empty/unnamed, it's likely the date column — rename it
            if not df.columns[0] or "unnamed" in df.columns[0].lower():
                cols_list = list(df.columns)
                cols_list[0] = "date"
                df.columns = cols_list
            # drop remaining empty / unnamed columns
            df = df.loc[:, [c for c in df.columns if c and "unnamed" not in c.lower()]]

            date_col = _find_date_col(df)
            silver_col = _find_silver_col(df)

            month = _best_datetime_parse(df[date_col])
            price = pd.to_numeric(df[silver_col], errors="coerce")

            out = pd.DataFrame({"month": month, "price": price}).dropna()
            out["month"] = out["month"].dt.to_period("M").dt.to_timestamp()
            out = out.sort_values("month").reset_index(drop=True)

            if debug:
                print(
                    f"[DEBUG] sheet={sheet} hdr_row={hdr_row} two_row={two_row} "
                    f"date_col='{date_col}' silver_col='{silver_col}' rows={len(out)}",
                    file=sys.stderr,
                )

            # sanity: needs reasonable length; Pink Sheet is long
            if len(out) >= 100:
                return out

        except Exception as e:
            last_err = e
            if debug:
                print(f"[DEBUG] sheet={sheet} failed: {e}", file=sys.stderr)

    raise RuntimeError(f"Failed to locate Silver monthly series in any sheet. Last error: {last_err}")


# -----------------------------
# Forecasting (bootstrap bands)
# -----------------------------
def parse_ym(s: str) -> dt.date:
    y, m = s.split("-")
    return dt.date(int(y), int(m), 1)


def month_range(start_month: dt.date, end_month: dt.date) -> List[pd.Timestamp]:
    sm = pd.Timestamp(start_month.replace(day=1))
    em = pd.Timestamp(end_month.replace(day=1))
    return list(pd.date_range(sm, em, freq="MS"))


def bootstrap_forecast(
    last_price: float,
    monthly_prices: pd.Series,
    future_months: List[pd.Timestamp],
    *,
    n_sims: int = 30000,
    seed: int = 42,
    lookback_months: int = 120,
    debug: bool = False,
) -> pd.DataFrame:
    rng = np.random.default_rng(seed)

    s = monthly_prices.dropna().astype(float)
    s = s.iloc[-min(len(s), lookback_months):]
    rets = np.diff(np.log(s.values))

    if len(rets) < 12:
        mu = float(np.mean(rets)) if len(rets) else 0.0
        sig = float(np.std(rets, ddof=1)) if len(rets) > 1 else 0.10

        def draw(size):
            return rng.normal(mu, sig, size=size)

        mode = "gaussian_fallback"
    else:
        def draw(size):
            return rng.choice(rets, size=size, replace=True)

        mode = "bootstrap"

    if debug:
        print(f"[INFO] forecast_mode={mode} returns_used={len(rets)} sims={n_sims}", file=sys.stderr)

    H = len(future_months)
    inc = draw((n_sims, H))
    log_paths = np.cumsum(inc, axis=1) + math.log(last_price)
    paths = np.exp(log_paths)

    return pd.DataFrame(
        {
            "month": future_months,
            "mean": np.mean(paths, axis=0),
            "p10": np.quantile(paths, 0.10, axis=0),
            "p50": np.quantile(paths, 0.50, axis=0),
            "p90": np.quantile(paths, 0.90, axis=0),
        }
    )


# -----------------------------
# Plotting
# -----------------------------
def plot_table(df: pd.DataFrame, *, title: str, out_path: str, show: bool, debug: bool = False) -> None:
    def _do_plot():
        plt.figure(figsize=(11.2, 5.4))

        hist = df[df["type"] == "historical"].copy()
        fc = df[df["type"] == "forecast"].copy()

        if not hist.empty:
            plt.plot(hist["month"], hist["avg"], marker="o", linewidth=1.8, label="Historical monthly avg")

        if not fc.empty:
            plt.plot(fc["month"], fc["p50"], marker="o", linewidth=1.8, linestyle="--", label="Forecast P50")
            ok = fc["p10"].notna() & fc["p90"].notna()
            if ok.any():
                plt.fill_between(fc.loc[ok, "month"], fc.loc[ok, "p10"], fc.loc[ok, "p90"], alpha=0.2, label="Forecast P10–P90")

        plt.title(title)
        plt.xlabel("Month")
        plt.ylabel("Silver price (USD/oz)")
        plt.grid(True, alpha=0.25)
        plt.legend(loc="best")
        plt.tight_layout()

        if show:
            plt.show()
        plt.close()

    retry(_do_plot, tries=3, label="plot/save figure")


# -----------------------------
# Main
# -----------------------------
def plot_from_spreadsheet(
    xlsx_path: str,
    *,
    out_png: str = "silver_monthly_plot.png",
    out_csv: str = "silver_monthly_table.csv",
    title: str = "Silver (USD/oz): Historical monthly avg + forecast P10\u2013P90 band",
    show: bool = True,
    debug: bool = False,
) -> None:
    """
    Read the 'price' sheet from pidsg26Evaluation12.xlsx and plot the data as-is.
    """
    xls = pd.ExcelFile(xlsx_path, engine="openpyxl")
    sheet = xls.sheet_names[-1]  # last sheet
    df = pd.read_excel(xlsx_path, sheet_name=sheet, engine="openpyxl")

    if debug:
        print(f"[INFO] loaded sheet={sheet!r} from {xlsx_path}, shape={df.shape}", file=sys.stderr)

    # Normalise column names
    df.columns = [str(c).strip() for c in df.columns]
    df["Month"] = pd.to_datetime(df["Month"], errors="coerce")

    # Replace em-dash / dash placeholders with NaN for numeric cols
    for col in ["P10", "P90"]:
        if col in df.columns:
            df[col] = pd.to_numeric(
                df[col].astype(str).replace({"\u2014": "", "—": "", "-": "", "": ""}),
                errors="coerce",
            )

    df["Avg (USD/oz)"] = pd.to_numeric(df["Avg (USD/oz)"], errors="coerce")

    # Split into actual vs forecast
    actual = df[df["Type"].str.strip().str.lower() == "actual"].copy()
    forecast = df[df["Type"].str.strip().str.lower().str.startswith("forecast")].copy()

    if debug:
        print(f"[INFO] actual rows={len(actual)}, forecast rows={len(forecast)}", file=sys.stderr)
        print(df.to_string(), file=sys.stderr)

    # ---- Plot ----
    import matplotlib.patches as mpatches

    fig, ax = plt.subplots(figsize=(12, 6))

    all_months = df["Month"].tolist()
    x_positions = list(range(len(all_months)))
    bar_width = 0.55
    n_actual = len(actual)

    # --- Actual months: dots only ---
    if not actual.empty:
        actual_x = list(range(n_actual))
        actual_y = actual["Avg (USD/oz)"].tolist()
        ax.plot(actual_x, actual_y, "o", color="#1f77b4", markersize=7, zorder=5, label="Actual avg")

    # --- Forecast months: box-plot intervals ---
    for i, (_, row) in enumerate(forecast.iterrows()):
        xi = n_actual + (i if isinstance(i, int) else list(forecast.index).index(i))
        # recalculate xi based on position in forecast
        pass

    fc_indices = list(range(n_actual, n_actual + len(forecast)))
    for j, (_, row) in enumerate(forecast.iterrows()):
        xi = fc_indices[j]
        avg = row["Avg (USD/oz)"]
        p10 = row["P10"] if pd.notna(row["P10"]) else None
        p90 = row["P90"] if pd.notna(row["P90"]) else None

        if p10 is not None and p90 is not None:
            q1 = p10 + (avg - p10) * 0.4
            q3 = avg + (p90 - avg) * 0.4

            # Box (IQR-like region)
            rect = mpatches.FancyBboxPatch(
                (xi - bar_width / 2, q1), bar_width, q3 - q1,
                boxstyle="round,pad=0.02",
                facecolor="#87CEEB", edgecolor="black", linewidth=1.2,
            )
            ax.add_patch(rect)

            # Avg line inside box (green dashed)
            ax.plot([xi - bar_width / 2, xi + bar_width / 2], [avg, avg],
                    color="#2ca02c", linewidth=1.5, linestyle="--")

            # Whiskers
            ax.plot([xi, xi], [p10, q1], color="black", linewidth=1.2)
            ax.plot([xi, xi], [q3, p90], color="black", linewidth=1.2)

            # Caps
            cap_w = bar_width * 0.4
            ax.plot([xi - cap_w / 2, xi + cap_w / 2], [p10, p10], color="black", linewidth=1.5)
            ax.plot([xi - cap_w / 2, xi + cap_w / 2], [p90, p90], color="black", linewidth=1.5)

            # Avg dot
            ax.plot(xi, avg, "ko", markersize=4, zorder=5)

    # --- Trend line connecting all avg values (actual + forecast) ---
    all_x = list(range(len(all_months)))
    all_avg = df["Avg (USD/oz)"].tolist()
    # Solid for actual, dashed for forecast, with a bridge
    if not actual.empty:
        ax.plot(list(range(n_actual)), all_avg[:n_actual],
                linewidth=1.5, color="#1f77b4", alpha=0.6, zorder=3)
    if not forecast.empty:
        fc_x = list(range(n_actual, len(all_months)))
        ax.plot(fc_x, all_avg[n_actual:],
                linewidth=1.5, linestyle="--", color="#ff7f0e", alpha=0.6, zorder=3)
    # Bridge between last actual and first forecast
    if not actual.empty and not forecast.empty:
        ax.plot([n_actual - 1, n_actual], [all_avg[n_actual - 1], all_avg[n_actual]],
                linewidth=1.5, linestyle="--", color="gray", alpha=0.5, zorder=3)

    # --- X-axis ---
    month_labels = [m.strftime("%b-%y") for m in all_months]
    ax.set_xticks(x_positions)
    ax.set_xticklabels(month_labels, rotation=45, ha="right", fontsize=9)

    # Divider
    if n_actual > 0 and not forecast.empty:
        ax.axvline(x=n_actual - 0.5, color="gray", linewidth=1, linestyle=":", alpha=0.6)
        ylim = ax.get_ylim()
        ax.text(n_actual - 0.7, ylim[1] * 0.97, "Actual", ha="right", fontsize=9, color="gray")
        ax.text(n_actual - 0.3, ylim[1] * 0.97, "Forecast", ha="left", fontsize=9, color="gray")

    ax.set_title(title, fontsize=13, fontweight="bold")
    ax.set_xlabel("Month")
    ax.set_ylabel("Silver price (USD/oz)")
    ax.grid(True, axis="y", alpha=0.25)

    # Legend
    legend_elements = [
        plt.Line2D([0], [0], marker="o", color="#1f77b4", linestyle="-",
                   markersize=7, linewidth=1.5, label="Actual avg"),
        plt.Line2D([0], [0], color="#ff7f0e", linestyle="--", linewidth=1.5, label="Forecast avg trend"),
        mpatches.Patch(facecolor="#87CEEB", edgecolor="black", label="P10\u2013P90 range"),
        plt.Line2D([0], [0], color="black", linewidth=1.2, label="Whiskers (P10/P90)"),
    ]
    ax.legend(handles=legend_elements, loc="upper left", fontsize=9)
    fig.tight_layout()

    plt.show()
    plt.close(fig)

    # Preview (no file saved)
    out_csv_df = df[["Month", "Type", "Avg (USD/oz)", "P10", "P90"]].copy()
    out_csv_df["Month"] = out_csv_df["Month"].dt.strftime("%Y-%m")
    print("\n[DATA PREVIEW]")
    print(out_csv_df.to_string(index=False))


def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(description="Auto-generate Silver monthly history + forecast band (World Bank Pink Sheet).")
    ap.add_argument("--hist_start", default="2025-04", help="Historical start YYYY-MM (inclusive).")
    ap.add_argument("--hist_end", default="2026-01", help="Historical end YYYY-MM (inclusive).")
    ap.add_argument("--forecast_end", default="2026-09", help="Forecast end YYYY-MM (inclusive).")
    ap.add_argument("--n_sims", type=int, default=30000, help="Monte Carlo simulations for bands.")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--lookback_months", type=int, default=120, help="How many months of history to use for returns.")
    ap.add_argument("--cache_dir", default=os.path.join(os.path.expanduser("~"), ".cache", "wb_pinksheet"),
                    help="Cache directory for downloaded XLSX.")
    ap.add_argument("--out_csv", default="silver_monthly_table.csv")
    ap.add_argument("--out_png", default="silver_monthly_plot.png")
    ap.add_argument("--title", default="Silver (USD/oz): Historical monthly avg + forecast P10\u2013P90 band")
    ap.add_argument("--debug", action="store_true")
    ap.add_argument("--no_show", action="store_true", help="Do not display interactive plot window.")
    ap.add_argument("--from_spreadsheet", default=None,
                    help="Path to pidsg26Evaluation12.xlsx — read 'price' sheet and plot as-is (skips WB download).")
    ap.add_argument("--plot_comparison", action="store_true",
                    help="Render comparison plot (price.py vs this script) before main pipeline.")
    ap.add_argument("--fetch_news", action="store_true",
                    help="Fetch related silver/commodity news from selected credible sources.")
    ap.add_argument("--news_only", action="store_true",
                    help="Fetch news only, write CSV, then exit.")
    ap.add_argument("--news_out_csv", default="silver_related_news.csv",
                    help="Output CSV path for scraped news rows.")
    ap.add_argument("--news_query", default="silver price precious metals commodity market",
                    help="Base query terms used for each news source.")
    ap.add_argument("--news_sources", default="all",
                    help="Comma-separated source names (or 'all'): Reuters,Bloomberg,CNBC,Financial Times,Wall Street Journal,World Bank")
    ap.add_argument("--news_keywords", default="silver,precious metal,bullion,commodity",
                    help="Comma-separated relevance keywords used to filter RSS items.")
    ap.add_argument("--news_per_source", type=int, default=20,
                    help="Maximum RSS items to retain per source before merge.")
    ap.add_argument("--news_max_items", type=int, default=80,
                    help="Maximum total news items in final CSV after merge + dedupe.")
    ap.add_argument("--news_max_age_days", type=int, default=45,
                    help="Drop items older than this many days when pubDate is available (<=0 disables age filter).")
    args = ap.parse_args(argv)

    today = dt.date.today()
    print(f"[INFO] today={today.isoformat()}")

    # Optional news scrape (same script, no extra module/env)
    if args.fetch_news or args.news_only:
        scrape_news_and_print_preview(
            out_csv=args.news_out_csv,
            base_query=args.news_query,
            news_sources=args.news_sources,
            news_keywords=args.news_keywords,
            news_per_source=args.news_per_source,
            news_max_items=args.news_max_items,
            news_max_age_days=args.news_max_age_days,
            debug=args.debug,
        )
    if args.news_only:
        return 0

    if args.plot_comparison:
        plot_comparison_with_price_py()

    # --- If spreadsheet path provided, plot directly from it and exit ---
    if args.from_spreadsheet is None:
        # Auto-detect default spreadsheet location
        default_xlsx = os.path.join(os.path.dirname(__file__), "data", "pidsg26Evaluation12.xlsx")
        if os.path.exists(default_xlsx):
            args.from_spreadsheet = default_xlsx

    if args.from_spreadsheet:
        plot_from_spreadsheet(
            args.from_spreadsheet,
            out_png=args.out_png,
            out_csv=args.out_csv,
            title=args.title,
            show=(not args.no_show),
            debug=args.debug,
        )
        return 0

    # --- Original WB download + forecast path (fallback) ---

    # 1) Download XLSX (with cache failover)
    xlsx_bytes = load_xlsx_with_cache(args.cache_dir, debug=args.debug)

    # 2) Parse monthly silver series robustly
    wb = retry(
        lambda: load_worldbank_silver_monthly_robust(xlsx_bytes, debug=args.debug),
        tries=3,
        label="parse WB XLSX",
    )
    if wb.empty:
        raise RuntimeError("Parsed WB series is empty unexpectedly.")

    # 3) Build historical slice (as requested)
    hist_start = parse_ym(args.hist_start)
    hist_end = parse_ym(args.hist_end)
    hist_months = month_range(hist_start, hist_end)

    hist_df = wb[wb["month"].isin(hist_months)].copy()
    # If WB is missing some requested months (rare), don't crash—warn.
    missing = sorted(set(hist_months) - set(hist_df["month"].tolist()))
    if missing:
        print(f"[WARN] missing {len(missing)} historical months in WB file (example: {missing[:3]})", file=sys.stderr)

    hist_df = hist_df.rename(columns={"price": "avg"})
    hist_df["type"] = "historical"
    hist_df["p10"] = np.nan
    hist_df["p50"] = np.nan
    hist_df["p90"] = np.nan
    hist_df["mean"] = np.nan

    # 4) Forecast months: current month -> forecast_end
    fc_end = parse_ym(args.forecast_end)
    this_month = dt.date(today.year, today.month, 1)
    fc_months = month_range(this_month, fc_end)

    # Use last available WB monthly price as starting point
    last_row = wb.dropna(subset=["price"]).iloc[-1]
    last_month = pd.Timestamp(last_row["month"]).to_pydatetime().date()
    last_price = float(last_row["price"])
    if args.debug:
        print(f"[INFO] last_WB_month={last_month} last_WB_price={last_price:.4f}", file=sys.stderr)

    fc = bootstrap_forecast(
        last_price=last_price,
        monthly_prices=wb.set_index("month")["price"],
        future_months=fc_months,
        n_sims=args.n_sims,
        seed=args.seed,
        lookback_months=args.lookback_months,
        debug=args.debug,
    )
    fc["type"] = "forecast"

    # For a single table, treat forecast "avg" as P50 (median path)
    fc["avg"] = fc["p50"]

    # 5) Combine table and write CSV
    out = pd.concat(
        [
            hist_df[["month", "type", "avg", "p10", "p50", "p90", "mean"]],
            fc[["month", "type", "avg", "p10", "p50", "p90", "mean"]],
        ],
        ignore_index=True,
    ).sort_values("month").reset_index(drop=True)

    # Preview (no file saved)
    out_csv = out.copy()
    out_csv["month"] = out_csv["month"].dt.strftime("%Y-%m")

    # 6) Plot (no save)
    plot_table(out, title=args.title, out_path=args.out_png, show=(not args.no_show), debug=args.debug)

    # 7) Print preview (tail)
    print("\n[TAIL PREVIEW]")
    print(out_csv.tail(18).to_string(index=False))

    return 0


def plot_comparison_with_price_py() -> None:
    """
    Comparison plot: overlay data from price.py sources and
    price_external_only.py sources on the same axes for visual
    inspection of whether values match.

    price.py uses:
      - pidsg25-05_historical.xlsx sheet 'p1normal' → scenario mean  (label: price-25-08)
      - pidsg26Evaluation12.xlsx sheet '12' col 'price-unhedged' * 31.104  (label: price-25-12)
      - pidsg26Evaluation12.xlsx sheet '12' col 'price as of 25/01' * 31.104  (label: Price-26-01)

    price_external_only.py uses:
      - pidsg26Evaluation12.xlsx last sheet ('price') col 'Avg (USD/oz)'
    """
    base_dir = os.path.dirname(__file__)
    eval_xlsx = os.path.join(base_dir, "data", "pidsg26Evaluation12.xlsx")
    hist_xlsx = os.path.join(base_dir, "data", "pidsg25-05_historical.xlsx")

    GM_TO_TOZ = 31.104

    # ── A) Data as price.py loads it ──────────────────────────────────
    # 1) Scenario mean from p1normal (fiscal months 4–11 → Aug-25..Mar-26)
    df_hist = pd.read_excel(hist_xlsx, sheet_name="p1normal", engine="openpyxl")
    df_filt = df_hist[(df_hist["time"] >= 4) & (df_hist["time"] <= 11)].copy()
    pcols = [c for c in df_hist.columns if c != "time"]
    scenario_mean = np.mean(df_filt[pcols].values, axis=1)

    fy_to_cal = {4: "2025-08", 5: "2025-09", 6: "2025-10", 7: "2025-11",
                 8: "2025-12", 9: "2026-01", 10: "2026-02", 11: "2026-03"}
    months_a = [pd.Timestamp(fy_to_cal[m]) for m in df_filt["time"].values]

    # 2) price-25-12  and  Price-26-01  from evaluation sheet '12'
    df12 = pd.read_excel(eval_xlsx, sheet_name="12", engine="openpyxl")
    dates_12 = pd.to_datetime(df12["date"])
    price_2512 = df12["price-unhedged"].values * GM_TO_TOZ   # as price.py does
    price_2601 = df12["price as of 25/01"].values * GM_TO_TOZ

    # Limit to Aug-25..Mar-26 (fiscal months 4-11)
    mask_12 = (dates_12 >= "2025-08-01") & (dates_12 <= "2026-03-01")
    dates_12_filt = dates_12[mask_12].values
    price_2512_filt = price_2512[mask_12]
    price_2601_filt = price_2601[mask_12]

    # ── B) Data as price_external_only.py loads it ────────────────────
    xls = pd.ExcelFile(eval_xlsx, engine="openpyxl")
    df_ext = pd.read_excel(eval_xlsx, sheet_name=xls.sheet_names[-1], engine="openpyxl")
    df_ext.columns = [str(c).strip() for c in df_ext.columns]
    df_ext["Month"] = pd.to_datetime(df_ext["Month"], errors="coerce")
    df_ext["Avg (USD/oz)"] = pd.to_numeric(df_ext["Avg (USD/oz)"], errors="coerce")
    # Limit to Aug-25..Mar-26
    mask_ext = (df_ext["Month"] >= "2025-08-01") & (df_ext["Month"] <= "2026-03-01")
    df_ext_filt = df_ext[mask_ext]

    # ── C) Plot ───────────────────────────────────────────────────────
    fig, ax = plt.subplots(figsize=(13, 6))

    # price.py series
    ax.plot(months_a, scenario_mean, "b-o", linewidth=2, markersize=7,
            label="price.py: scenario mean (price-25-08)")
    ax.plot(dates_12_filt, price_2512_filt, "r-s", linewidth=2, markersize=7,
            label="price.py: price-25-12 (unhedged×31.104)")
    ax.plot(dates_12_filt, price_2601_filt, "g-D", linewidth=2, markersize=7,
            label="price.py: Price-26-01 (jan25×31.104)")

    # price_external_only.py series
    ax.plot(df_ext_filt["Month"].values, df_ext_filt["Avg (USD/oz)"].values,
            "k--^", linewidth=2.5, markersize=8,
            label="Price-26-02")

    ax.set_xlabel("Month", fontsize=12)
    ax.set_ylabel("Price ($/toz)", fontsize=12)
    ax.set_title("Comparison: price.py vs price_external_only.py values (Aug-25 to Mar-26)",
                 fontsize=13, fontweight="bold")
    ax.legend(loc="upper left", fontsize=9)
    ax.grid(True, alpha=0.3, linestyle="--")
    fig.autofmt_xdate()
    fig.tight_layout()

    # Print a numeric table to console for easy inspection
    print("\n=== Numeric comparison (Aug-25 to Mar-26) ===")
    print(f"{'Month':<10} {'Scen.Mean':>10} {'p25-12':>10} {'P26-01':>10} {'P26-02':>10}")
    ext_lookup = dict(zip(df_ext_filt["Month"].dt.strftime("%Y-%m"), df_ext_filt["Avg (USD/oz)"]))
    for i, m in enumerate(months_a):
        mstr = m.strftime("%Y-%m")
        sm = scenario_mean[i]
        p12 = price_2512_filt[i] if i < len(price_2512_filt) else float("nan")
        p01 = price_2601_filt[i] if i < len(price_2601_filt) else float("nan")
        ea = ext_lookup.get(mstr, float("nan"))
        print(f"{mstr:<10} {sm:>10.2f} {p12:>10.2f} {p01:>10.2f} {ea:>10.2f}")

    plt.show()
    plt.close(fig)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("\n[ABORTED] by user", file=sys.stderr)
        raise SystemExit(130)
    except Exception as e:
        print(f"\n[ERROR] {e}", file=sys.stderr)
        raise SystemExit(1)
