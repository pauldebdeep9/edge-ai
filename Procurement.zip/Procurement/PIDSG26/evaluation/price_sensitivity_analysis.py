#!/usr/bin/env python3
"""
Sensitivity analysis: How does Cap-SAA advantage over Manual change
when unhedged prices increase (especially Dec-Mar)?
"""

import numpy as np
import pandas as pd
import cvxpy as cp
from pathlib import Path
import matplotlib.pyplot as plt

# Import from reoptimize2601
from reoptimize2601 import (
    load_eval_data, 
    reoptimize_unhedged_with_inventory_band,
    compute_inventory_series,
    choose_solver,
    COLUMN_MAP,
    EXCEL_PATH,
    SHEET_NAME,
    I0,
    HOLDING_COST,
    K_LOCK,
    KEEP_TOTAL,
    INV_MONTHS_MIN,
    INV_MONTHS_MAX,
    INV_MONTHS_DENOM,
    INV_MONTHS_PENALTY,
)

CAPACITY_UNHEDGED = 20000.0


def calculate_total_cost(q_hedged, q_unhedged, demand, price_hedged, price_unhedged, I0_val):
    """Calculate total cost for a given strategy."""
    # Procurement cost
    procurement_cost = np.sum(price_hedged * q_hedged) + np.sum(price_unhedged * q_unhedged)
    
    # Inventory and holding cost
    inventory = compute_inventory_series(q_hedged, q_unhedged, demand, I0_val)
    holding_cost = HOLDING_COST * np.sum(inventory)
    
    total_cost = procurement_cost + holding_cost
    
    return {
        'procurement_cost': procurement_cost,
        'holding_cost': holding_cost,
        'total_cost': total_cost,
        'inventory': inventory
    }


def run_sensitivity_analysis(price_increase_pct_range, months_to_increase):
    """
    Run sensitivity analysis by varying price increases.
    
    Args:
        price_increase_pct_range: List of percentage increases to test (e.g., [0, 5, 10, 15, 20])
        months_to_increase: List of month indices to increase (0-indexed, e.g., [7,8,9,10] for Dec-Mar)
    """
    # Load base data
    df = load_eval_data(EXCEL_PATH, SHEET_NAME, COLUMN_MAP)
    
    # Extract base data
    q_hedged = df[COLUMN_MAP["q_hedged"]].to_numpy(float)
    q_unhedged_saa = df[COLUMN_MAP["q_unhedged"]].to_numpy(float)
    q_manual_unhedged = df[COLUMN_MAP["q_manual_unhedged"]].to_numpy(float)
    demand = df[COLUMN_MAP["demand"]].to_numpy(float)
    price_hedged = df[COLUMN_MAP["price_hedged"]].to_numpy(float)
    price_unhedged_base = df[COLUMN_MAP["price_unhedged"]].to_numpy(float)
    
    solver = choose_solver()
    capacity = np.full(len(demand), float(CAPACITY_UNHEDGED))
    
    results = []
    
    print("="*100)
    print("PRICE SENSITIVITY ANALYSIS: Cap-SAA vs Manual")
    print("="*100)
    print(f"\nAnalyzing price changes in months: {[df[COLUMN_MAP['date']].iloc[i].strftime('%b-%y') for i in months_to_increase]}")
    print(f"Testing price change percentages: {price_increase_pct_range}% (negative = drops, positive = increases)\n")
    
    for pct_increase in price_increase_pct_range:
        # Create modified price vector
        price_unhedged = price_unhedged_base.copy()
        if pct_increase != 0:
            for month_idx in months_to_increase:
                price_unhedged[month_idx] *= (1 + pct_increase / 100)
        
        # Calculate Manual strategy cost (with FIXED manual provisioning)
        manual_results = calculate_total_cost(
            q_hedged, q_manual_unhedged, demand, price_hedged, price_unhedged, I0_val=0.0
        )
        
        # Calculate Cap-SAA cost (with FIXED Cap-SAA provisioning from base case)
        # NOTE: We do NOT reoptimize - we use the original Cap-SAA quantities
        capsaa_results = calculate_total_cost(
            q_hedged, q_unhedged_saa, demand, price_hedged, price_unhedged, I0_val=I0
        )
        
        # Calculate savings
        procurement_saving = manual_results['procurement_cost'] - capsaa_results['procurement_cost']
        holding_saving = manual_results['holding_cost'] - capsaa_results['holding_cost']
        total_saving = manual_results['total_cost'] - capsaa_results['total_cost']
        
        pct_total_saving = (total_saving / manual_results['total_cost']) * 100
        
        results.append({
            'price_increase_pct': pct_increase,
            'manual_procurement': manual_results['procurement_cost'],
            'manual_holding': manual_results['holding_cost'],
            'manual_total': manual_results['total_cost'],
            'capsaa_procurement': capsaa_results['procurement_cost'],
            'capsaa_holding': capsaa_results['holding_cost'],
            'capsaa_total': capsaa_results['total_cost'],
            'procurement_saving': procurement_saving,
            'holding_saving': holding_saving,
            'total_saving': total_saving,
            'pct_total_saving': pct_total_saving,
        })
        
        # Print results for this scenario
        print(f"\n{'─'*100}")
        if pct_increase > 0:
            print(f"Price Increase: +{pct_increase}% in Dec-25 to Mar-26")
        elif pct_increase < 0:
            print(f"Price Decrease: {pct_increase}% in Dec-25 to Mar-26")
        else:
            print(f"Baseline (No Price Change) in Dec-25 to Mar-26")
        print(f"{'─'*100}")
        if pct_increase != 0:
            print(f"Modified prices for affected months:")
            for month_idx in months_to_increase:
                print(f"  {df[COLUMN_MAP['date']].iloc[month_idx].strftime('%b-%y')}: "
                      f"${price_unhedged_base[month_idx]:.4f} → ${price_unhedged[month_idx]:.4f} "
                      f"(+${price_unhedged[month_idx] - price_unhedged_base[month_idx]:.4f})")
        
        print(f"\nManual Strategy:")
        print(f"  Procurement Cost: ${manual_results['procurement_cost']:,.2f}")
        print(f"  Holding Cost:     ${manual_results['holding_cost']:,.2f}")
        print(f"  Total Cost:       ${manual_results['total_cost']:,.2f}")
        
        print(f"\nCap-SAA Strategy:")
        print(f"  Procurement Cost: ${capsaa_results['procurement_cost']:,.2f}")
        print(f"  Holding Cost:     ${capsaa_results['holding_cost']:,.2f}")
        print(f"  Total Cost:       ${capsaa_results['total_cost']:,.2f}")
        
        print(f"\nCap-SAA Savings vs Manual:")
        print(f"  Procurement Saving: ${procurement_saving:,.2f} ({(procurement_saving/manual_results['procurement_cost']*100):.2f}%)")
        print(f"  Holding Saving:     ${holding_saving:,.2f} ({(holding_saving/manual_results['holding_cost']*100):.2f}%)")
        print(f"  TOTAL SAVING:       ${total_saving:,.2f} ({pct_total_saving:.2f}%)")
    
    return pd.DataFrame(results), df


def plot_sensitivity_results(results_df, df):
    """Plot sensitivity analysis results."""
    
    # Figure 1: Total Cost Comparison
    fig1 = plt.figure(figsize=(10, 6))
    ax1 = fig1.add_subplot(111)
    ax1.plot(results_df['price_increase_pct'], results_df['manual_total'], 
             marker='o', linewidth=2, label='Manual', color='green', markersize=8)
    ax1.plot(results_df['price_increase_pct'], results_df['capsaa_total'], 
             marker='s', linewidth=2, label='Cap-SAA', color='darkorange', markersize=8)
    ax1.set_xlabel('Price Change in Dec-Mar (%)', fontsize=12)
    ax1.set_ylabel('Total Cost ($)', fontsize=12)
    ax1.set_title('Total Cost vs Price Change', fontsize=14, fontweight='bold')
    ax1.legend(fontsize=11)
    ax1.grid(True, alpha=0.3)
    ax1.axvline(x=0, color='gray', linestyle='--', alpha=0.3)
    plt.tight_layout()
    
    # Figure 2: Cost Savings
    fig2 = plt.figure(figsize=(10, 6))
    ax2 = fig2.add_subplot(111)
    ax2.plot(results_df['price_increase_pct'], results_df['total_saving'], 
             marker='D', linewidth=2, color='purple', markersize=8)
    ax2.set_xlabel('Price Change in Dec-Mar (%)', fontsize=12)
    ax2.set_ylabel('Cap-SAA Total Savings vs Manual ($)', fontsize=12)
    ax2.set_title('Cost Savings vs Price Change', fontsize=14, fontweight='bold')
    ax2.grid(True, alpha=0.3)
    ax2.axhline(y=0, color='red', linestyle='--', alpha=0.5)
    ax2.axvline(x=0, color='gray', linestyle='--', alpha=0.3)
    plt.tight_layout()
    
    # Figure 3: Percentage Savings
    fig3 = plt.figure(figsize=(10, 6))
    ax3 = fig3.add_subplot(111)
    ax3.plot(results_df['price_increase_pct'], results_df['pct_total_saving'], 
             marker='*', linewidth=2, color='blue', markersize=10)
    ax3.set_xlabel('Price Change in Dec-Mar (%)', fontsize=12)
    ax3.set_ylabel('Cap-SAA Savings (%)', fontsize=12)
    ax3.set_title('Percentage Cost Savings vs Price Change', fontsize=14, fontweight='bold')
    ax3.grid(True, alpha=0.3)
    ax3.axhline(y=0, color='red', linestyle='--', alpha=0.5)
    ax3.axvline(x=0, color='gray', linestyle='--', alpha=0.3)
    plt.tight_layout()
    
    # Figure 4: Procurement vs Holding Savings
    fig4 = plt.figure(figsize=(10, 6))
    ax4 = fig4.add_subplot(111)
    x = np.arange(len(results_df))
    width = 0.35
    
    # Calculate percentage savings (base = Manual costs)
    pct_procurement_saving = (results_df['procurement_saving'] / results_df['manual_procurement']) * 100
    pct_holding_saving = (results_df['holding_saving'] / results_df['manual_holding']) * 100
    
    ax4.bar(x - width/2, pct_procurement_saving, width, 
            label='Procurement Saving', color='steelblue', alpha=0.7)
    ax4.bar(x + width/2, pct_holding_saving, width, 
            label='Holding Saving', color='coral', alpha=0.7)
    ax4.set_xlabel('Price Change in Dec-Mar (%)', fontsize=12)
    ax4.set_ylabel('Savings (% of Manual Cost)', fontsize=12)
    ax4.set_title('Breakdown: Procurement vs Holding Savings', fontsize=14, fontweight='bold')
    ax4.set_xticks(x)
    ax4.set_xticklabels(results_df['price_increase_pct'])
    ax4.legend(fontsize=11)
    ax4.grid(True, alpha=0.3, axis='y')
    ax4.axhline(y=0, color='black', linestyle='-', linewidth=0.8)
    # Add vertical line at baseline (0% change)
    baseline_idx = results_df[results_df['price_increase_pct'] == 0].index[0]
    ax4.axvline(x=baseline_idx, color='gray', linestyle='--', alpha=0.3)
    plt.tight_layout()
    
    plt.show()


def rigorous_monte_carlo_evaluation(n_scenarios=10000, seed=42):
    """
    Generate 10k random price scenarios with average price changes between -10% to +30%.
    For each scenario, compute procurement cost for both Cap-SAA and Manual provisioning
    without changing the order quantities (use fixed provisioning from base case).
    
    IMPORTANT: Only prices in Dec-Mar (months 8-11) are varied. Historical prices remain fixed.
    
    Args:
        n_scenarios: Number of random price scenarios to generate
        seed: Random seed for reproducibility
    
    Returns:
        Dictionary with results and statistics
    """
    np.random.seed(seed)
    
    # Load base data
    df = load_eval_data(EXCEL_PATH, SHEET_NAME, COLUMN_MAP)
    
    # Extract base data
    q_hedged = df[COLUMN_MAP["q_hedged"]].to_numpy(float)
    q_unhedged_saa = df[COLUMN_MAP["q_unhedged"]].to_numpy(float)
    q_manual_unhedged = df[COLUMN_MAP["q_manual_unhedged"]].to_numpy(float)
    demand = df[COLUMN_MAP["demand"]].to_numpy(float)
    price_hedged = df[COLUMN_MAP["price_hedged"]].to_numpy(float)
    price_unhedged_base = df[COLUMN_MAP["price_unhedged"]].to_numpy(float)
    
    n_months = len(demand)
    
    # Dec-Mar are months 8-11 (0-indexed: 0=Apr-25, ..., 8=Dec-25, 11=Mar-26)
    future_months = [8, 9, 10, 11]
    
    results = []
    
    print("\n" + "="*100)
    print("RIGOROUS MONTE CARLO EVALUATION (10K SCENARIOS)")
    print("="*100)
    print(f"\nGenerating {n_scenarios:,} random price scenarios...")
    print(f"Average price change range: -10% to +30%")
    print(f"ONLY varying prices in: {[df[COLUMN_MAP['date']].iloc[i].strftime('%b-%y') for i in future_months]}")
    print(f"Historical prices (Apr-Nov): FIXED")
    print(f"Fixed provisioning: Cap-SAA and Manual orders from base case")
    print("="*100)
    
    for scenario_idx in range(n_scenarios):
        # Generate random average price change between -10% and +30%
        avg_price_change_pct = np.random.uniform(-10, 30)
        
        # Generate individual month price changes for Dec-Mar around the average
        # Using normal distribution with mean = avg_price_change and std = 10%
        future_price_changes_pct = np.random.normal(avg_price_change_pct, 10, size=len(future_months))
        
        # Create modified price vector (start with base prices)
        price_unhedged_scenario = price_unhedged_base.copy()
        
        # Only modify prices for future months (Dec-Mar)
        for idx, month_idx in enumerate(future_months):
            price_unhedged_scenario[month_idx] = price_unhedged_base[month_idx] * (1 + future_price_changes_pct[idx] / 100)
        
        # Calculate Manual strategy cost (with FIXED manual provisioning)
        manual_results = calculate_total_cost(
            q_hedged, q_manual_unhedged, demand, price_hedged, price_unhedged_scenario, I0_val=0.0
        )
        
        # Calculate Cap-SAA cost (with FIXED Cap-SAA provisioning from base case)
        capsaa_results = calculate_total_cost(
            q_hedged, q_unhedged_saa, demand, price_hedged, price_unhedged_scenario, I0_val=I0
        )
        
        # Calculate savings
        procurement_saving = manual_results['procurement_cost'] - capsaa_results['procurement_cost']
        holding_saving = manual_results['holding_cost'] - capsaa_results['holding_cost']
        total_saving = manual_results['total_cost'] - capsaa_results['total_cost']
        
        pct_total_saving = (total_saving / manual_results['total_cost']) * 100 if manual_results['total_cost'] > 0 else 0
        
        results.append({
            'scenario': scenario_idx + 1,
            'avg_price_change_pct': avg_price_change_pct,
            'manual_procurement': manual_results['procurement_cost'],
            'manual_holding': manual_results['holding_cost'],
            'manual_total': manual_results['total_cost'],
            'capsaa_procurement': capsaa_results['procurement_cost'],
            'capsaa_holding': capsaa_results['holding_cost'],
            'capsaa_total': capsaa_results['total_cost'],
            'procurement_saving': procurement_saving,
            'holding_saving': holding_saving,
            'total_saving': total_saving,
            'pct_total_saving': pct_total_saving,
        })
        
        # Progress update every 1000 scenarios
        if (scenario_idx + 1) % 1000 == 0:
            print(f"Completed {scenario_idx + 1:,} / {n_scenarios:,} scenarios...")
    
    results_df = pd.DataFrame(results)
    
    # Print summary statistics
    print("\n" + "="*100)
    print("SUMMARY STATISTICS ACROSS 10K SCENARIOS")
    print("="*100)
    
    print(f"\nAverage Price Change Range: {results_df['avg_price_change_pct'].min():.2f}% to {results_df['avg_price_change_pct'].max():.2f}%")
    print(f"Mean Average Price Change: {results_df['avg_price_change_pct'].mean():.2f}%")
    
    print(f"\n{'Metric':<30} {'Mean':>15} {'Median':>15} {'Std Dev':>15} {'Min':>15} {'Max':>15}")
    print("-"*100)
    
    metrics = {
        'Total Saving ($)': 'total_saving',
        'Total Saving (%)': 'pct_total_saving',
        'Procurement Saving ($)': 'procurement_saving',
        'Holding Saving ($)': 'holding_saving',
        'Manual Total Cost ($)': 'manual_total',
        'Cap-SAA Total Cost ($)': 'capsaa_total',
    }
    
    for label, col in metrics.items():
        mean_val = results_df[col].mean()
        median_val = results_df[col].median()
        std_val = results_df[col].std()
        min_val = results_df[col].min()
        max_val = results_df[col].max()
        print(f"{label:<30} {mean_val:>15,.2f} {median_val:>15,.2f} {std_val:>15,.2f} {min_val:>15,.2f} {max_val:>15,.2f}")
    
    # Calculate probability of savings
    prob_positive_saving = (results_df['total_saving'] > 0).mean() * 100
    prob_negative_saving = (results_df['total_saving'] < 0).mean() * 100
    prob_zero_saving = (results_df['total_saving'] == 0).mean() * 100
    
    print(f"\n{'Outcome Probabilities':<30}")
    print("-"*100)
    print(f"  Cap-SAA saves money (saving > 0):   {prob_positive_saving:>6.2f}%")
    print(f"  Cap-SAA costs more (saving < 0):    {prob_negative_saving:>6.2f}%")
    print(f"  No difference (saving = 0):         {prob_zero_saving:>6.2f}%")
    
    return results_df


def plot_monte_carlo_results(results_df):
    """Plot Monte Carlo evaluation results - simplified to show only procurement and total cost."""
    
    # Calculate percentage savings
    pct_procurement_saving = (results_df['procurement_saving'] / results_df['manual_procurement']) * 100
    pct_total_saving = (results_df['total_saving'] / results_df['manual_total']) * 100
    
    # Figure 1: Histogram of Procurement Cost Savings (%)
    fig1 = plt.figure(figsize=(12, 6))
    ax1 = fig1.add_subplot(111)
    ax1.hist(pct_procurement_saving, bins=100, color='steelblue', alpha=0.7, edgecolor='black')
    ax1.axvline(x=0, color='red', linestyle='--', linewidth=2, label='Break-even')
    ax1.axvline(x=pct_procurement_saving.mean(), color='green', linestyle='-', linewidth=2, 
                label=f'Mean: {pct_procurement_saving.mean():.2f}%')
    ax1.axvline(x=pct_procurement_saving.median(), color='orange', linestyle='-', linewidth=2, 
                label=f'Median: {pct_procurement_saving.median():.2f}%')
    ax1.set_xlabel('Procurement Cost Savings: Cap-SAA vs Manual (%)', fontsize=12)
    ax1.set_ylabel('Frequency', fontsize=12)
    ax1.set_title('Distribution of Procurement Cost Savings (10K Scenarios)', fontsize=14, fontweight='bold')
    ax1.legend(fontsize=11)
    ax1.grid(True, alpha=0.3, axis='y')
    plt.tight_layout()
    
    # Figure 2: Histogram of Total Cost Savings (%)
    fig2 = plt.figure(figsize=(12, 6))
    ax2 = fig2.add_subplot(111)
    ax2.hist(pct_total_saving, bins=100, color='purple', alpha=0.7, edgecolor='black')
    ax2.axvline(x=0, color='red', linestyle='--', linewidth=2, label='Break-even')
    ax2.axvline(x=pct_total_saving.mean(), color='green', linestyle='-', linewidth=2, 
                label=f'Mean: {pct_total_saving.mean():.2f}%')
    ax2.axvline(x=pct_total_saving.median(), color='orange', linestyle='-', linewidth=2, 
                label=f'Median: {pct_total_saving.median():.2f}%')
    ax2.set_xlabel('Total Cost Savings: Cap-SAA vs Manual (%)', fontsize=12)
    ax2.set_ylabel('Frequency', fontsize=12)
    ax2.set_title('Distribution of Total Cost Savings (10K Scenarios)', fontsize=14, fontweight='bold')
    ax2.legend(fontsize=11)
    ax2.grid(True, alpha=0.3, axis='y')
    plt.tight_layout()
    
    plt.show()


def illustration_procurement_cost_analysis(price_range, n_samples_per_range=10000, seed=42):
    """
    Generate procurement cost analysis across a wider price range for illustration.
    For each price change level, generate n_samples scenarios and show distribution.
    
    Args:
        price_range: List of average price changes to test (e.g., [-50, -40, ..., 0, 10])
        n_samples_per_range: Number of random scenarios per price level
        seed: Random seed for reproducibility
    
    Returns:
        DataFrame with results
    """
    np.random.seed(seed)
    
    # Load base data
    df = load_eval_data(EXCEL_PATH, SHEET_NAME, COLUMN_MAP)
    
    # Extract base data
    q_hedged = df[COLUMN_MAP["q_hedged"]].to_numpy(float)
    q_unhedged_saa = df[COLUMN_MAP["q_unhedged"]].to_numpy(float)
    q_manual_unhedged = df[COLUMN_MAP["q_manual_unhedged"]].to_numpy(float)
    demand = df[COLUMN_MAP["demand"]].to_numpy(float)
    price_hedged = df[COLUMN_MAP["price_hedged"]].to_numpy(float)
    price_unhedged_base = df[COLUMN_MAP["price_unhedged"]].to_numpy(float)
    
    # Dec-Mar are months 8-11
    future_months = [8, 9, 10, 11]
    
    # Holding costs (constant)
    inv_manual = compute_inventory_series(q_hedged, q_manual_unhedged, demand, 0.0)
    holding_manual = HOLDING_COST * np.sum(inv_manual)
    
    inv_capsaa = compute_inventory_series(q_hedged, q_unhedged_saa, demand, I0)
    holding_capsaa = HOLDING_COST * np.sum(inv_capsaa)
    
    results = []
    
    print("\n" + "="*100)
    print(f"ILLUSTRATION: PROCUREMENT COST ANALYSIS ({n_samples_per_range} samples per price level)")
    print("="*100)
    print(f"Price range: {price_range}%")
    print(f"Only varying prices in: {[df[COLUMN_MAP['date']].iloc[i].strftime('%b-%y') for i in future_months]}")
    print("="*100)
    
    for avg_pct in price_range:
        print(f"\nGenerating {n_samples_per_range:,} scenarios for {avg_pct:+.0f}% average price change...")
        
        for sample_idx in range(n_samples_per_range):
            # Generate individual month price changes around the average
            future_price_changes_pct = np.random.normal(avg_pct, 10, size=len(future_months))
            
            # Create modified price vector (start with base prices)
            price_unhedged_scenario = price_unhedged_base.copy()
            
            # Only modify prices for future months (Dec-Mar)
            for idx, month_idx in enumerate(future_months):
                price_unhedged_scenario[month_idx] = price_unhedged_base[month_idx] * (1 + future_price_changes_pct[idx] / 100)
            
            # Calculate costs
            proc_manual = np.sum(price_hedged * q_hedged) + np.sum(price_unhedged_scenario * q_manual_unhedged)
            proc_capsaa = np.sum(price_hedged * q_hedged) + np.sum(price_unhedged_scenario * q_unhedged_saa)
            
            total_manual = proc_manual + holding_manual
            total_capsaa = proc_capsaa + holding_capsaa
            
            procurement_saving = proc_manual - proc_capsaa
            total_saving = total_manual - total_capsaa
            
            results.append({
                'avg_price_change_pct': avg_pct,
                'sample_idx': sample_idx + 1,
                'procurement_saving': procurement_saving,
                'total_saving': total_saving,
                'manual_procurement': proc_manual,
                'capsaa_procurement': proc_capsaa,
                'manual_total': total_manual,
                'capsaa_total': total_capsaa,
            })
    
    results_df = pd.DataFrame(results)
    
    # Summary statistics
    print("\n" + "="*100)
    print("SUMMARY STATISTICS BY PRICE LEVEL")
    print("="*100)
    
    summary = results_df.groupby('avg_price_change_pct').agg({
        'procurement_saving': ['mean', 'median', 'std', 'min', 'max'],
        'total_saving': ['mean', 'median']
    }).round(2)
    
    print(summary)
    
    # Count scenarios where Manual wins
    print("\n" + "="*100)
    print("SCENARIOS WHERE MANUAL BEATS CAP-SAA")
    print("="*100)
    
    for avg_pct in price_range:
        subset = results_df[results_df['avg_price_change_pct'] == avg_pct]
        manual_wins = (subset['total_saving'] < 0).sum()
        total = len(subset)
        pct_wins = manual_wins / total * 100
        print(f"Price change {avg_pct:+4.0f}%: Manual wins {manual_wins:5,} / {total:,} ({pct_wins:5.2f}%)")
    
    return results_df


def plot_illustration_procurement_cost(results_df):
    """Plot procurement cost savings distribution across price ranges."""
    
    # Calculate percentage savings
    pct_total_saving = (results_df['total_saving'] / results_df['manual_total']) * 100
    pct_procurement_saving = (results_df['procurement_saving'] / results_df['manual_procurement']) * 100
    
    # Get unique price levels
    price_levels = sorted(results_df['avg_price_change_pct'].unique())
    
    # Figure 1: Total Cost Savings (%)
    fig1 = plt.figure(figsize=(14, 7))
    ax1 = fig1.add_subplot(111)
    
    # Create box plot data for total cost
    box_data_total = [pct_total_saving[results_df['avg_price_change_pct'] == pct].values 
                      for pct in price_levels]
    
    # Create box plot
    bp1 = ax1.boxplot(box_data_total, labels=[f'{int(pct):+d}%' for pct in price_levels], 
                      patch_artist=True, showmeans=True, meanline=True, widths=0.6)
    
    # Color boxes based on whether mean is positive or negative
    for i, (box, pct) in enumerate(zip(bp1['boxes'], price_levels)):
        mean_saving = pct_total_saving[results_df['avg_price_change_pct'] == pct].mean()
        if mean_saving > 0:
            box.set_facecolor('lightblue')
        else:
            box.set_facecolor('lightcoral')
    
    # Add horizontal line at zero
    ax1.axhline(y=0, color='red', linestyle='--', linewidth=2, alpha=0.7, label='Break-even')
    
    # Labels and title
    ax1.set_xlabel('Average Price Change in Dec-Mar (%)', fontsize=13, fontweight='bold')
    ax1.set_ylabel('Total Cost Saving: (Manual - Cap-SAA) / Manual (%)', fontsize=13, fontweight='bold')
    ax1.set_title('Total Cost Savings Distribution Across Price Scenarios\n(10K samples per price level)', 
                  fontsize=15, fontweight='bold')
    ax1.grid(True, alpha=0.3, axis='y')
    ax1.legend(fontsize=11)
    
    # Add text annotation
    ax1.text(0.02, 0.98, 
            'Blue boxes: Cap-SAA cheaper on average\nRed boxes: Manual cheaper on average',
            transform=ax1.transAxes, fontsize=10, verticalalignment='top',
            bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
    
    plt.tight_layout()
    
    # Figure 2: Procurement Cost Savings (%)
    fig2 = plt.figure(figsize=(14, 7))
    ax2 = fig2.add_subplot(111)
    
    # Create box plot data for procurement cost
    box_data_proc = [pct_procurement_saving[results_df['avg_price_change_pct'] == pct].values 
                     for pct in price_levels]
    
    # Create box plot
    bp2 = ax2.boxplot(box_data_proc, labels=[f'{int(pct):+d}%' for pct in price_levels], 
                      patch_artist=True, showmeans=True, meanline=True, widths=0.6)
    
    # Color boxes based on whether mean is positive or negative
    for i, (box, pct) in enumerate(zip(bp2['boxes'], price_levels)):
        mean_saving = pct_procurement_saving[results_df['avg_price_change_pct'] == pct].mean()
        if mean_saving > 0:
            box.set_facecolor('lightblue')
        else:
            box.set_facecolor('lightcoral')
    
    # Add horizontal line at zero
    ax2.axhline(y=0, color='red', linestyle='--', linewidth=2, alpha=0.7, label='Break-even')
    
    # Labels and title
    ax2.set_xlabel('Average Price Change in Dec-Mar (%)', fontsize=13, fontweight='bold')
    ax2.set_ylabel('Procurement Cost Saving: (Manual - Cap-SAA) / Manual (%)', fontsize=13, fontweight='bold')
    ax2.set_title('Procurement Cost Savings Distribution Across Price Scenarios\n(10K samples per price level)', 
                  fontsize=15, fontweight='bold')
    ax2.grid(True, alpha=0.3, axis='y')
    ax2.legend(fontsize=11)
    
    # Add text annotation
    ax2.text(0.02, 0.98, 
            'Blue boxes: Cap-SAA cheaper on average\nRed boxes: Manual cheaper on average',
            transform=ax2.transAxes, fontsize=10, verticalalignment='top',
            bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
    
    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    # Define sensitivity analysis parameters
    price_increases = [-30, -20, -10, 0, 10, 20, 30]  # Percentage changes to test (negative = price drops)
    
    # Months 8-11 are Dec-25 to Mar-26 (0-indexed: 0=Apr-25, ..., 8=Dec-25, 11=Mar-26)
    affected_months = [8, 9, 10, 11]
    
    # Run analysis
    results_df, df = run_sensitivity_analysis(price_increases, affected_months)
    
    # Summary table
    print("\n" + "="*100)
    print("SUMMARY TABLE")
    print("="*100)
    print(results_df[['price_increase_pct', 'manual_total', 'capsaa_total', 
                      'total_saving', 'pct_total_saving']].to_string(index=False))
    
    # Plot results
    print("\nGenerating sensitivity analysis plots...")
    plot_sensitivity_results(results_df, df)
    
    # ============================================================================
    # RIGOROUS MONTE CARLO EVALUATION (10K SCENARIOS)
    # ============================================================================
    print("\n\n")
    print("#" * 100)
    print("# STARTING RIGOROUS MONTE CARLO EVALUATION")
    print("#" * 100)
    
    # Run Monte Carlo evaluation
    mc_results_df = rigorous_monte_carlo_evaluation(n_scenarios=10000, seed=42)
    
    # Plot Monte Carlo results
    print("\nGenerating Monte Carlo evaluation plots...")
    plot_monte_carlo_results(mc_results_df)
    
    # ============================================================================
    # ILLUSTRATION: PROCUREMENT COST ANALYSIS ACROSS WIDER PRICE RANGE
    # ============================================================================
    print("\n\n")
    print("#" * 100)
    print("# ILLUSTRATION: PROCUREMENT COST ANALYSIS ACROSS WIDER PRICE RANGE")
    print("#" * 100)
    
    # Wider price range for illustration: -50% to +10%
    illustration_price_range = [-50, -40, -30, -20, -10, 0, 10]
    
    # Run illustration analysis
    illustration_df = illustration_procurement_cost_analysis(
        price_range=illustration_price_range, 
        n_samples_per_range=10000, 
        seed=42
    )
    
    # Plot illustration
    print("\nGenerating illustration plot...")
    plot_illustration_procurement_cost(illustration_df)
    
    print("\n" + "="*100)
    print("ALL ANALYSES COMPLETE!")
    print("="*100)
