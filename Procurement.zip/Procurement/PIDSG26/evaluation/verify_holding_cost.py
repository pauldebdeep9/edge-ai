#!/usr/bin/env python3
"""Verify that holding costs are constant with fixed quantities."""

import numpy as np
import pandas as pd
from reoptimize2601 import (
    load_eval_data, compute_inventory_series, 
    COLUMN_MAP, EXCEL_PATH, SHEET_NAME, I0, HOLDING_COST
)

# Load base data
df = load_eval_data(EXCEL_PATH, SHEET_NAME, COLUMN_MAP)

q_hedged = df[COLUMN_MAP['q_hedged']].to_numpy(float)
q_unhedged_saa = df[COLUMN_MAP['q_unhedged']].to_numpy(float)
q_manual_unhedged = df[COLUMN_MAP['q_manual_unhedged']].to_numpy(float)
demand = df[COLUMN_MAP['demand']].to_numpy(float)

# Compute inventory for Manual (I0=0)
inv_manual = compute_inventory_series(q_hedged, q_manual_unhedged, demand, 0.0)
holding_manual = HOLDING_COST * np.sum(inv_manual)

# Compute inventory for Cap-SAA (I0 from config)
inv_capsaa = compute_inventory_series(q_hedged, q_unhedged_saa, demand, I0)
holding_capsaa = HOLDING_COST * np.sum(inv_capsaa)

print(f'Manual holding cost: ${holding_manual:,.2f}')
print(f'Cap-SAA holding cost: ${holding_capsaa:,.2f}')
print(f'Difference: ${holding_manual - holding_capsaa:,.2f}')
print()
print('✓ These holding costs should be CONSTANT across all price scenarios')
print('  since quantities and demand are fixed.')
