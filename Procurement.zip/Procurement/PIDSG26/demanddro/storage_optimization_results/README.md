# Automated Storage Capacity Optimization Results

**Generated:** October 28, 2025  
**Script:** `automated_storage_optimization.py`

---

## Overview

This directory contains results from the **automated storage capacity reoptimization pipeline** that takes McCormick.py's WDRO solution and reoptimizes it with a **storage capacity constraint**.

### Key Constraint
- **Storage Limit (s_max):** 12,000 units (one month's nominal demand)
- **Lead Time:** 0 (orders arrive immediately)
- **Initial Inventory:** 12,000 units

---

## Results Summary

### 💰 Cost Analysis
| Metric | Original (McCormick) | Optimized (Storage Cap) | Savings/Difference |
|--------|---------------------|------------------------|-------------------|
| **Procurement Cost** | $3,908,139 | $3,283,183 | **-$624,956** ✅ |
| **Holding Cost** | — | $64,227 | +$64,227 |
| **Backlog Cost** | — | $256,076 | +$256,076 |
| **Total Objective** | $3,908,139 | $3,603,486 | **-$304,653** ✅ |

### 📦 Order Quantities
| Supplier | Original | Optimized | Change |
|----------|----------|-----------|--------|
| **Hedged** | 80,457 units | 68,046 units | -12,411 units |
| **Unhedged** | 4,083 units | 0 units | -4,083 units |
| **Total** | 84,540 units | 68,046 units | **-16,494 units** |

### 🏗️ Storage Analysis
- **Maximum Storage Used:** 10,530 units (87.8% of capacity)
- **Average Storage:** 1,070 units per period
- **Storage Constraint:** ✅ Respected in all periods

### ⚠️ Backlog
- **Total Backlog:** 5,122 units
- **Periods with Backlog:** 1 out of 12
- **Max Backlog (single period):** 5,122 units

---

## Generated Files

### 📊 Data Files (CSV)
1. **`optimized_orders_with_storage_cap.csv`**
   - Optimized order quantities for both suppliers
   - Columns: `Hedged`, `Unhedged`
   - 12 rows (one per period)

2. **`inventory_trajectory.csv`**
   - Period-by-period inventory dynamics
   - Columns: `Period`, `Net_Stock_S`, `OnHand_P`, `Backlog_N`
   - Shows how inventory evolves over time

3. **`comparison_original_vs_optimized.csv`**
   - Side-by-side comparison of original vs optimized plans
   - Columns: `Period`, `Original_Hedged`, `Original_Unhedged`, `Optimized_Hedged`, `Optimized_Unhedged`, `Demand`, `Storage_OnHand`, `Backlog`

### 📈 Visualization Files (PNG)
1. **`plot1_orders_comparison.png`**
   - Side-by-side bar chart of orders (original vs optimized)
   - Supplier prices shown as dotted lines on secondary axis
   - Shows how orders shift from original McCormick solution

2. **`plot2_storage_vs_cap.png`**
   - Bar chart of on-hand inventory by period
   - Red dashed line shows 12,000 unit storage cap
   - Demonstrates constraint compliance

3. **`plot3_inventory_months.png`**
   - Inventory expressed as "months of coverage"
   - Normalized to 12,000 units/month nominal demand
   - Shows how long current inventory would last

4. **`plot4_cumulative_costs.png`**
   - Cumulative procurement costs over time
   - Compares original vs optimized
   - Shows cost savings progression
   - **Key insight:** $624,956 in procurement savings

5. **`plot5_stock_and_backlog.png`**
   - Two-panel plot:
     - Top: Net stock position (can be positive or negative)
     - Bottom: Backlog over time
   - Shows inventory dynamics and shortfall periods

6. **`plot6_cost_breakdown.png`**
   - Bar chart comparing cost categories
   - Shows procurement (original vs optimized), holding, backlog, and total

---

## Key Insights

### ✅ Strengths of Optimized Solution
1. **Significant Cost Savings:** $304,653 total reduction (7.8% savings)
2. **Storage Constraint Respected:** Never exceeds 12,000 unit limit
3. **Simplified Supply Chain:** Eliminated Unhedged supplier entirely
4. **Reduced Total Orders:** 19.5% fewer units ordered

### ⚠️ Trade-offs
1. **Holding Cost:** $64,227 added (storage has a cost)
2. **Backlog Cost:** $256,076 added (one period of shortage)
3. **Service Level:** One period with backlog (month 12)

### 💡 Recommendations
1. **Storage Management:** Consider investing in storage expansion beyond 12K if cost-effective
2. **Backlog Mitigation:** The single backlog period could be addressed by:
   - Slightly relaxing storage cap in earlier periods
   - Advance ordering in period 11
3. **Supplier Strategy:** Focus relationship on Hedged supplier (Unhedged not needed with storage cap)

---

## Technical Details

### Optimization Model
- **Type:** Lead time = 0 model (immediate arrival)
- **Decision Variables:** Order quantities for both suppliers (both optimized, not fixed)
- **Objective:** Minimize total cost (procurement + holding + backlog)
- **Constraints:**
  - Inventory balance dynamics
  - Storage capacity limit (12,000 units per period)
  - Per-period supplier capacity limits (20,000 units each)
  - Non-negativity of orders

### Solver
- **Solver:** CLARABEL (via CVXPY)
- **Status:** Optimal
- **Computation Time:** < 1 second

### Input Data Sources
- **Orders:** `Order.csv` (from McCormick.py WDRO optimization)
- **Prices:** `Data/pidsg25-26.xlsx` (sheet: 'price')
- **Capacities:** `Data/pidsg25-26.xlsx` (sheet: 'capacity')
- **Demand:** `Data/pidsg25-26.xlsx` (sheet: 'demand', averaged across scenarios)
- **Suppliers:** `Data/pidsg25-26.xlsx` (sheet: 'supplier')

---

## How to Reproduce

Run the automated pipeline:
```bash
python automated_storage_optimization.py
```

The script will:
1. Load McCormick.py results from `Order.csv`
2. Extract data from `Data/pidsg25-26.xlsx`
3. Align data to planning horizon
4. Validate parameters (displays checkpoint)
5. Run optimization with storage constraint
6. Save CSV results
7. Generate summary report
8. Create 6 visualization plots

**Parameters used:**
- Initial Inventory (I0): 12,000 units
- Storage Capacity (s_max): 12,000 units
- Holding Cost (h): $5 per unit per period
- Backlog Cost (b): $50 per unit per period
- Lead Times: 0 for both suppliers (override from original 3)

---

## Next Steps

1. **Review Visualizations:** Examine all 6 plots to understand the optimization results
2. **Validate Against Business Rules:** Check if the optimized plan is operationally feasible
3. **Sensitivity Analysis:** Try different storage caps (e.g., 15,000 or 10,000 units)
4. **Lead Time Analysis:** Re-run with original lead times = 3 to see impact
5. **Multi-Scenario:** Consider running with different demand scenarios

---

## Contact & Support

For questions about this optimization:
- Review the source script: `automated_storage_optimization.py`
- Check the original WDRO model: `McCormick.py`
- Compare with manual optimization: `storage_capacity_up.py`

**Note:** This optimization assumes the storage constraint is binding and critical. If storage cost is low relative to procurement savings, consider increasing the cap or removing it entirely.
