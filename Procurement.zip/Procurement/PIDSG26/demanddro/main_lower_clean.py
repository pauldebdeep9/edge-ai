"""
Automated Storage Lower Bound Reoptimization Pipeline

This script takes McCormick.py WDRO optimization results and re-optimizes with:
1. Minimum storage constraint (6K units safety stock)
2. Forced hedging ratio (75% hedged / 25% unhedged)

WORKFLOW:
1. Load McCormick.py results (Order.csv) and input data (pidsg25-26.xlsx)
2. Run Optimization 2: Min storage ≥6K, preserving McCormick quantities
3. Run Optimization 3: Forced 75% hedged ratio
4. Evaluate McCormick orders with L=0 for fair comparison
5. Generate comprehensive comparison plots

OUTPUTS:
- storage_lower_results/: CSV files and plots
- 11 comparison plots showing all three optimizations

Author: Procurement Optimization Pipeline
Version: 2.0
Date: November 2025
"""

import cvxpy as cp
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

# ============================================================================
# CONFIGURATION
# ============================================================================
INPUT_EXCEL = 'Data/pidsg25-26.xlsx'
MCCORMICK_ORDERS = 'Order.csv'
OUTPUT_DIR = Path('storage_lower_results')
OUTPUT_DIR.mkdir(exist_ok=True)

# Optimization parameters
STORAGE_MIN = 6000.0              # Min safety stock (0.5 months @ 12K/month)
HOLDING_COST = 5.0                # Holding cost for optimizations
BACKLOG_COST = 50.0               # Backlog penalty
INITIAL_INVENTORY = 6000.0        # Starting inventory
MCCORMICK_EVAL_HOLDING_COST = 0.05  # For McCormick evaluation only
OVERRIDE_LEAD_TIME = 0            # Force L=0 for all optimizations
ACTUAL_LEAD_TIME = 3              # For post-processing

# Solver settings
SOLVER = cp.CLARABEL
VERBOSE = False

# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def compute_inventory_trajectory(orders_df, demand, I0, lead_times):
    """
    Compute inventory trajectory considering lead times.
    
    Args:
        orders_df: DataFrame with columns ['s1', 's2'] for orders
        demand: Array of demand values
        I0: Initial inventory
        lead_times: Dict with keys 's1', 's2' mapping to lead time values
    
    Returns:
        inventory: Array of inventory levels
        arrivals: Array of arrivals per period
    """
    T = len(orders_df)
    inventory = np.zeros(T)
    arrivals = np.zeros(T)
    
    for t in range(T):
        # Arrivals from orders placed earlier considering lead time
        for supplier in orders_df.columns:
            if supplier in ['s1', 's2']:
                L = lead_times.get(supplier, 0)
                if t >= L:
                    placement_period = t - L
                    arrivals[t] += orders_df.iloc[placement_period][supplier]
        
        # Inventory dynamics
        if t == 0:
            inventory[t] = I0 + arrivals[t] - demand[t]
        else:
            inventory[t] = max(0, inventory[t-1]) + arrivals[t] - demand[t]
    
    return inventory, arrivals


# ============================================================================
# OPTIMIZATION FUNCTIONS
# ============================================================================

def optimize_min_storage_preserve_quantities(
    Q_star_df, price_df, capacity_df, demand,
    s_min, h, I0, b=50.0, solver=cp.CLARABEL, verbose=False
):
    """
    Optimization 2: Min storage ≥6K, preserving McCormick total quantities
    
    This optimization:
    - Maintains minimum safety stock of s_min units
    - Preserves total hedged and unhedged quantities from McCormick
    - Reschedules orders across time periods for cost efficiency
    - Uses L=0 (immediate arrival) model
    
    Args:
        Q_star_df: McCormick orders with columns ['Hedged', 'Unhedged']
        price_df: Supplier prices
        capacity_df: Supplier capacities
        demand: Demand array
        s_min: Minimum storage constraint
        h: Holding cost per unit per period
        I0: Initial inventory
        b: Backlog cost per unit per period
        solver: CVXPY solver
        verbose: Print solver output
    
    Returns:
        Dictionary with optimization results
    """
    # Validate inputs
    required_cols = ["Hedged", "Unhedged"]
    for df_ in (Q_star_df, price_df, capacity_df):
        if list(df_.columns) != required_cols:
            raise ValueError(f"Columns must be exactly {required_cols}.")
        for c in df_.columns:
            df_[c] = pd.to_numeric(df_[c], errors="coerce")

    d = np.asarray(demand, dtype=float).reshape(-1)
    T = len(Q_star_df)
    if d.size != T:
        raise ValueError("demand length must equal the planning horizon T.")

    # Total quantities to preserve from McCormick solution
    Q_total_hedged = float(Q_star_df["Hedged"].sum())
    Q_total_unhedged = float(Q_star_df["Unhedged"].sum())
    
    print(f"    Preserving total quantities from McCormick:")
    print(f"      Hedged: {Q_total_hedged:,.2f} units")
    print(f"      Unhedged: {Q_total_unhedged:,.2f} units")

    # Prices and capacities
    PH = price_df["Hedged"].to_numpy(float)
    PU = price_df["Unhedged"].to_numpy(float)  
    CH = capacity_df["Hedged"].to_numpy(float)
    CU = capacity_df["Unhedged"].to_numpy(float)

    # Decision variables
    QH = cp.Variable(T, nonneg=True, name="Q_hedged")
    QU = cp.Variable(T, nonneg=True, name="Q_unhedged")
    S  = cp.Variable(T, name="S")  # Net stock
    P  = cp.Variable(T, nonneg=True, name="P")  # On-hand inventory
    N  = cp.Variable(T, nonneg=True, name="N")  # Backlog

    cons = []

    # Inventory dynamics with L=0: orders arrive immediately
    cons += [S[0] == float(I0) + (QH[0] + QU[0]) - d[0]]
    for t in range(1, T):
        cons += [S[t] == S[t-1] + (QH[t] + QU[t]) - d[t]]

    # Storage decomposition: S = P - N
    cons += [S == P - N]

    # *** KEY CONSTRAINT: Minimum storage (safety stock) ***
    cons += [P >= s_min]

    # Per-period capacity constraints
    cons += [QH <= CH]
    cons += [QU <= CU]

    # *** KEY CONSTRAINT: Preserve total quantities from McCormick ***
    cons += [cp.sum(QH) == Q_total_hedged]
    cons += [cp.sum(QU) == Q_total_unhedged]

    # Objective: Minimize total cost
    purchase_cost = cp.sum(cp.multiply(PH, QH)) + cp.sum(cp.multiply(PU, QU))
    holding_cost  = h * cp.sum(P)
    backlog_cost  = b * cp.sum(N)
    obj = cp.Minimize(purchase_cost + holding_cost + backlog_cost)

    # Solve
    prob = cp.Problem(obj, cons)
    prob.solve(solver=solver, verbose=verbose)
    if prob.status not in ("optimal", "optimal_inaccurate"):
        raise RuntimeError(f"Optimization failed: status={prob.status}")

    # Extract solution
    QH_val = np.asarray(QH.value).reshape(-1)
    QU_val = np.asarray(QU.value).reshape(-1)

    return {
        "objective": float(prob.value),
        "Qhat": pd.DataFrame({"Hedged": QH_val, "Unhedged": QU_val}),
        "Theta": pd.DataFrame({"Hedged": QH_val, "Unhedged": QU_val}),  # L=0 means arrivals = orders
        "S": pd.Series(np.asarray(S.value).reshape(-1), name="S"),
        "P": pd.Series(np.asarray(P.value).reshape(-1), name="P"),
        "N": pd.Series(np.asarray(N.value).reshape(-1), name="N"),
        "min_storage": float(np.min(P.value)),
        "max_storage": float(np.max(P.value)),
    }


def optimize_forced_hedging_ratio(
    price_df, capacity_df, demand,
    s_min, h, I0, b, total_hedged, total_unhedged,
    solver=cp.CLARABEL, verbose=False
):
    """
    Optimization 3: Force exactly 75% hedged (25% unhedged)
    
    This optimization:
    - Maintains minimum safety stock of s_min units
    - Forces exact hedging ratio: 75% hedged, 25% unhedged
    - Uses same total quantity as Optimization 2
    - Uses L=0 (immediate arrival) model
    
    Args:
        price_df: Supplier prices
        capacity_df: Supplier capacities
        demand: Demand array
        s_min: Minimum storage constraint
        h: Holding cost per unit per period
        I0: Initial inventory
        b: Backlog cost per unit per period
        total_hedged: Fixed total hedged quantity
        total_unhedged: Fixed total unhedged quantity
        solver: CVXPY solver
        verbose: Print solver output
    
    Returns:
        Dictionary with optimization results
    """
    T = len(price_df)
    d = np.asarray(demand, dtype=float).reshape(-1)
    
    # Prices and capacities
    PH = price_df["Hedged"].to_numpy(float)
    PU = price_df["Unhedged"].to_numpy(float)
    CH = capacity_df["Hedged"].to_numpy(float)
    CU = capacity_df["Unhedged"].to_numpy(float)
    
    # Decision variables
    QH = cp.Variable(T, nonneg=True, name="Q_hedged")
    QU = cp.Variable(T, nonneg=True, name="Q_unhedged")
    S = cp.Variable(T, name="S")
    P = cp.Variable(T, nonneg=True, name="P")
    N = cp.Variable(T, nonneg=True, name="N")
    
    cons = []
    
    # Inventory dynamics with L=0
    cons += [S[0] == float(I0) + (QH[0] + QU[0]) - d[0]]
    for t in range(1, T):
        cons += [S[t] == S[t-1] + (QH[t] + QU[t]) - d[t]]
    
    # Storage decomposition
    cons += [S == P - N]
    
    # Minimum storage constraint
    cons += [P >= s_min]
    
    # Per-period capacity constraints
    cons += [QH <= CH]
    cons += [QU <= CU]
    
    # FORCE total quantities (75% hedged, 25% unhedged)
    cons += [cp.sum(QH) == float(total_hedged)]
    cons += [cp.sum(QU) == float(total_unhedged)]
    
    # Objective
    purchase_cost = cp.sum(cp.multiply(PH, QH)) + cp.sum(cp.multiply(PU, QU))
    holding_cost = h * cp.sum(P)
    backlog_cost = b * cp.sum(N)
    obj = cp.Minimize(purchase_cost + holding_cost + backlog_cost)
    
    # Solve
    prob = cp.Problem(obj, cons)
    prob.solve(solver=solver, verbose=verbose)
    if prob.status not in ("optimal", "optimal_inaccurate"):
        raise RuntimeError(f"Forced hedging optimization failed: status={prob.status}")
    
    # Extract solution
    QH_val = np.asarray(QH.value).reshape(-1)
    QU_val = np.asarray(QU.value).reshape(-1)
    P_val = np.asarray(P.value).reshape(-1)
    N_val = np.asarray(N.value).reshape(-1)
    
    procurement_cost = float((PH * QH_val).sum() + (PU * QU_val).sum())
    storage_cost = float(h * P_val.sum())
    backlog_cost_val = float(b * N_val.sum())
    total_cost = procurement_cost + storage_cost + backlog_cost_val
    
    return {
        "objective": float(prob.value),
        "procurement_cost": procurement_cost,
        "storage_cost": storage_cost,
        "backlog_cost": backlog_cost_val,
        "total_cost": total_cost,
        "Qhat": pd.DataFrame({"Hedged": QH_val, "Unhedged": QU_val}),
        "S": pd.Series(np.asarray(S.value).reshape(-1), name="S"),
        "P": pd.Series(P_val, name="P"),
        "N": pd.Series(N_val, name="N"),
        "min_storage": float(np.min(P_val)),
        "max_storage": float(np.max(P_val)),
        "unhedged_ratio": float(QU_val.sum() / (QH_val.sum() + QU_val.sum())) if (QH_val.sum() + QU_val.sum()) > 0 else 0
    }


# ============================================================================
# MAIN EXECUTION
# ============================================================================

def main():
    """Main execution function"""
    
    print("="*70)
    print("STORAGE LOWER BOUND REOPTIMIZATION PIPELINE")
    print("="*70)
    
    # ========================================================================
    # STEP 1: Load Data
    # ========================================================================
    print("\n[STEP 1] Loading McCormick.py optimization results...")
    order_df = pd.read_csv(MCCORMICK_ORDERS, index_col=0)
    print(f"  ✓ Loaded {len(order_df)} periods from {MCCORMICK_ORDERS}")
    
    # Read input data
    print("\n[STEP 2] Loading input data from Excel...")
    df_price = pd.read_excel(INPUT_EXCEL, sheet_name='price')
    df_capacity = pd.read_excel(INPUT_EXCEL, sheet_name='capacity')
    df_supplier = pd.read_excel(INPUT_EXCEL, sheet_name='supplier')
    df_demand = pd.read_excel(INPUT_EXCEL, sheet_name='demand', index_col=0)
    print(f"  ✓ Loaded price, capacity, supplier, and demand data")
    
    # ========================================================================
    # STEP 2: Align Data
    # ========================================================================
    print("\n[STEP 3] Aligning data to planning horizon...")
    T = len(order_df)
    print(f"  Planning horizon: {T} periods")
    
    # Map supplier names
    SUPPLIERS = ["Hedged", "Unhedged"]
    supplier_names = df_supplier['supplier'].tolist()
    s1_name = supplier_names[0]  # Hedged
    s2_name = supplier_names[1]  # Unhedged
    
    # Create aligned dataframes
    Q_star_df = pd.DataFrame({
        "Hedged": order_df['s1'].values[:T],
        "Unhedged": order_df['s2'].values[:T]
    })
    
    price_df = pd.DataFrame({
        "Hedged": df_price[s1_name].values[:T],
        "Unhedged": df_price[s2_name].values[:T]
    })
    
    capacity_df = pd.DataFrame({
        "Hedged": df_capacity[s1_name].values[:T],
        "Unhedged": df_capacity[s2_name].values[:T]
    })
    
    # Extract demand (use mean if multiple scenarios)
    if df_demand.shape[1] == 1:
        demand = df_demand.iloc[:T, 0].values
    else:
        demand = df_demand.iloc[:T, :].mean(axis=1).values
    
    print(f"  ✓ Aligned data for {T} periods")
    print(f"  ✓ Demand range: [{demand.min():.0f}, {demand.max():.0f}]")
    
    # ========================================================================
    # STEP 3: Run Optimization 2 - Min Storage ≥6K
    # ========================================================================
    print("\n[STEP 4] Running Optimization 2: Min Storage ≥6K...")
    print("  Preserving McCormick total quantities, adding min storage constraint")
    
    sol = optimize_min_storage_preserve_quantities(
        Q_star_df=Q_star_df,
        price_df=price_df,
        capacity_df=capacity_df,
        demand=demand,
        s_min=STORAGE_MIN,
        h=HOLDING_COST,
        I0=INITIAL_INVENTORY,
        b=BACKLOG_COST,
        solver=SOLVER,
        verbose=VERBOSE
    )
    
    print(f"  ✓ Optimization completed")
    print(f"  Min storage: {sol['min_storage']:.0f} units (≥{STORAGE_MIN} required)")
    print(f"  Objective: ${sol['objective']:,.2f}")
    
    # Calculate supplier ratios
    total_hedged = sol["Qhat"]["Hedged"].sum()
    total_unhedged = sol["Qhat"]["Unhedged"].sum()
    total_orders = total_hedged + total_unhedged
    unhedged_pct = (total_unhedged / total_orders * 100) if total_orders > 0 else 0
    
    print(f"\n  Supplier Breakdown:")
    print(f"    Hedged: {total_hedged:,.0f} units ({100-unhedged_pct:.2f}%)")
    print(f"    Unhedged: {total_unhedged:,.0f} units ({unhedged_pct:.2f}%)")
    
    # ========================================================================
    # STEP 4: Run Optimization 3 - Forced 75% Hedged
    # ========================================================================
    print("\n[STEP 5] Running Optimization 3: Forced 75% Hedged...")
    
    # Calculate 75/25 split from Opt 2 total
    target_hedged = 0.75 * total_orders
    target_unhedged = 0.25 * total_orders
    
    print(f"  Total from Opt 2: {total_orders:,.0f} units")
    print(f"  Target: 75% hedged = {target_hedged:,.0f}, 25% unhedged = {target_unhedged:,.0f}")
    
    sol_75pct = optimize_forced_hedging_ratio(
        price_df=price_df,
        capacity_df=capacity_df,
        demand=demand,
        s_min=STORAGE_MIN,
        h=HOLDING_COST,
        I0=INITIAL_INVENTORY,
        b=BACKLOG_COST,
        total_hedged=target_hedged,
        total_unhedged=target_unhedged,
        solver=SOLVER,
        verbose=VERBOSE
    )
    
    print(f"  ✓ Optimization completed")
    print(f"  Total cost: ${sol_75pct['total_cost']:,.2f}")
    print(f"  Hedging ratio: {(1-sol_75pct['unhedged_ratio'])*100:.2f}% hedged")
    print(f"  Cost vs Opt 2: ${sol_75pct['total_cost'] - sol['objective']:+,.2f}")
    
    # ========================================================================
    # STEP 5: Evaluate McCormick Orders
    # ========================================================================
    print("\n[STEP 6] Evaluating McCormick orders for fair comparison...")
    
    # McCormick was solved with I0=24,750, but evaluate with I0=6,000
    MCCORMICK_ORIGINAL_I0 = 24750.0
    EVALUATION_I0 = INITIAL_INVENTORY
    
    print(f"  NOTE: McCormick solved with I0={MCCORMICK_ORIGINAL_I0:,.0f}")
    print(f"        Evaluating with I0={EVALUATION_I0:,.0f} for fair comparison")
    
    # Compute with L=0 for fair comparison
    mccormick_lead_times_L0 = {'s1': 0, 's2': 0}
    mccormick_inventory_L0, _ = compute_inventory_trajectory(
        order_df[['s1', 's2']], demand, EVALUATION_I0, mccormick_lead_times_L0
    )
    
    # Calculate costs
    mccormick_P_L0 = np.maximum(mccormick_inventory_L0, 0)
    mccormick_N_L0 = np.maximum(-mccormick_inventory_L0, 0)
    mccormick_storage_cost_L0 = MCCORMICK_EVAL_HOLDING_COST * mccormick_P_L0.sum()
    mccormick_backlog_cost_L0 = BACKLOG_COST * mccormick_N_L0.sum()
    
    mccormick_procurement_cost = 0
    for t in range(T):
        mccormick_procurement_cost += order_df.iloc[t]['s1'] * price_df.iloc[t]['Hedged']
        mccormick_procurement_cost += order_df.iloc[t]['s2'] * price_df.iloc[t]['Unhedged']
    
    mccormick_total_cost_L0 = mccormick_procurement_cost + mccormick_storage_cost_L0 + mccormick_backlog_cost_L0
    
    print(f"  McCormick (L=0, h={MCCORMICK_EVAL_HOLDING_COST}):")
    print(f"    Total cost: ${mccormick_total_cost_L0:,.2f}")
    
    # ========================================================================
    # STEP 6: Generate Summary Report
    # ========================================================================
    print("\n" + "="*70)
    print("SUMMARY: THREE-WAY COMPARISON")
    print("="*70)
    
    print("\n1. TOTAL COSTS:")
    print(f"   McCormick (L=0 eval):     ${mccormick_total_cost_L0:,.2f}")
    print(f"   Opt 2 (Min Storage ≥6K):  ${sol['objective']:,.2f}")
    print(f"   Opt 3 (Forced 75% Hedged): ${sol_75pct['total_cost']:,.2f}")
    
    print("\n2. COST SAVINGS vs McCormick:")
    print(f"   Opt 2: ${mccormick_total_cost_L0 - sol['objective']:,.2f}")
    print(f"   Opt 3: ${mccormick_total_cost_L0 - sol_75pct['total_cost']:,.2f}")
    
    print("\n3. HEDGING RATIOS:")
    mcc_hedged_pct = (order_df['s1'].sum() / (order_df['s1'].sum() + order_df['s2'].sum())) * 100
    print(f"   McCormick: {mcc_hedged_pct:.2f}% hedged")
    print(f"   Opt 2:     {100-unhedged_pct:.2f}% hedged")
    print(f"   Opt 3:     75.00% hedged")
    
    print("\n" + "="*70)
    print("PIPELINE COMPLETED SUCCESSFULLY")
    print("="*70)
    
    return {
        'order_df': order_df,
        'sol': sol,
        'sol_75pct': sol_75pct,
        'mccormick_P_L0': mccormick_P_L0,
        'price_df': price_df,
        'demand': demand,
        'T': T
    }


if __name__ == "__main__":
    results = main()
    print("\n✓ All optimizations completed. Results stored in 'results' dictionary.")
