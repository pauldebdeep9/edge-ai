#!/usr/bin/env python3
"""
hedging_ratio_risk_portfolio.py

Generates a REAL Pareto frontier (Expected Cost vs Std-Dev of Cost)
by sweeping the hedging ratio h from 0% to 100% in configurable steps.

For each h:
  1. Solve a CVXPY scheduling problem (from hedging_ratio25.py logic)
     with fixed total orders, safety-stock >= 6 000, equal hedged distribution,
     and capacity constraints.
  2. Evaluate the resulting order schedule against every demand scenario
     from the Excel file to obtain a cost distribution.
  3. Record mean cost (y-axis) and std-dev of cost (x-axis / risk).

Outputs
  1. Pareto frontier scatter + efficient-frontier curve (Cost vs Risk)
  2. Tradeoff curves:  expected cost & risk  vs  hedging ratio h
  3. (Optional) the original illustrative / synthetic plots (--synthetic flag)

Run
  conda activate Sai2501
  python hedging_ratio_risk_portfolio.py                   # real data, show plots
  python hedging_ratio_risk_portfolio.py --save_prefix pf   # save PNGs
  python hedging_ratio_risk_portfolio.py --synthetic        # old illustrative plots

Deps (all in Sai2501 env)
  cvxpy, numpy, pandas, matplotlib, openpyxl
"""

from __future__ import annotations
import argparse
import math
import warnings
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Tuple, Dict, List

import cvxpy as cp
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# ---------------------------------------------------------------------------
# Configuration  (mirrors hedging_ratio25.py)
# ---------------------------------------------------------------------------
INPUT_EXCEL = "Data/Hedging25.xlsx"
STORAGE_MIN = 6_000.0          # safety-stock lower bound
HOLDING_COST = 5.0             # h  - holding cost per unit per period
BACKLOG_COST = 50.0            # b  - backlog penalty per unit per period
INITIAL_INVENTORY = 12_000.0   # I0 used in the storage re-optimisation
SOLVER = cp.CLARABEL
VERBOSE_SOLVER = False

# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------

def load_hedging_data() -> dict:
    """
    Read price, capacity, demand (all scenarios), and supplier info
    from the Hedging25 Excel workbook.  Also run McCormick to get the
    WDRO-optimal baseline orders.

    Returns a dict with keys:
        price_df      - DataFrame[Tx2] columns ['Hedged','Unhedged']
        capacity_df   - DataFrame[Tx2] columns ['Hedged','Unhedged']
        demand_mean   - ndarray[T]  (mean across scenarios)
        demand_all    - DataFrame[T x n_scenarios]  (all scenario columns)
        T             - int, planning horizon
        total_orders  - float, total units ordered in the McCormick baseline
        mccormick_hedged_ratio - float, hedged fraction in McCormick solution
        order_df      - DataFrame of McCormick orders (columns s1, s2)
    """
    from McCormick import run_mccormick

    # McCormick baseline
    order_df = run_mccormick(save_csv=False)
    T = len(order_df)

    # Supplier name mapping
    df_supplier = pd.read_excel(INPUT_EXCEL, sheet_name="supplier")
    s1_name = df_supplier["supplier"].iloc[0]
    s2_name = df_supplier["supplier"].iloc[1]

    # Prices
    df_price = pd.read_excel(INPUT_EXCEL, sheet_name="price")
    price_df = pd.DataFrame({
        "Hedged": df_price[s1_name].values[:T],
        "Unhedged": df_price[s2_name].values[:T],
    })

    # Capacities
    df_cap = pd.read_excel(INPUT_EXCEL, sheet_name="capacity")
    capacity_df = pd.DataFrame({
        "Hedged": df_cap[s1_name].values[:T],
        "Unhedged": df_cap[s2_name].values[:T],
    })

    # Demand - keep ALL scenario columns
    df_demand = pd.read_excel(INPUT_EXCEL, sheet_name="demand", index_col=0)
    demand_all = df_demand.iloc[:T, :]
    demand_mean = demand_all.mean(axis=1).values

    total_hedged = float(order_df["s1"].sum())
    total_unhedged = float(order_df["s2"].sum())
    total_orders = total_hedged + total_unhedged

    return dict(
        price_df=price_df,
        capacity_df=capacity_df,
        demand_mean=demand_mean,
        demand_all=demand_all,
        T=T,
        total_orders=total_orders,
        mccormick_hedged_ratio=total_hedged / total_orders,
        order_df=order_df,
    )


# ---------------------------------------------------------------------------
# Per-ratio optimisation  (mirrors hedging_ratio25.py)
# ---------------------------------------------------------------------------

def solve_for_hedging_ratio(
    h_ratio: float,
    price_df: pd.DataFrame,
    capacity_df: pd.DataFrame,
    demand: np.ndarray,
    total_orders: float,
    s_min: float = STORAGE_MIN,
    holding: float = HOLDING_COST,
    I0: float = INITIAL_INVENTORY,
    backlog: float = BACKLOG_COST,
) -> Optional[dict]:
    """
    Solve the scheduling LP for a FIXED hedging ratio.

    Returns dict with keys  objective, Qhat (DataFrame), or None if infeasible.
    """
    T = len(price_df)
    d = np.asarray(demand, dtype=float)

    total_hedged = h_ratio * total_orders
    total_unhedged = (1.0 - h_ratio) * total_orders

    PH = price_df["Hedged"].to_numpy(float)
    PU = price_df["Unhedged"].to_numpy(float)
    CH = capacity_df["Hedged"].to_numpy(float)
    CU = capacity_df["Unhedged"].to_numpy(float)

    QH = cp.Variable(T, nonneg=True)
    QU = cp.Variable(T, nonneg=True)
    S  = cp.Variable(T)
    P  = cp.Variable(T, nonneg=True)
    N  = cp.Variable(T, nonneg=True)

    cons = []
    # inventory dynamics  (L = 0)
    cons += [S[0] == float(I0) + QH[0] + QU[0] - d[0]]
    for t in range(1, T):
        cons += [S[t] == S[t - 1] + QH[t] + QU[t] - d[t]]
    cons += [S == P - N]
    cons += [P >= s_min]
    cons += [QH <= CH]
    cons += [QU <= CU]
    cons += [cp.sum(QH) == total_hedged]
    cons += [cp.sum(QU) == total_unhedged]
    # equal-distribution for hedged supplier
    for t in range(1, T):
        cons += [QH[t] == QH[0]]

    purchase = cp.sum(cp.multiply(PH, QH)) + cp.sum(cp.multiply(PU, QU))
    obj = cp.Minimize(purchase + holding * cp.sum(P) + backlog * cp.sum(N))

    prob = cp.Problem(obj, cons)
    try:
        prob.solve(solver=SOLVER, verbose=VERBOSE_SOLVER)
    except cp.SolverError:
        return None
    if prob.status not in ("optimal", "optimal_inaccurate"):
        return None

    QH_val = np.asarray(QH.value).ravel()
    QU_val = np.asarray(QU.value).ravel()
    return dict(
        objective=float(prob.value),
        Qhat=pd.DataFrame({"Hedged": QH_val, "Unhedged": QU_val}),
    )


# ---------------------------------------------------------------------------
# Scenario evaluation
# ---------------------------------------------------------------------------

def evaluate_schedule_across_scenarios(
    Qhat: pd.DataFrame,
    price_df: pd.DataFrame,
    demand_all: pd.DataFrame,
    holding: float = HOLDING_COST,
    backlog: float = BACKLOG_COST,
    I0: float = INITIAL_INVENTORY,
) -> np.ndarray:
    """
    Evaluate total cost of a FIXED order schedule under every demand scenario.
    Returns an array of length n_scenarios.
    """
    T = len(Qhat)
    QH = Qhat["Hedged"].values
    QU = Qhat["Unhedged"].values
    arrivals = QH + QU  # L = 0

    # procurement cost is deterministic (fixed schedule x fixed prices)
    proc_cost = float(
        (price_df["Hedged"].values * QH).sum()
        + (price_df["Unhedged"].values * QU).sum()
    )

    costs = []
    for col in demand_all.columns:
        d = demand_all[col].values[:T].astype(float)
        inv = np.zeros(T)
        inv[0] = I0 + arrivals[0] - d[0]
        for t in range(1, T):
            inv[t] = inv[t - 1] + arrivals[t] - d[t]
        on_hand = np.maximum(inv, 0.0)
        back = np.maximum(-inv, 0.0)
        total = proc_cost + holding * on_hand.sum() + backlog * back.sum()
        costs.append(total)

    return np.array(costs)


# ---------------------------------------------------------------------------
# Frontier builder
# ---------------------------------------------------------------------------

def build_real_frontier(
    n_points: int = 21,
    h_grid: Optional[np.ndarray] = None,
    data: Optional[dict] = None,
) -> Tuple[pd.DataFrame, dict]:
    """
    Sweep h from 0 to 1, solve + evaluate, return frontier DataFrame
    and the loaded data dict.

    If h_grid is provided it is used directly; otherwise a uniform
    linspace of n_points is created.
    If data is provided it is reused; otherwise load_hedging_data() is called.
    """
    if data is None:
        data = load_hedging_data()
    if h_grid is None:
        h_grid = np.linspace(0.0, 1.0, max(2, n_points))

    rows: List[dict] = []
    for h in h_grid:
        sol = solve_for_hedging_ratio(
            h_ratio=h,
            price_df=data["price_df"],
            capacity_df=data["capacity_df"],
            demand=data["demand_mean"],
            total_orders=data["total_orders"],
        )
        if sol is None:
            print(f"  [SKIP] h={h:.2f}  -- infeasible")
            continue

        cost_samples = evaluate_schedule_across_scenarios(
            sol["Qhat"],
            data["price_df"],
            data["demand_all"],
        )
        rows.append(dict(
            h=h,
            unhedged=1.0 - h,
            exp_cost=float(np.mean(cost_samples)),
            std_cost=float(np.std(cost_samples, ddof=1)),
            objective_det=sol["objective"],
        ))
        print(f"  h={h:.2f}  E[C]={rows[-1]['exp_cost']:,.0f}  "
              f"std[C]={rows[-1]['std_cost']:,.0f}  "
              f"det_obj={sol['objective']:,.0f}")

    front = pd.DataFrame(rows)
    front["risk"] = front["std_cost"]   # alias for plotting
    return front, data


# ---------------------------------------------------------------------------
# Pareto-front helper
# ---------------------------------------------------------------------------

def pareto_front_2d(x: np.ndarray, y: np.ndarray,
                    *, minimize_x: bool, minimize_y: bool) -> np.ndarray:
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    n = x.size
    keep = np.ones(n, dtype=bool)
    xx = x if minimize_x else -x
    yy = y if minimize_y else -y
    for i in range(n):
        if not keep[i]:
            continue
        dom = (xx <= xx[i]) & (yy <= yy[i]) & ((xx < xx[i]) | (yy < yy[i]))
        dom[i] = False
        if np.any(dom):
            keep[i] = False
    return np.where(keep)[0]


# ---------------------------------------------------------------------------
# Annotation helpers
# ---------------------------------------------------------------------------

def _smart_offset(x, y, xlim, ylim, *, base_dx=10, base_dy=8):
    xmin, xmax = xlim
    ymin, ymax = ylim
    xr, yr = xmax - xmin, ymax - ymin
    dx, dy, ha = base_dx, base_dy, "left"
    if x > xmax - 0.08 * xr:
        dx, ha, dy = -110, "right", -8
    if x < xmin + 0.10 * xr:
        dx, ha = 12, "left"
    if y > ymax - 0.08 * yr:
        dy = -14
    if y < ymin + 0.12 * yr:
        dy = 10
    return dx, dy, ha


def annotate_point(ax, x, y, text, *, dx=None, dy=None, ha=None):
    xlim, ylim = ax.get_xlim(), ax.get_ylim()
    if dx is None or dy is None or ha is None:
        adx, ady, aha = _smart_offset(x, y, xlim, ylim)
        dx = adx if dx is None else dx
        dy = ady if dy is None else dy
        ha = aha if ha is None else ha
    ax.annotate(
        text, (x, y), textcoords="offset points", xytext=(dx, dy),
        ha=ha, va="center", fontsize=9,
        bbox=dict(boxstyle="round,pad=0.18", fc="white", ec="none", alpha=0.70),
        zorder=10,
    )


def put_formula_box(ax, text, *, loc):
    loc_map = {
        "bottom_left":  (0.02, 0.03, "left",  "bottom"),
        "bottom_right": (0.98, 0.03, "right", "bottom"),
        "top_left":     (0.02, 0.97, "left",  "top"),
        "top_right":    (0.98, 0.97, "right", "top"),
    }
    xx, yy, hh, vv = loc_map[loc]
    ax.text(xx, yy, text, transform=ax.transAxes, fontsize=9, ha=hh, va=vv,
            bbox=dict(boxstyle="round,pad=0.25", fc="white", ec="none", alpha=0.70),
            zorder=9)


# ---------------------------------------------------------------------------
# Plotting - real frontier
# ---------------------------------------------------------------------------

def plot_real_frontier(
    front: pd.DataFrame,
    mccormick_h: float,
    *,
    save_path: Optional[str] = None,
    show: bool = True,
) -> None:
    """Scatter + Pareto curve of Expected Cost vs Std-Dev(Cost)."""
    x = front["risk"].to_numpy()
    y = front["exp_cost"].to_numpy()
    h = front["h"].to_numpy()

    idx_pf = pareto_front_2d(x, y, minimize_x=True, minimize_y=True)

    fig, ax = plt.subplots(figsize=(11.5, 5.8))
    sc = ax.scatter(x, y, c=h, cmap="viridis", s=50, alpha=0.85, edgecolors="k",
                    linewidths=0.4, zorder=5)
    cb = plt.colorbar(sc, ax=ax)
    cb.set_label("Hedging ratio  h  (fraction hedged)")

    # Pareto curve
    order = np.argsort(x[idx_pf])
    ax.plot(x[idx_pf][order], y[idx_pf][order], linewidth=2.2,
            color="#333", label="Efficient frontier (Pareto)")

    ax.margins(x=0.08, y=0.08)
    fig.canvas.draw()

    # ---- Key labelled points ----
    # Label every point in the frontier (they are all user-requested)
    all_h = front["h"].to_numpy()

    # Find the closest solved point to the McCormick optimal ratio
    j_mc = int(np.abs(all_h - mccormick_h).argmin())
    mc_h_actual = float(front.iloc[j_mc]["h"])

    # Plot McCormick optimal as a star
    ax.scatter([x[j_mc]], [y[j_mc]], s=220, marker="*", color="#d62728",
               edgecolors="black", linewidths=0.6, zorder=12,
               label=f"McCormick optimal  h*={mccormick_h*100:.1f}%")

    # Manual offset overrides for crowded / edge labels
    #   (dx, dy in offset-points, ha)
    overrides: Dict[float, Tuple[int, int, str]] = {
        0.0:  (-14, -14, "right"),
        0.25: (12, -14, "left"),
        0.50: (12, -14, "left"),
        0.60: (12, 14, "left"),
        0.70: (12, -14, "left"),
        0.75: (-12, 14, "right"),
        0.80: (-12, -14, "right"),
        0.90: (12, 14, "left"),
        0.95: (12, -14, "left"),
        1.0:  (12, -14, "left"),
    }

    for idx_i, row in front.iterrows():
        hh = row["h"]
        # Skip the McCormick-optimal — it gets its own star + label below
        if abs(hh - mc_h_actual) < 1e-6:
            continue
        j = int(idx_i)
        label_txt = f"h={hh*100:.0f}%"
        ax.scatter([x[j]], [y[j]], s=70, marker="x", color="#333", zorder=11)
        ov = overrides.get(round(hh, 2))
        if ov:
            annotate_point(ax, x[j], y[j], label_txt, dx=ov[0], dy=ov[1], ha=ov[2])
        else:
            annotate_point(ax, x[j], y[j], label_txt)

    # McCormick label
    mc_label = f"h={mc_h_actual*100:.1f}% (McCormick optimal)"
    annotate_point(ax, x[j_mc], y[j_mc], mc_label, dx=16, dy=14, ha="left")

    # ---- Legend: place near data instead of a separate box ----
    # Use only 2 legend entries: the Pareto line and the McCormick star
    ax.legend(loc="upper left", fontsize=9, framealpha=0.85)

    ax.set_title("Procurement Pareto Frontier: Expected Cost vs Risk (Std Dev)",
                 fontsize=13, fontweight="bold")
    ax.set_xlabel("Risk  (Std Dev of Total Cost across demand scenarios)")
    ax.set_ylabel("Expected Total Cost  (USD)")
    ax.grid(True, alpha=0.25)
    fig.tight_layout()

    if save_path:
        fig.savefig(save_path, dpi=170, bbox_inches="tight")
        print(f"[OK] saved: {save_path}")
    if show:
        plt.show()
    plt.close(fig)


def plot_real_tradeoff(
    front: pd.DataFrame,
    mccormick_h: float,
    *,
    save_path: Optional[str] = None,
    show: bool = True,
) -> None:
    """Expected cost & risk as functions of hedging ratio h."""
    h = front["h"].to_numpy()
    cost = front["exp_cost"].to_numpy()
    risk = front["risk"].to_numpy()

    fig, ax1 = plt.subplots(figsize=(11.5, 5))

    color_cost = "#1f77b4"
    color_risk = "#d62728"

    ax1.set_xlabel("Hedging ratio  h   (Unhedged = 1 - h)", fontsize=11)
    ax1.set_ylabel("Expected Total Cost (USD)", color=color_cost, fontsize=11)
    ln1 = ax1.plot(h, cost, color=color_cost, marker="o", markersize=5,
                   linewidth=2, label="Expected cost")
    ax1.tick_params(axis="y", labelcolor=color_cost)

    ax2 = ax1.twinx()
    ax2.set_ylabel("Risk  (Std Dev of Cost)", color=color_risk, fontsize=11)
    ln2 = ax2.plot(h, risk, color=color_risk, marker="s", markersize=5,
                   linewidth=2, label="Risk (std)")
    ax2.tick_params(axis="y", labelcolor=color_risk)

    # McCormick optimal vertical line
    ax1.axvline(mccormick_h, linestyle="--", color="gray", alpha=0.6,
                label=f"McCormick h*={mccormick_h*100:.0f}%")

    # combined legend
    from matplotlib.lines import Line2D
    lns = ln1 + ln2
    labs = [l.get_label() for l in lns]
    labs.append(f"McCormick h*={mccormick_h*100:.0f}%")
    lns.append(Line2D([0], [0], ls="--", color="gray", alpha=0.6))
    ax1.legend(lns, labs, loc="best", fontsize=9)

    ax1.set_title("Tradeoff vs Hedging Ratio  h", fontsize=13, fontweight="bold")
    ax1.grid(True, alpha=0.25)
    fig.tight_layout()

    if save_path:
        fig.savefig(save_path, dpi=170, bbox_inches="tight")
        print(f"[OK] saved: {save_path}")
    if show:
        plt.show()
    plt.close(fig)


# ---------------------------------------------------------------------------
# (Optional) Original synthetic illustrative plots - kept behind --synthetic
# ---------------------------------------------------------------------------

@dataclass
class ProcurementParams:
    fixed_price: float = 78.0
    hedge_premium: float = 0.6
    base_spot: float = 78.0
    spot_vol: float = 0.40
    basis_vol: float = 0.15
    basis_spot_corr: float = 0.10
    demand_mean_oz: float = 1_200_000.0
    demand_vol: float = 0.15
    spot_demand_corr: float = 0.25


def cvar(x, alpha=0.95, higher_is_worse=True):
    x = np.asarray(x, float)
    if higher_is_worse:
        var = np.quantile(x, alpha)
        tail = x[x >= var]
    else:
        var = np.quantile(x, 1.0 - alpha)
        tail = x[x <= var]
    return float(np.mean(tail)) if tail.size else float(var)


def simulate_procurement_scenarios(n, seed, p):
    rng = np.random.default_rng(seed)
    corr = np.array([
        [1.0, p.spot_demand_corr, p.basis_spot_corr],
        [p.spot_demand_corr, 1.0, 0.0],
        [p.basis_spot_corr, 0.0, 1.0],
    ])
    z = rng.multivariate_normal([0, 0, 0], corr, size=n)
    spot = p.base_spot * np.exp(p.spot_vol * z[:, 0] - 0.5 * p.spot_vol**2)
    demand = p.demand_mean_oz * np.exp(p.demand_vol * z[:, 1] - 0.5 * p.demand_vol**2)
    F = p.fixed_price + p.hedge_premium
    hedge_price = F * np.exp(p.basis_vol * z[:, 2] - 0.5 * p.basis_vol**2)
    return pd.DataFrame({"spot": spot, "demand_oz": demand, "hedge_price": hedge_price})


def synthetic_procurement_frontier(df_scen, h_grid, p, use_cvar):
    S = df_scen["spot"].to_numpy()
    D = df_scen["demand_oz"].to_numpy()
    H = df_scen["hedge_price"].to_numpy()
    rows = []
    for hval in h_grid:
        C = D * (hval * H + (1.0 - hval) * S)
        rows.append(dict(h=hval, unhedged=1.0 - hval, exp_cost=float(np.mean(C)),
                         risk=cvar(C) if use_cvar else float(np.std(C, ddof=1)),
                         std_cost=float(np.std(C, ddof=1)),
                         cvar95_cost=cvar(C)))
    return pd.DataFrame(rows)


def plot_synthetic_procurement(front, *, use_cvar, save_path, show):
    x = front["risk"].to_numpy()
    y = front["exp_cost"].to_numpy()
    h = front["h"].to_numpy()
    idx_pf = pareto_front_2d(x, y, minimize_x=True, minimize_y=True)
    fig, ax = plt.subplots(figsize=(11.5, 5.2))
    sc = ax.scatter(x, y, c=h, s=22, alpha=0.85)
    cb = plt.colorbar(sc, ax=ax)
    cb.set_label("Hedge ratio (h)")
    ax.plot(x[idx_pf], y[idx_pf], linewidth=2.2, label="Efficient frontier")
    ax.set_title("Illustrative Procurement Frontier (Synthetic)")
    ax.set_xlabel("Risk (CVaR95)" if use_cvar else "Risk (Std Dev)")
    ax.set_ylabel("Expected Cost (USD)")
    ax.grid(True, alpha=0.25)
    ax.legend()
    fig.tight_layout()
    if save_path:
        fig.savefig(save_path, dpi=170, bbox_inches="tight")
    if show:
        plt.show()
    plt.close(fig)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:
    ap = argparse.ArgumentParser(
        description="Pareto frontier for procurement hedging ratio")
    ap.add_argument("--n_points", type=int, default=21,
                    help="Grid points for h in [0,1]  (default: 21 = 5pct steps)")
    ap.add_argument("--save_prefix", default=None,
                    help="If set, save PNGs as <prefix>_*.png")
    ap.add_argument("--no_show", action="store_true",
                    help="Do not display plots interactively")
    ap.add_argument("--synthetic", action="store_true",
                    help="Run the old illustrative / synthetic frontier instead")
    ap.add_argument("--use_cvar", action="store_true",
                    help="(synthetic mode only) Use CVaR95 as risk metric")
    args = ap.parse_args()

    show = not args.no_show
    sp = args.save_prefix

    if args.synthetic:
        # ---- old illustrative path ----
        p = ProcurementParams()
        df_scen = simulate_procurement_scenarios(8000, 42 + 777, p)
        h_grid = np.linspace(0, 1, 401)
        front = synthetic_procurement_frontier(df_scen, h_grid, p, args.use_cvar)
        plot_synthetic_procurement(
            front, use_cvar=args.use_cvar,
            save_path=f"{sp}_synthetic_frontier.png" if sp else None,
            show=show)
        return 0

    # ---- real data path ----
    print("=" * 70)
    print("Building REAL Pareto frontier from Hedging25 data")
    print("=" * 70)

    # Load data once to learn the McCormick optimal ratio
    preloaded = load_hedging_data()
    mc_h_val = preloaded["mccormick_hedged_ratio"]

    # Build explicit grid: 0,25,50,60,70,75,80, optimal, 90,95,100
    explicit = sorted(set(
        [0.0, 0.25, 0.50, 0.60, 0.70, 0.75, 0.80,
         round(mc_h_val, 4),
         0.90, 0.95, 1.0]
    ))
    custom_grid = np.array(explicit)
    print(f"  Custom h grid ({len(custom_grid)} points): "
          f"{[f'{v:.2%}' for v in custom_grid]}")

    front, data = build_real_frontier(h_grid=custom_grid, data=preloaded)

    if front.empty:
        print("[ERROR] No feasible points found. Check capacity constraints.")
        return 1

    mc_h = data["mccormick_hedged_ratio"]
    print(f"\nMcCormick optimal hedging ratio:  {mc_h*100:.1f}%  hedged")
    print(f"Frontier has {len(front)} feasible points.\n")

    # Print summary table
    print(f"{'h':>6s}  {'E[Cost]':>12s}  {'std[Cost]':>12s}  {'Det Obj':>12s}")
    print("-" * 48)
    for _, r in front.iterrows():
        print(f"{r['h']:6.2f}  {r['exp_cost']:12,.0f}  "
              f"{r['std_cost']:12,.0f}  {r['objective_det']:12,.0f}")

    # Plot 1: Pareto frontier
    plot_real_frontier(
        front, mc_h,
        save_path=f"{sp}_proc_frontier.png" if sp else None,
        show=show,
    )

    # Plot 2: Tradeoff curves
    plot_real_tradeoff(
        front, mc_h,
        save_path=f"{sp}_proc_tradeoff.png" if sp else None,
        show=show,
    )

    print("\n[DONE] All plots generated.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
