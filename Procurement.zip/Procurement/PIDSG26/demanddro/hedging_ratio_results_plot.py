"""
Plot AI orders from Hedging25.xlsx result sheet:
  - Bar: AI order U (as-is per month)
  - Bar: sum(AI order H)/12 uniform across all months
  - Secondary axis: Price-H (dotted) and Price-U (dotted)
  - X-axis: Apr-24 to Mar-25
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Load data (first 12 rows only — rest are summaries)
df = pd.read_excel('Data/Hedging25.xlsx', sheet_name='result', nrows=12)

# Orders
ai_order_u = pd.to_numeric(df['AI order U'], errors='coerce').fillna(0).values
ai_order_h_uniform = pd.to_numeric(df['Ai order H'], errors='coerce').fillna(0).sum() / 12

# Prices
price_h = pd.to_numeric(df['Price-H'], errors='coerce').fillna(0).values
price_u = pd.to_numeric(df['Price-U'], errors='coerce').fillna(0).values

# X-axis: Apr-24 to Mar-25
months = pd.date_range(start='2024-04-01', periods=12, freq='MS')
xlabels = months.strftime('%b-%y')
x = np.arange(12)
width = 0.35

# Compute shared axis limits for side-by-side consistency
manual_proc = df['Manual Proc'].values
manual_hedged_uniform = (manual_proc * 0.75).sum() / 12
manual_unhedged = manual_proc * 0.25

all_order_vals = np.concatenate([
    [ai_order_h_uniform], ai_order_u,
    [manual_hedged_uniform], manual_unhedged
])
y_max_orders = max(all_order_vals) * 1.15  # 15% headroom

all_price_vals = np.concatenate([price_h, price_u])
price_min = all_price_vals.min() - 0.5
price_max = all_price_vals.max() + 0.5

# Plot Figure 1
fig, ax1 = plt.subplots(figsize=(13, 6))

bars_h = ax1.bar(x - width/2, [ai_order_h_uniform]*12, width,
                 label=f'AI Order H (uniform = {ai_order_h_uniform:,.0f}/mo)',
                 color='#1976D2', alpha=0.8, edgecolor='black')
bars_u = ax1.bar(x + width/2, ai_order_u, width,
                 label='AI Order U (per month)',
                 color='#FFA000', alpha=0.8, edgecolor='black')

ax1.set_xlabel('Time Period', fontsize=12, fontweight='bold')
ax1.set_ylabel('Order Quantity', fontsize=12, fontweight='bold')
ax1.set_ylim(0, y_max_orders)
ax1.set_xticks(x)
ax1.set_xticklabels(xlabels, rotation=45, ha='right')

# Secondary axis for prices
ax2 = ax1.twinx()
ax2.plot(x, price_h, color='#1976D2', linestyle=':', marker='o', markersize=5,
         linewidth=2, label='Price-H (Hedged)')
ax2.plot(x, price_u, color='#FFA000', linestyle=':', marker='s', markersize=5,
         linewidth=2, label='Price-U (Unhedged)')
ax2.set_ylabel('Price', fontsize=12, fontweight='bold')
ax2.set_ylim(price_min, price_max)

# Combined legend
lines1, labels1 = ax1.get_legend_handles_labels()
lines2, labels2 = ax2.get_legend_handles_labels()
ax1.legend(lines1 + lines2, labels1 + labels2, loc='upper right', fontsize=10)

ax1.set_title('AI Order Quantities and Supplier Prices (Apr-24 to Mar-25)', fontsize=14, fontweight='bold')
plt.tight_layout()
plt.show()

# ============================================================================
# FIGURE 2: Manual Procurement (75% Hedged, 25% Unhedged)
# ============================================================================

fig2, ax3 = plt.subplots(figsize=(13, 6))

bars_mh = ax3.bar(x - width/2, [manual_hedged_uniform]*12, width,
                  label=f'Manual Hedged (uniform = {manual_hedged_uniform:,.0f}/mo)',
                  color='#1976D2', alpha=0.8, edgecolor='black')
bars_mu = ax3.bar(x + width/2, manual_unhedged, width,
                  label='Manual Unhedged (per month)',
                  color='#FFA000', alpha=0.8, edgecolor='black')

ax3.set_xlabel('Time Period', fontsize=12, fontweight='bold')
ax3.set_ylabel('Order Quantity', fontsize=12, fontweight='bold')
ax3.set_ylim(0, y_max_orders)
ax3.set_xticks(x)
ax3.set_xticklabels(xlabels, rotation=45, ha='right')

# Secondary axis for prices
ax4 = ax3.twinx()
ax4.plot(x, price_h, color='#1976D2', linestyle=':', marker='o', markersize=5,
         linewidth=2, label='Price-H (Hedged)')
ax4.plot(x, price_u, color='#FFA000', linestyle=':', marker='s', markersize=5,
         linewidth=2, label='Price-U (Unhedged)')
ax4.set_ylabel('Price', fontsize=12, fontweight='bold')
ax4.set_ylim(price_min, price_max)

# Combined legend
lines3, labels3 = ax3.get_legend_handles_labels()
lines4, labels4 = ax4.get_legend_handles_labels()
ax3.legend(lines3 + lines4, labels3 + labels4, loc='upper right', fontsize=10)

ax3.set_title('Manual Procurement: 75% Hedged / 25% Unhedged (Apr-24 to Mar-25)', fontsize=14, fontweight='bold')
plt.tight_layout()
plt.show()
