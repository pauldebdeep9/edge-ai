import pandas as pd
import numpy as np
import os, re
from typing import List, Optional, Tuple

# ---------- Utilities ----------
MONTH_RE = re.compile(r"^[A-Za-z]{3}-\d{2}$")  # e.g., Apr-25

def _coerce_number(x):
    if pd.isna(x):
        return np.nan
    if isinstance(x, (int, float)):
        return float(x)
    s = str(x).strip().replace(",", "")
    try:
        return float(s)
    except Exception:
        return np.nan

def _norm_text(s: Optional[str]) -> str:
    if s is None or (isinstance(s, float) and pd.isna(s)):
        return ""
    return " ".join(str(s).strip().lower().replace("\u00a0", " ").split())

def _is_month_token(x) -> bool:
    s = _norm_text(x)
    return bool(MONTH_RE.match(s))

# ---------- Header detection ----------
def detect_header_rows(df: pd.DataFrame, scan_rows: int = 15) -> Tuple[int,int,int]:
    """
    Heuristics: find the first row among top `scan_rows` that contains >=4 month-like tokens (MMM-YY).
    Next row = attributes, next row = subs (status).
    """
    best_row = None
    best_count = -1
    max_scan = min(scan_rows, len(df))
    for r in range(max_scan):
        vals = df.iloc[r].tolist()
        cnt = sum(_is_month_token(v) for v in vals)
        if cnt > best_count:
            best_count = cnt
            best_row = r
    if best_row is None or best_count < 3:
        # fallback to classic (6,7,8)
        return 6,7,8
    return best_row, best_row+1, best_row+2

def load_multiheader_csv(path: str) -> Tuple[pd.DataFrame, pd.DataFrame]:
    # tolerant read (strings), we’ll re-read numeric later for values
    df = pd.read_csv(path, header=None, dtype=str, encoding_errors="ignore")
    r_month, r_attr, r_sub = detect_header_rows(df)

    months = df.iloc[r_month].copy()
    attrs  = df.iloc[r_attr].copy()
    subs   = df.iloc[r_sub].copy()

    # Forward-fill months and attributes selectively
    months_ff = months.copy()
    months_ff = months_ff.where(months_ff.notna(), None)
    # Only accept month tokens; non-months remain None
    months_ff = months_ff.apply(lambda x: x if _is_month_token(x) else None).ffill()

    attrs_ff = attrs.copy()
    last_attr = None
    for j in range(len(attrs_ff)):
        cur_attr = attrs_ff.iloc[j]
        if pd.notna(cur_attr) and str(cur_attr).strip() != "":
            last_attr = cur_attr
        elif pd.notna(months_ff.iloc[j]) and last_attr is not None:
            attrs_ff.iloc[j] = last_attr

    def status_from_sub(x):
        x = str(x).strip() if pd.notna(x) else ""
        return "planned" if x in {"L/F", "T/F"} else "actual"

    status = subs.apply(status_from_sub)

    header = pd.DataFrame({
        "month": months_ff,
        "attribute": attrs_ff,
        "sub": subs,
        "status": status
    })
    return df, header

# ---------- Material row search ----------
def _detect_label_columns(header: pd.DataFrame, widen_to: int = 12) -> List[int]:
    month_mask = header["month"].apply(_is_month_token).to_numpy()
    if month_mask.any():
        first_month_idx = int(np.argmax(month_mask))
        label_cols = list(range(first_month_idx))
        # widen a bit in case of alignment quirks
        label_cols = list(range(min(max(first_month_idx, 3), widen_to)))
    else:
        label_cols = list(range(min(8, len(header))))
    if not label_cols:
        label_cols = list(range(min(8, len(header))))
    return label_cols

def _match_row_indices_by_tokens(df: pd.DataFrame, cols: List[int], token_sets: List[List[str]]) -> Optional[int]:
    """
    token_sets is a list of AND-token lists. We accept the first row where ALL tokens in any set are present
    in the concatenation of specified label columns.
    """
    for idx in range(len(df)):
        cell_texts = []
        for c in cols:
            try:
                cell_texts.append(_norm_text(df.iat[idx, c]))
            except Exception:
                pass
        line = " ".join([t for t in cell_texts if t])
        for tokens in token_sets:
            if all(t in line for t in tokens):
                return idx
    return None

def extract_material_row(df_raw: pd.DataFrame, header: pd.DataFrame, material_name: str) -> pd.Series:
    label_cols = _detect_label_columns(header, widen_to=12)
    mat_norm = _norm_text(material_name)

    # 1) exact match in any label col
    exact_mask = pd.Series(False, index=df_raw.index)
    for c in label_cols:
        exact_mask |= df_raw.iloc[:, c].apply(_norm_text).eq(mat_norm)
    if exact_mask.any():
        return df_raw.iloc[exact_mask.idxmax()]

    # 2) contains match in any label col
    contains_mask = pd.Series(False, index=df_raw.index)
    for c in label_cols:
        contains_mask |= df_raw.iloc[:, c].apply(lambda x: mat_norm in _norm_text(x))
    if contains_mask.any():
        return df_raw.iloc[contains_mask.idxmax()]

    # 3) token-set fallback (e.g., ["silver","paste"] OR ["ag","paste"])
    token_sets = [
        [t for t in _norm_text(material_name).split() if t],   # tokens from given name
        ["silver","paste"],
        ["ag","paste"],
        ["silver","ag","paste"],
    ]
    idx = _match_row_indices_by_tokens(df_raw, label_cols, token_sets)
    if idx is not None:
        return df_raw.iloc[idx]

    # If still not found, print candidates and dump a small debug slice
    candidates = []
    for c in label_cols:
        col_vals = df_raw.iloc[:, c].dropna().astype(str).tolist()
        candidates.extend(col_vals)
    cand_norm = sorted({_norm_text(x) for x in candidates if _norm_text(x)})

    # dump debug view to help inspection
    debug_path = os.path.join("Data", "_debug_first40x12.csv")
    try:
        df_raw.iloc[:40, :12].to_csv(debug_path, index=False, header=False)
        dbg_msg = f"\nA small debug slice was written to: {debug_path}"
    except Exception:
        dbg_msg = ""

    preview = "\n  - " + "\n  - ".join(cand_norm[:60])
    raise ValueError(
        f"Material '{material_name}' not found.\n"
        f"Scanned label columns: {label_cols}\n"
        f"Top seen (normalized) label strings:\n{preview}\n"
        f"(Tip: open the debug CSV and copy the exact material text.){dbg_msg}"
    )

# ---------- Build timeseries ----------
def build_timeseries_for_material(
    csv_path: str,
    material: str = "Silver Paste",
    months_keep=(
        "Apr-25","May-25","Jun-25","Jul-25","Aug-25","Sep-25",
        "Oct-25","Nov-25","Dec-25","Jan-26","Feb-26","Mar-26"
    )
) -> pd.DataFrame:
    df_raw, header = load_multiheader_csv(csv_path)

    # reload for numeric values
    df_vals = pd.read_csv(csv_path, header=None, encoding_errors="ignore")
    row_raw = extract_material_row(df_raw, header, material)
    row_idx = row_raw.name

    tidy = header.copy()
    tidy["value"] = df_vals.iloc[row_idx].values

    # keep target months
    tidy = tidy[tidy["month"].apply(_is_month_token)]
    tidy = tidy[tidy["month"].isin(months_keep)].copy()

    def norm_attr(a):
        a = _norm_text(a)
        if a in {"pur","purchase","purch"}:
            return "purchase"
        if a in {"consumption","cons"}:
            return "consumption"
        if a in {"c/b","cb","closing balance","closing_bal","c_b"}:
            return "cb"
        if a in {"inv days","inv day","invdays","inventory days","inventory_day","inventory_days"}:
            return "inv_days"
        return a

    tidy["attribute"] = tidy["attribute"].apply(norm_attr)
    tidy["value"] = tidy["value"].apply(_coerce_number)

    wanted = []
    for attr in ["purchase","consumption","cb"]:
        for stat in ["planned","actual"]:
            wanted.append((attr,stat))
    wanted.append(("inv_days","actual"))

    records = []
    for m in months_keep:
        rec = {"month": m}
        for attr, stat in wanted:
            val = tidy.loc[
                (tidy["month"] == m) &
                (tidy["attribute"] == attr) &
                (tidy["status"] == stat),
                "value"
            ]
            rec[f"{attr}_{stat}"] = float(val.iloc[0]) if len(val) else np.nan
        records.append(rec)

    return pd.DataFrame.from_records(records).set_index("month")

# ---------- Main ----------
if __name__ == "__main__":
    csv_path = os.path.join("Data", "7.0 FY2025 Material Control.csv")
    material = "Silver Paste"     # if it still fails, try: "Ag Paste" or paste exact text from debug CSV
    out_path = os.path.join("Data", "silver_paste_timeseries.csv")

    print(f"Reading file: {csv_path}")
    try:
        df = build_timeseries_for_material(csv_path, material)
    except Exception as e:
        print("\n[ERROR] Could not locate the material row.")
        print(str(e))
        raise

    df.to_csv(out_path, index=True)
    print(f"\nSaved: {out_path}\n")
    print(df)
