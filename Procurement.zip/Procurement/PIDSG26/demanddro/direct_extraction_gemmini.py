import pandas as pd
import numpy as np
import os
import re
from typing import List, Optional, Tuple

# ---------- Utilities ----------
MONTH_RE = re.compile(r"^[A-Za-z]{3}-\d{2}$")  # e.g., Apr-25

def _coerce_number(x):
    """Safely convert a value to a float."""
    if pd.isna(x):
        return np.nan
    if isinstance(x, (int, float)):
        return float(x)
    # Handle strings with commas, parentheses for negatives, etc.
    s = str(x).strip().replace(",", "").replace("(", "-").replace(")", "")
    if not s:
        return np.nan
    try:
        return float(s)
    except (ValueError, TypeError):
        return np.nan

def _norm_text(s: Optional[str]) -> str:
    """Normalize text to lowercase, stripped, single-spaced string."""
    if s is None or (isinstance(s, float) and pd.isna(s)):
        return ""
    return " ".join(str(s).strip().lower().replace("\u00a0", " ").split())

def _is_month_token(x) -> bool:
    """Check if a string token matches the 'Mmm-YY' format."""
    s = str(x).strip()
    return bool(MONTH_RE.match(s))

def norm_status(s: str) -> str:
    """Normalize a status string to 'planned', 'forecast', or 'actual'."""
    a = _norm_text(s)
    if a in ["bp", "business plan"]: return "planned"
    if a in ["act", "actual"]: return "actual"
    if a in ["l/f"]: return "forecast"
    return a

def norm_attr(s: str) -> str:
    """Normalize an attribute string to a standard key."""
    a = _norm_text(s)
    if a in {"pur", "purchase"}: return "purchase"
    if a in {"con", "cons", "consumption"}: return "consumption"
    if a in {"c/b", "cb", "closing balance"}: return "cb"
    if a in {"inv day", "inv. day", "inv. days", "inv days", "inventory days", "inventory_day", "inventory_days"}: return "inv_days"
    return a

# ---------- Core Logic ----------
def detect_header_rows(df: pd.DataFrame, scan_rows: int = 15) -> Tuple[int, int, int]:
    """Find the three-row header block (Month, Attribute, Status)."""
    for r in range(min(scan_rows, len(df))):
        vals = df.iloc[r, :].values
        n_months = sum(1 for v in vals if _is_month_token(v))
        if n_months >= 4:
            return r, r + 1, r + 2
    raise ValueError(f"Could not detect a header row with months in the first {scan_rows} rows.")

def build_timeseries_for_material(csv_path: str, material_name: str) -> Optional[pd.DataFrame]:
    """Main function to find a material and extract its time-series data."""
    df = pd.read_csv(csv_path, header=None, low_memory=False)

    search_col_normalized = df.iloc[:, 1].astype(str).str.strip().str.lower()
    material_name_normalized = material_name.strip().lower()
    material_rows = df[search_col_normalized.str.contains(material_name_normalized, na=False)]
    
    if material_rows.empty:
        print(f"Warning: Material '{material_name}' not found.")
        return None
    material_row_idx = material_rows.index[0]

    df_subset = df.iloc[material_row_idx:, :].reset_index(drop=True)
    month_row_idx, attr_row_idx, status_row_idx = detect_header_rows(df_subset)

    # --- NEW LOGIC TO HANDLE SEPARATE BP, L/F, ACT DATA ROWS ---
    
    # 1. Isolate Header Rows and Data Rows
    months_header = df_subset.iloc[month_row_idx, :].ffill()
    attributes_header = df_subset.iloc[attr_row_idx, :].ffill()
    statuses_header = df_subset.iloc[status_row_idx, :].fillna("")
    
    data_block_df = df_subset.iloc[status_row_idx + 1: status_row_idx + 6]
    data_labels = data_block_df.iloc[:, 2].astype(str).str.strip().str.upper()

    bp_row = data_block_df[data_labels == 'BP']
    lf_row = data_block_df[data_labels == 'L/F']
    act_row = data_block_df[data_labels == 'ACT']
    
    # 2. Build Tidy DataFrame Directly
    records = []
    for i in range(len(df_subset.columns)):
        month = months_header[i]
        if not _is_month_token(month):
            continue

        attribute = norm_attr(attributes_header[i])
        status_from_header = norm_status(statuses_header[i])
        
        value = np.nan
        final_status = ""

        # Based on the status in the header, pick the value from the correct data row
        if status_from_header == 'planned' and not bp_row.empty:
            value = bp_row.iloc[0, i]
            final_status = 'planned'
        elif status_from_header == 'forecast' and not lf_row.empty:
            value = lf_row.iloc[0, i]
            final_status = 'forecast'
        elif status_from_header == 'actual' and not act_row.empty:
            value = act_row.iloc[0, i]
            final_status = 'actual'
        # Special handling for Inv. Days, which has a blank status and should come from the 'Act' row
        elif attribute == 'inv_days' and not act_row.empty:
            value = act_row.iloc[0, i]
            final_status = 'actual'
        
        if final_status and attribute:
            records.append({
                "month": month,
                "attribute": attribute,
                "status": final_status,
                "value": _coerce_number(value)
            })

    if not records:
        print("Warning: Failed to extract any valid data records.")
        return None

    tidy = pd.DataFrame.from_records(records)
    
    # 3. Pivot the Tidy DataFrame into the final format
    months_keep = sorted(tidy["month"].unique(), key=lambda m: pd.to_datetime(m, format='%b-%y'))
    
    wanted = []
    for attr in ["purchase", "consumption", "cb"]:
        for stat in ["planned", "actual", "forecast"]:
            wanted.append((attr, stat))
    wanted.append(("inv_days", "actual"))

    final_records = []
    for m in months_keep:
        rec = {"month": m}
        for attr, stat in wanted:
            val = tidy.loc[
                (tidy["month"] == m) & (tidy["attribute"] == attr) & (tidy["status"] == stat), "value"
            ]
            rec[f"{attr}_{stat}"] = float(val.iloc[0]) if len(val) > 0 else np.nan
        final_records.append(rec)

    return pd.DataFrame.from_records(final_records).set_index("month")

# ---------- Main Execution ----------
if __name__ == "__main__":
    csv_path = "Data/7.0 FY2025 Material Control.csv"
    material = "Silver Paste"
    out_path = "silver_paste_timeseries.csv"

    print(f"Reading file: {csv_path}")
    try:
        df_final = build_timeseries_for_material(csv_path, material)
        if df_final is not None:
            df_final.to_csv(out_path)
            print(f"Successfully extracted data for '{material}' and saved to {out_path}")
            print("\nPreview of the extracted data:")
            print(df_final.head())
    except Exception as e:
        print(f"\nAn error occurred: {e}")
        import traceback
        traceback.print_exc()