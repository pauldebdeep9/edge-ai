# save as make_demand_samples_dist.py
import numpy as np
import pandas as pd
import math

def _gamma_params_from_mean_cv(mu, cv):
    """
    Gamma(shape=k, scale=theta): mean=k*theta, var=k*theta^2.
    For target mean=mu and CV=cv (std=cv*mu):
      k = 1/cv^2
      theta = mu / k
    """
    if mu <= 0:
        return None, None
    k = 1.0 / (cv * cv)
    theta = mu / k
    return k, theta

def _lognormal_params_from_mean_cv(mu, cv):
    """
    Lognormal with parameters (m, s) where:
      mean = exp(m + s^2/2)
      CV^2 = exp(s^2) - 1  => s = sqrt(log(1+CV^2))
      m = log(mu) - s^2/2
    """
    if mu <= 0:
        return None, None
    s = math.sqrt(math.log(1.0 + cv * cv))
    m = math.log(mu) - 0.5 * s * s
    return m, s

def generate_samples_for_mu(mu, dist="gamma", cv=0.2, n=99, rng=None):
    """
    Generate n samples for a single mean 'mu' using the chosen distribution:
      - 'gamma'     : positive, right-skewed, var = (cv*mu)^2
      - 'lognormal' : positive, right-skewed, heavy tail, var = (cv*mu)^2
      - 'gaussian_cv': Normal with std = cv*mu (can be negative if mu small)
    Falls back to constant (mu) when params invalid or mu<=0.
    """
    if rng is None:
        rng = np.random.default_rng()

    if dist == "gamma":
        k, theta = _gamma_params_from_mean_cv(mu, cv)
        if k is None:
            return np.full(n, mu, dtype=float)
        return rng.gamma(shape=k, scale=theta, size=n)

    elif dist == "lognormal":
        m, s = _lognormal_params_from_mean_cv(mu, cv)
        if m is None:
            return np.full(n, mu, dtype=float)
        return rng.lognormal(mean=m, sigma=s, size=n)

    elif dist == "gaussian_cv":
        # std = cv * mu (can be 0 or negative mu -> std=abs(cv*mu))
        std = abs(cv * mu)
        if std == 0.0:
            return np.full(n, mu, dtype=float)
        return rng.normal(loc=mu, scale=std, size=n)

    else:
        raise ValueError(f"Unknown dist '{dist}'. Use 'gamma', 'lognormal', or 'gaussian_cv'.")

def main():
    # ===== User config (edit if needed) =====
    xlsx_path = "Data/pidsg25-26.xlsx"
    sheet_name = "demand"
    demand_col = "Demand"
    out_csv = "demand_99_samples_gamma.csv"
    dist = "gamma"          # choose: "gamma" | "lognormal" | "gaussian_cv"
    cv = 0.2                # 20% of mean (std = cv * mean)
    n_samples = 99
    seed = 42               # set None for non-deterministic
    # ========================================

    rng = np.random.default_rng(seed) if seed is not None else np.random.default_rng()

    df = pd.read_excel(xlsx_path, sheet_name=sheet_name)
    if demand_col not in df.columns:
        raise ValueError(f"Column '{demand_col}' not found in sheet '{sheet_name}'. Found: {list(df.columns)}")

    demand = pd.to_numeric(df[demand_col], errors="coerce").fillna(0.0).to_numpy()
    S = np.empty((len(demand), n_samples), dtype=float)

    for i, mu in enumerate(demand):
        S[i, :] = generate_samples_for_mu(mu, dist=dist, cv=cv, n=n_samples, rng=rng)

    # Build output DataFrame
    out = pd.DataFrame({demand_col: demand})
    for j in range(n_samples):
        out[f"sample_{j+1:02d}"] = S[:, j]

    out.to_csv(out_csv, index=False)
    print(f"Saved: {out_csv}")
    print(f"Dist={dist}, CV={cv}, Rows={len(demand)}, Samples/row={n_samples}")
    print(out.head())

# --- auto-run and show the command used ---
if __name__ == "__main__":
    main()
    print("\nCommand used for execution:")
    print("python make_demand_samples_dist.py")
