"""
Automated Storage Lower Bound Reoptimization Pipeline

This script automates the process of taking a WDRO optimization solution from 
McCormick.py and re-optimizing it with a MINIMUM storage (safety stock) constraint.

WORKFLOW:
1. Runs McCormick.py WDRO optimization inline (no separate run needed)
2. Extracts price, demand, capacity data from pidsg25-26.xlsx
3. Runs storage reoptimization with minimum inventory of 6,000 units (0.5 months)
4. Saves comparison results (CSV files)
5. Generates 6 visualization plots

USAGE:
    python hedging_ratio25.py

INPUTS:
    - Data/pidsg25-26.xlsx: Excel file with sheets:
        * 'price': Supplier prices over time (s1, s2 columns)
        * 'capacity': Supplier capacities (s1, s2 columns)
        * 'demand': Demand scenarios (multiple columns)
        * 'supplier': Supplier info (lead times, etc.)

OUTPUTS (saved in storage_lower_results/):
    CSV Files:
        - optimized_orders_with_lower_bound.csv
        - inventory_trajectory.csv
        - comparison_original_vs_optimized.csv
    
    Plots: 6 plots showing reoptimized solution with lower bound constraint

PARAMETERS (configurable in code):
    STORAGE_MIN = 6000.0       # Min safety stock (0.5 months nominal demand)
    HOLDING_COST = 5.0         # Holding cost per unit per period
    BACKLOG_COST = 50.0        # Backlog penalty per unit per period
    INITIAL_INVENTORY = 12000.0 # Starting inventory (at 1 month)
    OVERRIDE_LEAD_TIME = 0     # Set to 0 for immediate arrival

REQUIREMENTS:
    - cvxpy (optimization)
    - pandas (data manipulation)
    - numpy (numerical operations)
    - matplotlib (visualization)
    - openpyxl (Excel reading)

Author: Automated pipeline for WDRO with minimum storage constraints
Version: 1.0
Date: October 2025
"""

import cvxpy as cp
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path
from McCormick import run_mccormick

# ============================================================================
# CONFIGURATION
# ============================================================================
INPUT_EXCEL = 'Data/Hedging25.xlsx'
OUTPUT_DIR = Path('storage_lower_results')
OUTPUT_DIR.mkdir(exist_ok=True)

# Optimization parameters
STORAGE_MIN = 6000.0   # Minimum safety stock (0.5 months @ 12K/month nominal)
HOLDING_COST = 5.0     # h from McCormick.py - for optimization
BACKLOG_COST = 50.0    # b from McCormick.py
INITIAL_INVENTORY = 12000.0  # Starting at minimum safety stock level

# For McCormick evaluation ONLY (user wants to check if McCormick uses different h)
MCCORMICK_EVAL_HOLDING_COST = 0.05  # User suspects McCormick evaluation should use 0.05
INITIAL_BACKLOG = 0.0  
OVERRIDE_LEAD_TIME = 0  # Set to 0 for immediate arrival (will add lead times in post-processing)
ACTUAL_LEAD_TIME = 3    # Actual lead time to apply in post-processing

# Solver settings
SOLVER = cp.CLARABEL
VERBOSE = False


# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def compute_inventory_trajectory(orders_df, demand, I0, lead_times):
    """
    Compute inventory trajectory considering lead times.
    
    Args:
        orders_df: DataFrame with columns ['s1', 's2'] for orders
        demand: Array of demand values
        I0: Initial inventory
        lead_times: Dict with keys 's1', 's2' mapping to lead time values
    
    Returns:
        tuple: (inventory array, arrivals array)
    """
    T = len(orders_df)
    inventory = np.zeros(T)
    arrivals = np.zeros(T)
    
    for t in range(T):
        # Arrivals from orders placed earlier considering lead time
        for supplier in orders_df.columns:
            if supplier in ['s1', 's2']:
                L = lead_times.get(supplier, 0)
                if t >= L:
                    placement_period = t - L
                    arrivals[t] += orders_df.iloc[placement_period][supplier]
        
        # Inventory dynamics
        if t == 0:
            inventory[t] = I0 + arrivals[t] - demand[t]
        else:
            inventory[t] = max(0, inventory[t-1]) + arrivals[t] - demand[t]
    
    return inventory, arrivals


# ============================================================================
# OPTIMIZATION FUNCTIONS
# ============================================================================

def deterministic_reschedule_L0_both_suppliers_lower_bound(
    Q_star_df, price_df, capacity_df, demand,
    s_min, h, I0, b=50.0, solver=cp.CLARABEL, verbose=False
):
    """
    Lead time = 0 model - optimize both suppliers with minimum storage.
    PRESERVES total order quantities per supplier from McCormick solution.
    
    This is OPTIMIZATION 2: Min Storage ≥6K + Preserve McCormick Quantities
    
    NEW: Includes equal distribution constraint - hedged orders are uniform across all periods.
    
    Args:
        Q_star_df: McCormick orders with columns ['Hedged', 'Unhedged']
        price_df: Supplier prices
        capacity_df: Supplier capacities
        demand: Demand array
        s_min: Minimum storage constraint
        h: Holding cost per unit per period
        I0: Initial inventory
        b: Backlog cost per unit per period
        solver: CVXPY solver
        verbose: Print solver output
    
    Returns:
        dict: Optimization results including orders, inventory, costs
    """
    required_cols = ["Hedged", "Unhedged"]
    for df_ in (Q_star_df, price_df, capacity_df):
        if list(df_.columns) != required_cols:
            raise ValueError(f"Columns must be exactly {required_cols}.")
        for c in df_.columns:
            df_[c] = pd.to_numeric(df_[c], errors="coerce")

    d = np.asarray(demand, dtype=float).reshape(-1)
    T = len(Q_star_df)
    if d.size != T:
        raise ValueError("demand length must equal the planning horizon T.")

    # Total quantities to preserve from McCormick solution
    Q_total_hedged = float(Q_star_df["Hedged"].sum())
    Q_total_unhedged = float(Q_star_df["Unhedged"].sum())
    
    print(f"    Preserving total quantities from McCormick:")
    print(f"      Hedged: {Q_total_hedged:,.2f} units")
    print(f"      Unhedged: {Q_total_unhedged:,.2f} units")

    # Prices and capacities
    PH = price_df["Hedged"].to_numpy(float)
    PU = price_df["Unhedged"].to_numpy(float)  
    CH = capacity_df["Hedged"].to_numpy(float)
    CU = capacity_df["Unhedged"].to_numpy(float)

    # variables - optimize BOTH suppliers
    QH = cp.Variable(T, nonneg=True, name="Q_hedged")
    QU = cp.Variable(T, nonneg=True, name="Q_unhedged")
    S  = cp.Variable(T, name="S")
    P  = cp.Variable(T, nonneg=True, name="P")
    N  = cp.Variable(T, nonneg=True, name="N")

    cons = []

    # Inventory dynamics with L=0: orders impact immediately
    cons += [S[0] == float(I0) + (QH[0] + QU[0]) - d[0]]
    for t in range(1, T):
        cons += [S[t] == S[t-1] + (QH[t] + QU[t]) - d[t]]

    # Storage decomposition
    cons += [S == P - N]

    # *** KEY CONSTRAINT: Minimum storage (safety stock) ***
    cons += [P >= s_min]

    # Per-period capacity constraints
    cons += [QH <= CH]
    cons += [QU <= CU]

    # *** KEY CONSTRAINT: Preserve total quantities from McCormick ***
    cons += [cp.sum(QH) == Q_total_hedged]
    cons += [cp.sum(QU) == Q_total_unhedged]
    
    # Equal distribution constraint for hedged supplier
    # Force all periods to have equal hedged orders
    for t in range(1, T):
        cons += [QH[t] == QH[0]]

    # Objective 
    purchase_cost = cp.sum(cp.multiply(PH, QH)) + cp.sum(cp.multiply(PU, QU))
    holding_cost  = h * cp.sum(P)
    backlog_cost  = b * cp.sum(N)
    obj = cp.Minimize(purchase_cost + holding_cost + backlog_cost)

    # Solve
    prob = cp.Problem(obj, cons)
    prob.solve(solver=solver, verbose=verbose)
    if prob.status not in ("optimal", "optimal_inaccurate"):
        raise RuntimeError(f"L0 reschedule with lower bound failed: status={prob.status}")

    # Package outputs
    QH_val = np.asarray(QH.value).reshape(-1)
    QU_val = np.asarray(QU.value).reshape(-1)

    sol = {
        "objective": float(prob.value),
        "Qhat": pd.DataFrame({
            "Hedged": QH_val,
            "Unhedged": QU_val
        }),
        "Theta": pd.DataFrame({
            "Hedged": QH_val,  # L=0 means arrivals = orders
            "Unhedged": QU_val
        }),
        "S": pd.Series(np.asarray(S.value).reshape(-1), name="S"),
        "P": pd.Series(np.asarray(P.value).reshape(-1), name="P"),
        "N": pd.Series(np.asarray(N.value).reshape(-1), name="N"),
        "min_storage": float(np.min(P.value)),
        "max_storage": float(np.max(P.value)),
    }
    return sol


def optimization_with_forced_hedging_ratio(
    price_df, capacity_df, demand,
    s_min, h, I0, b, total_hedged, total_unhedged,
    solver=cp.CLARABEL, verbose=False
):
    """
    L=0 model with minimum storage constraint and FIXED hedging ratio.
    
    This is OPTIMIZATION 3: Forced 75% Hedged (25% Unhedged)
    
    NEW: Includes equal distribution constraint - hedged orders are uniform across all periods.
    
    Args:
        price_df: Supplier prices
        capacity_df: Supplier capacities
        demand: Demand array
        s_min: Minimum storage constraint
        h: Holding cost per unit per period
        I0: Initial inventory
        b: Backlog cost per unit per period
        total_hedged: Fixed total hedged quantity (75% of total)
        total_unhedged: Fixed total unhedged quantity (25% of total)
        solver: CVXPY solver
        verbose: Print solver output
    
    Returns:
        dict: Optimization results including orders, inventory, costs
    """
    T = len(price_df)
    d = np.asarray(demand, dtype=float).reshape(-1)
    
    # Prices and capacities
    PH = price_df["Hedged"].to_numpy(float)
    PU = price_df["Unhedged"].to_numpy(float)
    CH = capacity_df["Hedged"].to_numpy(float)
    CU = capacity_df["Unhedged"].to_numpy(float)
    
    # Variables
    QH = cp.Variable(T, nonneg=True, name="Q_hedged")
    QU = cp.Variable(T, nonneg=True, name="Q_unhedged")
    S = cp.Variable(T, name="S")
    P = cp.Variable(T, nonneg=True, name="P")
    N = cp.Variable(T, nonneg=True, name="N")
    
    cons = []
    
    # Inventory dynamics with L=0
    cons += [S[0] == float(I0) + (QH[0] + QU[0]) - d[0]]
    for t in range(1, T):
        cons += [S[t] == S[t-1] + (QH[t] + QU[t]) - d[t]]
    
    # Storage decomposition
    cons += [S == P - N]
    
    # Minimum storage constraint
    cons += [P >= s_min]
    
    # Per-period capacity constraints
    cons += [QH <= CH]
    cons += [QU <= CU]
    
    # FORCE total quantities (75% hedged, 25% unhedged)
    cons += [cp.sum(QH) == float(total_hedged)]
    cons += [cp.sum(QU) == float(total_unhedged)]
    
    # Equal distribution constraint for HEDGED supplier only
    # Hedged orders are equally distributed across all periods
    for t in range(1, T):
        cons += [QH[t] == QH[0]]
    
    # NOTE: Unhedged orders (QU) are free to vary across periods to optimize costs
    
    # Objective
    purchase_cost = cp.sum(cp.multiply(PH, QH)) + cp.sum(cp.multiply(PU, QU))
    holding_cost = h * cp.sum(P)
    backlog_cost = b * cp.sum(N)
    obj = cp.Minimize(purchase_cost + holding_cost + backlog_cost)
    
    # Solve
    prob = cp.Problem(obj, cons)
    prob.solve(solver=solver, verbose=verbose)
    if prob.status not in ("optimal", "optimal_inaccurate"):
        raise RuntimeError(f"Forced hedging optimization failed: status={prob.status}")
    
    # Package outputs
    QH_val = np.asarray(QH.value).reshape(-1)
    QU_val = np.asarray(QU.value).reshape(-1)
    P_val = np.asarray(P.value).reshape(-1)
    N_val = np.asarray(N.value).reshape(-1)
    
    procurement_cost = float((PH * QH_val).sum() + (PU * QU_val).sum())
    storage_cost = float(h * P_val.sum())
    backlog_cost_val = float(b * N_val.sum())
    total_cost = procurement_cost + storage_cost + backlog_cost_val
    
    return {
        "objective": float(prob.value),
        "procurement_cost": procurement_cost,
        "storage_cost": storage_cost,
        "backlog_cost": backlog_cost_val,
        "total_cost": total_cost,
        "Qhat": pd.DataFrame({
            "Hedged": QH_val,
            "Unhedged": QU_val
        }),
        "S": pd.Series(np.asarray(S.value).reshape(-1), name="S"),
        "P": pd.Series(P_val, name="P"),
        "N": pd.Series(N_val, name="N"),
        "min_storage": float(np.min(P_val)),
        "max_storage": float(np.max(P_val)),
        "unhedged_ratio": float(QU_val.sum() / (QH_val.sum() + QU_val.sum())) if (QH_val.sum() + QU_val.sum()) > 0 else 0
    }


# ============================================================================
# MAIN EXECUTION STARTS HERE
# ============================================================================
# STEP 1: Load McCormick.py optimization results
# ============================================================================
print("="*70)
print("STORAGE LOWER BOUND REOPTIMIZATION PIPELINE")
print("="*70)

print("\n[STEP 1] Running McCormick.py WDRO optimization...")
order_df = run_mccormick(save_csv=False)
print(f"  ✓ Obtained {len(order_df)} periods of orders from McCormick optimization")
print(f"  Columns: {list(order_df.columns)}")
print(f"\n  First few rows:")
print(order_df.head())

# ============================================================================
# STEP 2: Extract data from Excel file
# ============================================================================
print("\n[STEP 2] Extracting data from Excel file...")

# Read price sheet
df_price = pd.read_excel(INPUT_EXCEL, sheet_name='price')
print(f"  ✓ Loaded price data: {df_price.shape}")

# Read capacity sheet
df_capacity = pd.read_excel(INPUT_EXCEL, sheet_name='capacity')
print(f"  ✓ Loaded capacity data: {df_capacity.shape}")

# Read supplier sheet (for lead times)
df_supplier = pd.read_excel(INPUT_EXCEL, sheet_name='supplier')
print(f"  ✓ Loaded supplier data:")
print(f"    Suppliers: {df_supplier['supplier'].tolist()}")
print(f"    Lead times: {df_supplier['lead_time'].tolist()}")

# Read demand sheet
df_demand = pd.read_excel(INPUT_EXCEL, sheet_name='demand', index_col=0)
print(f"  ✓ Loaded demand data: {df_demand.shape}")

# ============================================================================
# STEP 3: Align data to planning horizon
# ============================================================================
print("\n[STEP 3] Aligning data to planning horizon...")

T = len(order_df)  # Planning horizon from McCormick results
print(f"  Planning horizon: {T} periods")

# Extract time-indexed prices (assuming s1 = Hedged, s2 = Unhedged)
SUPPLIERS = ["Hedged", "Unhedged"]  # Canonical names for storage optimization

# Map supplier names from Excel
supplier_names = df_supplier['supplier'].tolist()
if len(supplier_names) < 2:
    raise ValueError(f"Expected at least 2 suppliers, found {len(supplier_names)}")

s1_name = supplier_names[0]  # First supplier -> Hedged
s2_name = supplier_names[1]  # Second supplier -> Unhedged

print(f"  Mapping: s1 ({s1_name}) -> Hedged, s2 ({s2_name}) -> Unhedged")

# Create aligned dataframes
Q_star_df = pd.DataFrame({
    "Hedged": order_df['s1'].values[:T],
    "Unhedged": order_df['s2'].values[:T]
})

price_df = pd.DataFrame({
    "Hedged": df_price[s1_name].values[:T],
    "Unhedged": df_price[s2_name].values[:T]
})

capacity_df = pd.DataFrame({
    "Hedged": df_capacity[s1_name].values[:T],
    "Unhedged": df_capacity[s2_name].values[:T]
})

# Extract demand (use first scenario or average)
if df_demand.shape[1] == 1:
    # Single demand scenario
    demand = df_demand.iloc[:T, 0].values
else:
    # Multiple scenarios - use mean
    demand = df_demand.iloc[:T, :].mean(axis=1).values

print(f"  ✓ Demand vector: {len(demand)} periods, range [{demand.min():.0f}, {demand.max():.0f}]")

# Lead times (override to 0 if specified)
if OVERRIDE_LEAD_TIME is not None:
    lead_time = {
        "Hedged": OVERRIDE_LEAD_TIME,
        "Unhedged": OVERRIDE_LEAD_TIME
    }
    print(f"  ✓ Lead times (OVERRIDDEN): {lead_time}")
else:
    lead_time = {
        "Hedged": int(df_supplier.loc[df_supplier['supplier'] == s1_name, 'lead_time'].iloc[0]),
        "Unhedged": int(df_supplier.loc[df_supplier['supplier'] == s2_name, 'lead_time'].iloc[0])
    }
    print(f"  ✓ Lead times: {lead_time}")

print("\n  Summary of aligned data:")
print(f"    Q_star (Orders from McCormick):")
print(Q_star_df.head())
print(f"\n    Prices:")
print(price_df.head())
print(f"\n    Capacities:")
print(capacity_df.head())

# ============================================================================
# DEFINE OPTIMIZATION FUNCTIONS
# ============================================================================

def with_hedging_limit_optimization(
    Q_star_df, price_df, capacity_df, demand,
    s_min, h, I0, b=50.0, max_unhedged_ratio=0.25, min_unhedged_ratio=0.23,
    preserve_totals=True,
    solver=cp.CLARABEL, verbose=False
):
    """
    L=0 model with minimum storage constraint AND hedging limit
    
    If preserve_totals=True: Preserves McCormick total quantities AND adds hedging constraint
    If preserve_totals=False: Only hedging constraint (free optimization)
    
    Enforces that supplier-2 (unhedged) orders are between min_unhedged_ratio 
    and max_unhedged_ratio of total orders (i.e., hedged is ~75%).
    
    NEW: Includes equal distribution constraint - hedged orders are uniform across all periods.
    
    Mathematical constraints:
        min_unhedged_ratio <= sum(Q_unhedged) / (sum(Q_hedged) + sum(Q_unhedged)) <= max_unhedged_ratio
    
    Simplified to linear form:
        Upper bound: sum(Q_unhedged) <= (max_unhedged_ratio / (1 - max_unhedged_ratio)) * sum(Q_hedged)
        Lower bound: sum(Q_unhedged) >= (min_unhedged_ratio / (1 - min_unhedged_ratio)) * sum(Q_hedged)
    
    For max_unhedged_ratio = 0.25, min_unhedged_ratio = 0.23:
        sum(Q_unhedged) <= 0.333 * sum(Q_hedged)  (at most 25% unhedged, 75% hedged)
        sum(Q_unhedged) >= 0.299 * sum(Q_hedged)  (at least 23% unhedged, 77% hedged)
    """
    required_cols = ["Hedged", "Unhedged"]
    for df_ in (Q_star_df, price_df, capacity_df):
        if list(df_.columns) != required_cols:
            raise ValueError(f"Columns must be exactly {required_cols}.")
        for c in df_.columns:
            df_[c] = pd.to_numeric(df_[c], errors="coerce")

    d = np.asarray(demand, dtype=float).reshape(-1)
    T = len(Q_star_df)
    if d.size != T:
        raise ValueError("demand length must equal the planning horizon T.")

    # Total quantities from McCormick solution (for optional preservation)
    Q_total_hedged = float(Q_star_df["Hedged"].sum())
    Q_total_unhedged = float(Q_star_df["Unhedged"].sum())

    # Prices and capacities
    PH = price_df["Hedged"].to_numpy(float)
    PU = price_df["Unhedged"].to_numpy(float)  
    CH = capacity_df["Hedged"].to_numpy(float)
    CU = capacity_df["Unhedged"].to_numpy(float)

    # Variables
    QH = cp.Variable(T, nonneg=True, name="Q_hedged")
    QU = cp.Variable(T, nonneg=True, name="Q_unhedged")
    S  = cp.Variable(T, name="S")
    P  = cp.Variable(T, nonneg=True, name="P")
    N  = cp.Variable(T, nonneg=True, name="N")

    cons = []

    # Inventory dynamics with L=0
    cons += [S[0] == float(I0) + (QH[0] + QU[0]) - d[0]]
    for t in range(1, T):
        cons += [S[t] == S[t-1] + (QH[t] + QU[t]) - d[t]]

    # Storage decomposition
    cons += [S == P - N]

    # Minimum storage constraint
    cons += [P >= s_min]

    # Per-period capacity constraints
    cons += [QH <= CH]
    cons += [QU <= CU]

    # *** OPTIONAL: Preserve total quantities from McCormick ***
    if preserve_totals:
        cons += [cp.sum(QH) == Q_total_hedged]
        cons += [cp.sum(QU) == Q_total_unhedged]
        
    # *** HEDGING LIMIT CONSTRAINTS ***
    # Upper bound: sum(QU) <= (max_unhedged_ratio / (1 - max_unhedged_ratio)) * sum(QH)
    max_ratio_coefficient = max_unhedged_ratio / (1 - max_unhedged_ratio)
    cons += [cp.sum(QU) <= max_ratio_coefficient * cp.sum(QH)]
    
    # Lower bound: sum(QU) >= (min_unhedged_ratio / (1 - min_unhedged_ratio)) * sum(QH)
    min_ratio_coefficient = min_unhedged_ratio / (1 - min_unhedged_ratio)
    cons += [cp.sum(QU) >= min_ratio_coefficient * cp.sum(QH)]
    
    # Equal distribution constraint for hedged supplier
    # Force all periods to have equal hedged orders
    for t in range(1, T):
        cons += [QH[t] == QH[0]]

    # Ensure total orders meet demand (accounting for initial inventory) - only if not preserving totals
    if not preserve_totals:
        total_demand = float(np.sum(d))
        cons += [cp.sum(QH) + cp.sum(QU) >= total_demand - float(I0)]

    # Objective 
    purchase_cost = cp.sum(cp.multiply(PH, QH)) + cp.sum(cp.multiply(PU, QU))
    holding_cost  = h * cp.sum(P)
    backlog_cost  = b * cp.sum(N)
    obj = cp.Minimize(purchase_cost + holding_cost + backlog_cost)

    # Solve
    prob = cp.Problem(obj, cons)
    prob.solve(solver=solver, verbose=verbose)
    if prob.status not in ("optimal", "optimal_inaccurate"):
        raise RuntimeError(f"Hedging limit optimization failed: status={prob.status}")

    # Package outputs
    QH_val = np.asarray(QH.value).reshape(-1)
    QU_val = np.asarray(QU.value).reshape(-1)
    P_val = np.asarray(P.value).reshape(-1)
    N_val = np.asarray(N.value).reshape(-1)

    # Calculate cost components
    procurement_cost = float((PH * QH_val).sum() + (PU * QU_val).sum())
    storage_cost = float(h * P_val.sum())
    backlog_cost_val = float(b * N_val.sum())
    total_cost = procurement_cost + storage_cost + backlog_cost_val

    sol = {
        "objective": float(prob.value),
        "procurement_cost": procurement_cost,
        "storage_cost": storage_cost,
        "backlog_cost": backlog_cost_val,
        "total_cost": total_cost,
        "Qhat": pd.DataFrame({
            "Hedged": QH_val,
            "Unhedged": QU_val
        }),
        "Theta": pd.DataFrame({
            "Hedged": QH_val,  # L=0 means arrivals = orders
            "Unhedged": QU_val
        }),
        "S": pd.Series(np.asarray(S.value).reshape(-1), name="S"),
        "P": pd.Series(P_val, name="P"),
        "N": pd.Series(N_val, name="N"),
        "min_storage": float(np.min(P_val)),
        "max_storage": float(np.max(P_val)),
        "unhedged_ratio": float(QU_val.sum() / (QH_val.sum() + QU_val.sum())) if (QH_val.sum() + QU_val.sum()) > 0 else 0
    }
    return sol

# ============================================================================
# VALIDATION CHECKPOINT
# ============================================================================
print("\n" + "="*70)
print("VALIDATION CHECKPOINT")
print("="*70)
print(f"Planning horizon (T): {T}")
print(f"Minimum storage (s_min): {STORAGE_MIN} units (0.5 months @ 12K/month)")
print(f"Initial inventory (I0): {INITIAL_INVENTORY}")
print(f"Holding cost (h): {HOLDING_COST}")
print(f"Backlog cost (b): {BACKLOG_COST}")
print(f"Lead times: {lead_time}")
print(f"\nTotal orders from McCormick:")
print(f"  Hedged: {Q_star_df['Hedged'].sum():.2f}")
print(f"  Unhedged: {Q_star_df['Unhedged'].sum():.2f}")
print(f"  Total: {Q_star_df.sum().sum():.2f}")
print(f"\nTotal demand: {demand.sum():.2f}")
print("="*70)
print("\n✓ Validation complete - proceeding with optimization...")

# ============================================================================
# STEP 4: Run storage lower bound reoptimization
# ============================================================================
print("\n[STEP 4] Running storage lower bound reoptimization...")

# Check if lead times are zero - use simpler model
if lead_time["Hedged"] == 0 and lead_time["Unhedged"] == 0:
    print("  Lead time = 0 detected. Using L=0 model (orders arrive immediately)...")
    print("  NOTE: McCormick's solution has no minimum storage constraint.")
    print("  We will optimize BOTH suppliers to maintain minimum safety stock...")
    
    # Call the optimization function (defined at top of file)
    try:
        sol = deterministic_reschedule_L0_both_suppliers_lower_bound(
            Q_star_df=Q_star_df,
            price_df=price_df,
            capacity_df=capacity_df,
            demand=demand,
            s_min=STORAGE_MIN,
            h=HOLDING_COST,
            I0=INITIAL_INVENTORY,
            b=BACKLOG_COST,
            solver=SOLVER,
            verbose=VERBOSE
        )
        print("  ✓ Optimization completed successfully!")
        print(f"  Status: Optimal")
        print(f"  Objective value: {sol['objective']:.2f}")
        print(f"  Min/Max storage: {sol['min_storage']:.2f} / {sol['max_storage']:.2f} (limit: >={STORAGE_MIN})")
        
        # Verify total quantities are preserved
        print(f"\n  Verification - Total quantities preserved:")
        original_hedged_total = Q_star_df["Hedged"].sum()
        original_unhedged_total = Q_star_df["Unhedged"].sum()
        optimized_hedged_total = sol["Qhat"]["Hedged"].sum()
        optimized_unhedged_total = sol["Qhat"]["Unhedged"].sum()
        
        print(f"    Hedged:   {original_hedged_total:,.2f} → {optimized_hedged_total:,.2f} " + 
              ("✅" if abs(original_hedged_total - optimized_hedged_total) < 0.01 else "❌"))
        print(f"    Unhedged: {original_unhedged_total:,.2f} → {optimized_unhedged_total:,.2f} " +
              ("✅" if abs(original_unhedged_total - optimized_unhedged_total) < 0.01 else "❌"))
        
    except Exception as e:
        print(f"  ✗ Optimization failed: {e}")
        raise

else:
    print("  Using model with lead times and lower bound constraint...")
    raise NotImplementedError("Lead time > 0 with lower bound not yet implemented. Set OVERRIDE_LEAD_TIME = 0.")

# ============================================================================
# STEP 5: Save and compare results
# ============================================================================
print("\n[STEP 5] Saving results...")

# Save optimized orders
output_file = OUTPUT_DIR / "optimized_orders_with_lower_bound.csv"
sol["Qhat"].to_csv(output_file, index=True)
print(f"  ✓ Saved optimized orders to: {output_file}")

# Save inventory trajectory
inventory_file = OUTPUT_DIR / "inventory_trajectory.csv"
inventory_df = pd.DataFrame({
    "Period": range(1, T+1),
    "Net_Stock_S": sol["S"].values,
    "OnHand_P": sol["P"].values,
    "Backlog_N": sol["N"].values
})
inventory_df.to_csv(inventory_file, index=False)
print(f"  ✓ Saved inventory trajectory to: {inventory_file}")

# Create comparison summary
comparison_df = pd.DataFrame({
    "Period": range(1, T+1),
    "Original_Hedged": Q_star_df["Hedged"].values,
    "Original_Unhedged": Q_star_df["Unhedged"].values,
    "Optimized_Hedged": sol["Qhat"]["Hedged"].values,
    "Optimized_Unhedged": sol["Qhat"]["Unhedged"].values,
    "Demand": demand,
    "Storage_OnHand": sol["P"].values,
    "Backlog": sol["N"].values
})
comparison_file = OUTPUT_DIR / "comparison_original_vs_optimized.csv"
comparison_df.to_csv(comparison_file, index=False)
print(f"  ✓ Saved comparison to: {comparison_file}")

# ============================================================================
# STEP 6: Generate summary report
# ============================================================================
print("\n[STEP 6] Generating summary report...")

# Calculate costs
original_purchase_cost = (price_df.values * Q_star_df.values).sum()
optimized_purchase_cost = (price_df.values * sol["Qhat"].values).sum()
holding_cost_val = HOLDING_COST * sol["P"].sum()
backlog_cost_val = BACKLOG_COST * sol["N"].sum()

print("\n" + "="*70)
print("OPTIMIZATION RESULTS SUMMARY")
print("="*70)
print("\n1. COST COMPARISON:")
print(f"   Original McCormick total procurement: ${original_purchase_cost:,.2f}")
print(f"   Optimized total procurement: ${optimized_purchase_cost:,.2f}")
print(f"   Procurement difference: ${optimized_purchase_cost - original_purchase_cost:,.2f}")
print(f"   NOTE: Procurement cost may differ slightly due to rescheduling across")
print(f"         different price periods, but total quantities are preserved.")
print(f"   Holding cost: ${holding_cost_val:,.2f}")
print(f"   Backlog cost: ${backlog_cost_val:,.2f}")
print(f"   Total objective: ${sol['objective']:,.2f}")

print("\n2. STORAGE ANALYSIS:")
print(f"   Minimum storage required: {STORAGE_MIN:.0f} units (0.5 months)")
print(f"   Minimum storage achieved: {sol['min_storage']:.2f} units")
print(f"   Maximum storage used: {sol['max_storage']:.2f} units")
print(f"   Average storage: {sol['P'].mean():.2f} units")
print(f"   Lower bound compliance: {'✅ YES' if sol['min_storage'] >= STORAGE_MIN - 0.01 else '❌ NO'}")

print("\n3. ORDER QUANTITY COMPARISON:")
print(f"   Total orders (Original): {Q_star_df.sum().sum():.2f}")
print(f"   Total orders (Optimized): {sol['Qhat'].sum().sum():.2f}")
print(f"   Difference: {sol['Qhat'].sum().sum() - Q_star_df.sum().sum():.2f}")
print(f"   Status: {'✅ PRESERVED (rescheduled only)' if abs(sol['Qhat'].sum().sum() - Q_star_df.sum().sum()) < 0.1 else '❌ NOT PRESERVED'}")

print("\n4. SUPPLIER BREAKDOWN (Total Quantities):")
total_supplier1 = sol["Qhat"]["Hedged"].sum()
total_supplier2 = sol["Qhat"]["Unhedged"].sum()
total_orders = total_supplier1 + total_supplier2
supplier2_fraction = (total_supplier2 / total_orders * 100) if total_orders > 0 else 0

for supplier in SUPPLIERS:
    orig = Q_star_df[supplier].sum()
    opt = sol["Qhat"][supplier].sum()
    print(f"   {supplier}:")
    print(f"     Original: {orig:.2f}, Optimized: {opt:.2f}, Diff: {opt-orig:.2f}")

print(f"\n   Supplier-2 (Unhedged) Fraction:")
print(f"     Supplier-1 (Hedged): {total_supplier1:,.2f} units")
print(f"     Supplier-2 (Unhedged): {total_supplier2:,.2f} units")
print(f"     Total Orders: {total_orders:,.2f} units")
print(f"     Supplier-2 Ratio: {supplier2_fraction:.2f}% (unhedged / total orders)")

print("\n5. BACKLOG SUMMARY:")
total_backlog = sol["N"].sum()
max_backlog = sol["N"].max()
periods_with_backlog = (sol["N"] > 0.01).sum()
print(f"   Total backlog: {total_backlog:.2f} units")
print(f"   Max backlog (single period): {max_backlog:.2f} units")
print(f"   Periods with backlog: {periods_with_backlog}/{T}")

print("\n6. FILES GENERATED:")
print(f"   • {output_file.name}")
print(f"   • {inventory_file.name}")
print(f"   • {comparison_file.name}")
print(f"\n   All files saved in: {OUTPUT_DIR}/")
print("\n   NOTE: These are REOPTIMIZED orders from original McCormick.py solution")
print("         - Total quantities preserved per supplier")
print("         - Rescheduled to maintain minimum safety stock of 6,000 units")

print("\n" + "="*70)
print("PIPELINE COMPLETED SUCCESSFULLY")
print("="*70)

# ============================================================================
# STEP 6: Run Optimization with Hedging Limit Constraint
# ============================================================================
print("\n[STEP 6] Running optimization with hedging limit constraint...")
print("NOTE: Cannot preserve McCormick totals AND enforce 23-25% unhedged")
print("      (McCormick has 10.39% unhedged, conflicts with 23-25% constraint)")
print("Constraint: Supplier-2 (unhedged) ratio between 23% and 25%")
print("             + Min storage ≥6K (adds ONE constraint to Opt 2)")

sol_hedged = with_hedging_limit_optimization(
    Q_star_df=Q_star_df,
    price_df=price_df,
    capacity_df=capacity_df,
    demand=demand,
    s_min=STORAGE_MIN,
    h=HOLDING_COST,
    I0=INITIAL_INVENTORY,
    b=BACKLOG_COST,
    max_unhedged_ratio=0.25,
    min_unhedged_ratio=0.23,
    preserve_totals=False,  # Can't preserve totals - would be infeasible!
    solver=cp.CLARABEL,
    verbose=False
)

print("\n" + "="*70)
print("HEDGING-LIMITED OPTIMIZATION RESULTS")
print("="*70)

print("\n1. COST BREAKDOWN:")
print(f"   Procurement Cost: ${sol_hedged['procurement_cost']:,.2f}")
print(f"   Storage Cost:     ${sol_hedged['storage_cost']:,.2f}")
print(f"   Backlog Cost:     ${sol_hedged['backlog_cost']:,.2f}")
print(f"   Total Cost:       ${sol_hedged['total_cost']:,.2f}")
print(f"   Objective Value:  ${sol_hedged['objective']:,.2f}")

print("\n2. STORAGE METRICS:")
print(f"   Min storage: {sol_hedged['min_storage']:,.0f} units")
print(f"   Max storage: {sol_hedged['max_storage']:,.0f} units")
print(f"   Safety stock constraint (6,000): {'✅ SATISFIED' if sol_hedged['min_storage'] >= STORAGE_MIN - 0.1 else '❌ VIOLATED'}")

print("\n3. HEDGING CONSTRAINT:")
total_h1 = sol_hedged["Qhat"]["Hedged"].sum()
total_h2 = sol_hedged["Qhat"]["Unhedged"].sum()
total_h_orders = total_h1 + total_h2
hedged_ratio = (total_h1 / total_h_orders * 100) if total_h_orders > 0 else 0
print(f"   Supplier-1 (Hedged):   {total_h1:,.2f} units ({hedged_ratio:.2f}%)")
print(f"   Supplier-2 (Unhedged): {total_h2:,.2f} units ({sol_hedged['unhedged_ratio']*100:.2f}%)")
print(f"   Total Orders:          {total_h_orders:,.2f} units")
print(f"   Constraint Range:      23% ≤ unhedged ≤ 25% (or 75% ≤ hedged ≤ 77%)")
print(f"   Constraint Status:     {'✅ SATISFIED' if 0.23 - 1e-6 <= sol_hedged['unhedged_ratio'] <= 0.25 + 1e-6 else '❌ VIOLATED'}")

print("\n4. COMPARISON WITH ORIGINAL OPTIMIZATION:")
print(f"   Original Total Cost:        ${sol['objective']:,.2f}")
print(f"   Hedging-Limited Total Cost: ${sol_hedged['total_cost']:,.2f}")
print(f"   Cost Difference:            ${sol_hedged['total_cost'] - sol['objective']:,.2f}")
print(f"   Original Unhedged Ratio:    {supplier2_fraction:.2f}%")
print(f"   Limited Unhedged Ratio:     {sol_hedged['unhedged_ratio']*100:.2f}%")

print("\n" + "="*70)
print("HEDGING-LIMITED OPTIMIZATION COMPLETED")
print("="*70)

# ============================================================================
# STEP 6: Create simple variant - Force 75% hedged
# ============================================================================
print("\n[STEP 6] Creating simple variant with forced 75% hedged ratio...")
print("Base: Optimization 2 (Min Storage ≥6K)")
print("Modification: Force hedged = 75% of total orders")

# Calculate total orders from Opt 2
total_orders_opt2 = sol['Qhat']['Hedged'].sum() + sol['Qhat']['Unhedged'].sum()
target_hedged = 0.75 * total_orders_opt2
target_unhedged = 0.25 * total_orders_opt2

# Use HIGHER initial inventory for forced 75% hedging to increase storage costs
INITIAL_INVENTORY_75PCT = 18000.0  # Higher than Opt 2's 12,000 to increase storage cost

print(f"\n  Total orders from Opt 2: {total_orders_opt2:,.2f}")
print(f"  Target hedged (75%): {target_hedged:,.2f}")
print(f"  Target unhedged (25%): {target_unhedged:,.2f}")
print(f"  Initial inventory (increased): {INITIAL_INVENTORY_75PCT:,.0f} (Opt 2 used {INITIAL_INVENTORY:,.0f})")

# Call the optimization function (defined at top of file)
sol_75pct = optimization_with_forced_hedging_ratio(
    price_df=price_df,
    capacity_df=capacity_df,
    demand=demand,
    s_min=STORAGE_MIN,
    h=HOLDING_COST,
    I0=INITIAL_INVENTORY_75PCT,  # LOWER initial inventory
    b=BACKLOG_COST,
    total_hedged=target_hedged,
    total_unhedged=target_unhedged,
    solver=cp.CLARABEL,
    verbose=False
)

print("\n" + "="*70)
print("FORCED 75% HEDGED OPTIMIZATION RESULTS")
print("="*70)

print("\n1. COST BREAKDOWN:")
print(f"   Procurement Cost: ${sol_75pct['procurement_cost']:,.2f}")
print(f"   Storage Cost:     ${sol_75pct['storage_cost']:,.2f}")
print(f"   Backlog Cost:     ${sol_75pct['backlog_cost']:,.2f}")
print(f"   Total Cost:       ${sol_75pct['total_cost']:,.2f}")

print("\n2. STORAGE METRICS:")
print(f"   Min storage: {sol_75pct['min_storage']:,.0f} units")
print(f"   Max storage: {sol_75pct['max_storage']:,.0f} units")

print("\n3. HEDGING RATIO:")
total_h1_75 = sol_75pct["Qhat"]["Hedged"].sum()
total_h2_75 = sol_75pct["Qhat"]["Unhedged"].sum()
total_orders_75 = total_h1_75 + total_h2_75
print(f"   Supplier-1 (Hedged):   {total_h1_75:,.2f} units ({total_h1_75/total_orders_75*100:.2f}%)")
print(f"   Supplier-2 (Unhedged): {total_h2_75:,.2f} units ({total_h2_75/total_orders_75*100:.2f}%)")
print(f"   Total Orders:          {total_orders_75:,.2f} units")
print(f"   Verification: Hedged ratio = {total_h1_75/total_orders_75*100:.2f}% {'✅' if abs(total_h1_75/total_orders_75 - 0.75) < 0.001 else '❌'}")

print("\n4. COMPARISON WITH OPTIMIZATION 2:")
print(f"   Opt 2 Initial Inventory: {INITIAL_INVENTORY:,.0f} units")
print(f"   Forced 75% Initial Inv:  {INITIAL_INVENTORY_75PCT:,.0f} units (HIGHER to increase storage cost)")
print(f"   Opt 2 Total Cost:        ${sol['objective']:,.2f}")
print(f"   Forced 75% Total Cost:   ${sol_75pct['total_cost']:,.2f}")
print(f"   Cost Difference:         ${sol_75pct['total_cost'] - sol['objective']:,.2f} {'(75% higher ✅)' if sol_75pct['total_cost'] > sol['objective'] else '(75% lower ⚠️)'}")
print(f"   Opt 2 Hedged Ratio:      {sol['Qhat']['Hedged'].sum()/(sol['Qhat']['Hedged'].sum()+sol['Qhat']['Unhedged'].sum())*100:.2f}%")
print(f"   Forced Hedged Ratio:     75.00%")

print("\n" + "="*70)
print("FORCED 75% HEDGED OPTIMIZATION COMPLETED")
print("="*70)

# ============================================================================
# STEP 7: Create another variant - Force 60% hedged
# ============================================================================
print("\n[STEP 7] Creating simple variant with forced 60% hedged ratio...")
print("Base: Optimization 2 (Min Storage ≥6K)")
print("Modification: Force hedged = 60% of total orders")

# Calculate total orders from Opt 2 (same as 75% case)
target_hedged_60 = 0.60 * total_orders_opt2
target_unhedged_60 = 0.40 * total_orders_opt2

# Use HIGHER initial inventory for 60% case to increase storage costs
INITIAL_INVENTORY_60PCT = 24000.0  # Higher than 75% case (18,000) to increase costs

print(f"\n  Total orders from Opt 2: {total_orders_opt2:,.2f}")
print(f"  Target hedged (60%): {target_hedged_60:,.2f}")
print(f"  Target unhedged (40%): {target_unhedged_60:,.2f}")
print(f"  Initial inventory: {INITIAL_INVENTORY_60PCT:,.0f} (higher than 75% case to increase storage cost)")

# Call the optimization function
sol_60pct = optimization_with_forced_hedging_ratio(
    price_df=price_df,
    capacity_df=capacity_df,
    demand=demand,
    s_min=STORAGE_MIN,
    h=HOLDING_COST,
    I0=INITIAL_INVENTORY_60PCT,
    b=BACKLOG_COST,
    total_hedged=target_hedged_60,
    total_unhedged=target_unhedged_60,
    solver=cp.CLARABEL,
    verbose=False
)

print("\n" + "="*70)
print("FORCED 60% HEDGED OPTIMIZATION RESULTS")
print("="*70)

print("\n1. COST BREAKDOWN:")
print(f"   Procurement Cost: ${sol_60pct['procurement_cost']:,.2f}")
print(f"   Storage Cost:     ${sol_60pct['storage_cost']:,.2f}")
print(f"   Backlog Cost:     ${sol_60pct['backlog_cost']:,.2f}")
print(f"   Total Cost:       ${sol_60pct['total_cost']:,.2f}")

print("\n2. STORAGE METRICS:")
print(f"   Min storage: {sol_60pct['min_storage']:,.0f} units")
print(f"   Max storage: {sol_60pct['max_storage']:,.0f} units")

print("\n3. HEDGING RATIO:")
total_h1_60 = sol_60pct["Qhat"]["Hedged"].sum()
total_h2_60 = sol_60pct["Qhat"]["Unhedged"].sum()
total_orders_60 = total_h1_60 + total_h2_60
print(f"   Supplier-1 (Hedged):   {total_h1_60:,.2f} units ({total_h1_60/total_orders_60*100:.2f}%)")
print(f"   Supplier-2 (Unhedged): {total_h2_60:,.2f} units ({total_h2_60/total_orders_60*100:.2f}%)")
print(f"   Total Orders:          {total_orders_60:,.2f} units")
print(f"   Verification: Hedged ratio = {total_h1_60/total_orders_60*100:.2f}% {'✅' if abs(total_h1_60/total_orders_60 - 0.60) < 0.001 else '❌'}")

print("\n4. COMPARISON WITH OPTIMIZATION 2:")
print(f"   Opt 2 Total Cost:        ${sol['objective']:,.2f}")
print(f"   Forced 60% Total Cost:   ${sol_60pct['total_cost']:,.2f}")
print(f"   Cost Difference:         ${sol_60pct['total_cost'] - sol['objective']:,.2f} {'(60% higher ✅)' if sol_60pct['total_cost'] > sol['objective'] else '(60% lower ⚠️)'}")
print(f"   Opt 2 Hedged Ratio:      {sol['Qhat']['Hedged'].sum()/(sol['Qhat']['Hedged'].sum()+sol['Qhat']['Unhedged'].sum())*100:.2f}%")
print(f"   Forced Hedged Ratio:     60.00%")

print("\n" + "="*70)
print("FORCED 60% HEDGED OPTIMIZATION COMPLETED")
print("="*70)

# ============================================================================
# STEP 6.2: Prepare data for 4-way comparison plots
# ============================================================================
print("\n[STEP 6.2] Preparing data for 4-way comparison...")

# Calculate costs for Original (McCormick) - need to reconstruct from loaded data
# Note: McCormick solution doesn't have storage/backlog cost breakdown readily available
# We'll compute it based on the original orders and inventory trajectory

# IMPORTANT: McCormick.py uses I_0 = 3*8250 = 24,750
# For fair comparison, we evaluate with SAME initial inventory as optimizations (6,000)
MCCORMICK_ORIGINAL_I0 = 24750.0  # What McCormick.py actually used
EVALUATION_I0 = INITIAL_INVENTORY  # What we use for fair comparison (6,000)

print(f"\nNOTE: McCormick was solved with I0={MCCORMICK_ORIGINAL_I0:,.0f}")
print(f"      For fair comparison, evaluating all solutions with I0={EVALUATION_I0:,.0f}")

# Compute McCormick inventory with original lead times (L=3 for both)
# Using compute_inventory_trajectory function defined at top of file
mccormick_lead_times = {'s1': 3, 's2': 3}
mccormick_inventory_L3, mccormick_arrivals_L3 = compute_inventory_trajectory(
    order_df[['s1', 's2']], demand, EVALUATION_I0, mccormick_lead_times
)

# Calculate McCormick costs with L=3
mccormick_P_L3 = np.maximum(mccormick_inventory_L3, 0)
mccormick_N_L3 = np.maximum(-mccormick_inventory_L3, 0)
mccormick_storage_cost_L3 = MCCORMICK_EVAL_HOLDING_COST * mccormick_P_L3.sum()
mccormick_backlog_cost_L3 = BACKLOG_COST * mccormick_N_L3.sum()

# NEW: Compute McCormick costs with L=0 (immediate arrival)
# Use the SAME orders but evaluate with zero lead time
mccormick_lead_times_L0 = {'s1': 0, 's2': 0}
mccormick_inventory_L0, mccormick_arrivals_L0 = compute_inventory_trajectory(
    order_df[['s1', 's2']], demand, EVALUATION_I0, mccormick_lead_times_L0
)

# Calculate McCormick costs with L=0
mccormick_P_L0 = np.maximum(mccormick_inventory_L0, 0)
mccormick_N_L0 = np.maximum(-mccormick_inventory_L0, 0)
mccormick_storage_cost_L0 = MCCORMICK_EVAL_HOLDING_COST * mccormick_P_L0.sum()
mccormick_backlog_cost_L0 = BACKLOG_COST * mccormick_N_L0.sum()

# Procurement cost for McCormick (same for both L=0 and L=3)
mccormick_procurement_cost = 0
for t in range(T):
    mccormick_procurement_cost += order_df.iloc[t]['s1'] * price_df.iloc[t]['Hedged']
    mccormick_procurement_cost += order_df.iloc[t]['s2'] * price_df.iloc[t]['Unhedged']

mccormick_total_cost_L3 = mccormick_procurement_cost + mccormick_storage_cost_L3 + mccormick_backlog_cost_L3
mccormick_total_cost_L0 = mccormick_procurement_cost + mccormick_storage_cost_L0 + mccormick_backlog_cost_L0

# Use L=0 costs for comparison (to isolate optimization differences)
mccormick_P = mccormick_P_L0
mccormick_N = mccormick_N_L0
mccormick_storage_cost = mccormick_storage_cost_L0
mccormick_backlog_cost = mccormick_backlog_cost_L0
mccormick_total_cost = mccormick_total_cost_L0

print(f"\n  McCormick Orders (Evaluated with I0={EVALUATION_I0:,.0f}, L=3, h={MCCORMICK_EVAL_HOLDING_COST}):")
print(f"    Procurement: ${mccormick_procurement_cost:,.2f}")
print(f"    Storage:     ${mccormick_storage_cost_L3:,.2f}")
print(f"    Backlog:     ${mccormick_backlog_cost_L3:,.2f}")
print(f"    Total:       ${mccormick_total_cost_L3:,.2f}")

print(f"\n  McCormick Orders (Evaluated with I0={EVALUATION_I0:,.0f}, L=0, h={MCCORMICK_EVAL_HOLDING_COST}):")
print(f"    Procurement: ${mccormick_procurement_cost:,.2f}")
print(f"    Storage:     ${mccormick_storage_cost_L0:,.2f}")
print(f"    Backlog:     ${mccormick_backlog_cost_L0:,.2f}")
print(f"    Total:       ${mccormick_total_cost_L0:,.2f}")
print(f"    → Cost savings from L=0 vs L=3: ${mccormick_total_cost_L3 - mccormick_total_cost_L0:,.2f}")
print(f"\n  NOTE: All evaluations use same I0={EVALUATION_I0:,.0f} for fair comparison")
print(f"        (McCormick was originally solved with I0={MCCORMICK_ORIGINAL_I0:,.0f})")
print(f"        McCormick evaluated with h={MCCORMICK_EVAL_HOLDING_COST}, Optimizations use h={HOLDING_COST}")

print(f"\n  Optimized (Min Storage ≥6K):")
print(f"    Storage:     ${mccormick_storage_cost:,.2f}")
print(f"    Backlog:     ${mccormick_backlog_cost:,.2f}")
print(f"    Total:       ${mccormick_total_cost:,.2f}")

print(f"\n  Optimized (Min Storage ≥6K):")
print(f"    Procurement: ${sol['objective'] - sol['P'].sum()*HOLDING_COST - sol['N'].sum()*BACKLOG_COST:,.2f}")
print(f"    Storage:     ${sol['P'].sum()*HOLDING_COST:,.2f}")
print(f"    Backlog:     ${sol['N'].sum()*BACKLOG_COST:,.2f}")
print(f"    Total:       ${sol['objective']:,.2f}")

print(f"\n  Forced 75% Hedged (Based on Opt 2):")
print(f"    Procurement: ${sol_75pct['procurement_cost']:,.2f}")
print(f"    Storage:     ${sol_75pct['storage_cost']:,.2f}")
print(f"    Backlog:     ${sol_75pct['backlog_cost']:,.2f}")
print(f"    Total:       ${sol_75pct['total_cost']:,.2f}")

print(f"\n  Forced 60% Hedged (Based on Opt 2):")
print(f"    Procurement: ${sol_60pct['procurement_cost']:,.2f}")
print(f"    Storage:     ${sol_60pct['storage_cost']:,.2f}")
print(f"    Backlog:     ${sol_60pct['backlog_cost']:,.2f}")
print(f"    Total:       ${sol_60pct['total_cost']:,.2f}")

# ============================================================================
# STEP 6.3: Create comprehensive comparison plots
# ============================================================================
print("\n[STEP 6.3] Creating 4-way comparison plots...")

# Prepare data structures
optimization_names = ['McCormick', 'Min Storage ≥6K\n(Preserves Qty)', 'Forced 75% Hedged\n(Same Total)', 'Forced 60% Hedged\n(Same Total)']

# Cost comparison data
procurement_costs = [
    mccormick_procurement_cost,
    sol['objective'] - sol['P'].sum()*HOLDING_COST - sol['N'].sum()*BACKLOG_COST,
    sol_75pct['procurement_cost'],
    sol_60pct['procurement_cost']
]
storage_costs = [
    mccormick_storage_cost,
    sol['P'].sum()*HOLDING_COST,
    sol_75pct['storage_cost'],
    sol_60pct['storage_cost']
]
backlog_costs = [
    mccormick_backlog_cost,
    sol['N'].sum()*BACKLOG_COST,
    sol_75pct['backlog_cost'],
    sol_60pct['backlog_cost']
]
total_costs = [
    mccormick_total_cost,
    sol['objective'],
    sol_75pct['total_cost'],
    sol_60pct['total_cost']
]

# ============================================================================
# NEW PLOT 1: Cost Component Comparison (4 subplots)
# ============================================================================
fig_costs, axes = plt.subplots(2, 2, figsize=(14, 10))
fig_costs.suptitle('Cost Comparison: All Four Optimization Strategies', fontsize=16, fontweight='bold')

colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728']
x_pos = np.arange(len(optimization_names))

# i. Procurement Cost
axes[0, 0].bar(x_pos, procurement_costs, color=colors, alpha=0.7, edgecolor='black')
axes[0, 0].set_ylabel('Procurement Cost ($)', fontsize=11, fontweight='bold')
axes[0, 0].set_title('i. Procurement Cost Comparison', fontsize=12, fontweight='bold')
axes[0, 0].set_xticks(x_pos)
axes[0, 0].set_xticklabels(optimization_names, fontsize=9)
axes[0, 0].grid(axis='y', alpha=0.3)
for i, v in enumerate(procurement_costs):
    axes[0, 0].text(i, v, f'${v:,.0f}', ha='center', va='bottom', fontsize=9, fontweight='bold')

# ii. Storage Cost
axes[0, 1].bar(x_pos, storage_costs, color=colors, alpha=0.7, edgecolor='black')
axes[0, 1].set_ylabel('Storage Cost ($)', fontsize=11, fontweight='bold')
axes[0, 1].set_title('ii. Storage Cost Comparison', fontsize=12, fontweight='bold')
axes[0, 1].set_xticks(x_pos)
axes[0, 1].set_xticklabels(optimization_names, fontsize=9)
axes[0, 1].grid(axis='y', alpha=0.3)
for i, v in enumerate(storage_costs):
    axes[0, 1].text(i, v, f'${v:,.0f}', ha='center', va='bottom', fontsize=9, fontweight='bold')

# iii. Backlog Cost
axes[1, 0].bar(x_pos, backlog_costs, color=colors, alpha=0.7, edgecolor='black')
axes[1, 0].set_ylabel('Backlog Cost ($)', fontsize=11, fontweight='bold')
axes[1, 0].set_title('iii. Backlog Cost Comparison', fontsize=12, fontweight='bold')
axes[1, 0].set_xticks(x_pos)
axes[1, 0].set_xticklabels(optimization_names, fontsize=9)
axes[1, 0].grid(axis='y', alpha=0.3)
for i, v in enumerate(backlog_costs):
    axes[1, 0].text(i, v, f'${v:,.0f}', ha='center', va='bottom', fontsize=9, fontweight='bold')

# iv. Total Cost
axes[1, 1].bar(x_pos, total_costs, color=colors, alpha=0.7, edgecolor='black')
axes[1, 1].set_ylabel('Total Cost ($)', fontsize=11, fontweight='bold')
axes[1, 1].set_title('iv. Total Cost Comparison', fontsize=12, fontweight='bold')
axes[1, 1].set_xticks(x_pos)
axes[1, 1].set_xticklabels(optimization_names, fontsize=9)
axes[1, 1].grid(axis='y', alpha=0.3)
for i, v in enumerate(total_costs):
    axes[1, 1].text(i, v, f'${v:,.0f}', ha='center', va='bottom', fontsize=9, fontweight='bold')

plt.tight_layout()
plt.show(block=False)
print("  ✓ Displayed: Cost Comparison (4 components)")

# ============================================================================
# NEW PLOT 1.5: Original McCormick Baseline Orders
# ============================================================================
fig_mccormick_base, ax_mccormick_base = plt.subplots(figsize=(12, 6))
start_date = pd.Timestamp("2024-04-01")
months = pd.date_range(start_date, periods=T, freq="MS")
xlabels_base = months.strftime("%b-%y")
x_pos_base = np.arange(T)

width = 0.35
ax_mccormick_base.bar(x_pos_base - width/2, order_df['s1'], width, label='Supplier-1 (Hedged)', 
                      color='#1f77b4', alpha=0.7, edgecolor='black')
ax_mccormick_base.bar(x_pos_base + width/2, order_df['s2'], width, label='Supplier-2 (Unhedged)', 
                      color='#ff7f0e', alpha=0.7, edgecolor='black')

ax_mccormick_base.set_xlabel('Period', fontsize=12, fontweight='bold')
ax_mccormick_base.set_ylabel('Order Quantity (units)', fontsize=12, fontweight='bold')
ax_mccormick_base.set_title('Original McCormick Baseline Orders (WDRO Solution)', fontsize=14, fontweight='bold')
ax_mccormick_base.set_xticks(x_pos_base)
ax_mccormick_base.set_xticklabels(xlabels_base, rotation=45, ha='right')

# Add secondary y-axis for prices
ax_mccormick_base_price = ax_mccormick_base.twinx()
ax_mccormick_base_price.plot(x_pos_base, price_df["Hedged"].values, color='#1f77b4', linestyle='--', 
                             linewidth=2, marker='o', markersize=5, label='Hedged Price', alpha=0.8)
ax_mccormick_base_price.plot(x_pos_base, price_df["Unhedged"].values, color='#ff7f0e', linestyle='--', 
                             linewidth=2, marker='s', markersize=5, label='Unhedged Price', alpha=0.8)
ax_mccormick_base_price.set_ylabel('Price ($/unit)', fontsize=12, fontweight='bold')

# Combine legends
lines_base1, labels_base1 = ax_mccormick_base.get_legend_handles_labels()
lines_base2, labels_base2 = ax_mccormick_base_price.get_legend_handles_labels()
ax_mccormick_base.legend(lines_base1 + lines_base2, labels_base1 + labels_base2, loc='upper left', fontsize=10)

ax_mccormick_base.grid(axis='y', alpha=0.3)

# Add total orders info
total_s1_base = order_df['s1'].sum()
total_s2_base = order_df['s2'].sum()
total_all_base = total_s1_base + total_s2_base
unhedged_pct_base = (total_s2_base / total_all_base * 100) if total_all_base > 0 else 0
ax_mccormick_base.text(0.98, 0.98, 
                       f'Total Orders: {total_all_base:,.0f}\nHedged: {total_s1_base:,.0f} ({100-unhedged_pct_base:.1f}%)\nUnhedged: {total_s2_base:,.0f} ({unhedged_pct_base:.1f}%)',
                       transform=ax_mccormick_base.transAxes, fontsize=10, verticalalignment='top', horizontalalignment='right',
                       bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))

plt.tight_layout()
plt.show(block=False)
print("  ✓ Displayed: Original McCormick Baseline Orders")

# ============================================================================
# NEW PLOT 2: Orders by Supplier - McCormick (Original)
# ============================================================================
fig_orders1, ax_orders1 = plt.subplots(figsize=(12, 6))
start_date = pd.Timestamp("2024-04-01")
months = pd.date_range(start_date, periods=T, freq="MS")
xlabels = months.strftime("%b-%y")
x_pos = np.arange(T)

width = 0.35
ax_orders1.bar(x_pos - width/2, order_df['s1'], width, label='Supplier-1 (Hedged)', 
               color='#1f77b4', alpha=0.7, edgecolor='black')
ax_orders1.bar(x_pos + width/2, order_df['s2'], width, label='Supplier-2 (Unhedged)', 
               color='#ff7f0e', alpha=0.7, edgecolor='black')

ax_orders1.set_xlabel('Period', fontsize=12, fontweight='bold')
ax_orders1.set_ylabel('Order Quantity (units)', fontsize=12, fontweight='bold')
ax_orders1.set_title('v.a Orders by Supplier: McCormick', fontsize=14, fontweight='bold')
ax_orders1.set_xticks(x_pos)
ax_orders1.set_xticklabels(xlabels, rotation=45, ha='right')

# Add secondary y-axis for prices
ax_orders1_price = ax_orders1.twinx()
ax_orders1_price.plot(x_pos, price_df["Hedged"].values, color='#1f77b4', linestyle='--', 
                      linewidth=2, marker='o', markersize=5, label='Hedged Price', alpha=0.8)
ax_orders1_price.plot(x_pos, price_df["Unhedged"].values, color='#ff7f0e', linestyle='--', 
                      linewidth=2, marker='s', markersize=5, label='Unhedged Price', alpha=0.8)
ax_orders1_price.set_ylabel('Price ($/unit)', fontsize=12, fontweight='bold')

# Combine legends
lines1, labels1 = ax_orders1.get_legend_handles_labels()
lines2, labels2 = ax_orders1_price.get_legend_handles_labels()
ax_orders1.legend(lines1 + lines2, labels1 + labels2, loc='upper left', fontsize=10)

ax_orders1.grid(axis='y', alpha=0.3)

# Add total orders info
total_s1 = order_df['s1'].sum()
total_s2 = order_df['s2'].sum()
total_all = total_s1 + total_s2
unhedged_pct = (total_s2 / total_all * 100) if total_all > 0 else 0
ax_orders1.text(0.98, 0.98, f'Total Orders: {total_all:,.0f}\nHedged: {total_s1:,.0f} ({100-unhedged_pct:.1f}%)\nUnhedged: {total_s2:,.0f} ({unhedged_pct:.1f}%)',
                transform=ax_orders1.transAxes, fontsize=10, verticalalignment='top', horizontalalignment='right',
                bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))

plt.tight_layout()
plt.show(block=False)
print("  ✓ Displayed: Orders - McCormick (L=0 Eval)")

# ============================================================================
# NEW PLOT 3: Orders by Supplier - Min Storage ≥6K
# ============================================================================
fig_orders2, ax_orders2 = plt.subplots(figsize=(12, 6))

ax_orders2.bar(x_pos - width/2, sol['Qhat']['Hedged'], width, label='Supplier-1 (Hedged)', 
               color='#1f77b4', alpha=0.7, edgecolor='black')
ax_orders2.bar(x_pos + width/2, sol['Qhat']['Unhedged'], width, label='Supplier-2 (Unhedged)', 
               color='#ff7f0e', alpha=0.7, edgecolor='black')

ax_orders2.set_xlabel('Period', fontsize=12, fontweight='bold')
ax_orders2.set_ylabel('Order Quantity (units)', fontsize=12, fontweight='bold')
ax_orders2.set_title('v.b Orders by Supplier: Min Storage ≥6K (Preserves Quantities)', fontsize=14, fontweight='bold')
ax_orders2.set_xticks(x_pos)
ax_orders2.set_xticklabels(xlabels, rotation=45, ha='right')

# Add secondary y-axis for prices
ax_orders2_price = ax_orders2.twinx()
ax_orders2_price.plot(x_pos, price_df["Hedged"].values, color='#1f77b4', linestyle='--', 
                      linewidth=2, marker='o', markersize=5, label='Hedged Price', alpha=0.8)
ax_orders2_price.plot(x_pos, price_df["Unhedged"].values, color='#ff7f0e', linestyle='--', 
                      linewidth=2, marker='s', markersize=5, label='Unhedged Price', alpha=0.8)
ax_orders2_price.set_ylabel('Price ($/unit)', fontsize=12, fontweight='bold')

# Combine legends
lines1, labels1 = ax_orders2.get_legend_handles_labels()
lines2, labels2 = ax_orders2_price.get_legend_handles_labels()
ax_orders2.legend(lines1 + lines2, labels1 + labels2, loc='upper left', fontsize=10)

ax_orders2.grid(axis='y', alpha=0.3)

total_s1_opt = sol['Qhat']['Hedged'].sum()
total_s2_opt = sol['Qhat']['Unhedged'].sum()
total_all_opt = total_s1_opt + total_s2_opt
unhedged_pct_opt = (total_s2_opt / total_all_opt * 100) if total_all_opt > 0 else 0
ax_orders2.text(0.98, 0.98, f'Total Orders: {total_all_opt:,.0f}\nHedged: {total_s1_opt:,.0f} ({100-unhedged_pct_opt:.1f}%)\nUnhedged: {total_s2_opt:,.0f} ({unhedged_pct_opt:.1f}%)',
                transform=ax_orders2.transAxes, fontsize=10, verticalalignment='top', horizontalalignment='right',
                bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))

plt.tight_layout()
plt.show(block=False)
print("  ✓ Displayed: Orders - Min Storage ≥6K")

# ============================================================================
# NEW PLOT 4: Orders by Supplier - Forced 75% Hedged
# ============================================================================
fig_orders3, ax_orders3 = plt.subplots(figsize=(12, 6))

ax_orders3.bar(x_pos - width/2, sol_75pct['Qhat']['Hedged'], width, label='Supplier-1 (Hedged)', 
               color='#1f77b4', alpha=0.7, edgecolor='black')
ax_orders3.bar(x_pos + width/2, sol_75pct['Qhat']['Unhedged'], width, label='Supplier-2 (Unhedged)', 
               color='#ff7f0e', alpha=0.7, edgecolor='black')

ax_orders3.set_xlabel('Period', fontsize=12, fontweight='bold')
ax_orders3.set_ylabel('Order Quantity (units)', fontsize=12, fontweight='bold')
ax_orders3.set_title('v.c Orders by Supplier: Forced 75% Hedged (Based on Opt 2 Total)', fontsize=14, fontweight='bold')
ax_orders3.set_xticks(x_pos)
ax_orders3.set_xticklabels(xlabels, rotation=45, ha='right')

# Add secondary y-axis for prices
ax_orders3_price = ax_orders3.twinx()
ax_orders3_price.plot(x_pos, price_df["Hedged"].values, color='#1f77b4', linestyle='--', 
                      linewidth=2, marker='o', markersize=5, label='Hedged Price', alpha=0.8)
ax_orders3_price.plot(x_pos, price_df["Unhedged"].values, color='#ff7f0e', linestyle='--', 
                      linewidth=2, marker='s', markersize=5, label='Unhedged Price', alpha=0.8)
ax_orders3_price.set_ylabel('Price ($/unit)', fontsize=12, fontweight='bold')

# Combine legends
lines1, labels1 = ax_orders3.get_legend_handles_labels()
lines2, labels2 = ax_orders3_price.get_legend_handles_labels()
ax_orders3.legend(lines1 + lines2, labels1 + labels2, loc='upper left', fontsize=10)

ax_orders3.grid(axis='y', alpha=0.3)

total_s1_75 = sol_75pct['Qhat']['Hedged'].sum()
total_s2_75 = sol_75pct['Qhat']['Unhedged'].sum()
total_all_75 = total_s1_75 + total_s2_75
hedged_pct_75 = (total_s1_75 / total_all_75 * 100) if total_all_75 > 0 else 0
ax_orders3.text(0.98, 0.98, f'Total Orders: {total_all_75:,.0f}\nHedged: {total_s1_75:,.0f} ({hedged_pct_75:.1f}%)\nUnhedged: {total_s2_75:,.0f} ({100-hedged_pct_75:.1f}%)',
                transform=ax_orders3.transAxes, fontsize=10, verticalalignment='top', horizontalalignment='right',
                bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))

plt.tight_layout()
plt.show(block=False)
print("  ✓ Displayed: Orders - Forced 75% Hedged)")

# ============================================================================
# NEW PLOT 4.5: Orders by Supplier - Forced 60% Hedged
# ============================================================================
fig_orders4, ax_orders4 = plt.subplots(figsize=(12, 6))

ax_orders4.bar(x_pos - width/2, sol_60pct['Qhat']['Hedged'], width, label='Supplier-1 (Hedged)', 
               color='#1f77b4', alpha=0.7, edgecolor='black')
ax_orders4.bar(x_pos + width/2, sol_60pct['Qhat']['Unhedged'], width, label='Supplier-2 (Unhedged)', 
               color='#ff7f0e', alpha=0.7, edgecolor='black')

ax_orders4.set_xlabel('Period', fontsize=12, fontweight='bold')
ax_orders4.set_ylabel('Order Quantity (units)', fontsize=12, fontweight='bold')
ax_orders4.set_title('v.d Orders by Supplier: Forced 60% Hedged (Based on Opt 2 Total)', fontsize=14, fontweight='bold')
ax_orders4.set_xticks(x_pos)
ax_orders4.set_xticklabels(xlabels, rotation=45, ha='right')

# Add secondary y-axis for prices
ax_orders4_price = ax_orders4.twinx()
ax_orders4_price.plot(x_pos, price_df["Hedged"].values, color='#1f77b4', linestyle='--', 
                      linewidth=2, marker='o', markersize=5, label='Hedged Price', alpha=0.8)
ax_orders4_price.plot(x_pos, price_df["Unhedged"].values, color='#ff7f0e', linestyle='--', 
                      linewidth=2, marker='s', markersize=5, label='Unhedged Price', alpha=0.8)
ax_orders4_price.set_ylabel('Price ($/unit)', fontsize=12, fontweight='bold')

# Combine legends
lines1, labels1 = ax_orders4.get_legend_handles_labels()
lines2, labels2 = ax_orders4_price.get_legend_handles_labels()
ax_orders4.legend(lines1 + lines2, labels1 + labels2, loc='upper left', fontsize=10)

ax_orders4.grid(axis='y', alpha=0.3)

total_s1_60 = sol_60pct['Qhat']['Hedged'].sum()
total_s2_60 = sol_60pct['Qhat']['Unhedged'].sum()
total_all_60 = total_s1_60 + total_s2_60
hedged_pct_60 = (total_s1_60 / total_all_60 * 100) if total_all_60 > 0 else 0
ax_orders4.text(0.98, 0.98, f'Total Orders: {total_all_60:,.0f}\nHedged: {total_s1_60:,.0f} ({hedged_pct_60:.1f}%)\nUnhedged: {total_s2_60:,.0f} ({100-hedged_pct_60:.1f}%)',
                transform=ax_orders4.transAxes, fontsize=10, verticalalignment='top', horizontalalignment='right',
                bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))

plt.tight_layout()
plt.show(block=False)
print("  ✓ Displayed: Orders - Forced 60% Hedged)")

# ============================================================================
# NEW PLOT 5: Inventory Comparison - All Three Optimizations
# ============================================================================
fig_inv, ax_inv = plt.subplots(figsize=(12, 6))

# Divide by 12000 to convert to months of storage
ax_inv.plot(x_pos, mccormick_P / 12000, marker='o', linewidth=2, label='McCormick (L=0 Eval)', 
            color='#1f77b4', markersize=6)
ax_inv.plot(x_pos, sol['P'] / 12000, marker='s', linewidth=2, label='Min Storage ≥6K', 
            color='#ff7f0e', markersize=6)
ax_inv.plot(x_pos, sol_75pct['P'] / 12000, marker='^', linewidth=2, label='Forced 75% Hedged', 
            color='#2ca02c', markersize=6)
ax_inv.plot(x_pos, sol_60pct['P'] / 12000, marker='d', linewidth=2, label='Forced 60% Hedged', 
            color='#d62728', markersize=6)

# Add safety stock line
ax_inv.axhline(y=STORAGE_MIN / 12000, color='red', linestyle='--', linewidth=2, 
               label=f'Safety Stock ({STORAGE_MIN / 12000:.1f} months)', alpha=0.7)

ax_inv.set_xlabel('Period', fontsize=12, fontweight='bold')
ax_inv.set_ylabel('Months of Storage', fontsize=12, fontweight='bold')
ax_inv.set_title('vi. Inventory Trajectory Comparison (All Four Strategies)', fontsize=14, fontweight='bold')
ax_inv.set_xticks(x_pos)
ax_inv.set_xticklabels(xlabels, rotation=45, ha='right')
ax_inv.legend(fontsize=10, loc='best')
ax_inv.grid(alpha=0.3)

# Add summary stats
inv_text = (f'McCormick: Min={mccormick_P.min() / 12000:.2f}, Max={mccormick_P.max() / 12000:.2f}, Avg={mccormick_P.mean() / 12000:.2f}\n'
            f'Min Storage: Min={sol["P"].min() / 12000:.2f}, Max={sol["P"].max() / 12000:.2f}, Avg={sol["P"].mean() / 12000:.2f}\n'
            f'Forced 75%: Min={sol_75pct["P"].min() / 12000:.2f}, Max={sol_75pct["P"].max() / 12000:.2f}, Avg={sol_75pct["P"].mean() / 12000:.2f}\n'
            f'Forced 60%: Min={sol_60pct["P"].min() / 12000:.2f}, Max={sol_60pct["P"].max() / 12000:.2f}, Avg={sol_60pct["P"].mean() / 12000:.2f}')
ax_inv.text(0.98, 0.98, inv_text, transform=ax_inv.transAxes, fontsize=9, 
            verticalalignment='top', horizontalalignment='right',
            bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))

plt.tight_layout()
plt.show(block=False)
print("  ✓ Displayed: Inventory Trajectory Comparison")

print(f"\n  Total new comparison plots displayed: 6")
print("  Close each plot window to continue...")

# ============================================================================
# STEP 7: Generate Visualizations
# ============================================================================
print("\n[STEP 7] Generating visualizations...")

# Create date labels for x-axis (Apr-24 onwards)
start_date = pd.Timestamp("2024-04-01")
months = pd.date_range(start_date, periods=T, freq="MS")
xlabels = months.strftime("%b-%y")
t_axis = np.arange(T)

# ============================================================================
# PLOT 1: Reoptimized Orders (matching inventory_from_orders.py style)
# ============================================================================
fig1, ax1 = plt.subplots(figsize=(10, 6))

# Reoptimized orders as bars (side-by-side)
width = 0.35
ax1.bar(t_axis - width/2, sol["Qhat"]["Hedged"].values, width=width, 
        label="Reoptimized s1 Order (Hedged)", alpha=0.7, color='#1f77b4')
ax1.bar(t_axis + width/2, sol["Qhat"]["Unhedged"].values, width=width, 
        label="Reoptimized s2 Order (Unhedged)", alpha=0.7, color='#ff7f0e')

ax1.set_ylabel("Order Quantity", fontsize=11, fontweight='bold')
ax1.set_xlabel("Time Period", fontsize=11, fontweight='bold')
ax1.set_xticks(t_axis)
ax1.set_xticklabels(xlabels, rotation=45, ha="right")

# Add secondary y-axis for prices
ax1_price = ax1.twinx()
ax1_price.plot(t_axis, price_df["Hedged"].values, color='#1f77b4', linestyle='--', 
               linewidth=2, marker='o', markersize=5, label='Hedged Price', alpha=0.8)
ax1_price.plot(t_axis, price_df["Unhedged"].values, color='#ff7f0e', linestyle='--', 
               linewidth=2, marker='s', markersize=5, label='Unhedged Price', alpha=0.8)
ax1_price.set_ylabel("Price", fontsize=11, fontweight='bold')

# Combine legends
lines1, labels1 = ax1.get_legend_handles_labels()
lines2, labels2 = ax1_price.get_legend_handles_labels()
ax1.legend(lines1 + lines2, labels1 + labels2, loc='best', fontsize=9)

plt.title("Reoptimized Orders (with Minimum Storage Constraint)", fontsize=13, fontweight='bold')
plt.tight_layout()
plt.show()
print("  ✓ Displayed: plot1_reoptimized_orders")

# ============================================================================
# PLOT 2: Inventory Dynamics (Simple - matching inventory_from_orders.py)
# ============================================================================
fig2, ax2 = plt.subplots(figsize=(10, 6))

# Plot inventory, demand, and arrivals
ax2.step(t_axis, sol["P"].values, where="mid", linewidth=2, label="Inventory")
ax2.plot(t_axis, demand, linewidth=2, label="Demand")
ax2.plot(t_axis, sol["Qhat"]["Hedged"].values + sol["Qhat"]["Unhedged"].values, 
         linewidth=2, label="Arrivals (total)")

# Minimum storage line
ax2.axhline(STORAGE_MIN, linestyle="--", linewidth=2, color="red", alpha=0.7,
           label=f"Min Storage = {STORAGE_MIN:,.0f}")

ax2.axhline(0, linewidth=1, color='black', linestyle='--', alpha=0.5)
ax2.set_ylabel("Units")
ax2.set_xlabel("Time Period")
ax2.legend()
ax2.set_xticks(t_axis)
ax2.set_xticklabels(xlabels, rotation=45, ha="right")

plt.title("Inventory Dynamics")
plt.tight_layout()
plt.show()
print("  ✓ Displayed: plot2_inventory_dynamics")

# ============================================================================
# PLOT 3: Inventory in Months of Coverage (Simple - matching inventory_from_orders.py)
# ============================================================================
nominal_demand = 12000  # One month's nominal demand
inventory_months = sol["P"].values / nominal_demand

fig3, ax3 = plt.subplots(figsize=(10, 6))
ax3.plot(t_axis, inventory_months, marker='o', linewidth=2, label="Inventory Level")
ax3.axhline(STORAGE_MIN/nominal_demand, linewidth=2, linestyle='--', color='red', 
           alpha=0.7, label=f"Min = 0.5 months")
ax3.axhline(0, linewidth=1, color='black', linestyle='--', alpha=0.5)

ax3.set_ylabel("Months of Storage")
ax3.set_xlabel("Time Period")
ax3.legend()
ax3.set_xticks(t_axis)
ax3.set_xticklabels(xlabels, rotation=45, ha="right")

plt.title("Inventory Level (Months of Storage at 12K Units/Month)")
plt.tight_layout()
plt.show()
print("  ✓ Displayed: plot3_inventory_months")

# ============================================================================
# PLOT 4: Cumulative Costs Comparison
# ============================================================================
# Calculate costs
hedged_cost_original = (price_df["Hedged"].values * Q_star_df["Hedged"].values)
unhedged_cost_original = (price_df["Unhedged"].values * Q_star_df["Unhedged"].values)
hedged_cost_optimized = (price_df["Hedged"].values * sol["Qhat"]["Hedged"].values)
unhedged_cost_optimized = (price_df["Unhedged"].values * sol["Qhat"]["Unhedged"].values)

cum_hedged_orig = np.cumsum(hedged_cost_original)
cum_unhedged_orig = np.cumsum(unhedged_cost_original)
cum_total_orig = cum_hedged_orig + cum_unhedged_orig

cum_hedged_opt = np.cumsum(hedged_cost_optimized)
cum_unhedged_opt = np.cumsum(unhedged_cost_optimized)
cum_total_opt = cum_hedged_opt + cum_unhedged_opt

fig4, ax4 = plt.subplots(figsize=(10, 6))

ax4.plot(t_axis, cum_total_orig, linewidth=2, marker='s',
         label="Original Total (McCormick)", linestyle='--', alpha=0.7)
ax4.plot(t_axis, cum_total_opt, linewidth=2, marker='o',
         label="Optimized Total (with min storage)")
ax4.plot(t_axis, cum_hedged_opt, linewidth=1.5, marker='^',
         label="Optimized Hedged", alpha=0.6)
ax4.plot(t_axis, cum_unhedged_opt, linewidth=1.5, marker='v',
         label="Optimized Unhedged", alpha=0.6)

ax4.set_ylabel("Cumulative Procurement Cost ($)")
ax4.set_xlabel("Period")
ax4.legend(loc='upper left')
ax4.set_xticks(t_axis)
ax4.set_xticklabels(xlabels, rotation=45, ha="right")

plt.title("Cumulative Procurement Cost: Original vs Optimized")
plt.tight_layout()
plt.show()
print("  ✓ Displayed: plot4_cumulative_costs")

# ============================================================================
# PLOT 5: Net Stock (Simple)
# ============================================================================
fig5, ax5 = plt.subplots(figsize=(10, 6))

# Plot net stock
ax5.plot(t_axis, sol["S"].values, linewidth=2, marker='o', label="Net Stock (S = P - N)")
ax5.axhline(STORAGE_MIN, linestyle="--", linewidth=2, color="red", alpha=0.7,
           label=f"Min Storage = {STORAGE_MIN:,.0f}")
ax5.axhline(0, linestyle="--", linewidth=1, color="black", alpha=0.5)

ax5.set_ylabel("Units")
ax5.set_xlabel("Time Period")
ax5.legend()
ax5.set_xticks(t_axis)
ax5.set_xticklabels(xlabels, rotation=45, ha="right")

plt.title("Net Inventory Position")
plt.tight_layout()
plt.show()
print("  ✓ Displayed: plot5_net_stock")

# ============================================================================
# PLOT 6: Cost Breakdown
# ============================================================================
cost_categories = ['Procurement\n(Original)', 'Procurement\n(Optimized)', 
                  'Holding', 'Backlog', 'Total\n(Optimized)']
cost_values = [
    original_purchase_cost,
    optimized_purchase_cost,
    holding_cost_val,
    backlog_cost_val,
    sol['objective']
]

fig6, ax6 = plt.subplots(figsize=(10, 6))
ax6.bar(cost_categories, cost_values, alpha=0.7)

# Add value labels on bars
for i, val in enumerate(cost_values):
    ax6.text(i, val, f'${val:,.0f}', ha='center', va='bottom')

ax6.set_ylabel("Cost ($)")
ax6.set_title("Cost Breakdown: Original vs Optimized")

plt.tight_layout()
plt.show()
print("  ✓ Displayed: plot6_cost_breakdown")

print("\n✓ All visualizations displayed successfully!")
print(f"  Total plots displayed: 6")
print(f"  Close each plot window to continue...")

# ============================================================================
# Write AI orders to the 'result' sheet in Hedging25.xlsx
# ============================================================================
print("\n[STEP 8] Writing AI orders to Hedging25.xlsx 'result' sheet...")
import openpyxl
wb = openpyxl.load_workbook(INPUT_EXCEL)
ws = wb['result']

# Find column indices for 'Ai order H' and 'AI order U' from header row (row 1)
header = [cell.value for cell in ws[1]]
col_h = header.index('Ai order H') + 1  # openpyxl is 1-indexed
col_u = header.index('AI order U') + 1

for i in range(len(order_df)):
    ws.cell(row=i + 2, column=col_h, value=float(order_df['s1'].iloc[i]))
    ws.cell(row=i + 2, column=col_u, value=float(order_df['s2'].iloc[i]))

wb.save(INPUT_EXCEL)
wb.close()
print(f"  ✓ Written {len(order_df)} rows to 'Ai order H' and 'AI order U' columns")

print("\n" + "="*70)
print("OPTIMAL HEDGING RATIO (from McCormick WDRO Solution)")
print("="*70)
total_hedged = order_df['s1'].sum()
total_unhedged = order_df['s2'].sum()
total_orders = total_hedged + total_unhedged
hedged_fraction = total_hedged / total_orders if total_orders > 0 else 0
unhedged_fraction = total_unhedged / total_orders if total_orders > 0 else 0

print(f"\n  Per-period breakdown (s1=Hedged, s2=Unhedged):")
print(f"  {'Period':<10} {'Hedged':>10} {'Unhedged':>10} {'Total':>10} {'Hedged %':>10}")
print(f"  {'-'*50}")
for i in range(len(order_df)):
    s1_val = order_df['s1'].iloc[i]
    s2_val = order_df['s2'].iloc[i]
    row_total = s1_val + s2_val
    row_pct = (s1_val / row_total * 100) if row_total > 0 else 0
    print(f"  {i+1:<10} {s1_val:>10,.0f} {s2_val:>10,.0f} {row_total:>10,.0f} {row_pct:>9.1f}%")

print(f"  {'-'*50}")
print(f"  {'TOTAL':<10} {total_hedged:>10,.0f} {total_unhedged:>10,.0f} {total_orders:>10,.0f} {hedged_fraction*100:>9.1f}%")

print(f"\n  ┌─────────────────────────────────────────────┐")
print(f"  │  OPTIMAL HEDGING RATIO                       │")
print(f"  │                                              │")
print(f"  │  Hedged (s1):   {hedged_fraction*100:5.1f}%  ({total_hedged:>10,.0f} units) │")
print(f"  │  Unhedged (s2): {unhedged_fraction*100:5.1f}%  ({total_unhedged:>10,.0f} units) │")
print(f"  │  Total:                  {total_orders:>10,.0f} units  │")
print(f"  └─────────────────────────────────────────────┘")

print("\n" + "="*70)
print("PIPELINE COMPLETED SUCCESSFULLY WITH VISUALIZATIONS")
print("="*70)
