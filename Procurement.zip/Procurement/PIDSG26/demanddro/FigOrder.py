

import matplotlib.pyplot as plt
import pandas as pd

# Define custom colors
blue = '#1f77b4'      # standard matplotlib blue
amber = '#ffbf00'     # amber

should_plot= True

def plot_order(extracted_order, df_price):
    # Filter orders by suppliers s1 and s2
    order_s1 = extracted_order[extracted_order['supplier'] == 's1']
    order_s2 = extracted_order[extracted_order['supplier'] == 's2']

    # Group by t_order and sum the quantities
    order_grouped_s1 = order_s1.groupby('t_order')['value'].sum()
    order_grouped_s2 = order_s2.groupby('t_order')['value'].sum()

    # Define first 12 months from Apr-26 to Mar-27
    months = pd.date_range(start='2026-04-01', periods=12, freq='MS').strftime('%b-%y')
    x = range(1, 13)

    # Prepare order quantities (slice to 12 months)
    order_s1_vals = [order_grouped_s1.get(t, 0) for t in x]
    order_s2_vals = [order_grouped_s2.get(t, 0) for t in x]

    # Slice price data to first 12 entries
    price_s1_vals = df_price['s1'].values[:12]
    price_s2_vals = df_price['s2'].values[:12]

    # Plot setup
    fig, ax1 = plt.subplots(figsize=(12, 6))
    bar_width = 0.4

    # Plot order quantities on primary y-axis
    ax1.bar([t - bar_width/2 for t in x], order_s1_vals, width=bar_width, label='Orders from s1', color=blue)
    ax1.bar([t + bar_width/2 for t in x], order_s2_vals, width=bar_width, label='Orders from s2', color=amber)
    ax1.set_xlabel('Time Period')
    ax1.set_ylabel('Order Quantity')
    ax1.set_xticks(x)
    ax1.set_xticklabels(months, rotation=45)
    ax1.grid(True)

    # Plot prices on secondary y-axis
    ax2 = ax1.twinx()
    ax2.plot(x, price_s1_vals, linestyle='dotted', marker='o', label='Price from s1', color=blue)
    ax2.plot(x, price_s2_vals, linestyle='dotted', marker='s', label='Price from s2', color=amber)
    ax2.set_ylabel('Price')

    # Combine legends
    lines_1, labels_1 = ax1.get_legend_handles_labels()
    lines_2, labels_2 = ax2.get_legend_handles_labels()
    ax1.legend(lines_1 + lines_2, labels_1 + labels_2, loc='upper left')

    plt.title('Order Quantities and Supplier Prices (Apr 2026 – Mar 2027)')
    plt.tight_layout()
    plt.show()



def plot_manual(should_plot, df_price):
    total_order_df = pd.read_csv("Purchase.csv")
    total_order = total_order_df.iloc[:12, 1].values.astype(float)
    # total_order = total_order_df.iloc[:12, 1].values.astype(float)


    order_data = {
        't_order': list(range(1, 13)) * 2,
        'supplier': ['s1'] * 12 + ['s2'] * 12,
        'value': list(total_order * 0.25) + list(total_order * 0.75)
    }

    extracted_order_simulated = pd.DataFrame(order_data)

    if should_plot:
        plot_order(extracted_order_simulated, df_price)


import matplotlib.pyplot as plt
import pandas as pd

def plot_order_matrix(order_matrix, df_price):
    # Merge order_matrix with df_price to ensure alignment
    df_price_ = df_price.rename(columns={'time': 'placement'}).copy()
    merged = pd.merge(order_matrix, df_price_, on='placement', how='left', suffixes=('', '_price'))
    
    # For plotting, restrict to first 12 periods (placement 1 to 12)
    plot_df = merged[(merged['placement'] >= 1) & (merged['placement'] <= 12)].copy()
    x = plot_df['placement']
    
    # If months desired
    months = pd.date_range(start='2026-04-01', periods=12, freq='MS').strftime('%b-%y')
    
    # Plot setup
    fig, ax1 = plt.subplots(figsize=(12, 6))
    bar_width = 0.4
    blue = "#1976D2"
    amber = "#FFA000"
    
    # Plot order quantities
    ax1.bar(x - bar_width/2, plot_df['s1'], width=bar_width, label='DRO Demand Hedged', color=blue)
    ax1.bar(x + bar_width/2, plot_df['s2'], width=bar_width, label='DRO Demand Unhedged', color=amber)
    ax1.set_xlabel('Time Period')
    ax1.set_ylabel('Order Quantity')
    ax1.set_xticks(x)
    ax1.set_xticklabels(months, rotation=45)
    ax1.grid(True)
    
    # Plot prices on secondary y-axis
    ax2 = ax1.twinx()
    ax2.plot(x, plot_df['s1_price'], linestyle='dotted', marker='o', label='Price Hedged', color=blue)
    ax2.plot(x, plot_df['s2_price'], linestyle='dotted', marker='s', label='Price Unhedged', color=amber)
    ax2.set_ylabel('Price')
    
    # Combine legends
    lines_1, labels_1 = ax1.get_legend_handles_labels()
    lines_2, labels_2 = ax2.get_legend_handles_labels()
    ax1.legend(lines_1 + lines_2, labels_1 + labels_2, loc='upper left')
    
    plt.title('Order Quantities and Supplier Prices (Apr 2026 – Mar 2027)')
    plt.tight_layout()
    plt.show()

# Usage
# plot_order_matrix(order_matrix, df_price)










