#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Inventory simulation with multi-supplier orders and fixed lead time + cost plots.

Default configuration:
- Demand source : Data/pidsg25-26.xlsx  |  sheet='demand'  |  column='Demand'
- Prices source : Data/pidsg25-26.xlsx  |  sheet='price'   |  columns ['s1','s2']
- Orders source : Order.csv  (columns s1, s2, ...; optional placement/month)
- Lead time     : 3 months
- Initial stock : I0 = 15000 units (overridden by McCormick.py if available)
- Costs         : holding h, backlog b from McCormick.py if available

Outputs (under --outdir, default 'out_inventory/'):
  - arrivals_by_supplier.csv
  - inventory_timeseries.csv
  - cost_timeseries.csv
  - PNG plots for inventory and cumulative costs

Author: ChatGPT
"""

import argparse
from importlib.util import spec_from_file_location, module_from_spec
from pathlib import Path
from typing import Optional, Dict
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# ---------- Utilities ----------

def try_load_costs_from_mccormick(path: Path) -> Dict[str, float]:
    """
    Attempt to import h, b, I_0 from a local McCormick.py.
    Returns dict with any found keys; missing keys are omitted.
    """
    out: Dict[str, float] = {}
    if not path.exists():
        return out
    try:
        spec = spec_from_file_location("McCormick", str(path))
        mod = module_from_spec(spec)
        assert spec and spec.loader
        spec.loader.exec_module(mod)  # type: ignore[attr-defined]
        for k in ("h", "b", "I_0"):
            if hasattr(mod, k):
                out[k] = float(eval(str(getattr(mod, k))))
        return out
    except Exception:
        # non-fatal: just return empty to fall back on CLI/defaults
        return {}

# ---------- Excel Readers ----------

def read_demand_from_excel(
    xlsx_path: Path,
    sheet_name: str = "demand",
    demand_col: str = "Demand",
) -> np.ndarray:
    """Read demand from Excel (sheet/column)."""
    if not xlsx_path.exists():
        raise FileNotFoundError(f"Demand Excel not found: {xlsx_path}")
    df = pd.read_excel(xlsx_path, sheet_name=sheet_name)
    if demand_col not in df.columns:
        raise ValueError(f"Column '{demand_col}' not in sheet '{sheet_name}'. Available: {list(df.columns)}")
    demand = pd.to_numeric(df[demand_col], errors="coerce").fillna(0.0).to_numpy(dtype=float)
    return demand

def read_prices_from_excel(
    xlsx_path: Path,
    sheet_name: str = "price",
    cols: tuple[str, str] = ("s1", "s2"),
) -> pd.DataFrame:
    """
    Read per-month prices for suppliers from Excel sheet 'price' with columns 's1','s2'.
    Returns DataFrame with columns exactly ['s1','s2'] and one row per month.
    """
    if not xlsx_path.exists():
        raise FileNotFoundError(f"Price Excel not found: {xlsx_path}")
    df = pd.read_excel(xlsx_path, sheet_name=sheet_name)
    for c in cols:
        if c not in df.columns:
            raise ValueError(f"Column '{c}' not found in sheet '{sheet_name}'. Available: {list(df.columns)}")
    out = pd.DataFrame({c: pd.to_numeric(df[c], errors="coerce").fillna(0.0) for c in cols})
    return out

# ---------- Orders & Arrivals ----------

def read_orders(order_path: Path) -> pd.DataFrame:
    """Read Order.csv with supplier quantities per month."""
    if not order_path.exists():
        raise FileNotFoundError(f"Order file not found: {order_path}")

    df = pd.read_csv(order_path)
    df.columns = [c.strip() for c in df.columns]

    placement_col = None
    for c in df.columns:
        if c.lower() in ("placement", "month", "t", "time"):
            placement_col = c
            break

    if placement_col is not None:
        df = df.rename(columns={placement_col: "placement"})
        df["placement"] = pd.to_numeric(df["placement"], errors="coerce").fillna(0).astype(int)
    else:
        df.insert(0, "placement", range(1, len(df) + 1))

    for c in df.columns:
        if c != "placement":
            df[c] = pd.to_numeric(df[c], errors="coerce").fillna(0.0)

    for s in ("s1", "s2"):
        if s not in df.columns:
            df[s] = 0.0

    df = df.sort_values("placement")
    T = int(df["placement"].max())
    grid = pd.DataFrame({"placement": range(1, T + 1)})
    df = grid.merge(df, on="placement", how="left").fillna(0.0)
    return df

def compute_arrivals(orders: pd.DataFrame, lead: int) -> pd.DataFrame:
    """Shift orders by lead to compute arrivals per month."""
    supplier_cols = [c for c in orders.columns if c != "placement"]
    T_place = int(orders["placement"].max())
    T = T_place + max(lead, 0)
    arrivals = pd.DataFrame({"month": range(1, T + 1)})

    for s in supplier_cols:
        arr = np.zeros(T, dtype=float)
        placed = orders.set_index("placement")[s].reindex(range(1, T_place + 1), fill_value=0.0).to_numpy()
        if lead > 0:
            arr[lead:lead + T_place] = placed
        else:
            arr[:T_place] = placed
        arrivals[s] = arr

    arrivals["total_arrivals"] = arrivals[supplier_cols].sum(axis=1)
    return arrivals

# ---------- Inventory Simulation ----------

def simulate_inventory(demand: np.ndarray, arrivals_total: np.ndarray, I0: float) -> dict:
    """Inventory recursion: I_t = I_{t-1} + arrivals_t - demand_t."""
    T = max(len(demand), len(arrivals_total))
    d = np.zeros(T, dtype=float)
    d[: len(demand)] = demand
    a = np.zeros(T, dtype=float)
    a[: len(arrivals_total)] = arrivals_total

    inv = np.zeros(T + 1, dtype=float)
    inv[0] = I0
    for t in range(1, T + 1):
        inv[t] = inv[t - 1] + a[t - 1] - d[t - 1]

    backlog = np.clip(-inv[1:], a_min=0.0, a_max=None)
    return {"inventory": inv[1:], "backlog": backlog, "demand": d, "arrivals": a}

# ---------- Cost Calculation ----------

def align_len(vec: np.ndarray, T: int, pad_with: float = 0.0) -> np.ndarray:
    """Pad/trim a 1D array to length T."""
    v = np.asarray(vec, dtype=float)
    if len(v) >= T:
        return v[:T].copy()
    out = np.empty(T, dtype=float)
    out[:len(v)] = v
    out[len(v):] = pad_with
    return out

def compute_costs(
    orders: pd.DataFrame,
    prices_df: pd.DataFrame,
    sim: dict,
    h: float,
    b: float,
) -> pd.DataFrame:
    """
    Compute per-month costs:
    - Procurement per supplier: orders_placed[t, s] * price[t, s]
    - Holding: h * max(inventory_t, 0)
    - Backlog: b * backlog_t
    Returns DataFrame with columns:
      month, proc_s1, proc_s2, proc_total, hold_cost, backlog_cost
    """
    T_orders = int(orders["placement"].max())
    # prices per supplier, align length to T_orders (pad with last known price)
    s1p = prices_df["s1"].to_numpy(dtype=float)
    s2p = prices_df["s2"].to_numpy(dtype=float)
    pad1 = float(s1p[-1]) if len(s1p) > 0 else 0.0
    pad2 = float(s2p[-1]) if len(s2p) > 0 else 0.0
    s1p = align_len(s1p, T_orders, pad_with=pad1)
    s2p = align_len(s2p, T_orders, pad_with=pad2)

    s1_orders = orders["s1"].to_numpy(dtype=float)
    s2_orders = orders["s2"].to_numpy(dtype=float)

    proc_s1 = s1_orders * s1p
    proc_s2 = s2_orders * s2p
    proc_total = proc_s1 + proc_s2

    inv = sim["inventory"]
    backlog = sim["backlog"]
    T_sim = len(inv)
    # Holding/backlog aligned to inventory horizon
    hold = h * np.clip(inv, a_min=0.0, a_max=None)
    bl_cost = b * backlog

    # Build aligned monthly frame (max of both horizons)
    T = max(T_orders, T_sim)
    month = np.arange(1, T + 1)

    def pad(v, padv=0.0):
        return align_len(v, T, pad_with=padv)

    costs = pd.DataFrame(
        {
            "month": month,
            "proc_s1": pad(proc_s1),
            "proc_s2": pad(proc_s2),
            "proc_total": pad(proc_total),
            "hold_cost": pad(hold),
            "backlog_cost": pad(bl_cost),
        }
    )

    # Cumulative sums
    for col in ["proc_s1", "proc_s2", "proc_total", "hold_cost", "backlog_cost"]:
        costs[f"cum_{col}"] = costs[col].cumsum()

    return costs

# ---------- Hedging Fraction ----------

def compute_hedging_fraction(orders: pd.DataFrame, total_demand: float) -> dict:
    """
    Compute hedging fraction metrics.
    
    Args:
        orders: DataFrame with columns 's1' (hedged) and 's2' (unhedged)
        total_demand: Total demand across all periods
    
    Returns:
        dict with hedging fraction and related metrics
    """
    hedged_total = orders["s1"].sum()
    unhedged_total = orders["s2"].sum()
    total_orders = hedged_total + unhedged_total
    
    hedging_fraction = hedged_total / total_demand if total_demand > 0 else 0.0
    hedging_fraction_of_orders = hedged_total / total_orders if total_orders > 0 else 0.0
    
    return {
        "hedged_quantity": float(hedged_total),
        "unhedged_quantity": float(unhedged_total),
        "total_orders": float(total_orders),
        "total_demand": float(total_demand),
        "hedging_fraction": float(hedging_fraction),
        "hedging_fraction_of_orders": float(hedging_fraction_of_orders),
    }

# ---------- Save & Plot ----------

def save_inventory_and_arrivals(outdir: Path, arrivals_df: pd.DataFrame, sim: dict):
    outdir.mkdir(parents=True, exist_ok=True)
    arrivals_df.to_csv(outdir / "arrivals_by_supplier.csv", index=False)
    inv_df = pd.DataFrame(
        {
            "month": np.arange(1, len(sim["inventory"]) + 1),
            "inventory": sim["inventory"],
            "backlog": sim["backlog"],
            "demand": sim["demand"],
            "arrivals": sim["arrivals"],
        }
    )
    inv_df.to_csv(outdir / "inventory_timeseries.csv", index=False)
    
    # Generate month labels starting from Apr-26
    month_labels = pd.date_range(start='2026-04-01', periods=len(inv_df), freq='MS').strftime('%b-%y')
    
    # Inventory plot
    plt.figure(figsize=(10, 6))
    m = inv_df["month"].to_numpy()
    plt.step(m, inv_df["inventory"], where="mid", label="Inventory")
    plt.plot(m, inv_df["demand"], label="Demand")
    plt.plot(m, inv_df["arrivals"], label="Arrivals (total)")
    plt.axhline(0, linewidth=1, color='black', linestyle='--', alpha=0.5)
    plt.xlabel("Time Period"); plt.ylabel("Units"); plt.title("Inventory Dynamics"); plt.legend()
    plt.xticks(m, month_labels, rotation=45, ha='right')
    plt.tight_layout()
    plt.show()
    
    # Inventory in months of storage (nominal demand = 12,000 units)
    plt.figure(figsize=(10, 6))
    nominal_demand = 12000
    inventory_months = inv_df["inventory"] / nominal_demand
    plt.plot(m, inventory_months, marker='o', linewidth=2, label="Inventory Level")
    plt.axhline(0, linewidth=1, color='black', linestyle='--', alpha=0.5)
    plt.xlabel("Time Period"); plt.ylabel("Months of Storage"); 
    plt.title("Inventory Level (Months of Storage at 12K Units/Month)")
    plt.xticks(m, month_labels, rotation=45, ha='right')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.show()

def save_and_plot_costs(outdir: Path, costs: pd.DataFrame):
    outdir.mkdir(parents=True, exist_ok=True)
    costs.to_csv(outdir / "cost_timeseries.csv", index=False)
    
    # Generate month labels starting from Apr-26
    month_labels = pd.date_range(start='2026-04-01', periods=len(costs), freq='MS').strftime('%b-%y')

    # 1) Procurement per supplier (cumulative)
    plt.figure(figsize=(10, 6))
    plt.plot(costs["month"], costs["cum_proc_s1"], marker='o', label="Cumulative Procurement Cost - s1")
    plt.plot(costs["month"], costs["cum_proc_s2"], marker='s', label="Cumulative Procurement Cost - s2")
    plt.xlabel("Time Period"); plt.ylabel("Cost"); plt.title("Cumulative Procurement Cost by Supplier")
    plt.xticks(costs["month"], month_labels, rotation=45, ha='right')
    plt.legend(); plt.tight_layout()
    plt.show()

    # 2) Procurement total (cumulative)
    plt.figure(figsize=(10, 6))
    plt.plot(costs["month"], costs["cum_proc_total"], marker='o', label="Cumulative Procurement Cost - Total")
    plt.xlabel("Time Period"); plt.ylabel("Cost"); plt.title("Cumulative Procurement Cost (Total)")
    plt.xticks(costs["month"], month_labels, rotation=45, ha='right')
    plt.legend(); plt.tight_layout()
    plt.show()

    # 3) Holding (cumulative)
    plt.figure(figsize=(10, 6))
    plt.plot(costs["month"], costs["cum_hold_cost"], marker='o', label="Cumulative Storage (Holding) Cost")
    plt.xlabel("Time Period"); plt.ylabel("Cost"); plt.title("Cumulative Storage Cost")
    plt.xticks(costs["month"], month_labels, rotation=45, ha='right')
    plt.legend(); plt.tight_layout()
    plt.show()

    # 4) Backlog (cumulative)
    plt.figure(figsize=(10, 6))
    plt.plot(costs["month"], costs["cum_backlog_cost"], marker='o', label="Cumulative Backlog Cost")
    plt.xlabel("Time Period"); plt.ylabel("Cost"); plt.title("Cumulative Backlog Cost")
    plt.xticks(costs["month"], month_labels, rotation=45, ha='right')
    plt.legend(); plt.tight_layout()
    plt.show()

# ---------- CLI ----------

def main(argv: Optional[list] = None):
    parser = argparse.ArgumentParser(
        description="Inventory & cost simulation with demand (Excel), orders (CSV), lead time, and prices (Excel)."
    )
    parser.add_argument("--order", type=Path, default=Path("Order.csv"),
                        help="Path to Order.csv (default: Order.csv).")
    parser.add_argument("--demand-xlsx", type=Path, default=Path("Data/pidsg25-26.xlsx"),
                        help="Excel with demand/prices (default: Data/pidsg25-26.xlsx).")
    parser.add_argument("--sheet", type=str, default="demand",
                        help="Demand sheet name (default: 'demand').")
    parser.add_argument("--demand-col", type=str, default="Demand",
                        help="Demand column name (default: 'Demand').")
    parser.add_argument("--price-sheet", type=str, default="price",
                        help="Price sheet name (default: 'price').")
    parser.add_argument("--lead", type=int, default=3,
                        help="Lead time in months (default: 3).")
    parser.add_argument("--I0", type=float, default=30000.0,
                        help="Initial inventory (default: 30000; overridden by McCormick.py if present).")
    parser.add_argument("--h", type=float, default=None,
                        help="Holding cost per unit per month (override).")
    parser.add_argument("--b", type=float, default=None,
                        help="Backlog cost per unit per month (override).")
    parser.add_argument("--mccormick", type=Path, default=Path("McCormick.py"),
                        help="Path to McCormick.py to import h, b, I_0 (default: McCormick.py).")
    parser.add_argument("--outdir", type=Path, default=Path("out_inventory"),
                        help="Output directory (default: out_inventory).")
    args = parser.parse_args(argv)

    # Pull defaults from McCormick.py when available
    mc_vals = try_load_costs_from_mccormick(args.mccormick)
    I0 = float(mc_vals.get("I_0", args.I0))
    h = float(args.h if args.h is not None else mc_vals.get("h", 5.0))
    b = float(args.b if args.b is not None else mc_vals.get("b", 50.0))
    
    print(f"Parameters loaded: I0={I0}, h={h}, b={b}")
    if mc_vals:
        print(f"Successfully loaded from {args.mccormick}: {mc_vals}")
    else:
        print(f"Could not load from {args.mccormick}, using defaults")

    # Inputs
    demand = read_demand_from_excel(args.demand_xlsx, sheet_name=args.sheet, demand_col=args.demand_col)
    prices = read_prices_from_excel(args.demand_xlsx, sheet_name=args.price_sheet, cols=("s1", "s2"))
    orders = read_orders(args.order)

    # Arrivals & Inventory
    arrivals_df = compute_arrivals(orders, lead=args.lead)
    sim = simulate_inventory(demand=demand, arrivals_total=arrivals_df["total_arrivals"].to_numpy(), I0=I0)

    # Costs
    costs = compute_costs(orders=orders, prices_df=prices, sim=sim, h=h, b=b)

    # Save plots & tables
    save_inventory_and_arrivals(args.outdir, arrivals_df, sim)
    save_and_plot_costs(args.outdir, costs)

    # Compute hedging fraction
    hedging_metrics = compute_hedging_fraction(orders, total_demand=demand.sum())

    # Console summary
    print("== Summary ==")
    print(f"Demand source  : {args.demand_xlsx} | sheet='{args.sheet}' | column='{args.demand_col}'")
    print(f"Price source   : {args.demand_xlsx} | sheet='{args.price_sheet}' | cols=['s1','s2']")
    print(f"Orders source  : {args.order}")
    print(f"Lead time      : {args.lead} months")
    print(f"I0 / h / b     : {I0:.0f} / {h:.2f} / {b:.2f}")
    print(f"T(demand)      : {len(demand)}")
    print(f"T(orders)      : {int(orders['placement'].max())} | T(arrivals): {len(arrivals_df)}")
    print(f"Final inventory: {sim['inventory'][-1]:.2f}")
    print(f"Cumulative costs @ end (proc_total / holding / backlog): "
          f"{costs['cum_proc_total'].iloc[-1]:.2f} / {costs['cum_hold_cost'].iloc[-1]:.2f} / {costs['cum_backlog_cost'].iloc[-1]:.2f}")
    
    print(f"\n== Hedging Fraction ==")
    print(f"Total demand         : {hedging_metrics['total_demand']:,.2f} units")
    print(f"Hedged orders (s1)   : {hedging_metrics['hedged_quantity']:,.2f} units")
    print(f"Unhedged orders (s2) : {hedging_metrics['unhedged_quantity']:,.2f} units")
    print(f"Total orders         : {hedging_metrics['total_orders']:,.2f} units")
    print(f"Hedging fraction     : {hedging_metrics['hedging_fraction']:.2%} (hedged / total demand)")
    print(f"Hedging of orders    : {hedging_metrics['hedging_fraction_of_orders']:.2%} (hedged / total orders)")
    
    print(f"\nOutputs written to: {args.outdir.resolve()}")

if __name__ == "__main__":
    main()

"""
# === Example Commands ===

# From your repo folder:
cd /Users/debdeeppaul/Documents/Procurement/PIDSG26/demanddro

# Run with defaults (reads demand+prices from Excel, orders from Order.csv, lead=3, I0/h/b from McCormick.py if present):
python inventory_from_orders.py

# Override holding/backlog costs or I0 if needed:
python inventory_from_orders.py --h 6 --b 40 --I0 12000

# Save to a custom output dir:
python inventory_from_orders.py --outdir results_inventory

# Help:
python inventory_from_orders.py -h
"""
